export class CreateInventoryReportDto {}
