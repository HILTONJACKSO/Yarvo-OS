export class InventoryReport {}
