export class CreateBiDto {}
