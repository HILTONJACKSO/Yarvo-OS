export class ChargeTransfer {}
