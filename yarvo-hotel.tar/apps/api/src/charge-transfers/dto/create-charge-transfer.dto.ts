export class CreateChargeTransferDto {}
