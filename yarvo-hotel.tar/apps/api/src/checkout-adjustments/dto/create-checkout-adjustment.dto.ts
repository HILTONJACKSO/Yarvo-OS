export class CreateCheckoutAdjustmentDto {}
