export class CheckoutAdjustment {}
