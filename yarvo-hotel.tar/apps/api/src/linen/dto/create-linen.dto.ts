export class CreateLinenDto {}
