export class CreateInventoryDto {}
