export class CorporateReceivable {}
