export class CreateCorporateReceivableDto {}
