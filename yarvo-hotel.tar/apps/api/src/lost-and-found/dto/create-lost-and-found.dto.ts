export class CreateLostAndFoundDto {}
