export class CreateCashierShiftDto {}
