export class CashierShift {}
