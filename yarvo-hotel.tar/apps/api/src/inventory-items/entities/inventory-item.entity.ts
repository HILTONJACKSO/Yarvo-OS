export class InventoryItem {}
