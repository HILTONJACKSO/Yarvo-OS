export class CreateInventoryItemDto {}
