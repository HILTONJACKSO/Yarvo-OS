export class CreateDepartmentIssueDto {}
