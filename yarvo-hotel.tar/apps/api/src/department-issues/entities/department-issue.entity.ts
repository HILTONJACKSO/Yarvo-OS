export class DepartmentIssue {}
