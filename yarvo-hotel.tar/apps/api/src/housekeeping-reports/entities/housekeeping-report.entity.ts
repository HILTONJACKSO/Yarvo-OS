export class HousekeepingReport {}
