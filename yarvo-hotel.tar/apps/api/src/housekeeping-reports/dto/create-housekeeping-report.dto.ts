export class CreateHousekeepingReportDto {}
