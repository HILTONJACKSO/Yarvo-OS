export class CreateHousekeepingDto {}
