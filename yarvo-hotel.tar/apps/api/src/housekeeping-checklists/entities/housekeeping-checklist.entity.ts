export class HousekeepingChecklist {}
