export class CreateHousekeepingChecklistDto {}
