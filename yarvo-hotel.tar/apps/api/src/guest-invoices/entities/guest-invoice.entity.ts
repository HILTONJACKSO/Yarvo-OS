export class GuestInvoice {}
