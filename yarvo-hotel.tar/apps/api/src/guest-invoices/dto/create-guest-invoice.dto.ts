export class CreateGuestInvoiceDto {}
