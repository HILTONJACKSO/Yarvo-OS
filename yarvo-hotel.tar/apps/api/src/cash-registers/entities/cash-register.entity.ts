export class CashRegister {}
