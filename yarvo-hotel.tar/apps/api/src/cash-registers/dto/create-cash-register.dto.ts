export class CreateCashRegisterDto {}
