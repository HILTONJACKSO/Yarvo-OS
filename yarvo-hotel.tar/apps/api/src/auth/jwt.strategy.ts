import { ExtractJwt, Strategy } from 'passport-jwt';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private prisma: PrismaService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET || 'fallback_secret_for_dev',
    });
  }

  async validate(payload: any) {
    const user = await this.prisma.user.findUnique({ 
      where: { id: payload.sub },
      include: { businesses: true }
    });
    if (!user) {
      throw new UnauthorizedException();
    }
    return { 
      userId: payload.sub, 
      email: payload.email,
      businessId: user.businesses[0]?.businessId
    };
  }
}
