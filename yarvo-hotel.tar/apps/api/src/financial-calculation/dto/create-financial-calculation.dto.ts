export class CreateFinancialCalculationDto {}
