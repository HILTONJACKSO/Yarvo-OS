export class FinancialCalculation {}
