export class CreateCashMovementDto {}
