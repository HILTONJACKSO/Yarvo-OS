export class CashMovement {}
