export class CreateDashboardDto {}
