export class GuestFeedback {}
