export class CreateGuestFeedbackDto {}
