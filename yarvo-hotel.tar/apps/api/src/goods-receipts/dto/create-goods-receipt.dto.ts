export class CreateGoodsReceiptDto {}
