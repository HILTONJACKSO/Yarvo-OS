export class GoodsReceipt {}
