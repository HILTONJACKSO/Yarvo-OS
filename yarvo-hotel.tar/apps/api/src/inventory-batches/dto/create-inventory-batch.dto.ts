export class CreateInventoryBatchDto {}
