export class InventoryBatch {}
