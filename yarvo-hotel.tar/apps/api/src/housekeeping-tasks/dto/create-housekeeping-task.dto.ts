export class CreateHousekeepingTaskDto {}
