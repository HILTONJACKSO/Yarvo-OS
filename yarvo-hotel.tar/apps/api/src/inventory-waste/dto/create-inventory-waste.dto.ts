export class CreateInventoryWasteDto {}
