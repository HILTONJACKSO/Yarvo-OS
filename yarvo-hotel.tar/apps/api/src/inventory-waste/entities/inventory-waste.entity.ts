export class InventoryWaste {}
