export class InventoryConsumption {}
