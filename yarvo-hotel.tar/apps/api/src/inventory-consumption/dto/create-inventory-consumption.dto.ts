export class CreateInventoryConsumptionDto {}
