"use client";

import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import Link from 'next/link';
import { 
  Search, Plus, Filter, MoreHorizontal, FileEdit, Trash2, 
  Eye, Tag, ArrowUpDown, Box
} from 'lucide-react';

export default function CatalogItemsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/catalog-items`);
        if (res.ok) {
          setItems(await res.json());
        }
      } catch (error) {
        console.error('Failed to fetch items', error);
      } finally {
        setLoading(false);
      }
    };

    fetchItems();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('catalogItem.updated', fetchItems);

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this item?')) return;
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/catalog-items/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        setItems(items.filter(item => item.id !== id));
      } else {
        console.error('Failed to delete item');
      }
    } catch (error) {
      console.error('Error deleting item', error);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-400">Loading catalog items...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Products & Services</h2>
          <p className="text-slate-400">Manage your entire catalog of sellable items.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-slate-950 border border-slate-800 text-slate-300 rounded-md hover:bg-slate-900 transition-colors shadow-sm font-medium">
            Export CSV
          </button>
          <Link href="/dashboard/catalog/items/new" className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
            <Plus size={16} /> Add Product
          </Link>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col md:flex-row gap-4 bg-slate-950 p-4 rounded-xl shadow-sm border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by name, code, or category..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
          />
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <select className="w-full sm:w-auto px-4 py-2 rounded-lg border border-slate-800 bg-slate-950 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary">
            <option value="all">All Types</option>
            <option value="food">Food</option>
            <option value="beverage">Beverage</option>
            <option value="service">Service</option>
            <option value="package">Package</option>
          </select>
          <select className="w-full sm:w-auto px-4 py-2 rounded-lg border border-slate-800 bg-slate-950 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary">
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="draft">Draft</option>
            <option value="inactive">Inactive</option>
          </select>
          <button className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-slate-900 border border-slate-800 text-slate-300 rounded-lg hover:bg-slate-800 transition-colors shrink-0">
            <Filter size={16} /> More Filters
          </button>
        </div>
      </div>

      {/* Items Table */}
      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900 border-b text-sm text-slate-400">
                <th className="p-4 font-medium"><div className="flex items-center gap-1 cursor-pointer hover:text-slate-50">Item <ArrowUpDown size={14} /></div></th>
                <th className="p-4 font-medium">Code</th>
                <th className="p-4 font-medium">Category</th>
                <th className="p-4 font-medium">Base Price</th>
                <th className="p-4 font-medium">Availability</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {items.map(item => (
                <tr key={item.id} className="hover:bg-slate-900/50 transition-colors group">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-slate-800 border overflow-hidden shrink-0">
                        {item.imageUrl ? (
                          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                        ) : (
                          <Box className="w-5 h-5 text-gray-400 m-auto mt-2.5" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium text-slate-50">{item.name}</div>
                        <div className="text-xs text-slate-400">{item.itemType}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-sm text-slate-400 font-mono">{item.code}</td>
                  <td className="p-4">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-800 text-slate-300 text-xs font-medium">
                      <Tag size={12} /> {item.category?.name || 'Uncategorized'}
                    </span>
                  </td>
                  <td className="p-4 font-medium text-slate-50">${(item.basePrice || 0).toFixed(2)}</td>
                  <td className="p-4">
                    <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                      item.availabilityStatus === 'AVAILABLE' ? 'bg-emerald-500/10 text-emerald-400' : 
                      item.availabilityStatus === 'SOLD_OUT' ? 'bg-red-500/10 text-red-400' : 
                      'bg-slate-800 text-slate-200'
                    }`}>
                      {item.availabilityStatus}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                      item.status === 'ACTIVE' ? 'bg-blue-500/10 text-blue-400' : 'bg-slate-800 text-slate-200'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => alert('Editing items is coming soon!')} className="p-1.5 text-slate-400 hover:text-brand-primary hover:bg-brand-primary/10 rounded-md transition-colors">
                        <FileEdit size={16} />
                      </button>
                      <button onClick={() => handleDelete(item.id)} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {items.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No items found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="p-4 border-t flex items-center justify-between bg-slate-900">
          <span className="text-sm text-slate-400">Showing {items.length} of 186 items</span>
          <div className="flex gap-1">
            <button className="px-3 py-1 text-sm border bg-slate-950 rounded hover:bg-slate-900 disabled:opacity-50">Prev</button>
            <button className="px-3 py-1 text-sm border bg-brand-primary text-white rounded">1</button>
            <button className="px-3 py-1 text-sm border bg-slate-950 rounded hover:bg-slate-900">2</button>
            <button className="px-3 py-1 text-sm border bg-slate-950 rounded hover:bg-slate-900">3</button>
            <button className="px-3 py-1 text-sm border bg-slate-950 rounded hover:bg-slate-900 disabled:opacity-50">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}
