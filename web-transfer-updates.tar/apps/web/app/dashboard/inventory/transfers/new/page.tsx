"use client";

import { useState } from 'react';
import { Search, Save, Send, Trash2, ArrowRight } from 'lucide-react';
import Link from 'next/link';

export default function NewStockTransferPage() {
  const [items, setItems] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/inventory/locations`);
        if (response.ok) {
          const data = await response.json();
          setLocations(data);
        }
      } catch (error) {
        console.error('Failed to fetch locations:', error);
      }
    };
    fetchLocations();
  }, []);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">New Stock Transfer</h1>
          <p className="text-slate-400 mt-1">Move inventory items from one location to another.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Source Location <span className="text-red-500">*</span></label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option value="">Select source...</option>
                {locations.map(loc => (
                  <option key={loc.id} value={loc.id}>{loc.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Destination Location <span className="text-red-500">*</span></label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option value="">Select destination...</option>
                {locations.map(loc => (
                  <option key={loc.id} value={loc.id}>{loc.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Expected Transfer Date</label>
              <input type="date" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Requested By</label>
              <input type="text" defaultValue="Current User" disabled className="w-full px-4 py-2 border rounded-md bg-slate-900 text-slate-400" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-1">Notes</label>
              <textarea rows={2} placeholder="Reason for transfer..." className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50"></textarea>
            </div>
          </div>
        </div>

        <div className="border-t">
          <div className="p-4 bg-slate-900 border-b flex justify-between items-center">
            <h3 className="font-bold text-slate-50">Transfer Items</h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search to add item..." 
                className="w-full pl-9 pr-4 py-1.5 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
              />
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Item</th>
                <th className="p-4 font-semibold text-center">Source Available</th>
                <th className="p-4 font-semibold text-center w-32">Transfer Qty</th>
                <th className="p-4 font-semibold">Unit</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {items.map((item) => (
                <tr key={item.id} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4 text-center text-slate-400">{item.available} {item.unit}</td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      defaultValue={item.requested} 
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-center"
                    />
                  </td>
                  <td className="p-4 text-slate-400">{item.unit}</td>
                  <td className="p-4 text-right">
                    <button className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={18}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {items.length === 0 && (
            <div className="p-8 text-center text-slate-400">
              No items added to this transfer yet.
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between">
          <Link href="/dashboard/inventory/movements" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          <div className="flex gap-2">
            <button className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2">
              <Save size={18} /> Save as Draft
            </button>
            <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
              <Send size={18} /> Submit Request
            </button>
            <div className="w-px h-8 bg-gray-300 mx-2 self-center"></div>
            <button className="px-4 py-2 bg-green-600 text-white rounded-md font-medium hover:bg-green-700 transition flex items-center gap-2">
              <ArrowRight size={18} /> Direct Transfer (Issue & Receive)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
