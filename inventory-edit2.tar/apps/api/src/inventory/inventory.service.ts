import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { AppWebsocketGateway } from '../websocket/app-websocket.gateway';
import { CreateInventoryDto } from './dto/create-inventory.dto';
import { UpdateInventoryDto } from './dto/update-inventory.dto';

@Injectable()
export class InventoryService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly wsGateway: AppWebsocketGateway,
  ) {}

  async getDashboardStats() {
    const totalValueResult = await this.prisma.stockBalance.aggregate({
      _sum: {
        stockValue: true,
      },
    });

    const lowStockCount = await this.prisma.stockBalance.count({
      where: {
        quantityAvailable: { lte: 10, gt: 0 }
      }
    });

    const outOfStockCount = await this.prisma.stockBalance.count({
      where: { quantityAvailable: { lte: 0 } }
    });

    const openOrdersCount = await this.prisma.purchaseOrder.count({
      where: { status: 'OPEN' }
    });

    return {
      totalStockValue: totalValueResult._sum.stockValue || 0,
      lowStockItems: lowStockCount,
      outOfStock: outOfStockCount,
      openPurchaseOrders: openOrdersCount,
    };
  }

  async getItems() {
    return this.prisma.inventoryItem.findMany({
      orderBy: { name: 'asc' }
    });
  }

  async getStockLevels() {
    return this.prisma.stockBalance.findMany();
  }

  async getMovements() {
    return this.prisma.stockMovement.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getTransfers() {
    return this.prisma.stockTransfer.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getRecipes() {
    return this.prisma.recipe.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getCounts() {
    return this.prisma.stockCount.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getWaste() {
    return this.prisma.inventoryWaste.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getCategories() {
    return this.prisma.inventoryCategory.findMany();
  }

  async getUnits() {
    return this.prisma.unitOfMeasure.findMany();
  }

  async getLocations() {
    return this.prisma.stockLocation.findMany();
  }

  async create(businessId: string, data: CreateInventoryDto) {
    let categoryId = data.categoryId;

    if (categoryId.startsWith('ADD_NEW:')) {
      const categoryName = categoryId.split(':')[1];
      const newCategory = await this.prisma.inventoryCategory.create({
        data: {
          businessId,
          name: categoryName,
          code: categoryName.toUpperCase().replace(/\s+/g, '_').substring(0, 10),
          status: 'ACTIVE'
        }
      });
      categoryId = newCategory.id;
    }

    const item = await this.prisma.inventoryItem.create({
      data: {
        businessId,
        name: data.name,
        code: data.code,
        barcode: data.barcode,
        inventoryType: data.inventoryType,
        categoryId: categoryId,
        brand: data.brand,
        description: data.description,
        baseUnitId: data.baseUnitId,
        purchaseUnitId: data.purchaseUnitId,
        issueUnitId: data.issueUnitId,
        minimumStockLevel: data.minimumStockLevel,
        reorderLevel: data.reorderLevel,
        maximumStockLevel: data.maximumStockLevel,
        reorderQuantity: data.reorderQuantity,
        allowNegativeStock: data.allowNegativeStock || false,
        trackBatch: data.trackBatch || false,
        trackExpiry: data.trackExpiry || false,
        stockMethod: data.stockMethod || 'FIFO',
        initialUnitCost: data.initialUnitCost,
        standardCost: data.standardCost,
        preferredSupplierId: data.preferredSupplierId,
        currency: 'USD',
        status: 'ACTIVE'
      }
    });

    if (data.purchaseUnitId && data.purchaseConversionFactor && data.purchaseUnitId !== data.baseUnitId) {
      await this.prisma.inventoryUnitConversion.create({
        data: {
          inventoryItemId: item.id,
          fromUnitId: data.purchaseUnitId,
          toUnitId: data.baseUnitId,
          conversionFactor: data.purchaseConversionFactor
        }
      });
    }

    return item;
  }

  findAll() {
    return `This action returns all inventory`;
  }

  async findOne(id: string) {
    return this.prisma.inventoryItem.findUnique({
      where: { id }
    });
  }

  async update(id: string, data: UpdateInventoryDto, businessId: string = 'bus-kwalee-1') {
    let finalCategoryId = data.categoryId;

    if (finalCategoryId?.startsWith('ADD_NEW:')) {
      const newCategoryName = finalCategoryId.split(':')[1];
      const newCategory = await this.prisma.inventoryCategory.create({
        data: {
          businessId,
          name: newCategoryName,
          code: `CAT-${Date.now()}`,
          status: 'ACTIVE'
        }
      });
      finalCategoryId = newCategory.id;
    }

    const item = await this.prisma.inventoryItem.update({
      where: { id },
      data: {
        ...(data.name && { name: data.name }),
        ...(data.code && { code: data.code }),
        ...(data.barcode !== undefined && { barcode: data.barcode }),
        ...(data.inventoryType && { inventoryType: data.inventoryType }),
        ...(finalCategoryId && { categoryId: finalCategoryId }),
        ...(data.brand !== undefined && { brand: data.brand }),
        ...(data.description !== undefined && { description: data.description }),
        ...(data.baseUnitId && { baseUnitId: data.baseUnitId }),
        ...(data.purchaseUnitId !== undefined && { purchaseUnitId: data.purchaseUnitId }),
        ...(data.issueUnitId !== undefined && { issueUnitId: data.issueUnitId }),
        ...(data.minimumStockLevel !== undefined && { minimumStockLevel: data.minimumStockLevel }),
        ...(data.reorderLevel !== undefined && { reorderLevel: data.reorderLevel }),
        ...(data.maximumStockLevel !== undefined && { maximumStockLevel: data.maximumStockLevel }),
        ...(data.reorderQuantity !== undefined && { reorderQuantity: data.reorderQuantity }),
        ...(data.allowNegativeStock !== undefined && { allowNegativeStock: data.allowNegativeStock }),
        ...(data.trackBatch !== undefined && { trackBatch: data.trackBatch }),
        ...(data.trackExpiry !== undefined && { trackExpiry: data.trackExpiry }),
        ...(data.stockMethod && { stockMethod: data.stockMethod }),
        ...(data.initialUnitCost !== undefined && { initialUnitCost: data.initialUnitCost }),
        ...(data.standardCost !== undefined && { standardCost: data.standardCost }),
        ...(data.preferredSupplierId !== undefined && { preferredSupplierId: data.preferredSupplierId }),
        ...(data.status && { status: data.status })
      }
    });

    if (data.purchaseUnitId && data.purchaseConversionFactor) {
      // Very naive implementation: just find first and update, or create
      const existingConv = await this.prisma.inventoryUnitConversion.findFirst({
        where: { inventoryItemId: id, fromUnitId: data.purchaseUnitId }
      });
      if (existingConv) {
        await this.prisma.inventoryUnitConversion.update({
          where: { id: existingConv.id },
          data: { conversionFactor: data.purchaseConversionFactor }
        });
      } else {
        await this.prisma.inventoryUnitConversion.create({
          data: {
            inventoryItemId: id,
            fromUnitId: data.purchaseUnitId,
            toUnitId: data.baseUnitId!,
            conversionFactor: data.purchaseConversionFactor
          }
        });
      }
    }

    return item;
  }

  async remove(id: string) {
    return this.prisma.inventoryItem.delete({
      where: { id }
    });
  }
}
