"use client";

import { useState } from 'react';
import { ChevronRight, Save, X, Info, Box, Layers, Tag, DollarSign, Link as LinkIcon } from 'lucide-react';
import Link from 'next/link';

export default function NewInventoryItemPage() {
  const [step, setStep] = useState(1);
  const totalSteps = 5;

  const [customTypeMode, setCustomTypeMode] = useState(false);
  const [customCategoryMode, setCustomCategoryMode] = useState(false);

  const renderStepIndicators = () => {
    return (
      <div className="flex items-center mb-8 bg-slate-950 p-4 rounded-xl border shadow-sm overflow-x-auto">
        {[
          { num: 1, label: 'Basic Info', icon: <Info size={16} /> },
          { num: 2, label: 'Units', icon: <Box size={16} /> },
          { num: 3, label: 'Stock Control', icon: <Layers size={16} /> },
          { num: 4, label: 'Costing', icon: <DollarSign size={16} /> },
          { num: 5, label: 'Connections', icon: <LinkIcon size={16} /> },
        ].map((s, idx) => (
          <div key={s.num} className="flex items-center">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg font-medium text-sm transition-colors ${step === s.num ? 'bg-brand-primary text-white' : step > s.num ? 'text-brand-primary bg-blue-50' : 'text-slate-400'}`}>
              {s.icon}
              <span className="whitespace-nowrap">{s.label}</span>
            </div>
            {idx < 4 && <ChevronRight size={16} className="mx-2 text-gray-300" />}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/items" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Items</Link>
          <h1 className="text-2xl font-bold text-slate-50">Add Stock Item</h1>
          <p className="text-slate-400 mt-1">Create a new physical inventory or supply record.</p>
        </div>
      </div>

      {renderStepIndicators()}

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Basic Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Item Name <span className="text-red-500">*</span></label>
                  <input type="text" placeholder="e.g., Club Beer (Large)" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Stock Code <span className="text-red-500">*</span></label>
                  <input type="text" placeholder="e.g., B-CLUB-L" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Inventory Type <span className="text-red-500">*</span></label>
                  {customTypeMode ? (
                    <div className="flex items-center gap-2">
                      <input type="text" placeholder="e.g., CUSTOM_TYPE" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100" autoFocus />
                      <button onClick={() => setCustomTypeMode(false)} className="text-slate-400 hover:text-red-500"><X size={20}/></button>
                    </div>
                  ) : (
                    <select 
                      className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100"
                      onChange={(e) => e.target.value === 'ADD_NEW' && setCustomTypeMode(true)}
                    >
                      <option value="INGREDIENT">INGREDIENT</option>
                      <option value="FINISHED_GOOD">FINISHED_GOOD</option>
                      <option value="BEVERAGE">BEVERAGE</option>
                      <option value="ALCOHOL">ALCOHOL</option>
                      <option value="LINEN">LINEN</option>
                      <option value="HOUSEKEEPING_SUPPLY">HOUSEKEEPING_SUPPLY</option>
                      <option value="ADD_NEW" className="text-brand-primary font-bold">+ Create Custom Type...</option>
                    </select>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Category <span className="text-red-500">*</span></label>
                  {customCategoryMode ? (
                    <div className="flex items-center gap-2">
                      <input type="text" placeholder="e.g., Electronics" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100" autoFocus />
                      <button onClick={() => setCustomCategoryMode(false)} className="text-slate-400 hover:text-red-500"><X size={20}/></button>
                    </div>
                  ) : (
                    <select 
                      className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100"
                      onChange={(e) => e.target.value === 'ADD_NEW' && setCustomCategoryMode(true)}
                    >
                      <option value="">Select Category...</option>
                      <option value="Beer">Beer</option>
                      <option value="Meat and Poultry">Meat and Poultry</option>
                      <option value="Linen">Linen</option>
                      <option value="ADD_NEW" className="text-brand-primary font-bold">+ Create New Category...</option>
                    </select>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Barcode (Optional)</label>
                  <input type="text" placeholder="Scan or type barcode" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Brand (Optional)</label>
                  <input type="text" placeholder="e.g., Club" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Description</label>
                  <textarea rows={3} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50"></textarea>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Units & Conversions</h2>
              <div className="bg-blue-50 p-4 rounded-lg flex gap-3 text-blue-400 text-sm mb-6">
                <Info size={20} className="shrink-0" />
                <p>The <strong>Base Unit</strong> is how this item is counted in your inventory reports (e.g., Bottle). The <strong>Purchase Unit</strong> is how you buy it from suppliers (e.g., Carton).</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Base Unit <span className="text-red-500">*</span></label>
                  <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option>Bottle (btl)</option>
                    <option>Kilogram (kg)</option>
                    <option>Piece (pc)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Issue Unit</label>
                  <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option>Same as Base Unit</option>
                    <option>Gram (g)</option>
                  </select>
                </div>
                
                <div className="md:col-span-2 border-t pt-4 mt-2">
                  <h3 className="font-medium text-slate-50 mb-4">Purchasing Conversion</h3>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Purchase Unit</label>
                  <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option>Carton (ctn)</option>
                    <option>Bag (bag)</option>
                    <option>Same as Base Unit</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Conversion Factor</label>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-400">1 Purchase Unit =</span>
                    <input type="number" placeholder="24" className="w-24 px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                    <span className="text-sm text-slate-400">Base Units</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Stock Control</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Minimum Stock Level</label>
                  <input type="number" placeholder="e.g., 48" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Maximum Stock Level</label>
                  <input type="number" placeholder="e.g., 200" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Reorder Level</label>
                  <input type="number" placeholder="e.g., 50" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Reorder Quantity</label>
                  <input type="number" placeholder="e.g., 100" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                
                <div className="md:col-span-2 border-t pt-4 mt-2">
                  <h3 className="font-medium text-slate-50 mb-4">Tracking & Method</h3>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Track Batch Numbers</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Track Expiry Dates (Requires FEFO dispatch)</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Allow Negative Stock</span>
                    </label>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Preferred Stock Method</label>
                  <select className="w-full md:w-1/2 px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option>FIFO (First In, First Out)</option>
                    <option>FEFO (First Expired, First Out)</option>
                    <option>AVERAGE_COST</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Costing</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Initial Cost per Base Unit</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                    <input type="number" placeholder="1.20" className="w-full pl-8 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Standard Cost (Optional)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                    <input type="number" placeholder="1.25" className="w-full pl-8 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                  </div>
                </div>
                <div className="md:col-span-2">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                    <span className="text-sm text-slate-300">Cost Includes Tax</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Connections & Usage</h2>
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Preferred Supplier</label>
                  <select className="w-full md:w-1/2 px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option>Select a supplier...</option>
                    <option>ABC Distributors</option>
                    <option>Fresh Farms Co.</option>
                  </select>
                </div>
                
                <div className="border-t pt-4 mt-2">
                  <h3 className="font-medium text-slate-50 mb-4">Operational Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Eligible as a Recipe Ingredient</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Direct Sale Item (Links to POS Catalog without recipe)</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Minibar Item</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Housekeeping Item (Linen / Supply)</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="p-4 border-t bg-slate-900 flex justify-between">
          {step > 1 ? (
            <button 
              onClick={() => setStep(step - 1)}
              className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium"
            >
              Back
            </button>
          ) : (
            <Link href="/dashboard/inventory/items" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          )}

          <div className="flex gap-2">
            {step < totalSteps ? (
              <button 
                onClick={() => setStep(step + 1)}
                className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition"
              >
                Next Step
              </button>
            ) : (
              <>
                <button className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Save as Draft</button>
                <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
                  <Save size={18} /> Save and Activate
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
