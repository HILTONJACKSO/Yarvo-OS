import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { AppWebsocketGateway } from '../websocket/app-websocket.gateway';
import { CreateInventoryDto } from './dto/create-inventory.dto';
import { UpdateInventoryDto } from './dto/update-inventory.dto';
import { CreateCountDto } from './dto/create-count.dto';
import { CreateLocationDto } from './dto/create-location.dto';
import { UpdateCountItemsDto } from './dto/update-count-items.dto';

@Injectable()
export class InventoryService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly wsGateway: AppWebsocketGateway,
  ) {}

  async getDashboardStats() {
    const totalValueResult = await this.prisma.stockBalance.aggregate({
      _sum: {
        stockValue: true,
      },
    });

    const lowStockCount = await this.prisma.stockBalance.count({
      where: {
        quantityAvailable: { lte: 10, gt: 0 }
      }
    });

    const outOfStockCount = await this.prisma.stockBalance.count({
      where: { quantityAvailable: { lte: 0 } }
    });

    const openOrdersCount = await this.prisma.purchaseOrder.count({
      where: { status: 'OPEN' }
    });

    return {
      totalStockValue: totalValueResult._sum.stockValue || 0,
      lowStockItems: lowStockCount,
      outOfStock: outOfStockCount,
      openPurchaseOrders: openOrdersCount,
    };
  }

  async getItems() {
    const items = await this.prisma.inventoryItem.findMany({
      orderBy: { name: 'asc' }
    });

    const balances = await this.prisma.stockBalance.groupBy({
      by: ['inventoryItemId'],
      _sum: {
        quantityAvailable: true
      }
    });

    const balanceMap = new Map(balances.map(b => [b.inventoryItemId, b._sum.quantityAvailable || 0]));

    return items.map(item => ({
      ...item,
      available: balanceMap.get(item.id) || 0
    }));
  }

  async getStockLevels() {
    const balances = await this.prisma.stockBalance.findMany();
    const items = await this.prisma.inventoryItem.findMany();
    const locations = await this.prisma.stockLocation.findMany();

    const itemMap = new Map(items.map(i => [i.id, i]));
    const locationMap = new Map(locations.map(l => [l.id, l]));

    return balances.map(b => {
      const item = itemMap.get(b.inventoryItemId);
      const location = locationMap.get(b.stockLocationId);
      
      let status = 'Healthy';
      const minLevel = item?.minimumStockLevel || 0;
      if (b.quantityAvailable <= 0) {
        status = 'Out of Stock';
      } else if (b.quantityAvailable <= minLevel) {
        status = 'Low';
      }

      return {
        id: b.id,
        item: item ? `${item.name} (${item.code})` : 'Unknown Item',
        location: location ? location.name : 'Unknown Location',
        onHand: b.quantityOnHand,
        reserved: b.quantityReserved,
        available: b.quantityAvailable,
        minimum: minLevel,
        status: status
      };
    });
  }

  async getMovements() {
    return this.prisma.stockMovement.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getTransfers() {
    return this.prisma.stockTransfer.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getRecipes() {
    return this.prisma.recipe.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getCounts() {
    const rawCounts = await this.prisma.stockCount.findMany({
      orderBy: { createdAt: 'desc' }
    });

    const result = [];
    for (const count of rawCounts) {
      const countLocations = await this.prisma.stockCountLocation.findMany({
        where: { stockCountId: count.id }
      });
      let locationNames = [];
      for (const cl of countLocations) {
        const loc = await this.prisma.stockLocation.findUnique({ where: { id: cl.stockLocationId } });
        if (loc) locationNames.push(loc.name);
      }
      const locationStr = locationNames.length > 0 ? locationNames.join(', ') : 'Global Count';

      const items = await this.prisma.stockCountItem.findMany({
        where: { stockCountId: count.id }
      });
      
      let totalVariance = null;
      let hasCompletedItems = false;
      for (const item of items) {
        if (item.varianceCost !== null) {
          if (totalVariance === null) totalVariance = 0;
          totalVariance += item.varianceCost;
          hasCompletedItems = true;
        }
      }

      result.push({
        id: count.id,
        number: count.countNumber,
        location: locationStr,
        date: count.startedAt ? count.startedAt.toISOString().split('T')[0] : (count.createdAt ? count.createdAt.toISOString().split('T')[0] : '-'),
        type: count.countType.replace('_', ' '),
        blind: count.blindCount,
        variance: totalVariance,
        status: count.status
      });
    }

    return result;
  }

  async getCountById(id: string) {
    const count = await this.prisma.stockCount.findUnique({ where: { id } });
    if (!count) throw new Error('Count not found');

    const countLocations = await this.prisma.stockCountLocation.findMany({ where: { stockCountId: count.id } });
    const locationNames = [];
    for (const cl of countLocations) {
      const loc = await this.prisma.stockLocation.findUnique({ where: { id: cl.stockLocationId } });
      if (loc) locationNames.push(loc.name);
    }

    const items = await this.prisma.stockCountItem.findMany({ where: { stockCountId: count.id } });
    const mappedItems = [];
    for (const item of items) {
      const inventoryItem = await this.prisma.inventoryItem.findUnique({ where: { id: item.inventoryItemId } });
      const unit = inventoryItem?.baseUnitId ? await this.prisma.unitOfMeasure.findUnique({ where: { id: inventoryItem.baseUnitId } }) : null;
      
      mappedItems.push({
        id: item.id, // the StockCountItem ID
        itemId: inventoryItem?.id,
        name: inventoryItem?.name || 'Unknown Item',
        code: inventoryItem?.code || '-',
        unit: unit?.code || 'unit',
        systemQuantity: item.systemQuantity,
        countedQuantity: item.countedQuantity,
        varianceQuantity: item.varianceQuantity,
        varianceCost: item.varianceCost,
        unitCost: item.unitCost
      });
    }

    return {
      ...count,
      locationStr: locationNames.length > 0 ? locationNames.join(', ') : 'Global Count',
      items: mappedItems
    };
  }

  async updateCountItems(id: string, data: UpdateCountItemsDto) {
    for (const itemUpdate of data.items) {
      // Find the StockCountItem record
      const countItem = await this.prisma.stockCountItem.findUnique({ where: { id: itemUpdate.itemId } });
      if (!countItem) continue;

      const varianceQty = itemUpdate.countedQuantity - (countItem.systemQuantity || 0);
      const varianceCost = varianceQty * (countItem.unitCost || 0);

      await this.prisma.stockCountItem.update({
        where: { id: countItem.id },
        data: {
          countedQuantity: itemUpdate.countedQuantity,
          varianceQuantity: varianceQty,
          varianceCost: varianceCost,
          countedAt: new Date(),
          countedByUserId: 'user-1'
        }
      });
    }

    return this.getCountById(id);
  }

  async completeCount(id: string) {
    const count = await this.prisma.stockCount.findUnique({
      where: { id }
    });

    if (!count) throw new Error('Count not found');
    if (count.status === 'COMPLETED') throw new Error('Count is already completed');

    const items = await this.prisma.stockCountItem.findMany({
      where: { stockCountId: count.id }
    });

    for (const item of items) {
      if (item.countedQuantity === null || item.countedQuantity === undefined) {
        continue;
      }

      // Find existing StockBalance
      const existingBalance = await this.prisma.stockBalance.findFirst({
        where: {
          inventoryItemId: item.inventoryItemId,
          stockLocationId: item.stockLocationId
        }
      });

      let newQuantityAvailable = item.countedQuantity;
      if (existingBalance) {
        newQuantityAvailable = item.countedQuantity - existingBalance.quantityReserved;
        
        await this.prisma.stockBalance.update({
          where: { id: existingBalance.id },
          data: {
            quantityOnHand: item.countedQuantity,
            quantityAvailable: newQuantityAvailable
          }
        });
      } else {
        await this.prisma.stockBalance.create({
          data: {
            businessId: count.businessId,
            branchId: count.branchId,
            inventoryItemId: item.inventoryItemId,
            stockLocationId: item.stockLocationId,
            quantityOnHand: item.countedQuantity,
            quantityReserved: 0,
            quantityAvailable: item.countedQuantity
          }
        });
      }

      const varianceQty = item.varianceQuantity || 0;
      if (varianceQty !== 0) {
        const itemInfo = await this.prisma.inventoryItem.findUnique({ where: { id: item.inventoryItemId } });
        
        await this.prisma.stockMovement.create({
          data: {
            businessId: count.businessId,
            branchId: count.branchId,
            movementNumber: `MOV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
            inventoryItemId: item.inventoryItemId,
            movementType: 'ADJUSTMENT',
            fromLocationId: varianceQty < 0 ? item.stockLocationId : null,
            toLocationId: varianceQty > 0 ? item.stockLocationId : null,
            quantity: Math.abs(varianceQty),
            unitId: itemInfo?.baseUnitId || '',
            baseQuantity: Math.abs(varianceQty),
            referenceType: 'STOCK_COUNT',
            referenceId: count.id,
            reason: 'Stock Count Variance',
            status: 'COMPLETED',
            createdByUserId: count.createdByUserId
          }
        });
      }
    }

    const updatedCount = await this.prisma.stockCount.update({
      where: { id },
      data: {
        status: 'COMPLETED',
        submittedAt: new Date(),
        approvedByUserId: count.createdByUserId
      }
    });

    return updatedCount;
  }

  async createCount(businessId: string, data: CreateCountDto) {
    const countNumber = `CNT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newCount = await this.prisma.stockCount.create({
      data: {
        businessId,
        branchId: 'branch-1',
        countNumber,
        name: data.name,
        countType: data.countType,
        status: 'IN_PROGRESS',
        startedAt: new Date(),
        createdByUserId: 'user-1',
        blindCount: data.blindCount || false,
        freezeMovements: data.freezeMovements || false,
        notes: data.notes
      }
    });

    if (data.locationIds && data.locationIds.length > 0) {
      for (const locId of data.locationIds) {
        await this.prisma.stockCountLocation.create({
          data: {
            stockCountId: newCount.id,
            stockLocationId: locId
          }
        });

        // For simplicity, find all ACTIVE inventory items and add them to the count for this location
        const allItems = await this.prisma.inventoryItem.findMany({
          where: { businessId, status: 'ACTIVE' }
        });

        for (const item of allItems) {
          // Check if there is an existing balance
          const balance = await this.prisma.stockBalance.findFirst({
            where: {
              inventoryItemId: item.id,
              stockLocationId: locId
            }
          });

          await this.prisma.stockCountItem.create({
            data: {
              stockCountId: newCount.id,
              inventoryItemId: item.id,
              stockLocationId: locId,
              systemQuantity: balance ? balance.quantityAvailable : 0,
              unitCost: balance ? balance.averageUnitCost : item.initialUnitCost || 0
            }
          });
        }
      }
    }

    return newCount;
  }

  async getWaste() {
    return this.prisma.inventoryWaste.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getCategories() {
    return this.prisma.inventoryCategory.findMany();
  }

  async getUnits() {
    return this.prisma.unitOfMeasure.findMany();
  }

  async getLocations() {
    return this.prisma.stockLocation.findMany();
  }

  async createLocation(businessId: string, data: CreateLocationDto) {
    return this.prisma.stockLocation.create({
      data: {
        businessId,
        branchId: 'branch-1',
        name: data.name,
        code: data.code,
        locationType: data.locationType,
        allowsReceiving: data.allowsReceiving !== false,
        allowsIssuing: data.allowsIssuing !== false,
        allowsSalesDeduction: data.allowsSalesDeduction || false,
        status: data.status || 'ACTIVE'
      }
    });
  }

  async create(businessId: string, data: CreateInventoryDto) {
    let categoryId = data.categoryId;

    if (categoryId.startsWith('ADD_NEW:')) {
      const categoryName = categoryId.split(':')[1];
      const newCategory = await this.prisma.inventoryCategory.create({
        data: {
          businessId,
          name: categoryName,
          code: categoryName.toUpperCase().replace(/\s+/g, '_').substring(0, 10),
          status: 'ACTIVE'
        }
      });
      categoryId = newCategory.id;
    }

    const item = await this.prisma.inventoryItem.create({
      data: {
        businessId,
        name: data.name,
        code: data.code,
        barcode: data.barcode,
        inventoryType: data.inventoryType,
        categoryId: categoryId,
        brand: data.brand,
        description: data.description,
        baseUnitId: data.baseUnitId,
        purchaseUnitId: data.purchaseUnitId,
        issueUnitId: data.issueUnitId,
        minimumStockLevel: data.minimumStockLevel,
        reorderLevel: data.reorderLevel,
        maximumStockLevel: data.maximumStockLevel,
        reorderQuantity: data.reorderQuantity,
        allowNegativeStock: data.allowNegativeStock || false,
        trackBatch: data.trackBatch || false,
        trackExpiry: data.trackExpiry || false,
        stockMethod: data.stockMethod || 'FIFO',
        initialUnitCost: data.initialUnitCost,
        standardCost: data.standardCost,
        preferredSupplierId: data.preferredSupplierId,
        currency: 'USD',
        status: 'ACTIVE'
      }
    });

    if (data.purchaseUnitId && data.purchaseConversionFactor && data.purchaseUnitId !== data.baseUnitId) {
      await this.prisma.inventoryUnitConversion.create({
        data: {
          inventoryItemId: item.id,
          fromUnitId: data.purchaseUnitId,
          toUnitId: data.baseUnitId,
          conversionFactor: data.purchaseConversionFactor
        }
      });
    }

    return item;
  }

  findAll() {
    return `This action returns all inventory`;
  }

  async findOne(id: string) {
    return this.prisma.inventoryItem.findUnique({
      where: { id }
    });
  }

  async update(id: string, data: UpdateInventoryDto, businessId: string = 'bus-kwalee-1') {
    let finalCategoryId = data.categoryId;

    if (finalCategoryId?.startsWith('ADD_NEW:')) {
      const newCategoryName = finalCategoryId.split(':')[1];
      const newCategory = await this.prisma.inventoryCategory.create({
        data: {
          businessId,
          name: newCategoryName,
          code: `CAT-${Date.now()}`,
          status: 'ACTIVE'
        }
      });
      finalCategoryId = newCategory.id;
    }

    const item = await this.prisma.inventoryItem.update({
      where: { id },
      data: {
        ...(data.name && { name: data.name }),
        ...(data.code && { code: data.code }),
        ...(data.barcode !== undefined && { barcode: data.barcode }),
        ...(data.inventoryType && { inventoryType: data.inventoryType }),
        ...(finalCategoryId && { categoryId: finalCategoryId }),
        ...(data.brand !== undefined && { brand: data.brand }),
        ...(data.description !== undefined && { description: data.description }),
        ...(data.baseUnitId && { baseUnitId: data.baseUnitId }),
        ...(data.purchaseUnitId !== undefined && { purchaseUnitId: data.purchaseUnitId }),
        ...(data.issueUnitId !== undefined && { issueUnitId: data.issueUnitId }),
        ...(data.minimumStockLevel !== undefined && { minimumStockLevel: data.minimumStockLevel }),
        ...(data.reorderLevel !== undefined && { reorderLevel: data.reorderLevel }),
        ...(data.maximumStockLevel !== undefined && { maximumStockLevel: data.maximumStockLevel }),
        ...(data.reorderQuantity !== undefined && { reorderQuantity: data.reorderQuantity }),
        ...(data.allowNegativeStock !== undefined && { allowNegativeStock: data.allowNegativeStock }),
        ...(data.trackBatch !== undefined && { trackBatch: data.trackBatch }),
        ...(data.trackExpiry !== undefined && { trackExpiry: data.trackExpiry }),
        ...(data.stockMethod && { stockMethod: data.stockMethod }),
        ...(data.initialUnitCost !== undefined && { initialUnitCost: data.initialUnitCost }),
        ...(data.standardCost !== undefined && { standardCost: data.standardCost }),
        ...(data.preferredSupplierId !== undefined && { preferredSupplierId: data.preferredSupplierId }),
        ...(data.status && { status: data.status })
      }
    });

    if (data.purchaseUnitId && data.purchaseConversionFactor) {
      // Very naive implementation: just find first and update, or create
      const existingConv = await this.prisma.inventoryUnitConversion.findFirst({
        where: { inventoryItemId: id, fromUnitId: data.purchaseUnitId }
      });
      if (existingConv) {
        await this.prisma.inventoryUnitConversion.update({
          where: { id: existingConv.id },
          data: { conversionFactor: data.purchaseConversionFactor }
        });
      } else {
        await this.prisma.inventoryUnitConversion.create({
          data: {
            inventoryItemId: id,
            fromUnitId: data.purchaseUnitId,
            toUnitId: data.baseUnitId!,
            conversionFactor: data.purchaseConversionFactor
          }
        });
      }
    }

    return item;
  }

  async remove(id: string) {
    return this.prisma.inventoryItem.delete({
      where: { id }
    });
  }
}
