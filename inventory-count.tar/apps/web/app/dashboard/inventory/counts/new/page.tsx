"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Play, Save, CheckSquare, Square, EyeOff, Lock, Info, Loader2 } from 'lucide-react';

export default function NewStockCountPage() {
  const router = useRouter();
  const [isSaving, setIsSaving] = useState(false);
  const [locations, setLocations] = useState<any[]>([]);
  const [isLoadingLocations, setIsLoadingLocations] = useState(true);

  const [formData, setFormData] = useState({
    name: `Inventory Count ${new Date().toLocaleDateString()}`,
    countType: 'FULL',
    locationIds: [] as string[],
    blindCount: false,
    freezeMovements: false,
    notes: ''
  });

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/locations`, {
          headers: { 'x-business-id': 'bus-kwalee-1' }
        });
        if (res.ok) {
          const data = await res.json();
          setLocations(data);
        }
      } catch (err) {
        console.error('Error fetching locations', err);
      } finally {
        setIsLoadingLocations(false);
      }
    };
    fetchLocations();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const toggleLocation = (id: string) => {
    setFormData(prev => {
      const selected = prev.locationIds.includes(id);
      return {
        ...prev,
        locationIds: selected ? prev.locationIds.filter(l => l !== id) : [...prev.locationIds, id]
      };
    });
  };

  const handleCreate = async () => {
    if (formData.locationIds.length === 0) {
      alert("Please select at least one location to count.");
      return;
    }

    setIsSaving(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/counts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-business-id': 'bus-kwalee-1'
        },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        router.push('/dashboard/inventory/counts');
      } else {
        alert("Failed to create stock count.");
      }
    } catch (err) {
      console.error(err);
      alert("Error saving count");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/counts" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Counts</Link>
          <h1 className="text-2xl font-bold text-slate-50">Initiate Stock Count</h1>
          <p className="text-slate-400 mt-1">Configure your physical inventory count sheet.</p>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-6 space-y-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Count Name / Reference <span className="text-red-500">*</span></label>
              <input type="text" name="name" value={formData.name} onChange={handleChange} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Count Type <span className="text-red-500">*</span></label>
              <select name="countType" value={formData.countType} onChange={handleChange} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                <option value="FULL">Full Inventory Count</option>
                <option value="CYCLE">Cycle Count (Partial)</option>
                <option value="SPOT">Spot Check</option>
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-1">Notes / Instructions</label>
              <textarea name="notes" value={formData.notes} onChange={handleChange} rows={2} placeholder="Optional instructions for the counters..." className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50"></textarea>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-bold text-slate-50 mb-4">Locations to Count <span className="text-red-500">*</span></h3>
            
            {isLoadingLocations ? (
              <div className="flex items-center gap-2 text-slate-400">
                <Loader2 size={16} className="animate-spin" /> Loading locations...
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {locations.map(loc => {
                  const isSelected = formData.locationIds.includes(loc.id);
                  return (
                    <div 
                      key={loc.id} 
                      onClick={() => toggleLocation(loc.id)}
                      className={`cursor-pointer p-4 border rounded-lg flex items-start gap-3 transition-colors ${isSelected ? 'bg-brand-primary/10 border-brand-primary' : 'bg-slate-900 border-slate-700 hover:border-slate-500'}`}
                    >
                      <div className="mt-0.5">
                        {isSelected ? <CheckSquare size={18} className="text-brand-primary" /> : <Square size={18} className="text-slate-500" />}
                      </div>
                      <div>
                        <div className={`font-medium ${isSelected ? 'text-brand-primary' : 'text-slate-200'}`}>{loc.name}</div>
                        <div className="text-xs text-slate-400 mt-1">{loc.type?.replace('_', ' ')}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-bold text-slate-50 mb-4">Count Settings</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-start gap-3 p-4 border border-slate-700 rounded-lg cursor-pointer hover:bg-slate-900 transition-colors">
                <input type="checkbox" name="blindCount" checked={formData.blindCount} onChange={handleChange} className="mt-1 w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                <div>
                  <div className="font-medium text-slate-200 flex items-center gap-2"><EyeOff size={16} className="text-slate-400"/> Blind Count</div>
                  <div className="text-sm text-slate-400 mt-1">Counters will not see the expected system quantities on their sheets. They must count entirely from scratch.</div>
                </div>
              </label>
              
              <label className="flex items-start gap-3 p-4 border border-slate-700 rounded-lg cursor-pointer hover:bg-slate-900 transition-colors">
                <input type="checkbox" name="freezeMovements" checked={formData.freezeMovements} onChange={handleChange} className="mt-1 w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                <div>
                  <div className="font-medium text-slate-200 flex items-center gap-2"><Lock size={16} className="text-slate-400"/> Freeze Movements</div>
                  <div className="text-sm text-slate-400 mt-1">Prevents stock from being issued or transferred in the selected locations until the count is approved.</div>
                </div>
              </label>
            </div>
            
            <div className="mt-4 bg-blue-50/10 border border-blue-500/20 p-4 rounded-lg flex gap-3 text-blue-300 text-sm">
              <Info size={20} className="shrink-0 text-blue-400" />
              <p>When you click "Generate Count Sheet", the system will instantly snapshot the current stock balances for all active items in the selected locations and mark the count as "In Progress".</p>
            </div>
          </div>
          
        </div>
        
        <div className="p-4 border-t bg-slate-900 flex justify-end gap-3">
          <Link href="/dashboard/inventory/counts" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          <button 
            disabled={isSaving}
            onClick={handleCreate}
            className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Play size={18} />} 
            {isSaving ? 'Generating...' : 'Generate Count Sheet'}
          </button>
        </div>
      </div>
    </div>
  );
}
