"use client";

import { useState, useEffect } from 'react';
import { Search, Plus, Play, CheckCircle2, ClipboardList, AlertTriangle } from 'lucide-react';
import Link from 'next/link';

export default function StockCountsPage() {
  const [counts, setCounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/inventory/counts`);
      if (response.ok) {
        const data = await response.json();
        setCounts(data);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Stock Counts</h1>
          <p className="text-slate-400 mt-1">Conduct physical inventory checks and reconcile variances.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/inventory/counts/new" className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
            <Plus size={18} /> New Stock Count
          </Link>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search counts..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Statuses</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="REVIEW">Needs Review</option>
            <option value="COMPLETED">Completed</option>
          </select>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Count Ref</th>
              <th className="p-4 font-semibold">Location</th>
              <th className="p-4 font-semibold">Date</th>
              <th className="p-4 font-semibold">Type</th>
              <th className="p-4 font-semibold text-center">Blind Count</th>
              <th className="p-4 font-semibold text-right">Net Variance</th>
              <th className="p-4 font-semibold text-center">Status</th>
              <th className="p-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {counts.map((count) => (
              <tr key={count.id} className="hover:bg-slate-900">
                <td className="p-4 font-mono text-xs text-brand-primary font-medium">{count.number}</td>
                <td className="p-4 font-medium text-slate-50">{count.location}</td>
                <td className="p-4 text-slate-400">{count.date}</td>
                <td className="p-4 text-slate-400">{count.type}</td>
                <td className="p-4 text-center">
                  {count.blind ? <span className="text-slate-50">Yes</span> : <span className="text-slate-500">No</span>}
                </td>
                <td className={`p-4 text-right font-medium ${count.variance === null ? 'text-gray-400' : count.variance < 0 ? 'text-red-600' : count.variance > 0 ? 'text-green-600' : 'text-slate-50'}`}>
                  {count.variance === null ? '-' : `$${Math.abs(count.variance).toFixed(2)} ${count.variance < 0 ? 'Loss' : 'Gain'}`}
                </td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${count.status === 'COMPLETED' ? 'bg-emerald-500/10 text-green-700' : count.status === 'IN_PROGRESS' ? 'bg-blue-500/10 text-blue-700' : 'bg-amber-500/10 text-yellow-700'}`}>
                    {count.status.replace('_', ' ')}
                  </span>
                </td>
                <td className="p-4 flex items-center justify-end gap-2">
                  {count.status === 'IN_PROGRESS' ? (
                    <button className="px-3 py-1 bg-brand-primary text-white rounded text-xs font-medium flex items-center gap-1 hover:bg-brand-secondary">
                      <Play size={14} /> Resume Count
                    </button>
                  ) : (
                    <button className="p-1.5 text-gray-400 hover:text-brand-primary rounded"><ClipboardList size={18}/></button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
