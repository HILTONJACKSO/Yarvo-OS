"use client";

import { FileText, TrendingDown, PackageMinus, BarChart3, AlertTriangle, Download } from 'lucide-react';
import Link from 'next/link';

export default function InventoryReportsPage() {
  const reports = [
    {
      title: 'Stock Valuation Report',
      description: 'Current value of all inventory items based on moving average cost.',
      icon: <BarChart3 className="text-blue-500" size={24} />,
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Consumption & Usage',
      description: 'Detailed view of items consumed via POS recipes and direct department issues.',
      icon: <TrendingDown className="text-green-500" size={24} />,
      bgColor: 'bg-green-50',
    },
    {
      title: 'Waste & Spoilage Analysis',
      description: 'Financial impact of damaged, expired, or spoiled inventory items.',
      icon: <PackageMinus className="text-red-500" size={24} />,
      bgColor: 'bg-red-50',
    },
    {
      title: 'Low Stock Alerts',
      description: 'Items currently below their defined minimum par levels across all locations.',
      icon: <AlertTriangle className="text-amber-500" size={24} />,
      bgColor: 'bg-amber-50',
    },
    {
      title: 'Stock Movement Ledger',
      description: 'Complete audit trail of all physical transfers and receipts between dates.',
      icon: <FileText className="text-purple-500" size={24} />,
      bgColor: 'bg-purple-50',
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Inventory Reports</h1>
          <p className="text-slate-400 mt-1">Analyze stock valuation, usage, and operational efficiency.</p>
        </div>
      </div>

      <div className="bg-slate-950 p-6 rounded-xl border shadow-sm space-y-6">
        <div className="flex gap-4 p-4 bg-slate-900 rounded-lg border items-center">
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Report Period</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>This Month</option>
              <option>Last Month</option>
              <option>This Quarter</option>
              <option>Year to Date</option>
              <option>Custom Range</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Filter by Location</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>All Locations</option>
              <option>Main Store</option>
              <option>Kitchen Store</option>
              <option>Main Bar</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Filter by Category</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>All Categories</option>
              <option>Beverages</option>
              <option>Raw Food</option>
              <option>Cleaning Supplies</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {reports.map((report, idx) => (
            <div key={idx} className="border rounded-xl p-5 flex gap-4 hover:border-brand-primary/50 hover:shadow-md transition cursor-pointer group">
              <div className={`p-4 ${report.bgColor} rounded-lg h-fit group-hover:scale-110 transition-transform`}>
                {report.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-slate-50">{report.title}</h3>
                <p className="text-sm text-slate-400 mt-1">{report.description}</p>
                <div className="mt-4 flex gap-2">
                  <Link href={`/dashboard/inventory/reports/${report.title.toLowerCase().replace(/ & | /g, '-')}`} className="text-xs font-medium text-brand-primary hover:underline flex items-center gap-1">
                    <BarChart3 size={14} /> View Report
                  </Link>
                  <button className="text-xs font-medium text-slate-400 hover:text-slate-50 flex items-center gap-1 ml-auto">
                    <Download size={14} /> Export CSV
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
