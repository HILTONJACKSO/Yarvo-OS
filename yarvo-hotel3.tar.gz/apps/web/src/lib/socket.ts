import { io } from 'socket.io-client';

const URL = process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002';

export const socket = io(URL, {
  autoConnect: true,
  reconnection: true,
});
