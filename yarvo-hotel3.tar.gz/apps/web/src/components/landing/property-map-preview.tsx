"use client";

import { useState } from "react";
import { MapIcon as Map, InformationCircleIcon as Info, UserIcon as User, ClockIcon as Clock, CheckCircleIcon as CheckCircle2, WrenchIcon as Wrench, ExclamationCircleIcon as AlertCircle, HomeModernIcon as Bed, FireIcon as Utensils, MusicalNoteIcon as Music } from "@heroicons/react/24/outline";

type MapItem = {
  id: string;
  type: 'room' | 'table' | 'vip';
  label: string;
  status: 'available' | 'occupied' | 'reserved' | 'cleaning' | 'maintenance' | 'vip';
  details: any;
};

export function PropertyMapPreview() {
  const [selectedItem, setSelectedItem] = useState<MapItem | null>({
    id: 'r205',
    type: 'room',
    label: 'Room 205',
    status: 'occupied',
    details: {
      guest: 'Daniel Johnson',
      checkIn: 'Today, 2:00 PM',
      checkOut: 'Tomorrow, 11:00 AM',
      bill: '$300.00',
      orders: '1 Active (Restaurant)',
      housekeeping: 'Clean',
    }
  });

  const getStatusColor = (status: MapItem['status']) => {
    switch (status) {
      case 'available': return 'bg-emerald-500 border-emerald-600';
      case 'occupied': return 'bg-red-500 border-red-600';
      case 'reserved': return 'bg-blue-500 border-blue-600';
      case 'cleaning': return 'bg-amber-500 border-amber-600';
      case 'vip': return 'bg-purple-500 border-purple-600';
      case 'maintenance': return 'bg-slate-400 border-slate-500';
      default: return 'bg-slate-200 border-slate-700';
    }
  };

  const mapItems: MapItem[] = [
    { id: 'r201', type: 'room', label: '201', status: 'available', details: { guest: 'None', housekeeping: 'Clean' } },
    { id: 'r202', type: 'room', label: '202', status: 'cleaning', details: { guest: 'None', housekeeping: 'Cleaning in progress' } },
    { id: 'r203', type: 'room', label: '203', status: 'maintenance', details: { guest: 'None', housekeeping: 'AC Repair' } },
    { id: 'r204', type: 'room', label: '204', status: 'reserved', details: { guest: 'Sarah Connor', checkIn: 'Today, 4:00 PM' } },
    { id: 'r205', type: 'room', label: '205', status: 'occupied', details: { guest: 'Daniel Johnson', checkIn: 'Today, 2:00 PM', checkOut: 'Tomorrow, 11:00 AM', bill: '$300.00', orders: '1 Active', housekeeping: 'Clean' } },
    { id: 't1', type: 'table', label: 'T1', status: 'available', details: { guest: 'None' } },
    { id: 't2', type: 'table', label: 'T2', status: 'occupied', details: { waiter: 'Mary', guest: 'Walk-In', order: '#104', kitchen: 'Preparing', bill: '$85.00', timeSeated: '45 mins ago' } },
    { id: 't3', type: 'table', label: 'T3', status: 'cleaning', details: { waiter: 'John', status: 'Waiting to be bussed' } },
    { id: 'v1', type: 'vip', label: 'VIP 1', status: 'vip', details: { customer: 'Mr. Smith Group', reserved: '10:00 PM', services: '2x Bottle Service', balance: '$500.00' } },
  ];

  return (
    <section id="property-map" className="py-24 bg-slate-900 border-t border-slate-800/50">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 mb-6">
            <Map className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            See Your Entire Property Live
          </h2>
          <p className="text-lg text-slate-300">
            A real-time operational control center. Monitor rooms, tables, cabanas, and VIP areas from a bird's-eye view.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 max-w-6xl mx-auto">
          {/* Map Area */}
          <div className="flex-1 bg-slate-950 p-8 rounded-3xl shadow-xl border border-slate-800">
            {/* Status Legend */}
            <div className="flex flex-wrap gap-4 mb-8 pb-6 border-b border-slate-800">
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-emerald-500"></div><span className="text-sm font-medium text-slate-300">Available</span></div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-500"></div><span className="text-sm font-medium text-slate-300">Occupied</span></div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-blue-500"></div><span className="text-sm font-medium text-slate-300">Reserved</span></div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-amber-500"></div><span className="text-sm font-medium text-slate-300">Cleaning/Waiting</span></div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-purple-500"></div><span className="text-sm font-medium text-slate-300">VIP/Event</span></div>
              <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-slate-400"></div><span className="text-sm font-medium text-slate-300">Maintenance</span></div>
            </div>

            {/* Map Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {/* Hotel Block */}
              <div className="col-span-2 md:col-span-4 bg-slate-900 p-6 rounded-2xl border border-slate-800 border-dashed">
                <h4 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2"><Bed className="w-4 h-4" /> Hotel Rooms - Floor 2</h4>
                <div className="flex gap-4">
                  {mapItems.filter(i => i.type === 'room').map(item => (
                    <button 
                      key={item.id}
                      onClick={() => setSelectedItem(item)}
                      className={`w-16 h-16 rounded-xl flex items-center justify-center text-white font-bold text-sm shadow-sm transition-transform hover:scale-110 border-b-4 ${getStatusColor(item.status)} ${selectedItem?.id === item.id ? 'ring-4 ring-offset-2 ring-blue-400' : ''}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Restaurant Block */}
              <div className="col-span-2 bg-slate-900 p-6 rounded-2xl border border-slate-800 border-dashed">
                <h4 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2"><Utensils className="w-4 h-4" /> Restaurant Terrace</h4>
                <div className="flex gap-4">
                  {mapItems.filter(i => i.type === 'table').map(item => (
                    <button 
                      key={item.id}
                      onClick={() => setSelectedItem(item)}
                      className={`w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-sm transition-transform hover:scale-110 border-b-4 ${getStatusColor(item.status)} ${selectedItem?.id === item.id ? 'ring-4 ring-offset-2 ring-blue-400' : ''}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Nightclub Block */}
              <div className="col-span-2 bg-slate-900 p-6 rounded-2xl border border-slate-800">
                <h4 className="text-sm font-bold text-slate-400 mb-4 flex items-center gap-2"><Music className="w-4 h-4" /> Nightclub VIP Area</h4>
                <div className="flex gap-4">
                  {mapItems.filter(i => i.type === 'vip').map(item => (
                    <button 
                      key={item.id}
                      onClick={() => setSelectedItem(item)}
                      className={`px-6 h-12 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-[0_0_15px_rgba(139,92,246,0.3)] transition-transform hover:scale-105 border-b-2 ${getStatusColor(item.status)} ${selectedItem?.id === item.id ? 'ring-4 ring-offset-2 ring-purple-400 ring-offset-slate-900' : ''}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Side Panel */}
          <div className="w-full lg:w-[350px] bg-slate-900 rounded-3xl shadow-xl overflow-hidden flex flex-col transform transition-all duration-300">
            {selectedItem ? (
              <>
                <div className={`${getStatusColor(selectedItem.status).replace('border-', '').replace('-500', '-600')} p-6 flex items-center justify-between`}>
                  <h3 className="text-xl font-bold text-white">{selectedItem.type.toUpperCase()} {selectedItem.label}</h3>
                  <div className="px-3 py-1 bg-slate-950/20 rounded-full text-white text-xs font-bold uppercase backdrop-blur-sm">
                    {selectedItem.status}
                  </div>
                </div>
                <div className="p-6 flex-1 flex flex-col gap-4 text-slate-300">
                  {selectedItem.type === 'room' && (
                    <>
                      <div className="flex items-center gap-3"><User className="w-5 h-5 text-slate-400" /> <span className="font-medium text-white">{selectedItem.details.guest}</span></div>
                      {selectedItem.details.checkIn && <div className="flex items-center gap-3"><Clock className="w-5 h-5 text-slate-400" /> <span>In: {selectedItem.details.checkIn}</span></div>}
                      {selectedItem.details.checkOut && <div className="flex items-center gap-3"><CheckCircle2 className="w-5 h-5 text-slate-400" /> <span>Out: {selectedItem.details.checkOut}</span></div>}
                      {selectedItem.details.bill && <div className="flex items-center gap-3"><AlertCircle className="w-5 h-5 text-slate-400" /> <span>Bill: <strong className="text-white">{selectedItem.details.bill}</strong></span></div>}
                      {selectedItem.details.orders && <div className="flex items-center gap-3"><Utensils className="w-5 h-5 text-blue-600" /> <span className="text-blue-600">{selectedItem.details.orders}</span></div>}
                      <div className="mt-4 pt-4 border-t border-slate-800">
                        <div className="flex items-center gap-3"><Wrench className="w-5 h-5 text-slate-400" /> <span className="text-sm">Housekeeping: {selectedItem.details.housekeeping}</span></div>
                      </div>
                    </>
                  )}
                  {selectedItem.type === 'table' && (
                    <>
                      <div className="flex items-center gap-3"><User className="w-5 h-5 text-slate-400" /> <span className="font-medium text-white">Waiter: {selectedItem.details.waiter || 'None'}</span></div>
                      {selectedItem.details.guest && <div className="flex items-center gap-3"><User className="w-5 h-5 text-slate-400" /> <span>{selectedItem.details.guest}</span></div>}
                      {selectedItem.details.order && <div className="flex items-center gap-3"><AlertCircle className="w-5 h-5 text-slate-400" /> <span>Order {selectedItem.details.order}</span></div>}
                      {selectedItem.details.kitchen && <div className="flex items-center gap-3"><Utensils className="w-5 h-5 text-blue-600" /> <span className="text-blue-600">Kitchen: {selectedItem.details.kitchen}</span></div>}
                      {selectedItem.details.bill && <div className="flex items-center gap-3"><AlertCircle className="w-5 h-5 text-slate-400" /> <span>Bill: <strong className="text-white">{selectedItem.details.bill}</strong></span></div>}
                      {selectedItem.details.timeSeated && <div className="flex items-center gap-3"><Clock className="w-5 h-5 text-slate-400" /> <span>{selectedItem.details.timeSeated}</span></div>}
                      {selectedItem.details.status && <div className="flex items-center gap-3"><AlertCircle className="w-5 h-5 text-blue-600" /> <span className="text-blue-600">{selectedItem.details.status}</span></div>}
                    </>
                  )}
                  {selectedItem.type === 'vip' && (
                    <>
                      <div className="flex items-center gap-3"><User className="w-5 h-5 text-slate-400" /> <span className="font-medium text-white">{selectedItem.details.customer}</span></div>
                      <div className="flex items-center gap-3"><Clock className="w-5 h-5 text-slate-400" /> <span>Reserved for: {selectedItem.details.reserved}</span></div>
                      <div className="flex items-center gap-3"><Wine className="w-5 h-5 text-blue-600" /> <span className="text-blue-600">{selectedItem.details.services}</span></div>
                      <div className="flex items-center gap-3"><AlertCircle className="w-5 h-5 text-slate-400" /> <span>Balance: <strong className="text-white">{selectedItem.details.balance}</strong></span></div>
                    </>
                  )}
                </div>
                <div className="p-4 border-t border-slate-800 bg-slate-950">
                  <button className="w-full py-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold transition-colors">
                    Manage {selectedItem.type}
                  </button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
                <Info className="w-12 h-12 mb-4 opacity-50" />
                <p>Select a room, table, or cabana on the map to view live details.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
