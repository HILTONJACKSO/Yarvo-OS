"use client";

import { Mail, MessageSquare, Send, Smartphone, Plus } from 'lucide-react';

import { io } from 'socket.io-client';
import { useState, useEffect } from 'react';

export default function CommunicationsPage() {
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCommunications = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch('http://127.0.0.1:3002/businesses/current', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            const res = await fetch('http://127.0.0.1:3002/crm/communications', {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (res.ok) {
              const data = await res.json();
              setCampaigns(Array.isArray(data) ? data : []);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchCommunications();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('crm.updated', fetchCommunications);

    return () => {
      socket.off('crm.updated', fetchCommunications);
      socket.disconnect();
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Communications & Campaigns</h1>
          <p className="text-slate-400 mt-1">Send SMS, Email, and WhatsApp broadcasts to targeted customer segments.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
          <Plus size={18} /> New Campaign
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex justify-center items-center"><Mail /></div>
          <div>
            <h3 className="font-bold text-slate-50 text-lg">Email</h3>
            <p className="text-sm text-slate-400">{campaigns.filter(c => c.channel === 'EMAIL').length} Sent this month</p>
          </div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-green-50 text-green-500 flex justify-center items-center"><Smartphone /></div>
          <div>
            <h3 className="font-bold text-slate-50 text-lg">SMS</h3>
            <p className="text-sm text-slate-400">{campaigns.filter(c => c.channel === 'SMS').length} Sent this month</p>
          </div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-500 flex justify-center items-center"><MessageSquare /></div>
          <div>
            <h3 className="font-bold text-slate-50 text-lg">WhatsApp</h3>
            <p className="text-sm text-slate-400">{campaigns.filter(c => c.channel === 'WHATSAPP').length} Sent this month</p>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900">
          <h2 className="font-bold text-slate-50">Recent Campaigns</h2>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400 text-sm">Campaign Name</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Channel</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Audience Size</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Open Rate</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Date</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {campaigns.map((c, idx) => (
              <tr key={idx} className="hover:bg-slate-900 cursor-pointer">
                <td className="p-4 text-sm font-bold text-slate-50">{c.subject}</td>
                <td className="p-4 text-sm font-medium text-slate-400 flex items-center gap-2">
                  {c.channel === 'EMAIL' ? <Mail size={14} className="text-blue-500"/> : c.channel === 'SMS' ? <Smartphone size={14} className="text-green-500"/> : <MessageSquare size={14} className="text-emerald-500"/>}
                  {c.channel}
                </td>
                <td className="p-4 text-sm text-slate-400">{c.customer?.firstName} {c.customer?.lastName}</td>
                <td className="p-4 text-sm font-bold text-emerald-600">N/A</td>
                <td className="p-4 text-sm text-slate-400">{new Date(c.createdAt).toLocaleDateString()}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-bold rounded-full ${c.status === 'SENT' ? 'bg-emerald-500/10 text-green-700' : 'bg-blue-500/10 text-blue-700'}`}>{c.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
