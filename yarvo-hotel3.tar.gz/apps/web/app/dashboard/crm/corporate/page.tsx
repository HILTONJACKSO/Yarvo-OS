"use client";

import { Building, Phone, Mail, FileText, Plus, Search } from 'lucide-react';
import { io } from 'socket.io-client';
import { useState, useEffect } from 'react';

export default function CorporateCustomersPage() {
  const [corporates, setCorporates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCorporates = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch('http://127.0.0.1:3002/businesses/current', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            const res = await fetch('http://127.0.0.1:3002/crm/corporate', {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (res.ok) {
              const data = await res.json();
              setCorporates(Array.isArray(data) ? data : []);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchCorporates();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('crm.updated', fetchCorporates);

    return () => {
      socket.off('crm.updated', fetchCorporates);
      socket.disconnect();
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Corporate Customers</h1>
          <p className="text-slate-400 mt-1">Manage B2B relationships, billing accounts, and corporate credit limits.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition shadow-sm font-medium">
          <Plus size={16} /> Add Corporate
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex items-center justify-between">
          <div className="relative w-80">
            <input type="text" placeholder="Search companies..." className="w-full pl-10 pr-4 py-2 border rounded-md text-sm outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary" />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400 text-sm">Company</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Main Contact</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-right">Credit Limit</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-right">Outstanding Balance</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {corporates.map((c, idx) => (
              <tr key={idx} className="hover:bg-slate-900 cursor-pointer">
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400">
                      <Building size={18} />
                    </div>
                    <div>
                      <div className="font-bold text-slate-50">{c.companyName}</div>
                      <div className="text-xs text-brand-primary font-medium">{c.corporateNumber}</div>
                    </div>
                  </div>
                </td>
                <td className="p-4">
                  <div className="font-medium text-slate-50 text-sm mb-1">{c.mainContactName}</div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-1"><Mail size={12}/> {c.companyEmail || c.mainContactEmail || 'N/A'}</div>
                  <div className="flex items-center gap-2 text-xs text-slate-400"><Phone size={12}/> {c.companyPhone || c.mainContactPhone || 'N/A'}</div>
                </td>
                <td className="p-4 text-sm font-bold text-right text-slate-300">${(c.creditLimit || 0).toFixed(2)}</td>
                <td className="p-4 text-sm font-bold text-right text-red-600">${(c.outstandingBalance || 0).toFixed(2)}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-bold rounded-full ${c.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-slate-800 text-slate-400'}`}>{c.status || 'ACTIVE'}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
