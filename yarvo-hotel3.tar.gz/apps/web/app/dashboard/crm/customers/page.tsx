"use client";

import { useState, useEffect } from 'react';
import { Search, UserPlus, Filter, ShieldCheck, Users, Phone, Mail, User, Building2, Crown, DownloadCloud } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { io } from 'socket.io-client';

export default function CustomersDirectoryPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('All');
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch('http://127.0.0.1:3002/businesses/current', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            const res = await fetch('http://127.0.0.1:3002/crm/customers', {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (res.ok) {
              const data = await res.json();
              setCustomers(Array.isArray(data) ? data : []);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchCustomers();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('crm.updated', fetchCustomers);

    return () => {
      socket.off('crm.updated', fetchCustomers);
      socket.disconnect();
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-blue-500/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10 flex items-center gap-4">
          <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl shadow-inner">
            <Users size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-50 tracking-tight">Customer Directory</h1>
            <p className="text-slate-400 mt-1 font-medium text-sm md:text-base">Manage individuals, groups, and corporate accounts.</p>
          </div>
        </div>
        <div className="relative z-10 flex gap-3">
          <button className="px-5 py-2.5 bg-slate-950 border border-slate-800 text-slate-300 rounded-xl font-bold hover:bg-slate-900 transition flex items-center gap-2 shadow-sm">
            <DownloadCloud size={18} /> Export
          </button>
          <Link href="/dashboard/crm/customers/new" className="px-6 py-2.5 bg-brand-primary text-white rounded-xl font-bold hover:bg-brand-primary/90 transition flex items-center gap-2 shadow-md hover:shadow-lg">
            <UserPlus size={18} /> Register Customer
          </Link>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="bg-slate-950 rounded-3xl shadow-sm border border-slate-800 overflow-hidden">
        
        {/* Controls & Search */}
        <div className="p-6 border-b flex flex-col lg:flex-row gap-6 justify-between bg-slate-900/50">
          
          <div className="flex bg-slate-800/50 p-1 rounded-xl w-max border border-slate-800/50">
            {['All', 'Individuals', 'Groups', 'Corporate'].map(tab => (
              <button 
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-2 rounded-lg text-sm font-bold transition-all \${activeTab === tab ? 'bg-slate-950 text-slate-50 shadow-sm' : 'text-slate-400 hover:text-slate-300 hover:bg-gray-200/50'}`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="flex gap-3 w-full lg:w-auto">
            <div className="relative flex-1 lg:w-80">
              <Search className="absolute left-4 top-3 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search by name, ID, email, phone..." 
                className="w-full pl-11 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 transition-all shadow-sm font-medium"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm font-bold text-slate-300 hover:bg-slate-900 transition shadow-sm whitespace-nowrap">
              <Filter size={16} /> Filters
            </button>
          </div>
        </div>

        {/* Directory Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-gray-400 text-xs uppercase tracking-wider font-bold border-b border-slate-800">
              <tr>
                <th className="px-8 py-5">Customer Profile</th>
                <th className="px-6 py-5">Contact Details</th>
                <th className="px-6 py-5">Classification</th>
                <th className="px-6 py-5 text-center">Total Visits</th>
                <th className="px-8 py-5 text-right">Lifetime Value</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {customers.map((c, idx) => (
                <tr 
                  key={idx} 
                  className="hover:bg-blue-50/50 transition cursor-pointer group"
                  onClick={() => router.push(`/dashboard/crm/customers/${c.id}`)}
                >
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      {c.customerType === 'CORPORATE' ? (
                        <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-inner group-hover:scale-105 transition-transform">
                          <Building2 size={24} />
                        </div>
                      ) : (
                        <div className="w-12 h-12 rounded-2xl bg-brand-primary/10 text-brand-primary flex items-center justify-center font-black text-lg shadow-inner group-hover:scale-105 transition-transform">
                          {(c.firstName?.[0] || '') + (c.lastName?.[0] || '') || c.customerNumber?.substring(0, 2) || 'C'}
                        </div>
                      )}
                      
                      <div>
                        <div className="font-bold text-slate-50 text-base group-hover:text-brand-primary transition-colors">{c.firstName} {c.lastName}</div>
                        <div className="text-gray-400 text-xs font-bold mt-0.5 tracking-wide">{c.id}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-2 text-sm text-slate-400 font-medium">
                        <Phone size={14} className="text-gray-400"/> {c.phone}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-400 font-medium">
                        <Mail size={14} className="text-gray-400"/> {c.email}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-col items-start gap-2">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-400 bg-slate-800 px-2.5 py-1 rounded-md">
                        {c.customerType === 'CORPORATE' ? <Building2 size={14} /> : <User size={14} />} 
                        {c.customerType || 'INDIVIDUAL'}
                      </div>
                      <div className="flex gap-1 flex-wrap mt-1">
                        {c.isVip && (
                          <span className={`px-2.5 py-1 text-[10px] uppercase tracking-wider font-black rounded-full flex items-center gap-1 bg-amber-500/10 text-amber-700`}>
                            <Crown size={10} /> VIP
                          </span>
                        )}
                        {c.status && (
                           <span className={`px-2.5 py-1 text-[10px] uppercase tracking-wider font-black rounded-full flex items-center gap-1 bg-blue-500/10 text-blue-700`}>
                             {c.status}
                           </span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-center">
                    <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-slate-900 text-slate-300 font-bold border border-slate-800">
                      {c.totalVisits || 0}
                    </div>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="font-black text-lg text-emerald-600">${(c.lifetimeValue || 0).toFixed(2)}</div>
                    <div className="text-[10px] uppercase font-bold text-gray-400 mt-1">Total Spent</div>
                  </td>
                </tr>
              ))}
              {customers.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-8 py-20 text-center">
                    <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-900 mb-6 border border-slate-800">
                      <Users size={32} className="text-gray-300" />
                    </div>
                    <h3 className="text-xl font-black text-slate-50 mb-2">No customers found</h3>
                    <p className="text-slate-400 font-medium max-w-md mx-auto">Get started by adding a new customer profile. All individuals, groups, and corporate accounts will be listed here.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="p-4 border-t border-slate-800 flex justify-between items-center bg-slate-950 rounded-b-3xl">
          <div className="text-sm font-medium text-slate-400 pl-4">Showing <span className="font-bold text-slate-50">1</span> to <span className="font-bold text-slate-50">4</span> of <span className="font-bold text-slate-50">18,452</span> customers</div>
          <div className="flex gap-1.5 pr-4">
            <button className="px-4 py-2 border border-slate-800 rounded-xl bg-slate-950 hover:bg-slate-900 disabled:opacity-50 font-bold text-sm text-slate-300 shadow-sm" disabled>Prev</button>
            <button className="px-4 py-2 border border-brand-primary rounded-xl bg-brand-primary text-white font-bold text-sm shadow-sm">1</button>
            <button className="px-4 py-2 border border-slate-800 rounded-xl bg-slate-950 hover:bg-slate-900 font-bold text-sm text-slate-300 shadow-sm">2</button>
            <button className="px-4 py-2 border border-slate-800 rounded-xl bg-slate-950 hover:bg-slate-900 font-bold text-sm text-slate-300 shadow-sm">3</button>
            <button className="px-4 py-2 border border-slate-800 rounded-xl bg-slate-950 hover:bg-slate-900 font-bold text-sm text-slate-300 shadow-sm">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}
