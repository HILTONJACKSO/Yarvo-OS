"use client";

import { Star, ShieldCheck, Calendar, MapPin, User, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';
import { useState, useEffect } from 'react';

export default function VIPGuestsPage() {
  const [vips, setVips] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchVips = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch('http://127.0.0.1:3002/businesses/current', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            const res = await fetch('http://127.0.0.1:3002/crm/vip', {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (res.ok) {
              const data = await res.json();
              setVips(Array.isArray(data) ? data : []);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchVips();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('crm.updated', fetchVips);

    return () => {
      socket.off('crm.updated', fetchVips);
      socket.disconnect();
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50 flex items-center gap-2"><Star className="text-amber-500" /> VIP Management</h1>
          <p className="text-slate-400 mt-1">Special handling, preferences, and dedicated managers for your top guests.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl p-6 text-white shadow-md">
          <div className="text-amber-100 text-sm font-medium mb-1">In-House VIPs</div>
          <div className="text-4xl font-black">{vips.filter(v => v.status === 'IN_HOUSE').length}</div>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl p-6 text-white shadow-md">
          <div className="text-purple-100 text-sm font-medium mb-1">Arriving Today</div>
          <div className="text-4xl font-black">{vips.filter(v => v.status === 'ARRIVING_TODAY').length}</div>
        </div>
        <div className="bg-slate-950 rounded-2xl p-6 border shadow-sm">
          <div className="text-slate-400 text-sm font-medium mb-1">Total VIP Roster</div>
          <div className="text-4xl font-black text-slate-50">{vips.length}</div>
        </div>
      </div>

      <h2 className="font-bold text-slate-50 mb-4 text-lg">Active VIP Roster</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {vips.map((vip, idx) => (
          <div key={idx} className="bg-slate-950 border rounded-xl p-5 shadow-sm hover:border-amber-300 transition cursor-pointer relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition">
              <Star size={64} className="text-amber-500" />
            </div>
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 bg-amber-500/10 text-amber-700 rounded-full flex justify-center items-center font-bold text-xl">
                  {vip.firstName?.substring(0, 1) || 'V'}
                </div>
                <span className={`px-2 py-1 text-xs font-bold rounded-full bg-emerald-500/10 text-green-700`}>
                  {vip.status?.replace('_', ' ') || 'ACTIVE'}
                </span>
              </div>
              <h3 className="font-bold text-lg text-slate-50">{vip.firstName} {vip.lastName}</h3>
              <p className="text-sm text-slate-400 mb-4">{vip.customerNumber}</p>
              
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-slate-400"><MapPin size={16} className="text-gray-400"/> {vip.room}</div>
                <div className="flex items-center gap-2 text-slate-400"><ShieldCheck size={16} className="text-gray-400"/> {vip.manager}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
