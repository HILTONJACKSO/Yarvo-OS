"use client";

import { Users, TrendingUp, UserPlus, Star, Activity, AlertTriangle, ShieldCheck, Search, Bell } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';
import { useState, useEffect } from 'react';

export default function CRMDashboardPage() {
  const [kpis, setKpis] = useState<any[]>([]);
  const [topCustomer, setTopCustomer] = useState<any>(null);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCrmData = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch('http://127.0.0.1:3002/businesses/current', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            const res = await fetch('http://127.0.0.1:3002/crm/analytics/overview', {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (res.ok) {
              const data = await res.json();
              setKpis(data.kpis || []);
              setTopCustomer(data.topCustomer || null);
              setAlerts(data.alerts || []);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchCrmData();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('crm.updated', fetchCrmData);

    return () => {
      socket.off('crm.updated', fetchCrmData);
      socket.disconnect();
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-center bg-gray-900 text-white p-6 rounded-2xl shadow-lg">
        <div>
          <h1 className="text-3xl font-black tracking-tight">CRM Dashboard</h1>
          <p className="text-gray-400 mt-1">Unified customer relationship management.</p>
        </div>
        <div className="flex gap-4">
          <div className="relative">
            <input type="text" placeholder="Quick search phone or name..." className="pl-10 pr-4 py-2 bg-gray-800 border-none rounded-lg text-sm focus:ring-2 focus:ring-brand-primary outline-none" />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          </div>
        </div>
      </div>

      {kpis.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((kpi, idx) => (
            <div key={idx} className="bg-slate-950 p-6 rounded-2xl border shadow-sm flex flex-col justify-between hover:border-brand-primary/50 transition">
              <div className="flex justify-between items-start">
                <div className="p-2 bg-slate-900 rounded-lg"><Activity size={24} className="text-brand-primary" /></div>
                <span className={`text-sm font-bold flex items-center gap-1 ${kpi.trendUp ? 'text-emerald-600' : 'text-red-500'}`}>
                  {kpi.trendUp ? <TrendingUp size={14} /> : <TrendingUp size={14} className="rotate-180" />} {kpi.trend}
                </span>
              </div>
              <div className="mt-4">
                <h3 className="text-slate-400 font-medium text-sm">{kpi.title}</h3>
                <div className="text-3xl font-black text-slate-50 mt-1">{kpi.value}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-slate-950 p-8 rounded-3xl border shadow-sm text-center">
          <p className="text-slate-400 font-medium">Customer metrics are currently unavailable.</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Customer / Lifetime Value */}
        <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm flex flex-col justify-between">
          <div>
            <h2 className="font-bold text-slate-50 mb-6 flex items-center justify-between">
              Top Customer
              <Star size={18} className="text-brand-primary" />
            </h2>
            {topCustomer ? (
              <>
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-brand-primary text-white rounded-full flex items-center justify-center text-2xl font-bold">
                    {topCustomer.initials || 'VIP'}
                  </div>
                  <div>
                    <h3 className="font-bold text-xl text-slate-50">{topCustomer.name}</h3>
                    <p className="text-sm text-slate-400">{topCustomer.type}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-900 rounded-xl">
                    <div className="text-sm text-slate-400">Lifetime Value</div>
                    <div className="text-xl font-bold text-slate-50">{topCustomer.ltv}</div>
                  </div>
                  <div className="p-4 bg-slate-900 rounded-xl">
                    <div className="text-sm text-slate-400">Total Visits</div>
                    <div className="text-xl font-bold text-slate-50">{topCustomer.visits}</div>
                  </div>
                </div>
                <button className="w-full mt-6 py-2 border rounded-md text-sm font-medium hover:bg-slate-900">
                  View Profile
                </button>
              </>
            ) : (
              <p className="text-gray-400 text-sm text-center py-12">No customer data available.</p>
            )}
          </div>
        </div>

        {/* Operational Alerts */}
        <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm lg:col-span-2">
          <h2 className="font-bold text-slate-50 mb-6 flex items-center justify-between">
            CRM Alerts & Actions
            <Bell size={18} className="text-gray-400" />
          </h2>
          {alerts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {alerts.map((alert: any, i: number) => (
                <div key={i} className={`p-4 border bg-slate-900 rounded-xl flex items-start gap-3 cursor-pointer hover:bg-slate-800 transition`}>
                  <AlertTriangle className="text-brand-primary mt-0.5" size={18} />
                  <div>
                    <h4 className="font-bold text-slate-50 text-sm">{alert.title}</h4>
                    <p className="text-slate-300 text-sm mt-1">{alert.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-400 text-sm">No CRM alerts pending.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
