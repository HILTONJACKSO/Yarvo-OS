"use client";

import { useState, useEffect } from 'react';
import { socket } from '@/lib/socket';
import { 
  Search, Filter, Users, Calendar, ArrowRightLeft,
  ConciergeBell, ChevronRight, MoreHorizontal, FileText, CheckCircle2
} from 'lucide-react';
import Link from 'next/link';

export default function InHouseGuestsPage() {
  const [guests, setGuests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInHouseGuests = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/stays/in-house`);
        if (response.ok) {
          const data = await response.json();
          const mappedGuests = data.map((stay: any) => {
            const customer = stay.reservation?.customer;
            const resRoom = stay.reservation?.reservationRooms?.[0];
            return {
              id: stay.id,
              guestName: customer?.displayName || 'Unknown Guest',
              room: resRoom?.room?.number || 'Unassigned',
              roomType: resRoom?.roomType?.name || 'Standard Room',
              arrival: stay.reservation?.arrivalDate,
              departure: stay.expectedDepartureTime,
              nightsRemaining: stay.expectedDepartureTime ? Math.max(0, Math.ceil((new Date(stay.expectedDepartureTime).getTime() - new Date().getTime()) / (1000 * 3600 * 24))) : 0,
              occupants: (stay.reservation?.adults || 1) + (stay.reservation?.children || 0),
              balance: 0, // Placeholder until folios are fully joined
              status: stay.status === 'CHECKED_IN' ? 'In House' : stay.status,
              vip: customer?.isVIP || false,
              corporate: customer?.company || null
            };
          });
          setGuests(mappedGuests);
        }
      } catch (error) {
        console.error('Failed to fetch in-house guests:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchInHouseGuests();

    const onUpdate = () => {
      fetchInHouseGuests();
    };

    socket.on('stays.updated', onUpdate);
    return () => {
      socket.off('stays.updated', onUpdate);
    };
  }, []);

  return (
    <div className="space-y-6">
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">In-House Guests</h2>
          <p className="text-slate-400">Currently occupying {guests.length} rooms.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/front-desk/walk-in" className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
            Walk-In Check-In
          </Link>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border flex flex-col md:flex-row p-4 gap-4 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-slate-700 rounded-md leading-5 bg-slate-950 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-brand-primary focus:border-brand-primary sm:text-sm transition duration-150 ease-in-out"
            placeholder="Search by guest name, room, or stay ID..."
          />
        </div>
        
        <div className="flex gap-2 w-full md:w-auto">
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-700 rounded-md text-sm font-medium text-slate-300 bg-slate-950 hover:bg-slate-900">
            <Filter size={16} /> Filters
          </button>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-slate-900">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Room & Guest</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Dates</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Balance</th>
                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody className="bg-slate-950 divide-y divide-gray-200">
              {guests.map((guest) => (
                <tr key={guest.id} className="hover:bg-slate-900 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 bg-brand-primary/10 rounded-lg flex items-center justify-center text-brand-primary font-bold">
                        {guest.room}
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-slate-50 flex items-center gap-2">
                          {guest.guestName}
                          {guest.vip && <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">VIP</span>}
                        </div>
                        <div className="text-sm text-slate-400">{guest.roomType} â€¢ {guest.occupants} pax</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-50">{guest.arrival ? new Date(guest.arrival).toLocaleDateString() : ''} to {guest.departure ? new Date(guest.departure).toLocaleDateString() : ''}</div>
                    <div className="text-sm text-slate-400">{guest.nightsRemaining} nights remaining</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      guest.status === 'Checkout Pending' ? 'bg-orange-100 text-orange-800' :
                      guest.status === 'Checked In' ? 'bg-blue-500/10 text-blue-400' :
                      'bg-emerald-500/10 text-emerald-400'
                    }`}>
                      {guest.status}
                    </span>
                    {guest.corporate && (
                      <div className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                        <Users size={12} /> {guest.corporate}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-medium ${guest.balance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      ${guest.balance.toFixed(2)}
                    </div>
                    <div className="text-xs text-slate-400">Folio Active</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end gap-2">
                      <Link href={`/dashboard/stays/${guest.id}`} className="text-brand-primary hover:text-brand-primary/80 px-3 py-1 bg-brand-primary/10 rounded-md transition-colors">
                        View Stay
                      </Link>
                      <button className="text-gray-400 hover:text-slate-400 p-1">
                        <MoreHorizontal size={20} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
