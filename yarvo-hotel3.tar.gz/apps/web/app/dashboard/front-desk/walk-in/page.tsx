"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { 
  CheckCircle2, ArrowRight, UserPlus, Search, 
  Calendar, Users, BedDouble, CreditCard, ShieldCheck,
  Building2, Users as UsersIcon
} from 'lucide-react';

export default function WalkInCheckInPage() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchParams, setSearchParams] = useState({
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(new Date().getTime() + 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    adults: 1,
    children: 0,
    roomTypeId: ''
  });
  const [availableRooms, setAvailableRooms] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, 5));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));

  const performSearch = async () => {
    setIsSearching(true);
    try {
      const query = new URLSearchParams({
        startDate: searchParams.startDate,
        endDate: searchParams.endDate,
        adults: searchParams.adults.toString(),
        children: searchParams.children.toString()
      });
      if (searchParams.roomTypeId) {
        query.append('roomTypeId', searchParams.roomTypeId);
      }
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/availability/search?${query.toString()}`);
      if (res.ok) {
        const data = await res.json();
        // The endpoint returns room types. We can simulate picking a specific room from them.
        setAvailableRooms(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearching(false);
      nextStep();
    }
  };

  const completeCheckIn = () => {
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      router.push('/dashboard/front-desk');
    }, 1500);
  };

  const steps = [
    "Search", "Guest", "Room", "Payment", "Confirm"
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="bg-slate-950 p-6 rounded-xl shadow-sm border flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Walk-In Check-In</h2>
          <p className="text-slate-400">Create a reservation and check in immediately.</p>
        </div>
        <div className="flex gap-2">
          {steps.map((step, idx) => (
            <div key={idx} className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep > idx + 1 ? 'bg-green-500 text-white' :
                currentStep === idx + 1 ? 'bg-brand-primary text-white' :
                'bg-slate-800 text-gray-400'
              }`}>
                {currentStep > idx + 1 ? <CheckCircle2 size={16} /> : idx + 1}
              </div>
              <span className="text-[10px] mt-1 text-slate-400 uppercase">{step}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Main Form Area */}
        <div className="md:col-span-2 space-y-6">
          
          {/* Step 1: Search Availability */}
          {currentStep === 1 && (
            <div className="bg-slate-950 rounded-xl shadow-sm border p-6 space-y-6">
              <h3 className="text-lg font-semibold border-b pb-4">Step 1: Search Availability</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Check-Out Date</label>
                  <input type="date" 
                    value={searchParams.endDate}
                    onChange={e => setSearchParams({...searchParams, endDate: e.target.value})}
                    className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                  <p className="text-xs text-slate-400 mt-1">Check-in is right now.</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Room Type</label>
                  <select 
                    value={searchParams.roomTypeId}
                    onChange={e => setSearchParams({...searchParams, roomTypeId: e.target.value})}
                    className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm">
                    <option value="">Any Room Type</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Adults</label>
                  <input type="number" 
                    value={searchParams.adults}
                    onChange={e => setSearchParams({...searchParams, adults: parseInt(e.target.value)})}
                    className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Children</label>
                  <input type="number" 
                    value={searchParams.children}
                    onChange={e => setSearchParams({...searchParams, children: parseInt(e.target.value)})}
                    className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                </div>
              </div>

              <div className="pt-4 flex justify-end border-t">
                <button onClick={performSearch} disabled={isSearching} className="px-4 py-2 border rounded-md text-sm font-medium hover:bg-slate-900 text-brand-primary border-brand-primary/20 bg-brand-primary/5 flex items-center gap-2">
                  <Search size={16} /> {isSearching ? 'Searching...' : 'Find Rooms'}
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Select Guest */}
          {currentStep === 2 && (
            <div className="bg-slate-950 rounded-xl shadow-sm border p-6 space-y-6">
              <h3 className="text-lg font-semibold border-b pb-4">Step 2: Guest Profile</h3>
              
              <div className="flex gap-4">
                <button className="flex-1 p-4 border border-brand-primary ring-1 ring-brand-primary rounded-lg text-center bg-brand-primary/5">
                  <UserPlus className="mx-auto mb-2 text-brand-primary" size={24} />
                  <span className="block font-medium text-brand-primary">Quick Register</span>
                </button>
                <button className="flex-1 p-4 border rounded-lg text-center hover:bg-slate-900 text-slate-400">
                  <Search className="mx-auto mb-2" size={24} />
                  <span className="block font-medium">Existing Customer</span>
                </button>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">First Name</label>
                    <input type="text" className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Last Name</label>
                    <input type="text" className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Phone Number</label>
                    <input type="tel" className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">ID / Passport</label>
                    <input type="text" className="w-full border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Select Room */}
          {currentStep === 3 && (
            <div className="bg-slate-950 rounded-xl shadow-sm border p-6 space-y-6">
              <h3 className="text-lg font-semibold border-b pb-4">Step 3: Select Available Room</h3>
              
              <div className="space-y-3">
                {availableRooms.map((type, idx) => (
                  <label key={idx} className="relative flex items-start p-4 cursor-pointer border rounded-lg hover:border-gray-400">
                    <div className="flex items-center h-5">
                      <input type="radio" name="room" className="focus:ring-brand-primary h-4 w-4 text-brand-primary border-slate-700" defaultChecked={idx === 0} />
                    </div>
                    <div className="ml-3 flex-1 flex justify-between">
                      <div>
                        <span className="block text-sm font-medium text-slate-50">{type.name}</span>
                        <span className="block text-sm text-slate-400">Max {type.baseOccupancy} Guests</span>
                      </div>
                      <div className="text-right">
                        <span className="block font-medium text-slate-50">${type.baseRate} / night</span>
                      </div>
                    </div>
                  </label>
                ))}
                {availableRooms.length === 0 && (
                  <div className="text-center p-4 text-slate-400">No rooms available for these dates.</div>
                )}
              </div>
            </div>
          )}

          {/* Step 4: Financial Review */}
          {currentStep === 4 && (
            <div className="bg-slate-950 rounded-xl shadow-sm border p-6 space-y-6">
              <h3 className="text-lg font-semibold border-b pb-4">Step 4: Payment Guarantee</h3>
              
              <div className="bg-slate-900 p-4 rounded-lg space-y-2 border">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Room Rate ($120 x 2 nights)</span>
                  <span className="font-medium text-slate-50">$240.00</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Estimated Taxes</span>
                  <span className="font-medium text-slate-50">$24.00</span>
                </div>
                <div className="pt-2 border-t flex justify-between">
                  <span className="font-semibold text-slate-50">Total Stay Estimate</span>
                  <span className="font-bold text-slate-50">$264.00</span>
                </div>
              </div>

              <div className="space-y-4">
                <label className="block text-sm font-medium text-slate-300">Initial Payment / Deposit</label>
                <div className="flex items-center gap-4">
                  <div className="relative rounded-md shadow-sm flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-slate-400 sm:text-sm">$</span>
                    </div>
                    <input type="number" defaultValue="264.00" className="pl-7 block w-full border-slate-700 rounded-md focus:ring-brand-primary focus:border-brand-primary sm:text-sm" />
                  </div>
                  <select className="border-slate-700 rounded-md shadow-sm focus:ring-brand-primary focus:border-brand-primary sm:text-sm flex-1">
                    <option>Cash</option>
                    <option>Credit Card (Terminal)</option>
                    <option>Mobile Money</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Step 5: Confirm */}
          {currentStep === 5 && (
            <div className="bg-slate-950 rounded-xl shadow-sm border p-6 space-y-6 text-center">
              <div className="w-16 h-16 bg-emerald-500/10 text-green-500 rounded-full flex items-center justify-center mx-auto">
                <ShieldCheck size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-50">Ready for Check-In</h3>
                <p className="text-slate-400 mt-2">The system will create the customer profile, reservation, stay record, and guest folio simultaneously.</p>
              </div>

              <div className="pt-6 flex justify-center gap-4">
                <button 
                  onClick={completeCheckIn}
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-brand-primary text-white font-medium rounded-md hover:bg-brand-primary/90 flex items-center gap-2"
                >
                  {isSubmitting ? 'Processing...' : 'Complete Walk-In'}
                </button>
              </div>
            </div>
          )}

          {/* Navigation Controls */}
          <div className="flex justify-between items-center pt-4">
            <button
              onClick={prevStep}
              disabled={currentStep === 1 || isSubmitting}
              className="px-4 py-2 border rounded-md text-sm font-medium text-slate-300 hover:bg-slate-900 disabled:opacity-50"
            >
              Back
            </button>
            {currentStep < 5 && (
              <button
                onClick={nextStep}
                className="px-6 py-2 bg-gray-900 text-white rounded-md text-sm font-medium hover:bg-gray-800 flex items-center gap-2"
              >
                Next Step <ArrowRight size={16} />
              </button>
            )}
          </div>

        </div>

        {/* Sidebar Summary */}
        <div className="md:col-span-1 space-y-6">
          <div className="bg-slate-900 rounded-xl border p-5 space-y-4">
            <h3 className="font-semibold text-slate-50">Summary</h3>
            <p className="text-sm text-slate-400">Details will populate as you fill out the wizard.</p>
          </div>
        </div>

      </div>
    </div>
  );
}
