"use client";

import { useState, useEffect } from 'react';
import { socket } from '@/lib/socket';
import { 
  ConciergeBell, Search, Filter, MessageSquare, 
  Clock, CheckCircle2, AlertCircle, Plus
} from 'lucide-react';
import Link from 'next/link';

export default function GuestRequestsPage() {
  const [requests, setRequests] = useState<any[]>([]);
  const [stats, setStats] = useState({
    open: 0,
    inProgress: 0,
    completedToday: 0,
    overdue: 0
  });

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const [reqRes, statsRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/guest-requests`),
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/guest-requests/stats`)
        ]);

        if (reqRes.ok) {
          const data = await reqRes.json();
          const mapped = data.map((req: any) => {
            const customer = req.stay?.reservation?.customer;
            const resRoom = req.stay?.reservation?.reservationRooms?.[0];
            return {
              id: req.id,
              room: resRoom?.room?.number || 'Unknown',
              guestName: customer?.displayName || 'Unknown Guest',
              category: req.type || 'General',
              description: req.description,
              status: req.status === 'OPEN' ? 'Open' : req.status === 'IN_PROGRESS' ? 'In Progress' : 'Completed',
              priority: req.priority || 'Normal',
              requestedAt: new Date(req.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              assignedTo: null
            };
          });
          setRequests(mapped);
        }

        if (statsRes.ok) {
          const s = await statsRes.json();
          setStats(s);
        }
      } catch (error) {
        console.error('Failed to fetch guest requests:', error);
      }
    };

    fetchRequests();

    socket.on('guestRequests.updated', fetchRequests);
    return () => {
      socket.off('guestRequests.updated', fetchRequests);
    };
  }, []);

  return (
    <div className="space-y-6">
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Guest Requests</h2>
          <p className="text-slate-400">Manage and fulfill requests from in-house guests.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 font-medium">
          <Plus size={16} /> New Request
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-950 p-4 rounded-xl shadow-sm border border-l-4 border-l-blue-500">
          <p className="text-sm text-slate-400 font-medium">Open</p>
          <p className="text-2xl font-bold text-slate-50">{stats.open}</p>
        </div>
        <div className="bg-slate-950 p-4 rounded-xl shadow-sm border border-l-4 border-l-amber-500">
          <p className="text-sm text-slate-400 font-medium">In Progress</p>
          <p className="text-2xl font-bold text-slate-50">{stats.inProgress}</p>
        </div>
        <div className="bg-slate-950 p-4 rounded-xl shadow-sm border border-l-4 border-l-green-500">
          <p className="text-sm text-slate-400 font-medium">Completed Today</p>
          <p className="text-2xl font-bold text-slate-50">{stats.completedToday}</p>
        </div>
        <div className="bg-slate-950 p-4 rounded-xl shadow-sm border border-l-4 border-l-red-500">
          <p className="text-sm text-slate-400 font-medium">Overdue / SLA Missed</p>
          <p className="text-2xl font-bold text-slate-50">{stats.overdue}</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border flex flex-col md:flex-row p-4 gap-4 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-slate-700 rounded-md leading-5 bg-slate-950 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-brand-primary focus:border-brand-primary sm:text-sm transition duration-150 ease-in-out"
            placeholder="Search requests by room or description..."
          />
        </div>
        
        <div className="flex gap-2 w-full md:w-auto">
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-700 rounded-md text-sm font-medium text-slate-300 bg-slate-950 hover:bg-slate-900">
            <Filter size={16} /> Filters
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {requests.map(request => (
          <div key={request.id} className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden flex flex-col">
            <div className={`p-4 border-b flex justify-between items-start ${
              request.status === 'Open' ? 'bg-blue-50/50' : 
              request.status === 'In Progress' ? 'bg-amber-50/50' : 
              'bg-slate-900'
            }`}>
              <div className="flex gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-lg ${
                  request.priority === 'High' ? 'bg-red-500/10 text-red-700' : 'bg-slate-950 border text-slate-300'
                }`}>
                  {request.room}
                </div>
                <div>
                  <h3 className="font-semibold text-slate-50">{request.category}</h3>
                  <p className="text-xs text-slate-400">{request.guestName}</p>
                </div>
              </div>
              <span className={`px-2.5 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded-full ${
                request.status === 'Open' ? 'bg-blue-500/10 text-blue-400' :
                request.status === 'In Progress' ? 'bg-amber-500/10 text-amber-400' :
                'bg-emerald-500/10 text-emerald-400'
              }`}>
                {request.status}
              </span>
            </div>
            
            <div className="p-4 flex-1">
              <p className="text-slate-300 text-sm">{request.description}</p>
            </div>

            <div className="p-4 bg-slate-900 border-t flex items-center justify-between mt-auto">
              <div className="flex items-center gap-1 text-xs text-slate-400 font-medium">
                <Clock size={14} /> {request.requestedAt}
              </div>
              
              <div className="flex gap-2">
                {request.status !== 'Completed' && (
                  <button className="text-xs font-medium bg-slate-950 border border-slate-700 text-slate-300 hover:bg-slate-900 px-3 py-1.5 rounded">
                    {request.status === 'Open' ? 'Assign' : 'Update'}
                  </button>
                )}
                {request.status !== 'Completed' && (
                  <button className="text-xs font-medium bg-brand-primary text-white hover:bg-brand-primary/90 px-3 py-1.5 rounded flex items-center gap-1">
                    <CheckCircle2 size={14} /> Resolve
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
