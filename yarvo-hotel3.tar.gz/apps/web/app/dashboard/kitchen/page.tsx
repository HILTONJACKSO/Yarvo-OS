'use client';

import { useState, useEffect } from 'react';
import { ChefHat, Clock, CheckCircle2, AlertCircle, Maximize2, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';
import { io } from 'socket.io-client';

export default function KitchenDisplayPage() {
  const [currentTime, setCurrentTime] = useState(new Date());

  const [tickets, setTickets] = useState<any[]>([]);

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;
        const res = await fetch('http://127.0.0.1:3002/kitchen-display/tickets', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          // Ensure dates are parsed correctly
          const parsed = data.map((t: any) => ({ ...t, receivedAt: new Date(t.receivedAt) }));
          setTickets(parsed);
        }
      } catch (err) {
        console.error('Error fetching tickets', err);
      }
    };

    fetchTickets();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('kitchen.updated', fetchTickets);
    socket.on('orders.updated', fetchTickets);

    return () => {
      socket.off('kitchen.updated', fetchTickets);
      socket.off('orders.updated', fetchTickets);
      socket.disconnect();
    };
  }, []);

  const updateTicketStatus = async (id: string, newStatus: string) => {
    const token = localStorage.getItem('access_token');
    await fetch(`http://127.0.0.1:3002/kitchen-display/tickets/${id}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status: newStatus })
    });
    setTickets(tickets.map(t => t.id === id ? { ...t, status: newStatus } : t));
  };

  const newTickets = tickets.filter(t => t.status === 'NEW');
  const preparingTickets = tickets.filter(t => t.status === 'PREPARING');
  const readyTickets = tickets.filter(t => t.status === 'READY');

  const TicketCard = ({ ticket }: { ticket: any }) => {
    const elapsedMins = Math.floor((currentTime.getTime() - ticket.receivedAt.getTime()) / 60000);
    const isLate = elapsedMins > 20;

    return (
      <div className={`bg-slate-950 rounded-xl border-2 shadow-sm overflow-hidden flex flex-col ${
        ticket.priority === 'VIP' ? 'border-amber-400' : 
        isLate ? 'border-red-400' : 'border-slate-800'
      }`}>
        {/* Header */}
        <div className={`p-3 text-white flex items-center justify-between ${
          ticket.priority === 'VIP' ? 'bg-amber-500' : 
          isLate ? 'bg-red-500' : 'bg-gray-800'
        }`}>
          <div>
            <h3 className="font-bold">{ticket.table}</h3>
            <p className="text-xs opacity-80">{ticket.id} â€¢ {ticket.orderType.replace('_', ' ')}</p>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-xl font-bold font-mono">{elapsedMins}m</span>
            {ticket.priority === 'VIP' && <span className="text-xs font-bold bg-slate-950 text-amber-500 px-1 rounded uppercase">VIP</span>}
          </div>
        </div>

        {/* Items */}
        <div className="p-4 flex-1 bg-slate-950">
          <ul className="space-y-4">
            {ticket.items.map((item: any, i: number) => (
              <li key={i} className="border-b border-slate-800 pb-3 last:border-0 last:pb-0">
                <div className="flex items-start gap-3">
                  <span className="font-bold text-lg text-slate-50 w-6">{item.quantity}x</span>
                  <div>
                    <p className="font-bold text-slate-50 text-lg leading-tight">{item.name}</p>
                    {item.modifiers.length > 0 && (
                      <p className="text-sm text-slate-400 mt-1">
                        <span className="text-brand-primary font-medium">+</span> {item.modifiers.join(', ')}
                      </p>
                    )}
                    {item.note && (
                      <p className="text-sm text-red-600 mt-1 bg-red-50 p-1.5 rounded inline-block font-medium">
                        * {item.note}
                      </p>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Actions */}
        <div className="p-3 border-t border-slate-800 bg-slate-900 flex gap-2">
          {ticket.status === 'NEW' && (
            <button 
              onClick={() => updateTicketStatus(ticket.id, 'PREPARING')}
              className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition"
            >
              Start Preparing
            </button>
          )}
          {ticket.status === 'PREPARING' && (
            <button 
              onClick={() => updateTicketStatus(ticket.id, 'READY')}
              className="flex-1 bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 transition flex items-center justify-center gap-2"
            >
              <CheckCircle2 size={20} /> Mark Ready
            </button>
          )}
          {ticket.status === 'READY' && (
            <div className="flex-1 text-center py-3 text-green-700 font-bold bg-emerald-500/10 rounded-lg">
              Ready for Pickup
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="h-[calc(100vh-64px)] bg-gray-900 flex flex-col overflow-hidden -m-8">
      {/* KDS Header */}
      <div className="bg-gray-800 text-white p-4 flex items-center justify-between border-b border-gray-700 shrink-0">
        <div className="flex items-center gap-4">
          <div className="bg-brand-primary p-2 rounded-lg">
            <ChefHat size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Kitchen Display</h1>
            <p className="text-sm text-gray-400">Main Kitchen Station</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-gray-300">
            <span className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></span>
            Live Updates Active
          </div>
          <div className="text-2xl font-mono font-bold tracking-wider">
            {format(currentTime, 'HH:mm')}
          </div>
          <button className="p-2 hover:bg-gray-700 rounded-lg transition text-gray-300">
            <Maximize2 size={20} />
          </button>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="flex-1 overflow-hidden p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
          
          {/* New Column */}
          <div className="flex flex-col bg-gray-800/50 rounded-2xl overflow-hidden border border-gray-700">
            <div className="p-4 bg-gray-800 border-b border-gray-700 flex justify-between items-center shrink-0">
              <h2 className="font-bold text-lg text-white flex items-center gap-2">
                <AlertCircle size={20} className="text-blue-400" />
                NEW ({newTickets.length})
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {newTickets.map(t => <TicketCard key={t.id} ticket={t} />)}
            </div>
          </div>

          {/* Preparing Column */}
          <div className="flex flex-col bg-gray-800/50 rounded-2xl overflow-hidden border border-gray-700">
            <div className="p-4 bg-gray-800 border-b border-gray-700 flex justify-between items-center shrink-0">
              <h2 className="font-bold text-lg text-white flex items-center gap-2">
                <Clock size={20} className="text-amber-400" />
                PREPARING ({preparingTickets.length})
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {preparingTickets.map(t => <TicketCard key={t.id} ticket={t} />)}
            </div>
          </div>

          {/* Ready Column */}
          <div className="flex flex-col bg-gray-800/50 rounded-2xl overflow-hidden border border-gray-700">
            <div className="p-4 bg-gray-800 border-b border-gray-700 flex justify-between items-center shrink-0">
              <h2 className="font-bold text-lg text-white flex items-center gap-2">
                <CheckCircle2 size={20} className="text-green-400" />
                READY ({readyTickets.length})
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {readyTickets.map(t => <TicketCard key={t.id} ticket={t} />)}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
