"use client";

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Plus, Clock, Building2 } from 'lucide-react';
import { io } from 'socket.io-client';

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];

export default function OperatingHoursPage() {
  const [hours, setHours] = useState<any[]>([]);
  const [areas, setAreas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  const [token, setToken] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');

  const [formData, setFormData] = useState({
    dayOfWeek: 'MONDAY',
    openTime: '09:00',
    closeTime: '22:00',
    isClosed: false,
    propertyAreaId: 'none',
  });

  const fetchData = async (t: string, bId: string) => {
    try {
      const headers = { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId };
      const [resHours, resAreas] = await Promise.all([
        fetch(`http://127.0.0.1:3002/operating-hours`, { headers }),
        fetch(`http://127.0.0.1:3002/property-areas`, { headers })
      ]);
      const dataHours = await resHours.json();
      const dataAreas = await resAreas.json();
      
      setHours(Array.isArray(dataHours) ? dataHours : []);
      setAreas(Array.isArray(dataAreas) ? dataAreas : []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${t}` }})
      .then(r => r.json())
      .then(data => {
        if (!data || !Array.isArray(data) || data.length === 0) return;
        setBusinessId(data[0].businessId);
        const bId = data[0].business.branches?.[0]?.id;
        setBranchId(bId);
        fetchData(t, bId).finally(() => setLoading(false));

        const socket = io('http://127.0.0.1:3002', {
          auth: { token: t }
        });

        socket.on('property.hours.updated', () => {
          fetchData(t, bId);
        });

        return () => {
          socket.disconnect();
        };
      });
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        propertyAreaId: formData.propertyAreaId === 'none' ? null : formData.propertyAreaId,
      };

      const res = await fetch(`http://127.0.0.1:3002/operating-hours`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsAdding(false);
        setFormData({ dayOfWeek: 'MONDAY', openTime: '09:00', closeTime: '22:00', isClosed: false, propertyAreaId: 'none' });
        fetchData(token, branchId);
      }
    } catch (err) { console.error(err); }
  };

  if (loading) return <div className="text-slate-400">Loading operating hours...</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Operating Hours</h1>
          <p className="text-slate-400 text-sm">Set global or area-specific opening and closing times.</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-brand-primary flex items-center gap-2">
          {isAdding ? 'Cancel' : <><Plus size={16} /> Add Hours</>}
        </Button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Day of Week</Label>
            <Select value={formData.dayOfWeek} onValueChange={v => setFormData({...formData, dayOfWeek: v || ''})}>
              <SelectTrigger><SelectValue placeholder="Select day" /></SelectTrigger>
              <SelectContent>
                {DAYS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Specific Area (Optional)</Label>
            <Select value={formData.propertyAreaId || ''} onValueChange={v => setFormData({...formData, propertyAreaId: v || ''})}>
              <SelectTrigger><SelectValue placeholder="Global (Entire Branch)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Global (Entire Branch)</SelectItem>
                {areas.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center gap-4 md:col-span-2 bg-slate-900 p-4 rounded-lg">
            <Switch checked={formData.isClosed} onCheckedChange={c => setFormData({...formData, isClosed: c})} />
            <div>
              <div className="font-medium text-slate-50">Mark as Closed</div>
              <div className="text-xs text-slate-400">Enable this if the area is completely closed on this day.</div>
            </div>
          </div>

          {!formData.isClosed && (
            <>
              <div className="space-y-2">
                <Label>Opening Time</Label>
                <Input type="time" required value={formData.openTime} onChange={e => setFormData({...formData, openTime: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Closing Time</Label>
                <Input type="time" required value={formData.closeTime} onChange={e => setFormData({...formData, closeTime: e.target.value})} />
              </div>
            </>
          )}

          <div className="md:col-span-2 flex justify-end mt-2">
            <Button type="submit" className="bg-brand-primary">Save Operating Hours</Button>
          </div>
        </form>
      )}

      {hours.length === 0 && !isAdding ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <Clock className="mx-auto h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-50 mb-1">No operating hours defined</h3>
          <p className="text-slate-400 mb-4">Set your general opening and closing times.</p>
          <Button onClick={() => setIsAdding(true)} variant="outline">Add First Schedule</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {hours.map(h => (
            <div key={h.id} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <Clock size={24} />
              </div>
              <div className="w-full">
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-slate-50 capitalize">{h.dayOfWeek.toLowerCase()}</h3>
                  {h.propertyAreaId ? (
                    <span className="bg-indigo-50 text-indigo-700 text-[10px] px-2 py-0.5 rounded-full font-semibold">Area Specific</span>
                  ) : (
                    <span className="bg-slate-800 text-slate-400 text-[10px] px-2 py-0.5 rounded-full font-semibold">Global</span>
                  )}
                </div>
                
                {h.isClosed ? (
                  <div className="text-sm font-semibold text-red-500 mt-2">CLOSED</div>
                ) : (
                  <div className="text-sm font-medium text-slate-400 mt-2">
                    {h.openTime} â€” {h.closeTime}
                  </div>
                )}
                
                {h.propertyAreaId && (
                  <div className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                    <Building2 size={12} /> {areas.find(a => a.id === h.propertyAreaId)?.name || 'Unknown Area'}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
