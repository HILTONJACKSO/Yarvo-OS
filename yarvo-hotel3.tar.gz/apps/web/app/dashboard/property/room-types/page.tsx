"use client";

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, BedDouble } from 'lucide-react';

export default function RoomTypesPage() {
  const [types, setTypes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  const [token, setToken] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    basePrice: '',
    capacity: '',
  });

  const fetchData = async (t: string, bId: string) => {
    try {
      const res = await fetch(`http://127.0.0.1:3002/room-types`, {
        headers: { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId }
      });
      const data = await res.json();
      setTypes(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${t}` }})
      .then(r => r.json())
      .then(data => {
        if (!data || !Array.isArray(data) || data.length === 0) return;
        setBusinessId(data[0].businessId);
        const bId = data[0].business.branches?.[0]?.id;
        setBranchId(bId);
        fetchData(t, bId).finally(() => setLoading(false));
      });
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        basePrice: formData.basePrice ? parseFloat(formData.basePrice) : 0,
        capacity: formData.capacity ? parseInt(formData.capacity) : 1,
      };

      const res = await fetch(`http://127.0.0.1:3002/room-types`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsAdding(false);
        setFormData({ name: '', description: '', basePrice: '', capacity: '' });
        fetchData(token, branchId);
      } else {
        alert('Failed to save room type');
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div className="text-slate-400">Loading room types...</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Room Types</h1>
          <p className="text-slate-400 text-sm">Define standard configurations for your hotel rooms.</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-brand-primary flex items-center gap-2">
          {isAdding ? 'Cancel' : <><Plus size={16} /> Add Room Type</>}
        </Button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Type Name</Label>
            <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Deluxe Double Room" />
          </div>
          <div className="space-y-2">
            <Label>Base Price per Night</Label>
            <Input type="number" step="0.01" required value={formData.basePrice} onChange={e => setFormData({...formData, basePrice: e.target.value})} placeholder="0.00" />
          </div>
          <div className="space-y-2">
            <Label>Capacity (Adults)</Label>
            <Input type="number" required value={formData.capacity} onChange={e => setFormData({...formData, capacity: e.target.value})} placeholder="e.g. 2" />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Input value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Short description of the room type" />
          </div>
          <div className="md:col-span-2 flex justify-end mt-2">
            <Button type="submit" className="bg-brand-primary">Save Room Type</Button>
          </div>
        </form>
      )}

      {types.length === 0 && !isAdding ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <BedDouble className="mx-auto h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-50 mb-1">No room types defined</h3>
          <p className="text-slate-400 mb-4">Create room types before adding individual rooms.</p>
          <Button onClick={() => setIsAdding(true)} variant="outline">Add First Room Type</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {types.map(t => (
            <div key={t.id} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-lg bg-brand-primary/10 text-brand-primary flex items-center justify-center">
                  <BedDouble size={24} />
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-slate-50">${t.basePrice}</div>
                  <div className="text-xs text-slate-400">per night</div>
                </div>
              </div>
              <h3 className="font-bold text-lg text-slate-50 mb-1">{t.name}</h3>
              <p className="text-sm text-slate-400 mb-4">{t.description || 'No description provided.'}</p>
              
              <div className="flex items-center gap-4 text-sm text-slate-400">
                <div className="bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
                  Up to {t.capacity} guests
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
