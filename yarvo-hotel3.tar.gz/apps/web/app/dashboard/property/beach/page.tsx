"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Umbrella, Sun, Palmtree, Waves } from 'lucide-react';

export default function BeachSetupPage() {
  const [spots, setSpots] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({ name: '', type: 'CABANA', capacity: '2', basePrice: '0' });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSpots([...spots, { id: Date.now().toString(), ...formData }]);
    setIsAdding(false);
    setFormData({ name: '', type: 'CABANA', capacity: '2', basePrice: '0' });
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'CABANA': return <Palmtree className="text-emerald-500 w-6 h-6" />;
      case 'UMBRELLA': return <Umbrella className="text-blue-500 w-6 h-6" />;
      case 'CHAIR': return <Sun className="text-amber-500 w-6 h-6" />;
      default: return <Waves className="text-cyan-500 w-6 h-6" />;
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50 flex items-center gap-2">
            <Waves className="w-6 h-6 text-brand-primary" /> Beach Setup
          </h1>
          <p className="text-slate-400 text-sm mt-1">Manage cabanas, umbrellas, and beach chairs.</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-brand-primary hover:bg-brand-secondary text-white">
          {isAdding ? 'Cancel' : <><Plus size={16} className="mr-2" /> Add Beach Spot</>}
        </Button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Spot Name / Number</Label>
            <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Cabana 01" />
          </div>
          <div className="space-y-2">
            <Label>Type</Label>
            <Select required value={formData.type} onValueChange={v => setFormData({...formData, type: v})}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="CABANA">Cabana</SelectItem>
                <SelectItem value="UMBRELLA">Umbrella & Chairs</SelectItem>
                <SelectItem value="CHAIR">Single Lounger</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Capacity (People)</Label>
            <Input type="number" required value={formData.capacity} onChange={e => setFormData({...formData, capacity: e.target.value})} placeholder="2" />
          </div>
          <div className="space-y-2">
            <Label>Base Price (Optional)</Label>
            <Input type="number" value={formData.basePrice} onChange={e => setFormData({...formData, basePrice: e.target.value})} placeholder="0" />
          </div>
          <div className="md:col-span-2 flex justify-end mt-4">
            <Button type="submit" className="bg-brand-primary">Save Beach Spot</Button>
          </div>
        </form>
      )}

      {spots.length === 0 && !isAdding ? (
        <div className="text-center py-16 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <Palmtree className="mx-auto h-16 w-16 text-slate-700 mb-4" />
          <h3 className="text-lg font-medium text-slate-200 mb-2">No Beach Spots Added</h3>
          <p className="text-slate-400 mb-6 max-w-md mx-auto">You haven't configured any beach assets yet. Add cabanas, umbrellas, or loungers to start managing reservations.</p>
          <Button onClick={() => setIsAdding(true)} variant="outline" className="border-brand-primary text-brand-primary hover:bg-brand-primary/10">Add First Spot</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {spots.map(spot => (
            <div key={spot.id} className="bg-slate-950 p-5 rounded-xl border border-slate-800 shadow-sm flex flex-col items-center justify-center text-center relative overflow-hidden hover:border-brand-primary/50 transition-colors">
              <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-brand-primary to-blue-500"></div>
              <div className="p-3 bg-slate-900 rounded-full mb-3">
                {getTypeIcon(spot.type)}
              </div>
              <div className="text-lg font-bold text-slate-50">{spot.name}</div>
              <div className="text-sm text-slate-400 capitalize">{spot.type.toLowerCase()}</div>
              <div className="mt-3 w-full flex justify-between text-xs text-slate-500 bg-slate-900 px-3 py-2 rounded-md">
                <span>Cap: {spot.capacity}</span>
                <span>${spot.basePrice}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
