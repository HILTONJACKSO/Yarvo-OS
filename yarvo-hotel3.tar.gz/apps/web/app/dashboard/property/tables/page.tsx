"use client";

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Grid2x2, Utensils, Beer, LayoutGrid } from 'lucide-react';

export default function TablesPage() {
  const [areas, setAreas] = useState<any[]>([]);
  const [tables, setTables] = useState<any[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [isAddingArea, setIsAddingArea] = useState(false);
  const [isAddingBulk, setIsAddingBulk] = useState(false);
  
  const [token, setToken] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');

  const [areaData, setAreaData] = useState({ name: '', serviceType: 'RESTAURANT', description: '' });
  const [tableData, setTableData] = useState({ prefix: '', startNum: '', endNum: '', capacity: '', seatingAreaId: '' });

  const fetchData = async (t: string, bId: string) => {
    try {
      const headers = { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId };
      const [resAreas, resTables] = await Promise.all([
        fetch(`http://127.0.0.1:3002/seating-areas`, { headers }),
        fetch(`http://127.0.0.1:3002/tables`, { headers }),
      ]);
      const dataAreas = await resAreas.json();
      const dataTables = await resTables.json();
      
      setAreas(Array.isArray(dataAreas) ? dataAreas : []);
      setTables(Array.isArray(dataTables) ? dataTables : []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${t}` }})
      .then(r => r.json())
      .then(data => {
        if (!data || !Array.isArray(data) || data.length === 0) return;
        setBusinessId(data[0].businessId);
        const bId = data[0].business.branches?.[0]?.id;
        setBranchId(bId);
        fetchData(t, bId).finally(() => setLoading(false));
      });
  }, []);

  const handleSaveArea = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`http://127.0.0.1:3002/seating-areas`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId },
        body: JSON.stringify(areaData)
      });
      if (res.ok) {
        setIsAddingArea(false);
        setAreaData({ name: '', serviceType: 'RESTAURANT', description: '' });
        fetchData(token, branchId);
      }
    } catch (err) { console.error(err); }
  };

  const handleSaveTables = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        bulk: {
          prefix: tableData.prefix,
          startNum: parseInt(tableData.startNum),
          endNum: parseInt(tableData.endNum),
          capacity: parseInt(tableData.capacity),
          seatingAreaId: tableData.seatingAreaId,
        }
      };

      const res = await fetch(`http://127.0.0.1:3002/tables`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsAddingBulk(false);
        setTableData({ prefix: '', startNum: '', endNum: '', capacity: '', seatingAreaId: '' });
        fetchData(token, branchId);
      }
    } catch (err) { console.error(err); }
  };

  if (loading) return <div className="text-slate-400">Loading seating...</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Tables & Seating</h1>
          <p className="text-slate-400 text-sm">Manage restaurant tables, bar stools, and nightclub booths.</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => { setIsAddingArea(!isAddingArea); setIsAddingBulk(false); }} variant="outline" className="flex items-center gap-2">
            {isAddingArea ? 'Cancel' : <><Plus size={16} /> New Area</>}
          </Button>
          <Button onClick={() => { setIsAddingBulk(!isAddingBulk); setIsAddingArea(false); }} className="bg-brand-primary flex items-center gap-2">
            {isAddingBulk ? 'Cancel' : <><LayoutGrid size={16} /> Bulk Add Tables</>}
          </Button>
        </div>
      </div>

      {isAddingArea && (
        <form onSubmit={handleSaveArea} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Seating Area Name</Label>
            <Input required value={areaData.name} onChange={e => setAreaData({...areaData, name: e.target.value})} placeholder="e.g. Main Dining Room" />
          </div>
          <div className="space-y-2">
            <Label>Service Type</Label>
            <Select value={areaData.serviceType} onValueChange={v => setAreaData({...areaData, serviceType: v || ''})}>
              <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="RESTAURANT">Restaurant</SelectItem>
                <SelectItem value="BAR">Bar</SelectItem>
                <SelectItem value="NIGHTCLUB">Nightclub VIP</SelectItem>
                <SelectItem value="LOUNGE">Lounge</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2 space-y-2">
            <Label>Description</Label>
            <Input value={areaData.description} onChange={e => setAreaData({...areaData, description: e.target.value})} placeholder="Optional notes" />
          </div>
          <div className="md:col-span-2 flex justify-end mt-2">
            <Button type="submit" className="bg-brand-primary">Save Area</Button>
          </div>
        </form>
      )}

      {isAddingBulk && (
        <form onSubmit={handleSaveTables} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div className="md:col-span-2 space-y-2">
            <Label>Seating Area</Label>
            <Select required value={tableData.seatingAreaId} onValueChange={v => setTableData({...tableData, seatingAreaId: v || ''})}>
              <SelectTrigger>
                {tableData.seatingAreaId ? (() => {
                  const a = areas.find(a => a.id === tableData.seatingAreaId);
                  return a ? `${a.name} (${a.serviceType})` : <span className="text-slate-400">Select area</span>;
                })() : <span className="text-slate-400">Select area</span>}
              </SelectTrigger>
              <SelectContent>
                {areas.map(a => <SelectItem key={a.id} value={a.id}>{a.name} ({a.serviceType})</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Default Capacity</Label>
            <Input type="number" required value={tableData.capacity} onChange={e => setTableData({...tableData, capacity: e.target.value})} placeholder="e.g. 4" />
          </div>
          <div className="space-y-2">
            <Label>Prefix (Optional)</Label>
            <Input value={tableData.prefix} onChange={e => setTableData({...tableData, prefix: e.target.value})} placeholder="e.g. Table" />
          </div>
          <div className="grid grid-cols-2 gap-2 md:col-span-2">
            <div className="space-y-2">
              <Label>Start Number</Label>
              <Input type="number" required value={tableData.startNum} onChange={e => setTableData({...tableData, startNum: e.target.value})} placeholder="1" />
            </div>
            <div className="space-y-2">
              <Label>End Number</Label>
              <Input type="number" required value={tableData.endNum} onChange={e => setTableData({...tableData, endNum: e.target.value})} placeholder="20" />
            </div>
          </div>
          <div className="md:col-span-2 flex justify-end mt-2">
            <Button type="submit" className="bg-brand-primary w-full">Generate Tables</Button>
          </div>
        </form>
      )}

      {areas.length === 0 && !isAddingArea ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <Utensils className="mx-auto h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-50 mb-1">No seating areas defined</h3>
          <p className="text-slate-400 mb-4">Create a seating area (like Main Dining Room) before adding tables.</p>
          <Button onClick={() => setIsAddingArea(true)} variant="outline">Add Seating Area</Button>
        </div>
      ) : (
        <div className="space-y-8">
          {areas.map(area => {
            const areaTables = tables.filter(t => t.seatingAreaId === area.id);
            return (
              <div key={area.id} className="bg-slate-950 rounded-xl border border-slate-800 shadow-sm overflow-hidden">
                <div className="bg-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-brand-primary/10 text-brand-primary rounded-lg flex items-center justify-center">
                      {area.serviceType === 'BAR' ? <Beer size={20} /> : <Utensils size={20} />}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-50">{area.name}</h3>
                      <p className="text-xs text-slate-400">{area.serviceType} â€¢ {areaTables.length} Tables</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => { setTableData({...tableData, seatingAreaId: area.id}); setIsAddingBulk(true); }}>Add Tables</Button>
                </div>
                
                <div className="p-6">
                  {areaTables.length === 0 ? (
                    <div className="text-center py-6 text-gray-400 text-sm">No tables added to this area yet.</div>
                  ) : (
                    <div className="grid grid-cols-3 md:grid-cols-6 lg:grid-cols-8 gap-4">
                      {areaTables.map(table => (
                        <div key={table.id} className="border border-slate-800 rounded-lg p-3 text-center hover:border-brand-primary cursor-pointer transition-colors">
                          <Grid2x2 className="mx-auto h-6 w-6 text-gray-400 mb-2" />
                          <div className="font-bold text-slate-50 text-sm">{table.name}</div>
                          <div className="text-xs text-slate-400">{table.capacity} seats</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
