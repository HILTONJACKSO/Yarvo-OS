"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Building, ArrowRight, CheckCircle2, Circle } from 'lucide-react';
import Link from 'next/link';

export default function PropertySetupPage() {
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('access_token');
    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${token}` }})
      .then(r => r.json())
      .then(businessData => {
        if (!businessData || !Array.isArray(businessData) || businessData.length === 0) {
          setLoading(false);
          return null;
        }
        setData(businessData[0]);
        setLoading(false);
      })
      .catch(console.error);
  }, []);

  if (loading) return <div className="text-slate-400">Loading Property Setup...</div>;
  if (!data) return <div className="text-red-500">No business found.</div>;

  const branch = data.business.branches?.[0];
  const services = branch?.services || [];
  
  const hasServices = services.some((s: any) => s.isEnabled);
  // Calculate progress
  const setupProgress = hasServices ? 40 : 0;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-50 mb-2">Set Up Your Property</h1>
        <p className="text-slate-400 text-lg">Tell the system what your business offers and how your property is organized.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="bg-slate-950 p-8 rounded-xl shadow-sm border border-slate-800 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Building size={120} />
            </div>
            
            <h2 className="text-xl font-bold text-slate-50 mb-6 relative z-10">Setup Checklist</h2>
            
            <div className="space-y-4 relative z-10">
              <div className="flex items-start gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800">
                {hasServices ? <CheckCircle2 className="text-emerald-500 mt-0.5" /> : <Circle className="text-gray-300 mt-0.5" />}
                <div>
                  <h3 className="font-semibold text-slate-50">1. Select Services</h3>
                  <p className="text-sm text-slate-400 mb-3">Choose the amenities your branch offers (Hotel, Restaurant, Beach, etc.)</p>
                  {!hasServices && (
                    <Button onClick={() => router.push('/dashboard/property/services')} size="sm" className="bg-brand-primary">Start Setup</Button>
                  )}
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800 opacity-70">
                <Circle className="text-gray-300 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-slate-50">2. Create Property Areas</h3>
                  <p className="text-sm text-slate-400">Map out buildings, floors, and physical sections.</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800 opacity-70">
                <Circle className="text-gray-300 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-slate-50">3. Add Rooms and Spaces</h3>
                  <p className="text-sm text-slate-400">Create rooms, restaurant tables, or beach cabanas.</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-lg bg-slate-900 border border-slate-800 opacity-70">
                <Circle className="text-gray-300 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-slate-50">4. Review Setup</h3>
                  <p className="text-sm text-slate-400">Review your final configuration.</p>
                </div>
              </div>
            </div>
            
            {hasServices && (
              <div className="mt-8 pt-6 border-t border-slate-800 flex justify-end">
                <Button onClick={() => router.push('/dashboard/property/areas')} className="bg-brand-primary flex items-center gap-2">
                  Continue Setup <ArrowRight size={16} />
                </Button>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-950 p-6 rounded-xl shadow-sm border border-slate-800 text-center">
            <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2">Setup Progress</h3>
            <div className="text-4xl font-bold text-brand-primary mb-4">{setupProgress}%</div>
            <div className="w-full bg-slate-800 rounded-full h-2 mb-2">
              <div className="bg-brand-primary h-2 rounded-full" style={{ width: `${setupProgress}%` }}></div>
            </div>
            <p className="text-xs text-slate-400">Property setup is {setupProgress}% complete.</p>
          </div>
          
          <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-xl text-indigo-900">
            <h3 className="font-bold mb-2 flex items-center gap-2"><Building size={18} /> Why do this?</h3>
            <p className="text-sm opacity-80 leading-relaxed">
              Setting up your property structure is required before you can accept reservations, assign staff to specific areas, or manage table orders.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
