"use client";

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, MonitorSmartphone } from 'lucide-react';
import { io } from 'socket.io-client';

export default function ServicePointsPage() {
  const [points, setPoints] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  const [token, setToken] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    pointType: 'POS',
    description: '',
  });

  const fetchData = async (t: string, bId: string) => {
    try {
      const res = await fetch(`http://127.0.0.1:3002/service-points`, {
        headers: { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId }
      });
      const data = await res.json();
      setPoints(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${t}` }})
      .then(r => r.json())
      .then(data => {
        if (!data || !Array.isArray(data) || data.length === 0) return;
        setBusinessId(data[0].businessId);
        const bId = data[0].business.branches?.[0]?.id;
        setBranchId(bId);
        fetchData(t, bId);

        const socket = io('http://127.0.0.1:3002', {
          auth: { token: t }
        });

        socket.on('property.servicePoint.updated', () => {
          fetchData(t, bId);
        });

        return () => {
          socket.disconnect();
        };
      });
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const businessId = localStorage.getItem('business_id');
      const url = `${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/property/service-points`;
      
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || '' },
        body: JSON.stringify({ ...formData, code: formData.name.toUpperCase().replace(/\s+/g, '_') })
      });

      if (res.ok) {
        setIsAdding(false);
        setFormData({ name: '', pointType: 'POS', description: '' });
        fetchData(token, branchId);
      }
    } catch (err) { console.error(err); }
  };

  if (loading) return <div className="text-slate-400">Loading service points...</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Service Points & POS</h1>
          <p className="text-slate-400 text-sm">Define physical terminals like Reception Desks, Bar Registers, or Kiosks.</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-brand-primary flex items-center gap-2">
          {isAdding ? 'Cancel' : <><Plus size={16} /> Add Service Point</>}
        </Button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Main Bar POS 1" />
          </div>
          <div className="space-y-2">
            <Label>Type</Label>
            <Select value={formData.pointType || ''} onValueChange={v => setFormData({...formData, pointType: v || ''})}>
              <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="POS">Point of Sale (POS)</SelectItem>
                <SelectItem value="RECEPTION">Reception Desk</SelectItem>
                <SelectItem value="KIOSK">Self-Service Kiosk</SelectItem>
                <SelectItem value="CONCIERGE">Concierge Desk</SelectItem>
                <SelectItem value="DISPATCH">Kitchen Dispatch</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2 space-y-2">
            <Label>Description</Label>
            <Input value={formData.description || ''} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Optional notes" />
          </div>
          <div className="md:col-span-2 flex justify-end mt-2">
            <Button type="submit" className="bg-brand-primary">Save Service Point</Button>
          </div>
        </form>
      )}

      {points.length === 0 && !isAdding ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <MonitorSmartphone className="mx-auto h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-50 mb-1">No service points defined</h3>
          <p className="text-slate-400 mb-4">Add your first POS or reception desk.</p>
          <Button onClick={() => setIsAdding(true)} variant="outline">Add Service Point</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {points.map(p => (
            <div key={p.id} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                <MonitorSmartphone size={24} />
              </div>
              <div>
                <h3 className="font-bold text-slate-50">{p.name}</h3>
                <div className="text-xs text-slate-400 mb-2">{p.pointType}</div>
                <div className="text-sm text-slate-400">{p.description}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
