"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { LogOut, AlertTriangle, CheckCircle, Clock, Search, UserMinus, FileText, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';

export default function CheckoutsDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState({
    departuresToday: 0,
    pendingCheckouts: 0,
    completedToday: 0,
    outstandingBalances: 0
  });
  const [pendingList, setPendingList] = useState<any[]>([]);
  const [historyList, setHistoryList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const [statsRes, pendingRes, historyRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/checkouts/stats`),
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/checkouts/pending`),
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/checkouts/history`)
        ]);

        if (statsRes.ok) setStats(await statsRes.json());
        if (pendingRes.ok) {
          const p = await pendingRes.json();
          setPendingList(p.slice(0, 5));
        }
        if (historyRes.ok) {
          const h = await historyRes.json();
          setHistoryList(h.slice(0, 5));
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboard();

    const onUpdate = () => fetchDashboard();
    // Assuming checkouts might be impacted by stay updates or checkout updates
    socket.on('stays.updated', onUpdate);
    socket.on('checkouts.updated', onUpdate);

    return () => {
      socket.off('stays.updated', onUpdate);
      socket.off('checkouts.updated', onUpdate);
    };
  }, []);

  if (loading) {
    return <div className="p-8 text-center text-slate-400">Loading Checkout Dashboard...</div>;
  }

  const statCards = [
    { title: "Departures Today", value: stats.departuresToday, icon: UserMinus, color: "text-blue-600", bg: "bg-blue-50", link: "/dashboard/checkouts/departures" },
    { title: "Pending Checkouts", value: stats.pendingCheckouts, icon: Clock, color: "text-amber-600", bg: "bg-amber-50", link: "/dashboard/checkouts/pending" },
    { title: "Completed Today", value: stats.completedToday, icon: CheckCircle, color: "text-green-600", bg: "bg-green-50", link: "/dashboard/checkouts/history" },
    { title: "Outstanding Balances", value: stats.outstandingBalances, icon: AlertTriangle, color: "text-red-600", bg: "bg-red-50", link: "/dashboard/checkouts/outstanding" },
  ];

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Checkout Dashboard</h1>
          <p className="text-slate-400 mt-1">Manage guest departures, room release, and final invoicing</p>
        </div>
        <div className="flex gap-3">
          <Link href="/dashboard/checkouts/history" className="px-4 py-2 border border-slate-700 rounded-md text-sm font-medium hover:bg-slate-900 transition">
            View History
          </Link>
          <Link href="/dashboard/checkouts/new" className="px-4 py-2 bg-brand-primary text-white rounded-md text-sm font-medium hover:bg-brand-primary/90 transition flex items-center gap-2">
            <LogOut size={16} /> New Checkout
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, i) => (
          <Link key={i} href={stat.link} className="bg-slate-950 rounded-xl shadow-sm border p-6 flex items-start justify-between hover:shadow-md transition group">
            <div>
              <p className="text-sm text-slate-400 font-medium">{stat.title}</p>
              <h3 className="text-3xl font-bold text-slate-50 mt-2 group-hover:text-brand-primary transition">{stat.value}</h3>
            </div>
            <div className={`p-3 rounded-lg ${stat.bg}`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
          </Link>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="p-6 border-b flex justify-between items-center">
            <h2 className="text-lg font-bold text-slate-50">Pending Checkouts</h2>
            <Link href="/dashboard/checkouts/pending" className="text-sm text-brand-primary hover:underline flex items-center gap-1">
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="p-0">
            <div className="divide-y">
              {pendingList.map((stay) => {
                const roomNum = stay.reservation?.reservationRooms?.[0]?.room?.number || '??';
                const guestName = stay.reservation?.customer?.displayName || 'Unknown';
                return (
                  <div key={stay.id} className="p-4 hover:bg-slate-900 transition flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center text-slate-400 font-bold text-sm">
                        {roomNum}
                      </div>
                      <div>
                        <p className="font-medium text-slate-50">{guestName}</p>
                        <p className="text-sm text-slate-400">Departure time: {new Date(stay.expectedDepartureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                      </div>
                    </div>
                    <Link href={`/dashboard/checkouts/checkout-${stay.id}`} className="text-sm bg-brand-primary/10 text-brand-primary px-3 py-1.5 rounded-md hover:bg-brand-primary hover:text-white transition font-medium">
                      Process
                    </Link>
                  </div>
                );
              })}
              {pendingList.length === 0 && (
                <div className="p-6 text-center text-slate-400">No pending checkouts.</div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="p-6 border-b flex justify-between items-center">
            <h2 className="text-lg font-bold text-slate-50">Recent Invoices</h2>
            <Link href="/dashboard/checkouts/history" className="text-sm text-brand-primary hover:underline flex items-center gap-1">
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="p-0">
            <div className="divide-y">
              {historyList.map((stay) => {
                const roomNum = stay.reservation?.reservationRooms?.[0]?.room?.number || '??';
                const guestName = stay.reservation?.customer?.displayName || 'Unknown';
                const totalBalance = stay.guestFolios?.reduce((acc: number, f: any) => acc + Number(f.balance), 0) || 0;
                return (
                  <div key={stay.id} className="p-4 hover:bg-slate-900 transition flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="font-medium text-slate-50">{guestName}</p>
                        <p className="text-sm text-slate-400">Room {roomNum}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-slate-50">${totalBalance.toFixed(2)}</p>
                      <p className="text-xs text-green-600 font-medium">Checked Out</p>
                    </div>
                  </div>
                );
              })}
              {historyList.length === 0 && (
                <div className="p-6 text-center text-slate-400">No recent checkouts.</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
