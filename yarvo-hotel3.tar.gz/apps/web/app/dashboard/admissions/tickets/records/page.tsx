"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, History, Ticket, CheckCircle2, XCircle } from 'lucide-react';
import io from 'socket.io-client';

export default function TicketRecordsPage() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchTickets = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/tickets/issued`);
      if (res.ok) {
        setTickets(await res.json());
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const filteredTickets = tickets.filter(t => 
    t.ticketNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.ticketType?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Ticket Records</h1>
          <p className="text-slate-400 mt-1">View all issued tickets, their current statuses, and validity records.</p>
        </div>
        <div className="flex items-center gap-3 bg-slate-900 border border-slate-800 rounded-lg p-1 text-slate-300">
          <div className="flex items-center gap-2 px-3">
            <History size={18} />
            <span className="font-medium">{tickets.length} Total</span>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-800 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by ticket ID or name..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-brand-primary"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition">
            <Filter size={16} />
            Filter
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="bg-slate-950/50 text-slate-400 border-b border-slate-800 uppercase text-xs tracking-wider">
              <tr>
                <th className="p-4 font-medium">Ticket ID</th>
                <th className="p-4 font-medium">Type</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium">Issue Date</th>
                <th className="p-4 font-medium">Valid From</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {loading ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500">Loading records...</td>
                </tr>
              ) : filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500">No tickets found matching your criteria.</td>
                </tr>
              ) : (
                filteredTickets.map(ticket => (
                  <tr key={ticket.id} className="hover:bg-slate-800/20 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-800/50 rounded-md text-brand-primary">
                          <Ticket size={16} />
                        </div>
                        <span className="font-medium text-slate-200">{ticket.ticketNumber}</span>
                      </div>
                    </td>
                    <td className="p-4 font-medium text-slate-300">
                      {ticket.ticketType?.name || 'Unknown'}
                    </td>
                    <td className="p-4">
                      {ticket.status === 'ACTIVE' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          <CheckCircle2 size={12} />
                          Active
                        </span>
                      )}
                      {ticket.status === 'USED' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-500/10 text-slate-400 border border-slate-500/20">
                          Used
                        </span>
                      )}
                      {ticket.status === 'EXPIRED' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-red-500/10 text-red-400 border border-red-500/20">
                          <XCircle size={12} />
                          Expired
                        </span>
                      )}
                      {!['ACTIVE', 'USED', 'EXPIRED'].includes(ticket.status) && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-500/10 text-slate-400 border border-slate-500/20">
                          {ticket.status}
                        </span>
                      )}
                    </td>
                    <td className="p-4 text-slate-400 whitespace-nowrap">
                      {new Date(ticket.createdAt).toLocaleString()}
                    </td>
                    <td className="p-4 text-slate-400 whitespace-nowrap">
                      {new Date(ticket.validFrom).toLocaleDateString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
