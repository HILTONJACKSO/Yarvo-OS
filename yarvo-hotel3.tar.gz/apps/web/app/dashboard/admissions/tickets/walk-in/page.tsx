"use client";

import { useState, useEffect } from 'react';
import { ShoppingCart, Ticket, Plus, Minus, CreditCard, Banknote, QrCode, X, Printer } from 'lucide-react';
import io from 'socket.io-client';
import { ConfirmationModal } from '@/components/ui/confirmation-modal';

export default function WalkInSalesPage() {
  const [cart, setCart] = useState<{id: string, name: string, price: number, quantity: number}[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [lastOrder, setLastOrder] = useState<any[]>([]);

  const fetchProducts = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/tickets/types`);
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
      }
    } catch (err) {
      console.error('Failed to fetch products', err);
    }
  };

  useEffect(() => {
    fetchProducts();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('admissions.updated', () => {
      fetchProducts();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  const addToCart = (product: any) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { id: product.id, name: product.name, price: product.basePrice || product.price || 0, quantity: 1 }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQ = item.quantity + delta;
        return newQ > 0 ? { ...item, quantity: newQ } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const taxes = subtotal * 0.1; // 10% standard tax rate
  const total = subtotal + taxes;

  const handleCheckout = async () => {
    setIsProcessing(true);
    
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/tickets/issue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tickets: cart }),
      });
      
      const issuedTickets = await res.json();
      
      setIsProcessing(false);
      setLastOrder([...cart]); // Wait, better to just save the cart items for the visual modal 
      setShowSuccess(true);
      setCart([]);
      setPaymentMethod(null);
    } catch (err) {
      console.error('Failed to issue tickets', err);
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto flex gap-6 h-[calc(100vh-8rem)]">
      
      {/* Product Catalog grid */}
      <div className="flex-1 flex flex-col space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Walk-in Ticket Sales</h1>
          <p className="text-slate-400 mt-1">Select tickets for immediate entry.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 overflow-y-auto pb-4">
          {products.length === 0 ? (
            <div className="col-span-full text-center text-slate-400 py-8">No ticket types available.</div>
          ) : (
            products.map(product => (
              <div 
                key={product.id} 
                onClick={() => addToCart(product)}
                className="bg-slate-950 p-6 rounded-xl border hover:border-brand-primary/50 hover:shadow-md cursor-pointer transition flex flex-col justify-between h-32"
              >
                <h3 className="font-bold text-slate-50">{product.name}</h3>
                <div className="flex justify-between items-center mt-4">
                  <span className="text-lg font-bold text-brand-primary">${(product.basePrice || product.price || 0).toFixed(2)}</span>
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
                    <Ticket size={16} />
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Cart Panel */}
      <div className="w-96 bg-slate-950 border rounded-xl shadow-sm flex flex-col overflow-hidden">
        <div className="p-4 bg-slate-900 border-b flex justify-between items-center">
          <h2 className="font-bold text-slate-50 flex items-center gap-2">
            <ShoppingCart size={18} /> Current Order
          </h2>
          <span className="text-sm font-medium text-slate-400">{cart.length} items</span>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-2">
              <Ticket size={48} className="opacity-20" />
              <p>No tickets selected</p>
            </div>
          ) : (
            cart.map(item => (
              <div key={item.id} className="flex justify-between items-start border-b pb-4">
                <div>
                  <h4 className="font-medium text-slate-50">{item.name}</h4>
                  <div className="text-brand-primary font-medium mt-1">${(item.price * item.quantity).toFixed(2)}</div>
                </div>
                <div className="flex items-center gap-2 bg-slate-900 rounded-lg p-1 border">
                  <button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-slate-950 rounded"><Minus size={14}/></button>
                  <span className="w-6 text-center font-medium">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-slate-950 rounded"><Plus size={14}/></button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-4 border-t bg-slate-900 space-y-3">
          <div className="flex justify-between text-sm text-slate-400">
            <span>Subtotal</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm text-slate-400">
            <span>Taxes (10%)</span>
            <span>${taxes.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-bold text-lg text-slate-50 pt-2 border-t">
            <span>Total to Pay</span>
            <span>${total.toFixed(2)}</span>
          </div>
        </div>

        <div className="p-4 bg-slate-950 border-t grid grid-cols-2 gap-2">
          <button 
            onClick={() => setPaymentMethod('cash')}
            className={`flex flex-col items-center justify-center gap-1 p-3 rounded-lg transition font-medium ${
              paymentMethod === 'cash' ? 'bg-brand-primary text-white border-brand-primary' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            } border`}
          >
            <Banknote size={20} />
            Cash
          </button>
          <button 
            onClick={() => setPaymentMethod('card')}
            className={`flex flex-col items-center justify-center gap-1 p-3 rounded-lg transition font-medium ${
              paymentMethod === 'card' ? 'bg-brand-primary text-white border-brand-primary' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            } border`}
          >
            <CreditCard size={20} />
            Card
          </button>
          <button 
            disabled={cart.length === 0 || !paymentMethod || isProcessing}
            onClick={handleCheckout}
            className={`col-span-2 flex items-center justify-center gap-2 p-3 rounded-lg transition font-medium mt-2 ${
              cart.length === 0 || !paymentMethod || isProcessing 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                : 'bg-brand-primary hover:bg-brand-secondary text-white'
            }`}
          >
            <QrCode size={18} />
            {isProcessing ? 'Processing...' : 'Issue QR Tickets'}
          </button>
        </div>
      </div>

      {showSuccess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-full animate-in fade-in zoom-in-95 duration-200">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
              <h2 className="text-xl font-bold text-slate-50">Print Tickets</h2>
              <button onClick={() => setShowSuccess(false)} className="text-slate-400 hover:text-white"><X size={20}/></button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1 space-y-6" id="printable-tickets">
              {lastOrder.flatMap(item => Array.from({length: item.quantity}).map((_, i) => (
                <div key={`${item.id}-${i}`} className="bg-white rounded-lg flex overflow-hidden text-slate-900 shadow-lg border border-slate-200">
                  <div className="w-2/3 p-6 border-r-2 border-dashed border-slate-300 flex flex-col justify-between relative bg-slate-50">
                    <div className="absolute -top-3 -right-3 w-6 h-6 bg-slate-900 rounded-full"></div>
                    <div className="absolute -bottom-3 -right-3 w-6 h-6 bg-slate-900 rounded-full"></div>
                    
                    <div>
                      <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Yarvo Admissions</div>
                      <h3 className="text-2xl font-black text-slate-900 leading-tight">{item.name}</h3>
                      <div className="text-sm text-slate-500 mt-1">Valid: {new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div className="mt-8 flex justify-between items-end">
                      <div className="font-mono text-xs text-slate-400">{Math.random().toString(36).substr(2, 9).toUpperCase()}-{Math.random().toString(36).substr(2, 9).toUpperCase()}</div>
                      <div className="text-xl font-bold text-brand-primary">${item.price.toFixed(2)}</div>
                    </div>
                  </div>
                  
                  <div className="w-1/3 bg-white p-6 flex flex-col items-center justify-center">
                    <QrCode size={80} className="text-slate-800" strokeWidth={1.5} />
                    <div className="mt-2 text-[10px] uppercase font-bold tracking-widest text-slate-400 text-center">Scan at Gate</div>
                  </div>
                </div>
              )))}
            </div>

            <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end gap-3">
              <button onClick={() => setShowSuccess(false)} className="px-4 py-2 rounded-md text-sm font-medium text-slate-300 hover:bg-slate-800 transition">
                Close
              </button>
              <button 
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 bg-brand-primary hover:bg-brand-secondary rounded-md text-sm font-medium text-white transition flex items-center gap-2"
              >
                <Printer size={16} />
                Print Tickets
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
