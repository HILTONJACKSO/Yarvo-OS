"use client";

import { useState } from 'react';
import { ScanLine, CheckCircle2, XCircle, Search } from 'lucide-react';

export default function GateScannerPage() {
  const [scanInput, setScanInput] = useState('');
  const [result, setResult] = useState<{ status: 'valid' | 'invalid' | null, message: string, details?: any }>({ status: null, message: '' });

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scanInput.trim()) {
      setResult({
        status: 'invalid',
        message: 'EMPTY INPUT',
        details: { error: 'Please scan a barcode or enter a ticket number.', action: 'Try again' }
      });
      return;
    }

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/tickets/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticketNumber: scanInput })
      });
      
      if (res.ok) {
        const data = await res.json();
        if (data.status === 'valid') {
          setResult({
            status: 'valid',
            message: 'GREEN / VALID',
            details: {
              name: data.ticket?.customerId || 'Walk-in',
              ticket: data.ticket?.ticketTypeId || 'General Access',
              count: '1 Guest',
              action: 'Allowed - Welcome'
            }
          });
        } else {
          setResult({
            status: 'invalid',
            message: 'RED / INVALID',
            details: {
              error: data.message,
              action: 'Entry Denied'
            }
          });
        }
      } else {
        setResult({
          status: 'invalid',
          message: 'ERROR',
          details: { error: 'Server Error', action: 'Try again' }
        });
      }
    } catch (err) {
      console.error(err);
      setResult({
        status: 'invalid',
        message: 'NETWORK ERROR',
        details: { error: 'Connection Failed', action: 'Try again' }
      });
    }
    
    setScanInput('');
  };

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col items-center justify-center p-6 font-mono text-white">
      <div className="absolute top-6 left-6">
        <h1 className="text-2xl font-bold tracking-widest text-gray-400">YARVO GATE CONTROL</h1>
        <p className="text-slate-400 text-sm">Location: Sunset Nightclub â€¢ Gate 1</p>
      </div>

      <button className="absolute top-6 right-6 px-4 py-2 bg-gray-800 rounded hover:bg-gray-700 transition" onClick={() => window.history.back()}>
        Close Scanner
      </button>

      {/* Simulator Input (for USB scanner or manual entry) */}
      <form onSubmit={handleScan} className="w-full max-w-lg mb-12">
        <div className="relative">
          <input 
            autoFocus
            type="text" 
            value={scanInput}
            onChange={(e) => setScanInput(e.target.value)}
            placeholder="Scan QR or enter ticket number..."
            className="w-full bg-gray-800 border-2 border-gray-700 rounded-lg py-4 pl-12 pr-4 text-xl focus:outline-none focus:border-brand-primary"
          />
          <ScanLine className="absolute left-4 top-4 text-slate-400" size={24} />
          <button type="submit" className="absolute right-2 top-2 bottom-2 bg-brand-primary px-4 rounded font-bold">SCAN</button>
        </div>
        <p className="text-center text-slate-400 mt-2 text-sm">Focus input field to use USB barcode scanner</p>
      </form>

      {/* Scan Result Full-Screen Display */}
      <div className="w-full max-w-4xl h-96 flex items-center justify-center rounded-2xl border-4 transition-colors overflow-hidden" 
           style={{ borderColor: result.status === 'valid' ? '#22c55e' : result.status === 'invalid' ? '#ef4444' : '#374151', backgroundColor: result.status === 'valid' ? 'rgba(34, 197, 94, 0.1)' : result.status === 'invalid' ? 'rgba(239, 68, 68, 0.1)' : 'transparent' }}>
        
        {result.status === null ? (
          <div className="text-slate-400 flex flex-col items-center gap-4">
            <ScanLine size={64} className="opacity-50 animate-pulse" />
            <h2 className="text-2xl font-bold tracking-widest">READY TO SCAN</h2>
          </div>
        ) : result.status === 'valid' ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-green-500/10 text-green-400">
            <CheckCircle2 size={96} className="mb-6" />
            <h2 className="text-5xl font-black mb-6 tracking-wider">{result.message}</h2>
            <div className="text-center text-2xl space-y-2 opacity-90">
              <p>{result.details?.name}</p>
              <p className="font-bold">{result.details?.ticket}</p>
              <p>{result.details?.count}</p>
            </div>
            <div className="mt-8 px-8 py-3 bg-green-500 text-white rounded-full text-2xl font-bold tracking-widest uppercase shadow-[0_0_30px_rgba(34,197,94,0.5)]">
              {result.details?.action}
            </div>
          </div>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-red-500/10 text-red-500">
            <XCircle size={96} className="mb-6" />
            <h2 className="text-5xl font-black mb-6 tracking-wider">{result.message}</h2>
            <div className="text-center text-3xl font-bold opacity-90 mb-8">
              {result.details?.error}
            </div>
            <div className="px-8 py-3 bg-red-500 text-white rounded-full text-xl font-bold tracking-widest uppercase shadow-[0_0_30px_rgba(239,68,68,0.5)]">
              {result.details?.action}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
