"use client";

import { useEffect, useState } from 'react';
import { Plus, Edit2, Shield, Settings2 } from 'lucide-react';
import Link from 'next/link';
import io from 'socket.io-client';

export default function VenuesPage() {
  const [venues, setVenues] = useState<any[]>([]);

  const fetchVenues = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/venues`);
      if (res.ok) {
        const data = await res.json();
        setVenues(data);
      }
    } catch (err) {
      console.error('Failed to fetch venues', err);
    }
  };

  useEffect(() => {
    fetchVenues();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('admissions.updated', () => {
      fetchVenues();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Venues & Capacity Configuration</h1>
          <p className="text-slate-400 mt-1">Manage physical spaces, capacities, and sub-areas.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
          <Plus size={18} /> Add Venue
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400">Venue Name</th>
              <th className="p-4 font-medium text-slate-400">Type</th>
              <th className="p-4 font-medium text-slate-400">Max Capacity</th>
              <th className="p-4 font-medium text-slate-400">Configured Areas</th>
              <th className="p-4 font-medium text-slate-400">Status</th>
              <th className="p-4 font-medium text-slate-400 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {venues.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-400">
                  No venues configured yet.
                </td>
              </tr>
            ) : (
              venues.map((venue) => (
                <tr key={venue.id} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">{venue.name}</td>
                  <td className="p-4">
                    <span className="px-2.5 py-1 bg-slate-800 text-slate-300 text-xs rounded-full font-medium">
                      {venue.venueType || venue.type}
                    </span>
                  </td>
                  <td className="p-4">{venue.maximumCapacity || venue.capacity} guests</td>
                  <td className="p-4 text-slate-400">
                    {venue.areas && venue.areas.length > 0 ? venue.areas.map((a: any) => a.name).join(', ') : 'None'}
                  </td>
                  <td className="p-4">
                    <span className={`px-2.5 py-1 text-xs rounded-full font-medium ${
                      venue.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-red-500/10 text-red-700'
                    }`}>
                      {venue.status}
                    </span>
                  </td>
                  <td className="p-4 text-right space-x-2">
                    <button className="p-2 text-gray-400 hover:text-brand-primary rounded-md hover:bg-brand-primary/10 transition">
                      <Settings2 size={16} />
                    </button>
                    <button className="p-2 text-gray-400 hover:text-brand-primary rounded-md hover:bg-brand-primary/10 transition">
                      <Edit2 size={16} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
