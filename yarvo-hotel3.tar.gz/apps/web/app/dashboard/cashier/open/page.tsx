"use client";

import { useState } from 'react';
import { Monitor, DollarSign, Clock, User, CheckCircle2 } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function OpenCashierShiftPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const [shiftData, setShiftData] = useState({
    registerId: '',
    openingCash: ''
  });

  const [registers, setRegisters] = useState<{id: string, name: string}[]>([]);

  useEffect(() => {
    const fetchRegisters = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch('http://127.0.0.1:3002/cash-registers', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setRegisters(data);
        }
      } catch (err) {
        console.error('Failed to fetch registers', err);
      }
    };
    fetchRegisters();
  }, []);

  const handleOpenShift = async () => {
    if (!shiftData.registerId) return;
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const res = await fetch('http://127.0.0.1:3002/cashier-shifts/open', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          cashRegisterId: shiftData.registerId,
          openingCash: shiftData.openingCash
        })
      });

      if (res.ok) {
        setSuccess(true);
        setTimeout(() => {
          router.push('/dashboard/cashier/my-shift');
        }, 1500);
      } else {
        const errorData = await res.json();
        alert(`Failed to open shift: ${errorData.message}`);
      }
    } catch (err) {
      console.error('Failed to open shift', err);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-md mx-auto mt-20 p-8 bg-slate-950 rounded-xl shadow-sm border border-slate-800 text-center">
        <div className="w-20 h-20 bg-emerald-500/10 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={40} />
        </div>
        <h2 className="text-2xl font-bold text-slate-50 mb-2">Shift Opened</h2>
        <p className="text-slate-400">Your cashier shift has successfully started. Redirecting to your shift dashboard...</p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-brand-primary/10 text-brand-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Monitor size={32} />
        </div>
        <h2 className="text-2xl font-bold text-slate-50">Open Cashier Shift</h2>
        <p className="text-slate-400 mt-1">Start a new shift and declare your opening cash float</p>
      </div>

      <div className="bg-slate-950 p-8 rounded-2xl shadow-sm border border-slate-800 space-y-6">
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Select Cash Register</label>
          <div className="relative">
            <Monitor className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <select 
              value={shiftData.registerId}
              onChange={e => setShiftData({...shiftData, registerId: e.target.value})}
              className="w-full pl-10 p-3 border border-slate-700 rounded-xl focus:ring-2 focus:ring-brand-primary outline-none"
            >
              <option value="">-- Choose a Register --</option>
              {registers.map(reg => (
                <option key={reg.id} value={reg.id}>{reg.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300">Opening Cash Float</label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="number" 
              value={shiftData.openingCash}
              onChange={e => setShiftData({...shiftData, openingCash: e.target.value})}
              className="w-full pl-10 p-3 border border-slate-700 rounded-xl focus:ring-2 focus:ring-brand-primary outline-none text-lg font-medium"
              placeholder="0.00"
            />
          </div>
          <p className="text-xs text-slate-400 mt-1">The amount of physical cash currently in the drawer.</p>
        </div>

        <div className="pt-4">
          <button 
            disabled={loading || !shiftData.registerId}
            onClick={handleOpenShift}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
              !shiftData.registerId || loading
                ? 'bg-slate-800 text-gray-400 cursor-not-allowed'
                : 'bg-brand-primary text-white hover:bg-brand-primary/90 shadow-lg hover:shadow-brand-primary/20'
            }`}
          >
            {loading ? 'Opening Shift...' : 'Start Shift'}
          </button>
        </div>
      </div>
      
      <div className="flex items-center justify-center gap-6 text-sm text-slate-400">
        <div className="flex items-center gap-2">
          <User size={16} />
          <span>Logged in as: <strong>Admin User</strong></span>
        </div>
        <div className="flex items-center gap-2">
          <Clock size={16} />
          <span>Time: <strong>{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</strong></span>
        </div>
      </div>
    </div>
  );
}
