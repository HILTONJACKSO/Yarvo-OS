"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit2, Trash2, Save, X, Search, Calendar, Bed, Wrench, AlertCircle, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';

export default function RoomBlocksPage() {
  const [blocks, setBlocks] = useState<any[]>([]);
  const [rooms, setRooms] = useState<any[]>([]);
  const [types, setTypes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);

  const [newBlock, setNewBlock] = useState({
    roomId: '',
    startDate: '',
    endDate: '',
    reason: 'MAINTENANCE',
    notes: ''
  });

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (t) {
      fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${t}` }})
        .then(r => r.json())
        .then(data => {
          if (!data || !Array.isArray(data) || data.length === 0) return;
          const bId = data[0].business.branches?.[0]?.id;
          
          const headers = { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId };
          Promise.all([
            fetch(`http://127.0.0.1:3002/rooms`, { headers }),
            fetch(`http://127.0.0.1:3002/room-types`, { headers }),
          ]).then(async ([resRooms, resTypes]) => {
            const dataRooms = await resRooms.json();
            const dataTypes = await resTypes.json();
            setRooms(Array.isArray(dataRooms) ? dataRooms : []);
            setTypes(Array.isArray(dataTypes) ? dataTypes : []);
          });
        });
    }
    // TODO: Wire up actual blocks fetch API
    setLoading(false);
  }, []);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setBlocks([{
      ...newBlock,
      id: `blk-${Date.now()}`,
      roomNumber: newBlock.roomId === 'r-1' ? '101' : '102',
      roomType: 'Deluxe Room',
      status: 'ACTIVE'
    }, ...blocks]);
    setIsCreating(false);
    setNewBlock({ roomId: '', startDate: '', endDate: '', reason: 'MAINTENANCE', notes: '' });
  };

  const handleResolve = (id: string) => {
    setBlocks(blocks.filter(b => b.id !== id));
  };

  const getReasonBadge = (reason: string) => {
    switch(reason) {
      case 'MAINTENANCE': return <Badge className="bg-red-500"><Wrench className="w-3 h-3 mr-1" /> Maintenance</Badge>;
      case 'DEEP_CLEANING': return <Badge className="bg-blue-500">Deep Cleaning</Badge>;
      case 'OUT_OF_ORDER': return <Badge className="bg-gray-800"><AlertTriangle className="w-3 h-3 mr-1" /> Out of Order</Badge>;
      default: return <Badge variant="outline">{reason}</Badge>;
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Maintenance Blocks</h2>
          <p className="text-slate-400">Manage rooms that are out of order or under maintenance</p>
        </div>
        <Button onClick={() => setIsCreating(true)} className="bg-brand-primary text-white hover:bg-brand-secondary">
          <Plus className="w-4 h-4 mr-2" /> Add Block
        </Button>
      </div>

      {isCreating && (
        <Card className="border-brand-primary shadow-md">
          <CardHeader>
            <CardTitle>Create Room Block</CardTitle>
            <CardDescription>This room will be removed from available inventory for the specified dates.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2 lg:col-span-2">
                  <Label>Room</Label>
                  <Select value={newBlock.roomId} onValueChange={v => setNewBlock({...newBlock, roomId: v || ''})} required>
                    <SelectTrigger>
                      {newBlock.roomId ? (() => {
                        const room = rooms.find(r => r.id === newBlock.roomId);
                        if (!room) return <span className="text-slate-400">Select a room</span>;
                        const typeName = types.find(t => t.id === room.roomTypeId)?.name || '';
                        return `Room ${room.roomNumber} - ${typeName}`;
                      })() : <span className="text-slate-400">Select a room</span>}
                    </SelectTrigger>
                    <SelectContent>
                      {rooms.length === 0 && <SelectItem value="disabled" disabled>No rooms found</SelectItem>}
                      {rooms.map(room => {
                        const typeName = types.find(t => t.id === room.roomTypeId)?.name || 'Unknown Type';
                        return (
                          <SelectItem key={room.id} value={room.id}>
                            Room {room.roomNumber} - {typeName}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input type="date" value={newBlock.startDate} onChange={e => setNewBlock({...newBlock, startDate: e.target.value})} required />
                </div>
                <div className="space-y-2">
                  <Label>End Date</Label>
                  <Input type="date" value={newBlock.endDate} onChange={e => setNewBlock({...newBlock, endDate: e.target.value})} required />
                </div>
                <div className="space-y-2 lg:col-span-2">
                  <Label>Reason</Label>
                  <Select value={newBlock.reason} onValueChange={v => setNewBlock({...newBlock, reason: v || ''})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MAINTENANCE">Maintenance / Repair</SelectItem>
                      <SelectItem value="DEEP_CLEANING">Deep Cleaning</SelectItem>
                      <SelectItem value="OUT_OF_ORDER">Out of Order</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 lg:col-span-4">
                  <Label>Notes / Description</Label>
                  <Textarea value={newBlock.notes} onChange={e => setNewBlock({...newBlock, notes: e.target.value})} placeholder="Why is this room being blocked?" />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsCreating(false)}>Cancel</Button>
                <Button type="submit" className="bg-brand-primary text-white hover:bg-brand-secondary">Save Block</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-900 text-slate-400 border-b">
                <tr>
                  <th className="px-6 py-4 font-medium">Room</th>
                  <th className="px-6 py-4 font-medium">Dates</th>
                  <th className="px-6 py-4 font-medium">Reason</th>
                  <th className="px-6 py-4 font-medium">Notes</th>
                  <th className="px-6 py-4 font-medium text-center">Status</th>
                  <th className="px-6 py-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-slate-400">Loading blocks...</td>
                  </tr>
                ) : blocks.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-slate-400">No active blocks.</td>
                  </tr>
                ) : (
                  blocks.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-900">
                      <td className="px-6 py-4">
                        <p className="font-bold text-slate-50">Room {b.roomNumber}</p>
                        <p className="text-xs text-slate-400">{b.roomType}</p>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <p className="text-slate-50">{format(new Date(b.startDate), 'MMM d, yyyy')} â€”</p>
                        <p className="text-slate-50">{format(new Date(b.endDate), 'MMM d, yyyy')}</p>
                      </td>
                      <td className="px-6 py-4">{getReasonBadge(b.reason)}</td>
                      <td className="px-6 py-4 text-slate-400 max-w-xs truncate">{b.notes}</td>
                      <td className="px-6 py-4 text-center">
                        <Badge variant="outline" className="border-green-200 bg-green-50 text-green-700">Active</Badge>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Button onClick={() => handleResolve(b.id)} size="sm" variant="outline" className="text-slate-400 hover:text-green-600 hover:bg-green-50 border-slate-800">
                          <CheckCircle2 className="w-4 h-4 mr-2" /> Resolve
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
