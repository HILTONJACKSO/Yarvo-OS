"use client";

import { useState, useEffect } from 'react';
import { Save, Receipt, Image as ImageIcon, Type, LayoutTemplate } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { io } from 'socket.io-client';

export default function ReceiptSettingsPage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const [settings, setSettings] = useState({
    headerText: 'Yarvo Hotel & Resort',
    addressText: '123 Ocean Drive, Coastal City\nPhone: +1 234 567 8900\nEmail: hello@yarvohotel.com',
    footerText: 'Thank you for your visit!\nPlease come again.',
    taxNumber: 'TAX-123456789',
    showLogo: true,
    showTaxBreakdown: true,
    showCashierName: true,
  });

  useEffect(() => {
    fetchBranchSettings();

    const token = localStorage.getItem('access_token');
    if (!token) return;

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002', {
      auth: { token }
    });

    socket.on('settings.branch.updated', () => {
      fetchBranchSettings();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const fetchBranchSettings = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      const branchId = localStorage.getItem('branch_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/branches/${branchId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        }
      });
      
      if (!res.ok) throw new Error('Failed to load branch settings');
      const data = await res.json();
      
      if (data.receiptSettings) {
        setSettings(data.receiptSettings);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    setError('');
    setSuccess(false);

    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      const branchId = localStorage.getItem('branch_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/branches/${branchId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        },
        body: JSON.stringify({ receiptSettings: settings })
      });
      
      if (!res.ok) throw new Error('Failed to save receipt settings');
      
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Receipt Configuration</h2>
          <p className="text-slate-400 text-sm mt-1">Customize the appearance of printed and digital receipts</p>
        </div>
        <button 
          onClick={handleSave}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors"
        >
          <Save size={18} />
          {loading ? 'Saving...' : 'Save Configuration'}
        </button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-emerald-50 text-emerald-400 border-emerald-200">
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>Receipt settings updated successfully.</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-50 flex items-center gap-2 border-b border-gray-50 pb-3">
              <Type size={18} className="text-brand-primary" /> Header & Details
            </h3>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Business Name (Header)</label>
              <input 
                type="text" 
                value={settings.headerText} 
                onChange={e => setSettings({...settings, headerText: e.target.value})}
                className="w-full p-3 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none font-bold text-center"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Address & Contact Info</label>
              <textarea 
                value={settings.addressText} 
                onChange={e => setSettings({...settings, addressText: e.target.value})}
                className="w-full p-3 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none text-center resize-none"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Tax Identification Number</label>
              <input 
                type="text" 
                value={settings.taxNumber} 
                onChange={e => setSettings({...settings, taxNumber: e.target.value})}
                className="w-full p-3 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none text-center"
              />
            </div>
          </div>

          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-50 flex items-center gap-2 border-b border-gray-50 pb-3">
              <Type size={18} className="text-brand-primary" /> Footer Message
            </h3>
            
            <div className="space-y-2">
              <textarea 
                value={settings.footerText} 
                onChange={e => setSettings({...settings, footerText: e.target.value})}
                className="w-full p-3 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none text-center resize-none"
                rows={3}
              />
            </div>
          </div>

          <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-50 flex items-center gap-2 border-b border-gray-50 pb-3">
              <LayoutTemplate size={18} className="text-brand-primary" /> Display Options
            </h3>
            
            <div className="space-y-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={settings.showLogo}
                  onChange={e => setSettings({...settings, showLogo: e.target.checked})}
                  className="w-5 h-5 text-brand-primary rounded border-slate-700 focus:ring-brand-primary"
                />
                <span className="text-slate-300">Print Logo at the top</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={settings.showTaxBreakdown}
                  onChange={e => setSettings({...settings, showTaxBreakdown: e.target.checked})}
                  className="w-5 h-5 text-brand-primary rounded border-slate-700 focus:ring-brand-primary"
                />
                <span className="text-slate-300">Show detailed tax breakdown</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={settings.showCashierName}
                  onChange={e => setSettings({...settings, showCashierName: e.target.checked})}
                  className="w-5 h-5 text-brand-primary rounded border-slate-700 focus:ring-brand-primary"
                />
                <span className="text-slate-300">Print cashier name</span>
              </label>
            </div>
          </div>
        </div>

        {/* Live Preview */}
        <div>
          <div className="sticky top-6 bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-inner min-h-[600px] flex flex-col items-center">
            <h3 className="font-bold text-slate-400 mb-6 uppercase tracking-wider text-sm flex items-center gap-2">
              <Receipt size={16} /> Live Preview
            </h3>

            <div className="bg-slate-950 p-8 w-80 shadow-lg border-t-4 border-gray-800 font-mono text-sm text-slate-200 relative">
              {/* Jagged bottom edge effect */}
              <div className="absolute -bottom-2 left-0 right-0 h-4 bg-repeat-x" style={{
                backgroundImage: 'linear-gradient(45deg, transparent 33.333%, white 33.333%, white 66.667%, transparent 66.667%), linear-gradient(-45deg, transparent 33.333%, white 33.333%, white 66.667%, transparent 66.667%)',
                backgroundSize: '8px 16px',
                backgroundPosition: '0 -8px'
              }}></div>

              <div className="text-center space-y-1 mb-6">
                {settings.showLogo && (
                  <div className="mx-auto w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mb-3">
                    <ImageIcon size={20} className="text-gray-400" />
                  </div>
                )}
                <h1 className="font-bold text-lg">{settings.headerText || 'BUSINESS NAME'}</h1>
                <p className="whitespace-pre-line text-xs">{settings.addressText}</p>
                {settings.taxNumber && <p className="text-xs mt-2">Tax ID: {settings.taxNumber}</p>}
              </div>

              <div className="border-t border-dashed border-gray-400 py-2 my-2 text-xs">
                <div className="flex justify-between"><span>Date:</span><span>2026-07-18 15:30</span></div>
                <div className="flex justify-between"><span>Receipt No:</span><span>RCP-1046</span></div>
                {settings.showCashierName && <div className="flex justify-between"><span>Cashier:</span><span>Admin User</span></div>}
              </div>

              <div className="border-t border-dashed border-gray-400 py-4 my-2 space-y-2">
                <div className="flex justify-between">
                  <span>1x Club Sandwich</span>
                  <span>$15.00</span>
                </div>
                <div className="flex justify-between">
                  <span>2x Coca Cola</span>
                  <span>$6.00</span>
                </div>
              </div>

              <div className="border-t border-dashed border-gray-400 py-2 my-2 space-y-1">
                <div className="flex justify-between"><span>Subtotal</span><span>$21.00</span></div>
                {settings.showTaxBreakdown && (
                  <>
                    <div className="flex justify-between text-xs text-slate-400"><span>VAT (15%)</span><span>$3.15</span></div>
                    <div className="flex justify-between text-xs text-slate-400"><span>Service Charge</span><span>$1.05</span></div>
                  </>
                )}
                <div className="flex justify-between font-bold text-lg pt-2"><span>TOTAL</span><span>$25.20</span></div>
              </div>

              <div className="border-t border-dashed border-gray-400 py-2 my-2 space-y-1">
                <div className="flex justify-between"><span>CASH</span><span>$30.00</span></div>
                <div className="flex justify-between"><span>CHANGE</span><span>$4.80</span></div>
              </div>

              <div className="mt-8 text-center text-xs whitespace-pre-line">
                {settings.footerText}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
