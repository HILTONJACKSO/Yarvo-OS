"use client";

import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Save, X, Search, Percent, DollarSign, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { io } from 'socket.io-client';

export default function TaxesSettingsPage() {
  const [taxes, setTaxes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  const [isEditing, setIsEditing] = useState(false);
  const [currentTax, setCurrentTax] = useState<any>(null);

  useEffect(() => {
    fetchTaxes();

    const token = localStorage.getItem('access_token');
    if (!token) return;

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002', {
      auth: { token }
    });

    socket.on('settings.tax.updated', () => {
      fetchTaxes();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const fetchTaxes = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/taxes`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        }
      });
      
      if (!res.ok) throw new Error('Failed to load taxes');
      const data = await res.json();
      setTaxes(data);
      setLoading(false);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleEdit = (tax: any) => {
    setCurrentTax({ ...tax });
    setIsEditing(true);
  };

  const handleCreate = () => {
    setCurrentTax({
      name: '',
      code: '',
      calculationType: 'PERCENTAGE',
      rate: 0,
      priceTreatment: 'EXCLUSIVE',
      status: 'ACTIVE'
    });
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      
      const isNew = !currentTax.id;
      const url = `${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/taxes${isNew ? '' : `/${currentTax.id}`}`;
      
      const res = await fetch(url, {
        method: isNew ? 'POST' : 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        },
        body: JSON.stringify(currentTax)
      });
      
      if (!res.ok) throw new Error('Failed to save tax');
      
      setIsEditing(false);
      fetchTaxes();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this tax rule?')) return;
    
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/taxes/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        }
      });
      
      if (!res.ok) throw new Error('Failed to delete tax');
      fetchTaxes();
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (loading) return <div className="p-8">Loading Taxes...</div>;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Tax Configuration</h2>
          <p className="text-slate-400 text-sm mt-1">Manage government taxes, VAT, and local charges</p>
        </div>
        <button 
          onClick={handleCreate}
          className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors"
        >
          <Plus size={18} />
          New Tax Rule
        </button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {isEditing ? (
        <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-slate-50">{currentTax.id ? 'Edit Tax Rule' : 'New Tax Rule'}</h3>
            <button onClick={() => setIsEditing(false)} className="text-gray-400 hover:text-slate-400">
              <X size={24} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Tax Name</label>
              <input 
                type="text" 
                value={currentTax.name} 
                onChange={e => setCurrentTax({...currentTax, name: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                placeholder="e.g. Value Added Tax"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Tax Code</label>
              <input 
                type="text" 
                value={currentTax.code} 
                onChange={e => setCurrentTax({...currentTax, code: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                placeholder="e.g. VAT_15"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Calculation Type</label>
              <select 
                value={currentTax.calculationType}
                onChange={e => setCurrentTax({...currentTax, calculationType: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="PERCENTAGE">Percentage (%)</option>
                <option value="FIXED_AMOUNT">Fixed Amount ($)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">
                {currentTax.calculationType === 'PERCENTAGE' ? 'Rate (%)' : 'Amount'}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  {currentTax.calculationType === 'PERCENTAGE' ? <Percent size={16} /> : <DollarSign size={16} />}
                </div>
                <input 
                  type="number" 
                  value={currentTax.calculationType === 'PERCENTAGE' ? currentTax.rate : currentTax.fixedAmount} 
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    if (currentTax.calculationType === 'PERCENTAGE') {
                      setCurrentTax({...currentTax, rate: val});
                    } else {
                      setCurrentTax({...currentTax, fixedAmount: val});
                    }
                  }}
                  className="w-full pl-10 p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Price Treatment</label>
              <select 
                value={currentTax.priceTreatment}
                onChange={e => setCurrentTax({...currentTax, priceTreatment: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="EXCLUSIVE">Exclusive (Added on top of price)</option>
                <option value="INCLUSIVE">Inclusive (Already in the price)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Status</label>
              <select 
                value={currentTax.status}
                onChange={e => setCurrentTax({...currentTax, status: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
          </div>

          <div className="mt-8 flex justify-end gap-3">
            <button 
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 border border-slate-700 text-slate-300 rounded-lg hover:bg-slate-900 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSave}
              className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors flex items-center gap-2"
            >
              <Save size={18} />
              Save Tax Rule
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search taxes..." 
                className="w-full pl-10 p-2 border border-slate-800 rounded-lg text-sm focus:ring-2 focus:ring-brand-primary outline-none"
              />
            </div>
          </div>
          
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900 text-slate-400 text-sm border-b border-slate-800">
                <th className="p-4 font-medium">Tax Name</th>
                <th className="p-4 font-medium">Code</th>
                <th className="p-4 font-medium">Rate / Amount</th>
                <th className="p-4 font-medium">Treatment</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {taxes.map(tax => (
                <tr key={tax.id} className="border-b border-gray-50 hover:bg-slate-900/50 transition-colors">
                  <td className="p-4">
                    <p className="font-medium text-slate-50">{tax.name}</p>
                  </td>
                  <td className="p-4 text-sm text-slate-400 font-mono bg-slate-800 rounded px-2 py-1 w-max my-3 mx-2 inline-block">
                    {tax.code}
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-1 font-medium">
                      {tax.calculationType === 'PERCENTAGE' ? (
                        <span className="text-brand-primary">{tax.rate}%</span>
                      ) : (
                        <span className="text-emerald-600">${tax.fixedAmount}</span>
                      )}
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      tax.priceTreatment === 'INCLUSIVE' ? 'bg-blue-500/10 text-blue-700' : 'bg-purple-100 text-purple-700'
                    }`}>
                      {tax.priceTreatment}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      tax.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-700' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {tax.status}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button 
                      onClick={() => handleEdit(tax)}
                      className="p-2 text-gray-400 hover:text-brand-primary transition-colors inline-block"
                      title="Edit"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button 
                      onClick={() => handleDelete(tax.id)}
                      className="p-2 text-gray-400 hover:text-red-500 transition-colors inline-block"
                      title="Delete"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
              {taxes.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No tax rules configured. Click "New Tax Rule" to create one.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
