"use client";

import { useState, useEffect } from 'react';
import { Save, Store } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function BranchesSettingsPage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');

  const [settings, setSettings] = useState({
    name: '',
    code: '',
    address: '',
    city: '',
    phone: '',
    email: '',
    timezone: '',
  });

  useEffect(() => {
    fetchBranchSettings();
  }, []);

  const fetchBranchSettings = async () => {
    try {
      const token = localStorage.getItem('access_token');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/businesses/current`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!res.ok) throw new Error('Failed to load branches');
      const data = await res.json();
      
      if (data && data.length > 0 && data[0].business.branches.length > 0) {
        const branch = data[0].business.branches[0]; // Assuming first branch for now
        setBusinessId(data[0].businessId);
        setBranchId(branch.id);
        
        setSettings({
          name: branch.name || '',
          code: branch.code || '',
          address: branch.address || '',
          city: branch.city || '',
          phone: branch.phone || '',
          email: branch.email || '',
          timezone: branch.timezone || '',
        });
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    setError('');
    setSuccess(false);

    try {
      const token = localStorage.getItem('access_token');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/branches/${branchId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId
        },
        body: JSON.stringify(settings)
      });
      
      if (!res.ok) throw new Error('Failed to save branch settings');
      
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Branch Details</h2>
          <p className="text-slate-400 text-sm mt-1">Manage details for your current branch</p>
        </div>
        <button 
          onClick={handleSave}
          disabled={loading || !branchId}
          className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors disabled:opacity-50"
        >
          <Save size={18} />
          {loading ? 'Saving...' : 'Save Changes'}
        </button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-emerald-50 text-emerald-400 border-emerald-200">
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>Branch settings saved successfully.</AlertDescription>
        </Alert>
      )}

      <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Branch Name</label>
            <input 
              type="text" 
              value={settings.name} 
              onChange={e => setSettings({...settings, name: e.target.value})}
              className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Branch Code</label>
            <input 
              type="text" 
              value={settings.code} 
              onChange={e => setSettings({...settings, code: e.target.value})}
              className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">City</label>
            <input 
              type="text" 
              value={settings.city} 
              onChange={e => setSettings({...settings, city: e.target.value})}
              className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Timezone</label>
            <input 
              type="text" 
              value={settings.timezone} 
              onChange={e => setSettings({...settings, timezone: e.target.value})}
              className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none"
              placeholder="e.g. America/New_York"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Email Address</label>
            <input 
              type="email" 
              value={settings.email} 
              onChange={e => setSettings({...settings, email: e.target.value})}
              className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Phone Number</label>
            <input 
              type="text" 
              value={settings.phone} 
              onChange={e => setSettings({...settings, phone: e.target.value})}
              className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none"
            />
          </div>
          
          <div className="space-y-2 md:col-span-2">
            <label className="block text-sm font-medium text-slate-300">Address</label>
            <textarea 
              value={settings.address} 
              onChange={e => setSettings({...settings, address: e.target.value})}
              className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none h-24"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
