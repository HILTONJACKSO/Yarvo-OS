"use client";

import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Save, X, Search, Percent, DollarSign, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { io } from 'socket.io-client';

export default function ServiceChargesSettingsPage() {
  const [charges, setCharges] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  const [isEditing, setIsEditing] = useState(false);
  const [currentCharge, setCurrentCharge] = useState<any>(null);

  useEffect(() => {
    fetchCharges();

    const token = localStorage.getItem('access_token');
    if (!token) return;

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002', {
      auth: { token }
    });

    socket.on('settings.serviceCharge.updated', () => {
      fetchCharges();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const fetchCharges = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/service-charges`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        }
      });
      
      if (!res.ok) throw new Error('Failed to load service charges');
      const data = await res.json();
      setCharges(data);
      setLoading(false);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleEdit = (charge: any) => {
    setCurrentCharge({ ...charge });
    setIsEditing(true);
  };

  const handleCreate = () => {
    setCurrentCharge({
      name: '',
      code: '',
      calculationType: 'PERCENTAGE',
      rate: 0,
      mandatory: true,
      staffDistributionEligible: false,
      appliesToType: 'ALL',
      status: 'ACTIVE'
    });
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      
      const isNew = !currentCharge.id;
      const url = `${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/service-charges${isNew ? '' : `/${currentCharge.id}`}`;
      
      const res = await fetch(url, {
        method: isNew ? 'POST' : 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        },
        body: JSON.stringify(currentCharge)
      });
      
      if (!res.ok) throw new Error('Failed to save service charge');
      
      setIsEditing(false);
      fetchCharges();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service charge?')) return;
    
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/service-charges/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        }
      });
      
      if (!res.ok) throw new Error('Failed to delete service charge');
      fetchCharges();
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (loading) return <div className="p-8">Loading Service Charges...</div>;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Service Charges</h2>
          <p className="text-slate-400 text-sm mt-1">Manage delivery fees, gratuities, and other service charges</p>
        </div>
        <button 
          onClick={handleCreate}
          className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors"
        >
          <Plus size={18} />
          New Service Charge
        </button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {isEditing ? (
        <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-slate-50">{currentCharge.id ? 'Edit Service Charge' : 'New Service Charge'}</h3>
            <button onClick={() => setIsEditing(false)} className="text-gray-400 hover:text-slate-400">
              <X size={24} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Charge Name</label>
              <input 
                type="text" 
                value={currentCharge.name} 
                onChange={e => setCurrentCharge({...currentCharge, name: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                placeholder="e.g. Room Service Delivery"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Code</label>
              <input 
                type="text" 
                value={currentCharge.code} 
                onChange={e => setCurrentCharge({...currentCharge, code: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                placeholder="e.g. RS_DELIVERY"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Calculation Type</label>
              <select 
                value={currentCharge.calculationType}
                onChange={e => setCurrentCharge({...currentCharge, calculationType: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="PERCENTAGE">Percentage (%)</option>
                <option value="FIXED_AMOUNT">Fixed Amount ($)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">
                {currentCharge.calculationType === 'PERCENTAGE' ? 'Rate (%)' : 'Amount'}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                  {currentCharge.calculationType === 'PERCENTAGE' ? <Percent size={16} /> : <DollarSign size={16} />}
                </div>
                <input 
                  type="number" 
                  value={currentCharge.calculationType === 'PERCENTAGE' ? currentCharge.rate : currentCharge.fixedAmount} 
                  onChange={e => {
                    const val = parseFloat(e.target.value);
                    if (currentCharge.calculationType === 'PERCENTAGE') {
                      setCurrentCharge({...currentCharge, rate: val});
                    } else {
                      setCurrentCharge({...currentCharge, fixedAmount: val});
                    }
                  }}
                  className="w-full pl-10 p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Is Mandatory?</label>
              <select 
                value={currentCharge.mandatory ? 'YES' : 'NO'}
                onChange={e => setCurrentCharge({...currentCharge, mandatory: e.target.value === 'YES'})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="YES">Yes</option>
                <option value="NO">No (Optional Gratuity)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Staff Distribution Eligible?</label>
              <select 
                value={currentCharge.staffDistributionEligible ? 'YES' : 'NO'}
                onChange={e => setCurrentCharge({...currentCharge, staffDistributionEligible: e.target.value === 'YES'})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="YES">Yes (e.g. Tips pool)</option>
                <option value="NO">No (Kept by House)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Status</label>
              <select 
                value={currentCharge.status}
                onChange={e => setCurrentCharge({...currentCharge, status: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
          </div>

          <div className="mt-8 flex justify-end gap-3">
            <button 
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 border border-slate-700 text-slate-300 rounded-lg hover:bg-slate-900 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSave}
              className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors flex items-center gap-2"
            >
              <Save size={18} />
              Save Service Charge
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search service charges..." 
                className="w-full pl-10 p-2 border border-slate-800 rounded-lg text-sm focus:ring-2 focus:ring-brand-primary outline-none"
              />
            </div>
          </div>
          
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900 text-slate-400 text-sm border-b border-slate-800">
                <th className="p-4 font-medium">Name</th>
                <th className="p-4 font-medium">Code</th>
                <th className="p-4 font-medium">Rate / Amount</th>
                <th className="p-4 font-medium">Type</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {charges.map(charge => (
                <tr key={charge.id} className="border-b border-gray-50 hover:bg-slate-900/50 transition-colors">
                  <td className="p-4">
                    <p className="font-medium text-slate-50">{charge.name}</p>
                    {charge.staffDistributionEligible && (
                       <span className="text-xs text-brand-primary">Tips Pool Eligible</span>
                    )}
                  </td>
                  <td className="p-4 text-sm text-slate-400 font-mono bg-slate-800 rounded px-2 py-1 w-max my-3 mx-2 inline-block">
                    {charge.code}
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-1 font-medium">
                      {charge.calculationType === 'PERCENTAGE' ? (
                        <span className="text-brand-primary">{charge.rate}%</span>
                      ) : (
                        <span className="text-emerald-600">${charge.fixedAmount}</span>
                      )}
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      charge.mandatory ? 'bg-orange-100 text-orange-700' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {charge.mandatory ? 'MANDATORY' : 'OPTIONAL'}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      charge.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-700' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {charge.status}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button 
                      onClick={() => handleEdit(charge)}
                      className="p-2 text-gray-400 hover:text-brand-primary transition-colors inline-block"
                      title="Edit"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button 
                      onClick={() => handleDelete(charge.id)}
                      className="p-2 text-gray-400 hover:text-red-500 transition-colors inline-block"
                      title="Delete"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
              {charges.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No service charges configured. Click "New Service Charge" to create one.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
