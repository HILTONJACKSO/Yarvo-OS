"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Shield, Users, Edit, Plus, X, Lock, Key, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { socket } from '@/lib/socket';

export default function RolesPage() {
  const router = useRouter();
  const [roles, setRoles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleDesc, setNewRoleDesc] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [businessId, setBusinessId] = useState('');
  const [token, setToken] = useState('');

  const fetchRoles = () => {
    const currentToken = localStorage.getItem('access_token');
    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${currentToken}` }})
    .then(r => r.json())
    .then(data => {
      if (!data || !Array.isArray(data) || data.length === 0) {
        setLoading(false);
        return null;
      }
      const bid = data[0].businessId;
      setBusinessId(bid);
      setToken(currentToken || '');
      return fetch('http://127.0.0.1:3002/roles', { headers: { 'Authorization': `Bearer ${currentToken}`, 'x-business-id': bid }});
    })
    .then(r => r ? r.json() : [])
    .then(data => {
      setRoles(Array.isArray(data) ? data : []);
      setLoading(false);
    })
    .catch(console.error);
  };

  useEffect(() => {
    fetchRoles();

    const onRolesUpdated = () => {
      fetchRoles();
    };

    socket.on('roles.updated', onRolesUpdated);

    return () => {
      socket.off('roles.updated', onRolesUpdated);
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-indigo-500/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10 flex items-center gap-4">
          <div className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl">
            <Lock size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-50 tracking-tight">Roles & Permissions</h1>
            <p className="text-slate-400 mt-1 font-medium text-sm md:text-base">Control what your staff can see and do within the platform.</p>
          </div>
        </div>
        <div className="relative z-10">
          <button 
            onClick={() => setIsModalOpen(true)} 
            className="px-6 py-3 bg-brand-primary text-white rounded-xl font-bold hover:bg-brand-primary/90 transition flex items-center gap-2 shadow-md hover:shadow-lg"
          >
            <Plus size={18} /> Create New Role
          </button>
        </div>
      </div>

      {/* Roles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {roles.map(role => (
          <div key={role.id} className="bg-slate-950 p-6 rounded-3xl border border-slate-800 shadow-sm flex flex-col hover:shadow-md hover:border-indigo-100 transition-all group relative overflow-hidden">
            <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-5 transition-opacity pointer-events-none">
              <Shield size={64} />
            </div>
            
            <div className="flex items-start justify-between mb-6 relative z-10">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-50 to-blue-50 text-indigo-600 flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                <Shield size={24} />
              </div>
              {role.isSystemRole && (
                <span className="px-3 py-1.5 bg-slate-800 text-slate-400 text-xs font-bold tracking-wider uppercase rounded-full">
                  System Default
                </span>
              )}
            </div>

            <div className="relative z-10 mb-6">
              <h3 className="text-xl font-black text-slate-50 tracking-tight mb-1">{role.name}</h3>
              <p className="text-sm text-slate-400 font-medium line-clamp-2">
                {role.description || 'No description provided for this role.'}
              </p>
            </div>
            
            <div className="flex items-center gap-2 mb-6 px-4 py-2.5 bg-slate-900 rounded-xl relative z-10">
              <Users size={16} className="text-gray-400" />
              <span className="text-sm font-bold text-slate-50">{role._count?.employees || 0}</span>
              <span className="text-sm font-medium text-slate-400">Staff Assigned</span>
            </div>
            
            <div className="mt-auto pt-4 border-t border-slate-800 relative z-10">
              <Link href={`/dashboard/settings/roles/${role.id}`}>
                <button className="w-full py-2.5 px-4 bg-slate-950 border border-slate-800 text-slate-300 font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-indigo-50 hover:text-indigo-700 hover:border-indigo-200 transition-colors shadow-sm">
                  <Settings size={16} /> Edit Permissions
                </button>
              </Link>
            </div>
          </div>
        ))}
      </div>

      {/* Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-900/40 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-200 p-4">
          <div className="bg-slate-950 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="h-2 bg-gradient-to-r from-brand-primary via-indigo-500 to-purple-500 w-full"></div>
            <div className="p-8">
              <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
                    <Key size={24} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-slate-50">Create New Role</h2>
                    <p className="text-sm text-slate-400 font-medium mt-1">Define a custom permission set.</p>
                  </div>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 text-gray-400 hover:text-slate-50 hover:bg-slate-800 rounded-full transition">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-bold">Role Name</Label>
                  <Input 
                    placeholder="e.g. Shift Manager" 
                    value={newRoleName} 
                    onChange={e => setNewRoleName(e.target.value)} 
                    className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base"
                    autoFocus
                  />
                </div>
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-bold">Description</Label>
                  <Input 
                    placeholder="e.g. Manages daily shifts and handles voids" 
                    value={newRoleDesc} 
                    onChange={e => setNewRoleDesc(e.target.value)} 
                    className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-10">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsModalOpen(false)}
                  className="h-12 px-6 rounded-xl font-bold"
                >
                  Cancel
                </Button>
                <Button 
                  className="bg-brand-primary hover:bg-brand-primary/90 h-12 px-8 rounded-xl font-bold shadow-md hover:shadow-lg transition-all" 
                  disabled={submitting || !newRoleName.trim()}
                  onClick={async () => {
                    setSubmitting(true);
                    try {
                      const currentToken = localStorage.getItem('access_token');
                      const res = await fetch('http://127.0.0.1:3002/roles', {
                        method: 'POST',
                        headers: {
                          'Content-Type': 'application/json',
                          'Authorization': `Bearer ${currentToken}`,
                          'x-business-id': businessId
                        },
                        body: JSON.stringify({ name: newRoleName, description: newRoleDesc })
                      });
                      if (res.ok) {
                        const newRole = await res.json();
                        setRoles([...roles, newRole]);
                        setIsModalOpen(false);
                        setNewRoleName('');
                        setNewRoleDesc('');
                      } else {
                        const err = await res.json();
                        alert(err.message || 'Failed to create role');
                      }
                    } catch (e) {
                      console.error(e);
                    } finally {
                      setSubmitting(false);
                    }
                  }}
                >
                  {submitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Creating...
                    </div>
                  ) : 'Create Role'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
