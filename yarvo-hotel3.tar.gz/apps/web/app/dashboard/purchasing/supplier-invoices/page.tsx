"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, FileText, CheckCircle2, Clock } from 'lucide-react';

export default function SupplierInvoicesPage() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [totalUnpaid, setTotalUnpaid] = useState(0);

  const fetchData = async () => {
    try {
      const [invRes, statsRes] = await Promise.all([
        fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/supplier-invoices`),
        fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/supplier-invoices/stats`)
      ]);
      
      if (invRes.ok) {
        const data = await invRes.json();
        setInvoices(data);
      }
      if (statsRes.ok) {
        const stats = await statsRes.json();
        setTotalUnpaid(stats.totalUnpaid);
      }
    } catch (error) {
      console.error('Failed to fetch supplier invoices:', error);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('purchasing.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Supplier Invoices</h1>
          <p className="text-slate-400 mt-1">Track amounts owed to vendors based on received goods.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-500/10 text-red-600 rounded-lg"><Clock size={24} /></div>
          <div>
            <p className="text-slate-400 font-medium text-sm">Total Unpaid</p>
            <h3 className="text-2xl font-black text-slate-50">${totalUnpaid.toFixed(2)}</h3>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search invoices..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Statuses</option>
            <option value="UNPAID">Unpaid</option>
            <option value="PARTIAL">Partially Paid</option>
            <option value="PAID">Fully Paid</option>
          </select>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Invoice #</th>
              <th className="p-4 font-semibold">Supplier</th>
              <th className="p-4 font-semibold">Invoice Date</th>
              <th className="p-4 font-semibold">Due Date</th>
              <th className="p-4 font-semibold text-right">Amount</th>
              <th className="p-4 font-semibold">GRN Ref</th>
              <th className="p-4 font-semibold text-center">Status</th>
              <th className="p-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {invoices.map((inv) => (
              <tr key={inv.id} className="hover:bg-slate-900">
                <td className="p-4 font-mono text-xs text-brand-primary font-medium">{inv.number}</td>
                <td className="p-4 font-medium text-slate-50">{inv.supplierId || 'Unknown'}</td>
                <td className="p-4 text-slate-400">{inv.date}</td>
                <td className="p-4 text-slate-400">{inv.dueDate}</td>
                <td className="p-4 text-right font-medium text-slate-50">${inv.totalAmount?.toFixed(2) || '0.00'}</td>
                <td className="p-4 text-slate-400 font-mono text-xs">{inv.grnRef}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${inv.status === 'PAID' ? 'bg-emerald-500/10 text-green-700' : inv.status === 'UNPAID' ? 'bg-red-500/10 text-red-700' : 'bg-amber-500/10 text-yellow-700'}`}>
                    {inv.status}
                  </span>
                </td>
                <td className="p-4 flex items-center justify-end gap-2">
                  <button className="px-3 py-1 bg-slate-950 border text-slate-300 rounded text-xs font-medium hover:bg-slate-900">
                    Record Payment
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
