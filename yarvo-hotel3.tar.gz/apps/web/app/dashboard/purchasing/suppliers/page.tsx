"use client";

import { useState, useEffect } from 'react';
import { Search, Plus, Edit2, Mail, Phone, ExternalLink } from 'lucide-react';

export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState<any[]>([]);

  const fetchSuppliers = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/suppliers`);
      if (response.ok) {
        const data = await response.json();
        setSuppliers(data);
      }
    } catch (error) {
      console.error('Failed to fetch suppliers:', error);
    }
  };

  useEffect(() => {
    fetchSuppliers();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('purchasing.updated', () => fetchSuppliers());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Suppliers</h1>
          <p className="text-slate-400 mt-1">Manage vendor details, contacts, and purchasing catalogs.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
            <Plus size={18} /> Add Supplier
          </button>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search suppliers..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Categories</option>
            <option value="beverages">Beverages</option>
            <option value="produce">Produce</option>
            <option value="general">General</option>
          </select>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Supplier Name</th>
              <th className="p-4 font-semibold">Code</th>
              <th className="p-4 font-semibold">Category</th>
              <th className="p-4 font-semibold">Primary Contact</th>
              <th className="p-4 font-semibold text-center">Status</th>
              <th className="p-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {suppliers.map((sup) => (
              <tr key={sup.id} className="hover:bg-slate-900">
                <td className="p-4 font-medium text-slate-50 flex items-center gap-2">
                  {sup.name}
                </td>
                <td className="p-4 text-slate-400 font-mono text-xs">{sup.code}</td>
                <td className="p-4 text-slate-400">{sup.category}</td>
                <td className="p-4">
                  <div className="flex flex-col">
                    <span className="text-slate-50 font-medium">{sup.contact}</span>
                    <span className="text-xs text-slate-400 flex items-center gap-1"><Phone size={12}/> {sup.phone}</span>
                    <span className="text-xs text-slate-400 flex items-center gap-1"><Mail size={12}/> {sup.email}</span>
                  </div>
                </td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${sup.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-slate-800 text-slate-300'}`}>
                    {sup.status}
                  </span>
                </td>
                <td className="p-4 flex items-center justify-end gap-2 h-full py-6">
                  <button className="p-1.5 text-gray-400 hover:text-brand-primary rounded"><Edit2 size={16}/></button>
                  <button className="p-1.5 text-gray-400 hover:text-brand-primary rounded"><ExternalLink size={16}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
