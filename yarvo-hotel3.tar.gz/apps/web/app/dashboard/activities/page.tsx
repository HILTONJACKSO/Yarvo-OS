"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Activity, Clock, User, PlusCircle, Trash2, Edit3, Settings, ShieldAlert, FileText, CheckCircle2 } from 'lucide-react';
import { socket } from '@/lib/socket';

export default function ActivitiesPage() {
  const router = useRouter();
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchActivities = () => {
    const token = localStorage.getItem('access_token');
    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${token}` }})
    .then(r => r.json())
    .then(data => {
      if (!data || !Array.isArray(data) || data.length === 0) {
        setLoading(false);
        return null;
      }
      const bid = data[0].businessId;
      return fetch('http://127.0.0.1:3002/activities', { headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }});
    })
    .then(r => r ? r.json() : [])
    .then(data => {
      setActivities(Array.isArray(data) ? data : []);
      setLoading(false);
    })
    .catch(console.error);
  };

  useEffect(() => {
    fetchActivities();

    const onActivitiesUpdated = () => {
      fetchActivities();
    };

    socket.on('activities.updated', onActivitiesUpdated);

    return () => {
      socket.off('activities.updated', onActivitiesUpdated);
    };
  }, []);

  const getActionIcon = (action: string) => {
    const act = action.toLowerCase();
    if (act.includes('create') || act.includes('add')) return <PlusCircle size={18} className="text-emerald-600" />;
    if (act.includes('delete') || act.includes('remove')) return <Trash2 size={18} className="text-red-600" />;
    if (act.includes('update') || act.includes('edit')) return <Edit3 size={18} className="text-blue-600" />;
    if (act.includes('login') || act.includes('auth')) return <ShieldAlert size={18} className="text-indigo-600" />;
    if (act.includes('complete') || act.includes('finish')) return <CheckCircle2 size={18} className="text-teal-600" />;
    return <Activity size={18} className="text-brand-primary" />;
  };

  const getActionColor = (action: string) => {
    const act = action.toLowerCase();
    if (act.includes('create') || act.includes('add')) return 'bg-emerald-50 border-emerald-100';
    if (act.includes('delete') || act.includes('remove')) return 'bg-red-50 border-red-100';
    if (act.includes('update') || act.includes('edit')) return 'bg-blue-50 border-blue-100';
    if (act.includes('login') || act.includes('auth')) return 'bg-indigo-50 border-indigo-100';
    if (act.includes('complete') || act.includes('finish')) return 'bg-teal-50 border-teal-100';
    return 'bg-brand-primary/10 border-brand-primary/20';
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return 'Just now';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    return date.toLocaleDateString();
  };

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-purple-500/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10 flex items-center gap-4">
          <div className="p-4 bg-purple-50 text-purple-600 rounded-2xl shadow-inner">
            <Activity size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-50 tracking-tight">Activity Log</h1>
            <p className="text-slate-400 mt-1 font-medium text-sm md:text-base">A chronological audit trail of all actions across the platform.</p>
          </div>
        </div>
        <div className="relative z-10 flex items-center gap-3">
          <button className="px-5 py-2.5 bg-slate-950 border border-slate-800 text-slate-300 rounded-xl font-bold hover:bg-slate-900 transition shadow-sm">
            Export Logs
          </button>
        </div>
      </div>

      {/* Timeline List */}
      <div className="bg-slate-950 rounded-3xl border border-slate-800 shadow-sm p-8 relative">
        {activities.length === 0 ? (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-900 mb-6">
              <Activity className="text-gray-300" size={32} />
            </div>
            <h3 className="text-xl font-black text-slate-50 mb-2 tracking-tight">No recent activity</h3>
            <p className="text-slate-400 font-medium max-w-md mx-auto">When staff perform actions, edit records, or log in, those events will automatically appear here.</p>
          </div>
        ) : (
          <div className="relative">
            {/* Vertical timeline line */}
            <div className="absolute left-8 top-8 bottom-8 w-px bg-slate-800"></div>

            <ul className="space-y-8 relative">
              {activities.map((act, index) => {
                const actorName = act.employee?.user?.fullName || 'System Automated';
                const actorInitial = actorName.charAt(0);
                
                return (
                  <li key={act.id} className="relative pl-24 group">
                    {/* Timeline Dot/Icon */}
                    <div className={`absolute left-[23px] top-1 w-10 h-10 rounded-full flex items-center justify-center border-4 border-white shadow-sm ${getActionColor(act.action)} group-hover:scale-110 transition-transform duration-300`}>
                      {getActionIcon(act.action)}
                    </div>

                    <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 shadow-sm group-hover:shadow-md transition-shadow hover:border-slate-800">
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 text-xs font-bold tracking-wide">
                              <User size={12} /> {actorName}
                            </span>
                            <span className="text-slate-500 text-sm font-medium">performed action:</span>
                          </div>
                          
                          <p className="text-slate-50 font-bold text-lg leading-snug">
                            {act.action} <span className="text-brand-primary/80 font-semibold">{act.resource}</span>
                          </p>
                          
                          {act.details && Object.keys(act.details).length > 0 && (
                            <div className="mt-4 p-4 bg-slate-900 rounded-xl border border-slate-800 flex items-start gap-3">
                              <FileText size={16} className="text-gray-400 mt-0.5" />
                              <div className="flex-1 overflow-x-auto">
                                <pre className="text-xs text-slate-400 font-mono whitespace-pre-wrap break-all">
                                  {JSON.stringify(act.details, null, 2)}
                                </pre>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 text-xs font-bold text-gray-400 md:text-right whitespace-nowrap bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 h-fit w-fit">
                          <Clock size={14} />
                          {formatTimeAgo(act.createdAt)}
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
