"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { LogIn, Search, CheckSquare } from 'lucide-react';
import { format } from 'date-fns';
import { socket } from '@/lib/socket';

export default function ArrivalsPage() {
  const router = useRouter();
  const [arrivals, setArrivals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchArrivals = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/reservations/arrivals`);
        if (response.ok) {
          const data = await response.json();
          setArrivals(data);
        }
      } catch (error) {
        console.error('Failed to fetch arrivals:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchArrivals();

    const onUpdate = () => {
      fetchArrivals();
    };

    socket.on('reservations.updated', onUpdate);

    return () => {
      socket.off('reservations.updated', onUpdate);
    };
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-200">Today's Arrivals</h2>
        <p className="text-slate-400">Guests scheduled to check-in today</p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2 border-b">
          <CardTitle className="text-lg font-medium">Expected Arrivals ({arrivals.length})</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search guest name..." className="pl-10 h-9" />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-900 text-slate-400 border-b">
                <tr>
                  <th className="px-4 py-3 font-medium">Guest</th>
                  <th className="px-4 py-3 font-medium">Reservation</th>
                  <th className="px-4 py-3 font-medium">Room</th>
                  <th className="px-4 py-3 font-medium">ETA</th>
                  <th className="px-4 py-3 font-medium">Balance</th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr><td colSpan={6} className="text-center py-8 text-slate-400">Loading arrivals...</td></tr>
                ) : arrivals.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-8 text-slate-400">No arrivals scheduled for today.</td></tr>
                ) : (
                  arrivals.map(a => (
                    <tr key={a.id} className="hover:bg-slate-900">
                      <td className="px-4 py-3 font-medium text-slate-50">{a.customer?.displayName || 'Unknown Guest'}</td>
                      <td className="px-4 py-3 text-brand-primary cursor-pointer hover:underline" onClick={() => router.push(`/dashboard/reservations/${a.id}`)}>
                        {a.reservationNumber}
                      </td>
                      <td className="px-4 py-3">
                        <p>{a.reservationRooms?.[0]?.roomType?.name || 'Unassigned'}</p>
                        {a.reservationRooms?.[0]?.roomId ? (
                          <span className="text-xs text-green-600 font-medium">Room {a.reservationRooms[0].roomId}</span>
                        ) : (
                          <span className="text-xs text-orange-500 font-medium">Not Assigned</span>
                        )}
                      </td>
                      <td className="px-4 py-3">{a.expectedArrivalTime || '14:00'}</td>
                      <td className="px-4 py-3">
                        <span className={`font-medium ${(a.expectedBalance || 0) > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                          ${(a.expectedBalance || 0).toFixed(2)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Button size="sm" className="bg-brand-primary text-white hover:bg-brand-secondary">
                          <LogIn className="w-4 h-4 mr-2" /> Check-In
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
