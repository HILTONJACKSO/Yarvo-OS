"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle2, XCircle } from 'lucide-react';
import { format } from 'date-fns';
import { socket } from '@/lib/socket';

export default function WaitlistPage() {
  const [waitlist, setWaitlist] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWaitlist = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/reservation-waitlist`);
        if (response.ok) {
          const data = await response.json();
          setWaitlist(data);
        }
      } catch (error) {
        console.error('Failed to fetch waitlist:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchWaitlist();

    const onUpdate = () => {
      fetchWaitlist();
    };

    socket.on('reservation_waitlist.updated', onUpdate);

    return () => {
      socket.off('reservation_waitlist.updated', onUpdate);
    };
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-200">Reservation Waitlist</h2>
        <p className="text-slate-400">Manage guests waiting for room availability</p>
      </div>

      <Card>
        <CardHeader className="border-b bg-slate-900 pb-4">
          <CardTitle className="text-lg font-medium">Current Waitlist</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-950 text-slate-400 border-b">
                <tr>
                  <th className="px-4 py-3 font-medium">Guest</th>
                  <th className="px-4 py-3 font-medium">Requested Dates</th>
                  <th className="px-4 py-3 font-medium">Room Type</th>
                  <th className="px-4 py-3 font-medium">Priority</th>
                  <th className="px-4 py-3 font-medium">Added</th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr><td colSpan={6} className="text-center py-8 text-slate-400">Loading waitlist...</td></tr>
                ) : waitlist.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-8 text-slate-400">Waitlist is currently empty.</td></tr>
                ) : (
                  waitlist.map(w => (
                    <tr key={w.id} className="hover:bg-slate-900">
                      <td className="px-4 py-4">
                        <p className="font-medium text-slate-50">{w.customer?.displayName || 'Unknown'}</p>
                        <p className="text-sm text-slate-400">{w.customer?.phone || w.contactPreference}</p>
                      </td>
                      <td className="px-4 py-4">
                        <p className="font-medium text-slate-300">{format(new Date(w.arrivalDate), 'MMM d')} - {format(new Date(w.departureDate), 'MMM d, yyyy')}</p>
                        <p className="text-sm text-slate-400">{w.roomType?.name || 'Any Room'}</p>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant="outline" className={w.notes?.includes('HIGH') ? "bg-red-50 text-red-700 border-red-200" : "bg-slate-900 text-slate-300"}>
                          {w.notes?.includes('HIGH') ? 'HIGH' : 'NORMAL'}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-100 border-none">{w.status}</Badge>
                      </td>
                      <td className="px-4 py-4 text-sm text-slate-400">
                        {format(new Date(w.createdAt), 'MMM d, p')}
                      </td>
                      <td className="px-4 py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="outline" className="text-brand-primary border-brand-primary/20 hover:bg-brand-primary/5">
                            <CheckCircle2 className="w-4 h-4 mr-1" /> Convert
                          </Button>
                          <Button size="sm" variant="ghost" className="text-gray-400 hover:text-red-600">
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
