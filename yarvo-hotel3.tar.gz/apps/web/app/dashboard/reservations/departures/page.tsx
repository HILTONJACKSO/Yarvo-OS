"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { LogOut, Search } from 'lucide-react';
import { socket } from '@/lib/socket';

export default function DeparturesPage() {
  const router = useRouter();
  const [departures, setDepartures] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDepartures = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/reservations/departures`);
        if (response.ok) {
          const data = await response.json();
          setDepartures(data);
        }
      } catch (error) {
        console.error('Failed to fetch departures:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDepartures();

    const onUpdate = () => {
      fetchDepartures();
    };

    socket.on('reservations.updated', onUpdate);

    return () => {
      socket.off('reservations.updated', onUpdate);
    };
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-200">Today's Departures</h2>
        <p className="text-slate-400">Guests scheduled to check-out today</p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2 border-b">
          <CardTitle className="text-lg font-medium">Expected Departures ({departures.length})</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input placeholder="Search guest name..." className="pl-10 h-9" />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-900 text-slate-400 border-b">
                <tr>
                  <th className="px-4 py-3 font-medium">Guest</th>
                  <th className="px-4 py-3 font-medium">Reservation</th>
                  <th className="px-4 py-3 font-medium">Room</th>
                  <th className="px-4 py-3 font-medium">Balance</th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr><td colSpan={5} className="text-center py-8 text-slate-400">Loading departures...</td></tr>
                ) : departures.length === 0 ? (
                  <tr><td colSpan={5} className="text-center py-8 text-slate-400">No departures scheduled for today.</td></tr>
                ) : (
                  departures.map(d => (
                    <tr key={d.id} className="hover:bg-slate-900">
                      <td className="px-4 py-3 font-medium text-slate-50">{d.customer?.displayName || 'Unknown Guest'}</td>
                      <td className="px-4 py-3 text-brand-primary cursor-pointer hover:underline" onClick={() => router.push(`/dashboard/reservations/${d.id}`)}>
                        {d.reservationNumber}
                      </td>
                      <td className="px-4 py-3 font-bold text-slate-300">Room {d.reservationRooms?.[0]?.roomId || 'Unassigned'}</td>
                      <td className="px-4 py-3">
                        <span className={`font-medium ${(d.expectedBalance || 0) > 0 ? 'text-red-600' : 'text-green-600'}`}>
                          ${(d.expectedBalance || 0).toFixed(2)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Button size="sm" variant="outline" className="text-orange-600 border-orange-200 hover:bg-orange-50">
                          <LogOut className="w-4 h-4 mr-2" /> Check-Out
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
