"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Users, ArrowRightLeft, Clock, CalendarCheck, Search, LogIn, LogOut, XCircle } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { socket } from '@/lib/socket';

export default function ReservationDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState<any>(null);
  const [recentReservations, setRecentReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReservations = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const headers: Record<string, string> = token ? { 'Authorization': `Bearer ${token}` } : {};

        const [statsRes, reservationsRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/reservations/stats`, { headers }),
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/reservations`, { headers })
        ]);

        if (statsRes.ok) {
          const statsData = await statsRes.json();
          setStats({
            arrivalsToday: statsData.arrivalsCount || 0,
            departuresToday: statsData.departuresCount || 0,
            currentlyReserved: statsData.inHouseCount || 0,
            pending: 0,
            guaranteed: 0,
            availableTonight: 0,
            waitlisted: 0,
            cancelledToday: 0
          });
        }

        if (reservationsRes.ok) {
          const resData = await reservationsRes.json();
          setRecentReservations(resData.slice(0, 5));
        }
      } catch (error) {
        console.error('Failed to fetch reservations data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchReservations();

    const onUpdate = () => {
      fetchReservations();
    };

    socket.on('reservations.updated', onUpdate);
    socket.on('reservation_waitlist.updated', onUpdate);
    socket.on('online_booking_requests.updated', onUpdate);

    return () => {
      socket.off('reservations.updated', onUpdate);
      socket.off('reservation_waitlist.updated', onUpdate);
      socket.off('online_booking_requests.updated', onUpdate);
    };
  }, []);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'CONFIRMED': return <Badge className="bg-blue-500">Confirmed</Badge>;
      case 'GUARANTEED': return <Badge className="bg-green-500">Guaranteed</Badge>;
      case 'PENDING': return <Badge className="bg-yellow-500 text-black">Pending</Badge>;
      case 'CANCELLED': return <Badge variant="destructive">Cancelled</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (loading) return <div className="p-8 text-center text-slate-400">Loading dashboard...</div>;

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Reservation Dashboard</h2>
          <p className="text-slate-400">Overview of today's property activity</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => router.push('/dashboard/reservations/new')} className="bg-brand-primary text-white hover:bg-brand-secondary">
            <CalendarCheck className="w-4 h-4 mr-2" /> New Reservation
          </Button>
          <Button onClick={() => router.push('/dashboard/reservations/search')} variant="outline" className="border-brand-primary text-brand-primary hover:bg-brand-primary/5">
            <Search className="w-4 h-4 mr-2" /> Search Availability
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-blue-500/10 rounded-lg text-blue-600"><LogIn size={24} /></div>
            <div>
              <p className="text-sm text-slate-400 font-medium">Arrivals Today</p>
              <p className="text-2xl font-bold text-slate-50">{stats?.arrivalsToday}</p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-orange-100 rounded-lg text-orange-600"><LogOut size={24} /></div>
            <div>
              <p className="text-sm text-slate-400 font-medium">Departures Today</p>
              <p className="text-2xl font-bold text-slate-50">{stats?.departuresToday}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-emerald-500/10 rounded-lg text-green-600"><CalendarCheck size={24} /></div>
            <div>
              <p className="text-sm text-slate-400 font-medium">Available Tonight</p>
              <p className="text-2xl font-bold text-slate-50">{stats?.availableTonight}</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 bg-purple-100 rounded-lg text-purple-600"><Users size={24} /></div>
            <div>
              <p className="text-sm text-slate-400 font-medium">Currently Reserved</p>
              <p className="text-2xl font-bold text-slate-50">{stats?.currentlyReserved}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-slate-400 font-medium">Pending</p>
            <p className="text-xl font-bold text-yellow-600">{stats?.pending}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-slate-400 font-medium">Guaranteed</p>
            <p className="text-xl font-bold text-green-600">{stats?.guaranteed}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-slate-400 font-medium">Waitlisted</p>
            <p className="text-xl font-bold text-indigo-600">{stats?.waitlisted}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-slate-400 font-medium">Cancelled Today</p>
            <p className="text-xl font-bold text-red-600">{stats?.cancelledToday}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2 border-b">
              <CardTitle className="text-lg font-medium text-slate-200">Recent Reservations</CardTitle>
              <Link href="/dashboard/reservations/all" className="text-sm text-brand-primary hover:underline">View All</Link>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-slate-900 text-slate-400 border-b">
                    <tr>
                      <th className="px-4 py-3 font-medium">Reservation</th>
                      <th className="px-4 py-3 font-medium">Guest</th>
                      <th className="px-4 py-3 font-medium">Arrival</th>
                      <th className="px-4 py-3 font-medium">Departure</th>
                      <th className="px-4 py-3 font-medium">Rooms</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {recentReservations.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-900 cursor-pointer" onClick={() => router.push(`/dashboard/reservations/${r.id}`)}>
                        <td className="px-4 py-3 font-medium text-brand-primary">{r.reservationNumber}</td>
                        <td className="px-4 py-3">{r.customer?.displayName || 'Unknown'}</td>
                        <td className="px-4 py-3">{format(new Date(r.arrivalDate), 'MMM d, yyyy')}</td>
                        <td className="px-4 py-3">{format(new Date(r.departureDate), 'MMM d, yyyy')}</td>
                        <td className="px-4 py-3">{r.reservationRooms?.length || 1}</td>
                        <td className="px-4 py-3">{getStatusBadge(r.status)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-2 border-b">
              <CardTitle className="text-lg font-medium text-slate-200">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-2">
              <Button variant="ghost" onClick={() => router.push('/dashboard/reservations/arrivals')} className="w-full justify-start text-slate-300 hover:bg-slate-800 hover:text-brand-primary">
                <LogIn className="w-4 h-4 mr-3" /> View Arrivals
              </Button>
              <Button variant="ghost" onClick={() => router.push('/dashboard/reservations/calendar')} className="w-full justify-start text-slate-300 hover:bg-slate-800 hover:text-brand-primary">
                <Calendar className="w-4 h-4 mr-3" /> View Calendar
              </Button>
              <Button variant="ghost" onClick={() => router.push('/dashboard/customers/walk-in')} className="w-full justify-start text-slate-300 hover:bg-slate-800 hover:text-brand-primary">
                <Users className="w-4 h-4 mr-3" /> Add Walk-In Guest
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
