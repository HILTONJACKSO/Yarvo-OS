"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Building, Users, Search, Plus, X, Briefcase, Settings } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { socket } from '@/lib/socket';

export default function DepartmentsPage() {
  const router = useRouter();
  const [departments, setDepartments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [businessId, setBusinessId] = useState('');
  const [token, setToken] = useState('');

  const fetchDepartments = () => {
    const t = localStorage.getItem('access_token');
    fetch('http://127.0.0.1:3002/businesses/current', { headers: { 'Authorization': `Bearer ${t}` }})
    .then(r => r.json())
    .then(data => {
      if (!data || !Array.isArray(data) || data.length === 0) {
        setLoading(false);
        return null;
      }
      const bid = data[0].businessId;
      setBusinessId(bid);
      setToken(t || '');
      return fetch('http://127.0.0.1:3002/departments', { headers: { 'Authorization': `Bearer ${t}`, 'x-business-id': bid }});
    })
    .then(r => r ? r.json() : [])
    .then(data => {
      setDepartments(Array.isArray(data) ? data : []);
      setLoading(false);
    })
    .catch(console.error);
  };

  useEffect(() => {
    fetchDepartments();

    const onDepartmentsUpdated = () => {
      fetchDepartments();
    };

    socket.on('departments.updated', onDepartmentsUpdated);

    return () => {
      socket.off('departments.updated', onDepartmentsUpdated);
    };
  }, []);

  const handleCreateDepartment = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('http://127.0.0.1:3002/departments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId
        },
        body: JSON.stringify({ name: newName, description: newDesc })
      });
      if (res.ok) {
        const newDept = await res.json();
        setDepartments([...departments, newDept]);
        setIsModalOpen(false);
        setNewName('');
        setNewDesc('');
      } else {
        const err = await res.json();
        alert(err.message || 'Failed to create department');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredDepts = departments.filter(d => 
    d.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-emerald-500/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10 flex items-center gap-4">
          <div className="p-4 bg-emerald-50 text-emerald-600 rounded-2xl">
            <Building size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-50 tracking-tight">Departments</h1>
            <p className="text-slate-400 mt-1 font-medium text-sm md:text-base">Organize your property into logical operational groups.</p>
          </div>
        </div>
        <div className="relative z-10">
          <button 
            onClick={() => setIsModalOpen(true)}
            className="px-6 py-3 bg-brand-primary text-white rounded-xl font-bold hover:bg-brand-primary/90 transition flex items-center gap-2 shadow-md hover:shadow-lg"
          >
            <Plus size={18} /> Add Department
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-950 p-4 rounded-2xl shadow-sm border border-slate-800 flex items-center gap-3 relative overflow-hidden">
        <div className="absolute left-0 top-0 bottom-0 w-2 bg-gradient-to-b from-brand-primary to-blue-400"></div>
        <div className="pl-4">
          <Search className="text-gray-400" size={20} />
        </div>
        <input 
          type="text" 
          placeholder="Search departments by name..." 
          className="w-full bg-transparent border-none focus:outline-none text-slate-50 font-medium placeholder:text-gray-400 py-2"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredDepts.map(dept => (
          <div key={dept.id} className="bg-slate-950 p-6 rounded-3xl border border-slate-800 shadow-sm hover:shadow-md hover:border-emerald-100 transition-all group relative overflow-hidden flex flex-col">
            <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-5 transition-opacity pointer-events-none">
              <Building size={64} />
            </div>
            
            <div className="flex items-start justify-between mb-6 relative z-10">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 text-emerald-600 flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                <Building size={24} />
              </div>
            </div>

            <div className="relative z-10 mb-6 flex-1">
              <h3 className="text-xl font-black text-slate-50 tracking-tight mb-1">{dept.name}</h3>
              <p className="text-sm text-slate-400 font-medium line-clamp-2">
                {dept.description || 'No operational description provided.'}
              </p>
            </div>
            
            <div className="flex items-center gap-2 mb-6 px-4 py-2.5 bg-slate-900 rounded-xl relative z-10">
              <Users size={16} className="text-gray-400" />
              <span className="text-sm font-bold text-slate-50">{dept._count?.employees || 0}</span>
              <span className="text-sm font-medium text-slate-400">Staff Assigned</span>
            </div>
            
            <div className="pt-4 border-t border-slate-800 relative z-10">
              <button 
                onClick={() => alert('Department configuration coming soon')}
                className="w-full py-2.5 px-4 bg-slate-950 border border-slate-800 text-slate-300 font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-200 transition-colors shadow-sm"
              >
                <Settings size={16} /> Configure
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {filteredDepts.length === 0 && (
        <div className="text-center py-20 bg-slate-950 rounded-3xl border border-slate-800 shadow-sm">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-900 mb-6">
            <Building className="text-gray-300" size={32} />
          </div>
          <h3 className="text-xl font-black text-slate-50 mb-2 tracking-tight">No departments found</h3>
          <p className="text-slate-400 font-medium max-w-md mx-auto">We couldn't find any departments matching your search criteria. Try a different keyword or create a new department.</p>
        </div>
      )}

      {/* Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-900/40 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-200 p-4">
          <div className="bg-slate-950 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="h-2 bg-gradient-to-r from-emerald-400 via-teal-500 to-cyan-500 w-full"></div>
            <div className="p-8">
              <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                    <Briefcase size={24} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-slate-50 tracking-tight">Add Department</h2>
                    <p className="text-sm text-slate-400 font-medium mt-1">Create a new organizational group.</p>
                  </div>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 text-gray-400 hover:text-slate-50 hover:bg-slate-800 rounded-full transition">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-bold">Department Name</Label>
                  <Input 
                    placeholder="e.g. Food & Beverage" 
                    value={newName} 
                    onChange={e => setNewName(e.target.value)} 
                    className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base"
                    autoFocus
                  />
                </div>
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-bold">Description</Label>
                  <Input 
                    placeholder="e.g. Handles all restaurant and bar operations" 
                    value={newDesc} 
                    onChange={e => setNewDesc(e.target.value)} 
                    className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-10">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsModalOpen(false)}
                  className="h-12 px-6 rounded-xl font-bold border-slate-800"
                >
                  Cancel
                </Button>
                <Button 
                  className="bg-brand-primary hover:bg-brand-primary/90 h-12 px-8 rounded-xl font-bold shadow-md hover:shadow-lg transition-all" 
                  disabled={submitting || !newName.trim()}
                  onClick={handleCreateDepartment}
                >
                  {submitting ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Adding...
                    </div>
                  ) : 'Add Department'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
