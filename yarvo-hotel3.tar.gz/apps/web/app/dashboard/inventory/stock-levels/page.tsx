"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, AlertTriangle, ArrowDown } from 'lucide-react';

export default function StockLevelsPage() {
  const [levels, setLevels] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/inventory/stock-levels`);
      if (response.ok) {
        const data = await response.json();
        setLevels(data);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Stock Levels</h1>
          <p className="text-slate-400 mt-1">Live view of physical on-hand stock versus available stock per location.</p>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex flex-wrap items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search items or locations..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Locations</option>
            <option value="main">Main Store</option>
            <option value="bar">Main Bar</option>
            <option value="kitchen">Kitchen Store</option>
          </select>
          <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-slate-300 hover:bg-slate-900 transition flex items-center gap-2 text-sm">
            <Filter size={16} /> Filters
          </button>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Item</th>
              <th className="p-4 font-semibold">Location</th>
              <th className="p-4 font-semibold text-right">On Hand</th>
              <th className="p-4 font-semibold text-right">Reserved</th>
              <th className="p-4 font-semibold text-right text-slate-50">Available</th>
              <th className="p-4 font-semibold text-right">Minimum</th>
              <th className="p-4 font-semibold text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {levels.map((level) => (
              <tr key={level.id} className="hover:bg-slate-900">
                <td className="p-4 font-medium text-slate-50">{level.item}</td>
                <td className="p-4 text-slate-400">{level.location}</td>
                <td className="p-4 text-right text-slate-400">{level.onHand}</td>
                <td className="p-4 text-right text-orange-500">{level.reserved}</td>
                <td className={`p-4 text-right font-bold ${level.available <= level.minimum ? 'text-red-600' : 'text-green-600'}`}>
                  {level.available}
                </td>
                <td className="p-4 text-right text-slate-400">{level.minimum}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full flex items-center justify-center gap-1 mx-auto w-max
                    ${level.status === 'Healthy' ? 'bg-emerald-500/10 text-green-700' : 
                      level.status === 'Low' ? 'bg-amber-500/10 text-yellow-700' : 
                      'bg-red-500/10 text-red-700'}`}>
                    {level.status === 'Low' || level.status === 'Out of Stock' ? <AlertTriangle size={12} /> : null}
                    {level.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
