"use client";

import { useState } from 'react';
import { Search, Save, Trash2, Info, ArrowRight, BookOpen } from 'lucide-react';
import Link from 'next/link';

export default function NewRecipePage() {
  const [ingredients, setIngredients] = useState<any[]>([]);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/recipes" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Recipes</Link>
          <h1 className="text-2xl font-bold text-slate-50">Create Recipe</h1>
          <p className="text-slate-400 mt-1">Link a POS product to its inventory ingredients.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 border-b">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Link to Catalog Product <span className="text-red-500">*</span></label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option>Grilled Chicken with Rice</option>
                <option>Club Beer (Large)</option>
                <option>Beef Burger</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Product Variation</label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option>None (Applies to all)</option>
                <option>Spicy</option>
                <option>Mild</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Production Store <span className="text-red-500">*</span></label>
              <div className="flex items-start gap-2">
                <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                  <option>Kitchen Store</option>
                  <option>Main Bar</option>
                </select>
              </div>
              <p className="text-xs text-slate-400 mt-1">Ingredients will be deducted from this location when the product is sold.</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Expected Yield / Portions</label>
              <input type="number" defaultValue="1" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
            </div>
          </div>
        </div>

        <div>
          <div className="p-4 bg-slate-900 border-b flex justify-between items-center">
            <h3 className="font-bold text-slate-50 flex items-center gap-2"><BookOpen size={18} /> Recipe Ingredients</h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search inventory items..." 
                className="w-full pl-9 pr-4 py-1.5 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
              />
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Ingredient</th>
                <th className="p-4 font-semibold text-center w-32">Quantity</th>
                <th className="p-4 font-semibold">Unit</th>
                <th className="p-4 font-semibold text-right">Unit Cost</th>
                <th className="p-4 font-semibold text-right">Total Cost</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {ingredients.map((item) => (
                <tr key={item.id} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      step="0.01"
                      defaultValue={item.qty} 
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-center"
                    />
                  </td>
                  <td className="p-4 text-slate-400">{item.unit}</td>
                  <td className="p-4 text-right text-slate-400">${item.costPerUnit.toFixed(2)}</td>
                  <td className="p-4 text-right font-medium text-slate-50">${item.totalCost.toFixed(2)}</td>
                  <td className="p-4 text-right">
                    <button className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={18}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-900">
              <tr>
                <td colSpan={4} className="p-4 text-right font-medium text-slate-300">Total Recipe Cost:</td>
                <td className="p-4 text-right font-bold text-red-600 text-lg">$2.10</td>
                <td></td>
              </tr>
              <tr>
                <td colSpan={4} className="px-4 py-2 text-right font-medium text-slate-300">Product Selling Price:</td>
                <td className="px-4 py-2 text-right font-bold text-green-600">$12.00</td>
                <td></td>
              </tr>
              <tr>
                <td colSpan={4} className="px-4 pb-4 pt-2 text-right font-medium text-slate-300 border-t">Cost Percentage:</td>
                <td className="px-4 pb-4 pt-2 text-right font-bold text-slate-50 border-t">17.5%</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between">
          <Link href="/dashboard/inventory/recipes" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          <div className="flex gap-2">
            <button className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2">
              <Save size={18} /> Save as Draft
            </button>
            <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
              <Save size={18} /> Save and Activate
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
