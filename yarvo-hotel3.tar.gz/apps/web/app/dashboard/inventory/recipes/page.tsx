"use client";

import { useState, useEffect } from 'react';
import { Search, Plus, ChefHat, Edit2 } from 'lucide-react';
import Link from 'next/link';

export default function RecipesPage() {
  const [recipes, setRecipes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/inventory/recipes`);
      if (response.ok) {
        const data = await response.json();
        setRecipes(data);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Recipes</h1>
          <p className="text-slate-400 mt-1">Link catalog products to inventory ingredients for automatic deduction.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/inventory/recipes/new" className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
            <Plus size={18} /> Create Recipe
          </Link>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search recipes..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="DRAFT">Draft</option>
            <option value="ARCHIVED">Archived</option>
          </select>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Catalog Product</th>
              <th className="p-4 font-semibold">Variation</th>
              <th className="p-4 font-semibold text-center">Ingredients</th>
              <th className="p-4 font-semibold text-right">Recipe Cost</th>
              <th className="p-4 font-semibold text-right">Selling Price</th>
              <th className="p-4 font-semibold text-right">Cost %</th>
              <th className="p-4 font-semibold text-center">Status</th>
              <th className="p-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {recipes.map((recipe) => (
              <tr key={recipe.id} className="hover:bg-slate-900">
                <td className="p-4 font-medium text-slate-50 flex items-center gap-3">
                  <div className="p-1.5 bg-slate-800 rounded text-slate-400">
                    <ChefHat size={16} />
                  </div>
                  {recipe.product}
                </td>
                <td className="p-4 text-slate-400">{recipe.variation}</td>
                <td className="p-4 text-center text-slate-400">{recipe.ingredientsCount} items</td>
                <td className="p-4 text-right font-medium text-red-600">${recipe.cost.toFixed(2)}</td>
                <td className="p-4 text-right font-medium text-green-600">${recipe.sellingPrice.toFixed(2)}</td>
                <td className="p-4 text-right text-slate-400">{recipe.costPercent.toFixed(2)}%</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${recipe.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-slate-800 text-slate-300'}`}>
                    {recipe.status}
                  </span>
                </td>
                <td className="p-4 flex items-center justify-end gap-2">
                  <button className="p-1.5 text-gray-400 hover:text-brand-primary rounded"><Edit2 size={16}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
