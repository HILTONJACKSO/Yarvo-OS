"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, Download, ArrowRightLeft, TrendingDown, TrendingUp, AlertCircle } from 'lucide-react';

export default function StockMovementsPage() {
  const [movements, setMovements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/inventory/movements`);
      if (response.ok) {
        const data = await response.json();
        setMovements(data);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  const renderIcon = (type: string) => {
    if (type.includes('IN') || type.includes('RECEIPT')) return <TrendingUp size={16} className="text-green-500" />;
    if (type.includes('OUT') || type.includes('DEDUCTION') || type.includes('CONSUMPTION') || type.includes('ISSUE')) return <TrendingDown size={16} className="text-red-500" />;
    if (type.includes('WASTE')) return <AlertCircle size={16} className="text-yellow-500" />;
    return <ArrowRightLeft size={16} className="text-slate-400" />;
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Stock Movements</h1>
          <p className="text-slate-400 mt-1">Immutable ledger of all inventory transactions and cost changes.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-slate-300 hover:bg-slate-900 transition flex items-center gap-2">
            <Download size={18} /> Export Ledger
          </button>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex flex-wrap items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search reference, item..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Movement Types</option>
            <option value="PURCHASE_RECEIPT">Purchases</option>
            <option value="SALE_DEDUCTION">Sales & Recipes</option>
            <option value="TRANSFER">Transfers</option>
            <option value="WASTE">Waste & Adjustments</option>
          </select>
          <input type="date" className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm" />
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Movement #</th>
              <th className="p-4 font-semibold">Date & Time</th>
              <th className="p-4 font-semibold">Item</th>
              <th className="p-4 font-semibold">Type</th>
              <th className="p-4 font-semibold">From &rarr; To</th>
              <th className="p-4 font-semibold text-right">Quantity</th>
              <th className="p-4 font-semibold text-right">Total Cost</th>
              <th className="p-4 font-semibold">Ref</th>
              <th className="p-4 font-semibold">User</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {movements.map((mov) => (
              <tr key={mov.id} className="hover:bg-slate-900">
                <td className="p-4 font-mono text-xs text-brand-primary font-medium">{mov.number}</td>
                <td className="p-4 text-slate-400 text-xs">{mov.date}</td>
                <td className="p-4 font-medium text-slate-50">{mov.item}</td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    {renderIcon(mov.type)}
                    <span className="text-xs font-medium text-slate-400">{mov.type.replace('_', ' ')}</span>
                  </div>
                </td>
                <td className="p-4 text-xs text-slate-400">
                  {mov.from} &rarr; {mov.to}
                </td>
                <td className={`p-4 text-right font-bold ${mov.qty.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                  {mov.qty}
                </td>
                <td className="p-4 text-right text-slate-400">{mov.cost}</td>
                <td className="p-4 text-slate-400 text-xs">{mov.ref}</td>
                <td className="p-4 text-slate-400">{mov.by}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
