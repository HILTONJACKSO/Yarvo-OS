"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, Plus, Clock, CheckCircle } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function CleaningTasksPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState<any[]>([]);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch('http://127.0.0.1:3002/housekeeping/tasks', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setTasks(data.map((t: any) => ({
            id: t.id,
            room: t.roomNumber,
            type: t.taskType,
            priority: t.priority,
            status: t.status,
            housekeeper: t.assignedTo,
            dueTime: '3:00 PM',
            elapsedTime: null
          })));
        }
      } catch (err) {
        console.error('Failed to fetch tasks', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTasks();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('housekeeping.task.updated', fetchTasks);
    return () => { socket.disconnect(); };
  }, []);

  const getPriorityBadge = (priority: string) => {
    switch(priority) {
      case 'NORMAL': return <span className="px-2 py-1 bg-slate-800 text-slate-300 rounded text-xs font-bold">NORMAL</span>;
      case 'HIGH': return <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded text-xs font-bold">HIGH</span>;
      case 'URGENT': return <span className="px-2 py-1 bg-red-500/10 text-red-700 rounded text-xs font-bold">URGENT</span>;
      case 'VIP': return <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs font-bold border border-purple-200">VIP</span>;
      default: return <span className="px-2 py-1 bg-slate-800 text-slate-300 rounded text-xs font-bold">{priority}</span>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'UNASSIGNED': return <span className="text-slate-400 font-medium text-sm border px-2 py-1 rounded-md bg-slate-900">Unassigned</span>;
      case 'ASSIGNED': return <span className="text-blue-600 font-medium text-sm border border-blue-200 px-2 py-1 rounded-md bg-blue-50">Assigned</span>;
      case 'IN_PROGRESS': return <span className="text-orange-600 font-medium text-sm border border-orange-200 px-2 py-1 rounded-md bg-orange-50">In Progress</span>;
      case 'AWAITING_INSPECTION': return <span className="text-purple-600 font-medium text-sm border border-purple-200 px-2 py-1 rounded-md bg-purple-50">Awaiting Inspection</span>;
      default: return <span className="text-slate-400 font-medium text-sm">{status}</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Cleaning Tasks</h1>
          <p className="text-slate-400 mt-1">Manage and track all housekeeping tasks across the property.</p>
        </div>
        <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-primary/90 transition flex items-center gap-2">
          <Plus size={18} /> New Task
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border p-4 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search tasks, rooms, housekeepers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
          />
        </div>
        <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950">
          <option value="">All Statuses</option>
          <option value="UNASSIGNED">Unassigned</option>
          <option value="ASSIGNED">Assigned</option>
          <option value="IN_PROGRESS">In Progress</option>
          <option value="AWAITING_INSPECTION">Awaiting Inspection</option>
        </select>
        <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-slate-900 transition">
          <Filter size={18} /> More Filters
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Task ID</th>
              <th className="p-4 font-semibold">Room</th>
              <th className="p-4 font-semibold">Type</th>
              <th className="p-4 font-semibold">Priority</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold">Housekeeper</th>
              <th className="p-4 font-semibold">Due</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={8} className="p-8 text-center text-slate-400">Loading tasks...</td></tr>
            ) : tasks.length === 0 ? (
              <tr><td colSpan={8} className="p-8 text-center text-slate-400">No tasks found.</td></tr>
            ) : tasks.map((task) => (
              <tr key={task.id} className="hover:bg-slate-900 transition">
                <td className="p-4 text-sm font-medium text-slate-400">{task.id}</td>
                <td className="p-4 font-bold text-slate-50">{task.room}</td>
                <td className="p-4 text-sm">{task.type.replace(/_/g, ' ')}</td>
                <td className="p-4">{getPriorityBadge(task.priority)}</td>
                <td className="p-4">{getStatusBadge(task.status)}</td>
                <td className="p-4">{task.housekeeper || <span className="text-slate-500 italic">Unassigned</span>}</td>
                <td className="p-4 text-sm text-slate-400">
                  <div className="flex items-center gap-1"><Clock size={14} className={task.elapsedTime ? 'text-orange-500' : ''}/> {task.elapsedTime ? `${task.elapsedTime} (Elapsed)` : task.dueTime}</div>
                </td>
                <td className="p-4 text-right">
                  <button className="text-brand-primary font-medium hover:underline text-sm">Manage</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
