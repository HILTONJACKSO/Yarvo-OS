"use client";

import { useState, useEffect } from 'react';
import { Sparkles, Bed, Clock, AlertTriangle, AlertCircle, RefreshCcw, BellRing, Briefcase, EyeOff, Wrench } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function HousekeepingDashboard() {
  const [stats, setStats] = useState({
    dirty: 0,
    assigned: 0,
    cleaning: 0,
    awaitingInspection: 0,
    ready: 0,
    recleaning: 0,
    doNotDisturb: 0,
    maintenance: 0,
    openTasks: 0
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch('http://127.0.0.1:3002/housekeeping/stats', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setStats({
            dirty: data.dirtyRooms,
            ready: data.cleanRooms,
            awaitingInspection: data.pendingInspections,
            cleaning: data.openTasks,
            assigned: data.staffOnDuty,
            recleaning: 0,
            doNotDisturb: 0,
            maintenance: 0,
            openTasks: data.openTasks
          });
        }
      } catch (err) {
        console.error('Failed to fetch housekeeping stats', err);
      }
    };

    fetchStats();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('housekeeping.room.updated', fetchStats);
    socket.on('housekeeping.task.updated', fetchStats);
    
    return () => {
      socket.disconnect();
    };
  }, []);

  const [alerts, setAlerts] = useState([
    { id: 1, type: 'critical', text: 'Four expected arrivals have rooms that are not ready.' },
    { id: 2, type: 'warning', text: 'Two rooms have exceeded their expected cleaning time.' },
    { id: 3, type: 'critical', text: 'One VIP-arrival room is still dirty.' },
    { id: 4, type: 'warning', text: 'Three stay-over rooms have not been serviced.' },
    { id: 5, type: 'info', text: 'Linen stock for "King Bedsheets" is below the configured level.' }
  ]);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Housekeeping Dashboard</h1>
          <p className="text-slate-400 mt-1">Real-time overview of room statuses and tasks.</p>
        </div>
        <div className="flex gap-3">
          <Link href="/dashboard/housekeeping/assign" className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-primary/90 transition">
            Assign Rooms
          </Link>
          <Link href="/dashboard/housekeeping/room-board" className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-slate-300 hover:bg-slate-900 transition">
            Live Room Board
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-red-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Dirty Rooms</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.dirty}</h3>
            </div>
            <div className="p-2 bg-red-50 rounded-lg"><Sparkles className="w-5 h-5 text-red-600" /></div>
          </div>
        </div>
        
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-green-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Ready for Guests</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.ready}</h3>
            </div>
            <div className="p-2 bg-green-50 rounded-lg"><Bed className="w-5 h-5 text-green-600" /></div>
          </div>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-blue-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Assigned</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.assigned}</h3>
            </div>
            <div className="p-2 bg-blue-50 rounded-lg"><Briefcase className="w-5 h-5 text-blue-600" /></div>
          </div>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-orange-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Currently Cleaning</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.cleaning}</h3>
            </div>
            <div className="p-2 bg-orange-50 rounded-lg"><RefreshCcw className="w-5 h-5 text-orange-600 animate-spin-slow" /></div>
          </div>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-purple-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Awaiting Inspection</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.awaitingInspection}</h3>
            </div>
            <div className="p-2 bg-purple-50 rounded-lg"><EyeOff className="w-5 h-5 text-purple-600" /></div>
          </div>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-yellow-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Recleaning Req.</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.recleaning}</h3>
            </div>
            <div className="p-2 bg-yellow-50 rounded-lg"><AlertTriangle className="w-5 h-5 text-yellow-600" /></div>
          </div>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-gray-500">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Do Not Disturb</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.doNotDisturb}</h3>
            </div>
            <div className="p-2 bg-slate-800 rounded-lg"><BellRing className="w-5 h-5 text-slate-400" /></div>
          </div>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-l-4 border-l-red-900">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400 mb-1">Maintenance Req.</p>
              <h3 className="text-3xl font-black text-slate-50">{stats.maintenance}</h3>
            </div>
            <div className="p-2 bg-red-50 rounded-lg"><Wrench className="w-5 h-5 text-red-900" /></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Alerts Section */}
        <div className="lg:col-span-2 bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="px-6 py-4 border-b bg-slate-900 flex justify-between items-center">
            <h3 className="font-bold text-slate-50 flex items-center gap-2"><AlertCircle size={18} className="text-red-500"/> Action Required</h3>
          </div>
          <div className="p-4 space-y-3">
            {alerts.map(alert => (
              <div key={alert.id} className={`p-4 rounded-lg flex items-start gap-3 border ${
                alert.type === 'critical' ? 'bg-red-50 border-red-100 text-red-900' :
                alert.type === 'warning' ? 'bg-orange-50 border-orange-100 text-orange-900' :
                'bg-blue-50 border-blue-100 text-blue-900'
              }`}>
                {alert.type === 'critical' ? <AlertCircle className="shrink-0 mt-0.5" size={18} /> :
                 alert.type === 'warning' ? <AlertTriangle className="shrink-0 mt-0.5" size={18} /> :
                 <Clock className="shrink-0 mt-0.5" size={18} />}
                <p className="font-medium text-sm">{alert.text}</p>
              </div>
            ))}
            {alerts.length === 0 && <p className="text-slate-400 p-4 text-center">No alerts at this time.</p>}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="px-6 py-4 border-b bg-slate-900">
            <h3 className="font-bold text-slate-50">Quick Actions</h3>
          </div>
          <div className="p-2">
            <Link href="/dashboard/housekeeping/inspections" className="flex items-center gap-3 p-3 hover:bg-slate-900 rounded-lg transition text-sm font-medium text-slate-300">
              <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center"><EyeOff size={16} /></div>
              Start Inspections ({stats.awaitingInspection})
            </Link>
            <Link href="/dashboard/housekeeping/lost-and-found" className="flex items-center gap-3 p-3 hover:bg-slate-900 rounded-lg transition text-sm font-medium text-slate-300">
              <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center"><Briefcase size={16} /></div>
              Report Lost Item
            </Link>
            <Link href="/dashboard/housekeeping/linen/movements" className="flex items-center gap-3 p-3 hover:bg-slate-900 rounded-lg transition text-sm font-medium text-slate-300">
              <div className="w-8 h-8 rounded-full bg-blue-500/10 text-blue-600 flex items-center justify-center"><Sparkles size={16} /></div>
              Record Linen Movement
            </Link>
            <Link href="/dashboard/housekeeping/stay-over" className="flex items-center gap-3 p-3 hover:bg-slate-900 rounded-lg transition text-sm font-medium text-slate-300">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-green-600 flex items-center justify-center"><Bed size={16} /></div>
              Manage Stay-Over Rooms
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
