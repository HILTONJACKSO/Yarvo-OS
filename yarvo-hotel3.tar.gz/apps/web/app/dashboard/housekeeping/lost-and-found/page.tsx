"use client";

import { useState, useEffect } from 'react';
import { Search, Plus, Archive, History } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function LostAndFoundPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch('http://127.0.0.1:3002/housekeeping/lost-and-found', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setItems(data.map((i: any) => ({
            id: i.itemNumber || i.id,
            item: i.description,
            category: i.category,
            foundIn: i.roomId ? `Room ${i.roomId}` : 'Public Area',
            dateFound: i.foundAt,
            status: i.status === 'FOUND' ? 'UNCLAIMED' : i.status,
            storageLocation: i.storageLocation || 'Unknown'
          })));
        }
      } catch (err) {
        console.error('Failed to fetch lost and found', err);
      } finally {
        setLoading(false);
      }
    };
    fetchItems();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('housekeeping.lostfound.updated', fetchItems);
    return () => { socket.disconnect(); };
  }, []);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'UNCLAIMED': return <span className="text-red-700 bg-red-500/10 font-medium text-xs px-2 py-1 rounded-md border border-red-200">Unclaimed</span>;
      case 'GUEST_CONTACTED': return <span className="text-blue-700 bg-blue-500/10 font-medium text-xs px-2 py-1 rounded-md border border-blue-200">Guest Contacted</span>;
      case 'RETURNED': return <span className="text-green-700 bg-emerald-500/10 font-medium text-xs px-2 py-1 rounded-md border border-green-200">Returned</span>;
      case 'DISCARDED': return <span className="text-slate-300 bg-slate-800 font-medium text-xs px-2 py-1 rounded-md border">Discarded</span>;
      default: return <span className="text-slate-400 font-medium text-xs">{status}</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Lost & Found</h1>
          <p className="text-slate-400 mt-1">Log and track items left behind by guests.</p>
        </div>
        <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-primary/90 transition flex items-center gap-2">
          <Plus size={18} /> Log New Item
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input type="text" placeholder="Search items, locations..." className="w-full pl-9 pr-4 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50" />
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 text-sm bg-slate-950 border rounded-md hover:bg-slate-900 text-slate-300 font-medium flex items-center gap-2"><Archive size={14}/> Unclaimed</button>
            <button className="px-3 py-1.5 text-sm bg-slate-950 border rounded-md hover:bg-slate-900 text-slate-300 font-medium flex items-center gap-2"><History size={14}/> History</button>
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-950 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Ref #</th>
              <th className="p-4 font-semibold">Item Description</th>
              <th className="p-4 font-semibold">Category</th>
              <th className="p-4 font-semibold">Found Location</th>
              <th className="p-4 font-semibold">Date Found</th>
              <th className="p-4 font-semibold">Storage</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={8} className="p-8 text-center text-slate-400">Loading items...</td></tr>
            ) : items.map((item) => (
              <tr key={item.id} className="hover:bg-slate-900 transition">
                <td className="p-4 text-sm font-medium text-slate-400">{item.id}</td>
                <td className="p-4 font-bold text-slate-50">{item.item}</td>
                <td className="p-4 text-sm text-slate-400">{item.category}</td>
                <td className="p-4 text-sm text-slate-200 font-medium">{item.foundIn}</td>
                <td className="p-4 text-sm text-slate-400">{item.dateFound}</td>
                <td className="p-4 text-sm text-slate-400 font-mono">{item.storageLocation}</td>
                <td className="p-4">{getStatusBadge(item.status)}</td>
                <td className="p-4 text-right">
                  <button className="text-brand-primary font-medium text-sm hover:underline">View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
