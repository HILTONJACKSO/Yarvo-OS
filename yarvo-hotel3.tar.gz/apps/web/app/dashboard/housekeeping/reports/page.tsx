"use client";

import { useState, useEffect } from 'react';
import { BarChart2, Calendar, Download, TrendingUp, Sparkles, CheckCircle2, Clock } from 'lucide-react';
import Link from 'next/link';

export default function HousekeepingReportsPage() {
  const [loading, setLoading] = useState(true);
  const [reports, setReports] = useState<any>({
    productivity: 100,
    totalCleaned: 0,
    totalPending: 0
  });

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch('http://127.0.0.1:3002/housekeeping/reports', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setReports(data);
        }
      } catch (err) {
        console.error('Failed to fetch reports', err);
      } finally {
        setLoading(false);
      }
    };
    fetchReports();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Housekeeping Reports</h1>
          <p className="text-slate-400 mt-1">Analytics on staff performance, cleaning times, and room turnaround.</p>
        </div>
        <div className="flex gap-2">
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950">
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
          </select>
          <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-slate-300 hover:bg-slate-900 transition flex items-center gap-2">
            <Download size={18} /> Export
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading analytics...</div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex items-center gap-3 mb-2 text-slate-400">
                <Clock size={18} /> <h3 className="font-medium text-sm">Avg. Turnaround Time</h3>
              </div>
              <p className="text-3xl font-black text-slate-50">{reports.avgTurnaroundTime || '0m'}</p>
              <p className="text-xs text-green-600 font-medium mt-2 flex items-center gap-1"><TrendingUp size={12}/> {reports.turnaroundTrend || '0% change'}</p>
            </div>

            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex items-center gap-3 mb-2 text-slate-400">
                <CheckCircle2 size={18} /> <h3 className="font-medium text-sm">Inspection Pass Rate</h3>
              </div>
              <p className="text-3xl font-black text-slate-50">{reports.inspectionPassRate || '0%'}</p>
              <p className="text-xs text-green-600 font-medium mt-2 flex items-center gap-1"><TrendingUp size={12}/> {reports.passRateTrend || '0% change'}</p>
            </div>

            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex items-center gap-3 mb-2 text-slate-400">
                <Sparkles size={18} /> <h3 className="font-medium text-sm">Rooms Cleaned</h3>
              </div>
              <p className="text-3xl font-black text-slate-50">{reports.totalCleaned || 0}</p>
              <p className="text-xs text-slate-400 font-medium mt-2">This week</p>
            </div>

            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex items-center gap-3 mb-2 text-slate-400">
                <BarChart2 size={18} /> <h3 className="font-medium text-sm">Top Performer</h3>
              </div>
              <p className="text-xl font-bold text-slate-50 truncate">{reports.topPerformer?.name || 'N/A'}</p>
              <p className="text-xs text-slate-400 font-medium mt-2">{reports.topPerformer?.rooms || 0} rooms â€¢ {reports.topPerformer?.passRate || '0%'} Pass Rate</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-slate-950 rounded-xl shadow-sm border p-6">
              <h3 className="font-bold text-slate-50 mb-4">Cleaning Time by Room Type</h3>
              <div className="space-y-4">
                {(reports.cleaningTimeByRoomType || []).length > 0 ? reports.cleaningTimeByRoomType.map((rt: any, idx: number) => (
                  <div key={idx}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium text-slate-300">{rt.type}</span>
                      <span className="text-slate-400">{rt.mins} mins</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${rt.percentage}%` }}></div>
                    </div>
                  </div>
                )) : (
                  <p className="text-sm text-slate-400">No data available.</p>
                )}
              </div>
            </div>

            <div className="bg-slate-950 rounded-xl shadow-sm border p-6">
              <h3 className="font-bold text-slate-50 mb-4">Inspection Failures by Category</h3>
              <div className="space-y-4">
                {(reports.inspectionFailures || []).length > 0 ? reports.inspectionFailures.map((failure: any, idx: number) => (
                  <div key={idx} className="flex items-center justify-between p-3 border rounded-lg bg-slate-900">
                    <span className="font-medium text-slate-300">{failure.category}</span>
                    <span className="font-bold text-red-600">{failure.count} Issues</span>
                  </div>
                )) : (
                  <p className="text-sm text-slate-400">No inspection failures recorded.</p>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
