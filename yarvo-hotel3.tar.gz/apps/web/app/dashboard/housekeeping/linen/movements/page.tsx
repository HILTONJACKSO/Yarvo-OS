"use client";

import { useState, useEffect } from 'react';
import { Search, Plus, ArrowRightLeft, WashingMachine, Home, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function LinenMovementsPage() {
  const [movements, setMovements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovements = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch('http://127.0.0.1:3002/housekeeping/linen/movements', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setMovements(data.map((m: any) => ({
            id: m.id,
            item: m.linenItemId || 'Unknown Linen',
            type: m.movementType,
            quantity: m.quantity,
            date: m.createdAt || 'Today',
            by: m.createdByUserId || 'Unknown',
            notes: m.reason || ''
          })));
        }
      } catch (err) {
        console.error('Failed to fetch linen movements', err);
      } finally {
        setLoading(false);
      }
    };
    fetchMovements();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('housekeeping.linen.updated', fetchMovements);
    return () => { socket.disconnect(); };
  }, []);

  const getTypeBadge = (type: string) => {
    switch(type) {
      case 'TO_LAUNDRY': return <span className="text-orange-700 bg-orange-100 font-medium text-xs px-2 py-1 rounded border border-orange-200 flex items-center gap-1 w-max"><ArrowRightLeft size={12}/> To Laundry</span>;
      case 'FROM_LAUNDRY': return <span className="text-green-700 bg-emerald-500/10 font-medium text-xs px-2 py-1 rounded border border-green-200 flex items-center gap-1 w-max"><WashingMachine size={12}/> From Laundry</span>;
      case 'ROOM_PLACEMENT': return <span className="text-blue-700 bg-blue-500/10 font-medium text-xs px-2 py-1 rounded border border-blue-200 flex items-center gap-1 w-max"><Home size={12}/> To Room</span>;
      case 'DISCARD': return <span className="text-red-700 bg-red-500/10 font-medium text-xs px-2 py-1 rounded border border-red-200 flex items-center gap-1 w-max"><Trash2 size={12}/> Discarded</span>;
      default: return <span className="text-slate-400 font-medium text-xs">{type}</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping/linen/items" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Catalog</Link>
          <h1 className="text-2xl font-bold text-slate-50">Linen Movements</h1>
          <p className="text-slate-400 mt-1">Track linen going to laundry, returning from laundry, and discarded items.</p>
        </div>
        <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-primary/90 transition flex items-center gap-2">
          <ArrowRightLeft size={18} /> Record Movement
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input type="text" placeholder="Search movements..." className="w-full pl-9 pr-4 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50" />
          </div>
          <div className="flex gap-2">
            <select className="px-3 py-1.5 text-sm bg-slate-950 border rounded-md focus:outline-none text-slate-300">
              <option value="">All Movement Types</option>
              <option value="TO_LAUNDRY">To Laundry</option>
              <option value="FROM_LAUNDRY">From Laundry</option>
              <option value="DISCARD">Discarded</option>
            </select>
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-950 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">ID</th>
              <th className="p-4 font-semibold">Linen Item</th>
              <th className="p-4 font-semibold">Movement Type</th>
              <th className="p-4 font-semibold">Quantity</th>
              <th className="p-4 font-semibold">Date & Time</th>
              <th className="p-4 font-semibold">Recorded By</th>
              <th className="p-4 font-semibold">Notes</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400">Loading movements...</td></tr>
            ) : movements.map((m) => (
              <tr key={m.id} className="hover:bg-slate-900 transition">
                <td className="p-4 text-sm font-medium text-slate-400 font-mono">{m.id}</td>
                <td className="p-4 font-bold text-slate-50">{m.item}</td>
                <td className="p-4">{getTypeBadge(m.type)}</td>
                <td className="p-4 text-lg font-black text-slate-200">{m.quantity}</td>
                <td className="p-4 text-sm text-slate-400">{m.date}</td>
                <td className="p-4 text-sm font-medium text-slate-300">{m.by}</td>
                <td className="p-4 text-sm text-slate-400">{m.notes || 'â€”'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
