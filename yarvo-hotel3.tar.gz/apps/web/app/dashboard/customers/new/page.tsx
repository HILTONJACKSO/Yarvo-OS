"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Check, User, Mail, Phone, MapPin, ShieldCheck, Heart } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

export default function NewCustomerPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  
  const [formData, setFormData] = useState({
    customerType: 'INDIVIDUAL',
    firstName: '',
    middleName: '',
    lastName: '',
    email: '',
    phone: '',
    alternativePhone: '',
    gender: '',
    dateOfBirth: '',
    nationality: '',
    preferredLanguage: 'English',
    country: '',
    city: '',
    address: '',
    isVip: false,
    marketingConsent: false,
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const displayName = [formData.firstName, formData.lastName].filter(Boolean).join(' ') || 'Unknown Customer';
      
      const payload = {
        ...formData,
        displayName,
        customerNumber: `CUST-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
        dateOfBirth: formData.dateOfBirth ? new Date(formData.dateOfBirth).toISOString() : null,
      };

      const res = await fetch('http://127.0.0.1:3002/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        router.push(`/dashboard/customers/${data.id}`);
      } else {
        console.error('Failed to create customer');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft size={20} />
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Register New Customer</h2>
          <p className="text-slate-400 text-sm">Create a comprehensive profile for an individual guest</p>
        </div>
      </div>

      <div className="flex gap-4 mb-8">
        {[
          { num: 1, title: 'Basic Info', icon: User },
          { num: 2, title: 'Contact', icon: Mail },
          { num: 3, title: 'Details', icon: MapPin },
          { num: 4, title: 'Preferences', icon: Heart }
        ].map((s) => (
          <div key={s.num} className={`flex-1 relative ${step >= s.num ? 'text-brand-primary' : 'text-gray-400'}`}>
            <div className={`flex flex-col items-center gap-2 relative z-10`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${step > s.num ? 'bg-brand-primary border-brand-primary text-white' : step === s.num ? 'border-brand-primary bg-slate-950' : 'border-slate-800 bg-slate-900'}`}>
                {step > s.num ? <Check size={18} /> : <s.icon size={18} />}
              </div>
              <span className="text-xs font-medium text-center">{s.title}</span>
            </div>
            {s.num < 4 && (
              <div className={`absolute top-5 left-1/2 w-full h-[2px] -translate-y-1/2 ${step > s.num ? 'bg-brand-primary' : 'bg-gray-200'}`} style={{ width: 'calc(100% - 20px)' }} />
            )}
          </div>
        ))}
      </div>

      <Card className="border-slate-800 shadow-sm">
        <CardContent className="p-8">
          {step === 1 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
              <h3 className="text-lg font-semibold text-slate-200 border-b pb-2">Basic Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label>First Name <span className="text-red-500">*</span></Label>
                  <Input value={formData.firstName} onChange={(e) => handleInputChange('firstName', e.target.value)} placeholder="e.g. John" />
                </div>
                <div className="space-y-2">
                  <Label>Middle Name</Label>
                  <Input value={formData.middleName} onChange={(e) => handleInputChange('middleName', e.target.value)} placeholder="Optional" />
                </div>
                <div className="space-y-2">
                  <Label>Last Name <span className="text-red-500">*</span></Label>
                  <Input value={formData.lastName} onChange={(e) => handleInputChange('lastName', e.target.value)} placeholder="e.g. Doe" />
                </div>
                <div className="space-y-2">
                  <Label>Gender</Label>
                  <Select value={formData.gender} onValueChange={(val) => handleInputChange('gender', val)}>
                    <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MALE">Male</SelectItem>
                      <SelectItem value="FEMALE">Female</SelectItem>
                      <SelectItem value="OTHER">Other</SelectItem>
                      <SelectItem value="PREFER_NOT_TO_SAY">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Date of Birth</Label>
                  <Input type="date" value={formData.dateOfBirth} onChange={(e) => handleInputChange('dateOfBirth', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Nationality</Label>
                  <Input value={formData.nationality} onChange={(e) => handleInputChange('nationality', e.target.value)} placeholder="e.g. American" />
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
              <h3 className="text-lg font-semibold text-slate-200 border-b pb-2">Contact Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Primary Phone <span className="text-red-500">*</span></Label>
                  <Input value={formData.phone} onChange={(e) => handleInputChange('phone', e.target.value)} placeholder="+1 234 567 890" />
                </div>
                <div className="space-y-2">
                  <Label>Alternative Phone</Label>
                  <Input value={formData.alternativePhone} onChange={(e) => handleInputChange('alternativePhone', e.target.value)} placeholder="Optional" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Email Address</Label>
                  <Input type="email" value={formData.email} onChange={(e) => handleInputChange('email', e.target.value)} placeholder="john.doe@example.com" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Preferred Language</Label>
                  <Select value={formData.preferredLanguage} onValueChange={(val) => handleInputChange('preferredLanguage', val)}>
                    <SelectTrigger><SelectValue placeholder="Select language" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="Spanish">Spanish</SelectItem>
                      <SelectItem value="French">French</SelectItem>
                      <SelectItem value="German">German</SelectItem>
                      <SelectItem value="Arabic">Arabic</SelectItem>
                      <SelectItem value="Chinese">Chinese</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
              <h3 className="text-lg font-semibold text-slate-200 border-b pb-2">Location Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Country of Residence</Label>
                  <Input value={formData.country} onChange={(e) => handleInputChange('country', e.target.value)} placeholder="e.g. United States" />
                </div>
                <div className="space-y-2">
                  <Label>City</Label>
                  <Input value={formData.city} onChange={(e) => handleInputChange('city', e.target.value)} placeholder="e.g. New York" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Physical Address</Label>
                  <Input value={formData.address} onChange={(e) => handleInputChange('address', e.target.value)} placeholder="Full street address" />
                </div>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
              <h3 className="text-lg font-semibold text-slate-200 border-b pb-2">Preferences & Status</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 p-4 border rounded-lg bg-amber-500/10 border-amber-500/20 hover:border-amber-500/40 transition-colors">
                  <Checkbox 
                    id="isVip" 
                    checked={formData.isVip} 
                    onCheckedChange={(checked) => handleInputChange('isVip', checked)}
                    className="data-[state=checked]:bg-amber-500 data-[state=checked]:text-slate-950 border-amber-500/50"
                  />
                  <div className="space-y-1">
                    <Label htmlFor="isVip" className="font-medium text-amber-400 cursor-pointer">Mark as VIP Customer</Label>
                    <p className="text-xs text-amber-500/80">VIP customers receive priority service and special amenities across all branches.</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3 p-4 border rounded-lg bg-slate-900 border-slate-800 hover:border-emerald-500/50 transition-colors">
                  <Checkbox 
                    id="marketing" 
                    checked={formData.marketingConsent} 
                    onCheckedChange={(checked) => handleInputChange('marketingConsent', checked)}
                  />
                  <div className="space-y-1">
                    <Label htmlFor="marketing" className="font-medium cursor-pointer">Marketing Consent</Label>
                    <p className="text-xs text-slate-400">Customer agrees to receive promotional emails and SMS messages.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="p-6 bg-slate-900 border-t flex justify-between rounded-b-xl">
          <Button 
            variant="outline" 
            onClick={() => setStep(step - 1)} 
            disabled={step === 1 || loading}
          >
            Previous
          </Button>
          
          {step < 4 ? (
            <Button 
              className="bg-brand-primary hover:bg-brand-secondary text-white" 
              onClick={() => setStep(step + 1)}
              disabled={step === 1 && (!formData.firstName || !formData.lastName)}
            >
              Continue
            </Button>
          ) : (
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white" 
              onClick={handleSubmit}
              disabled={loading}
            >
              {loading ? 'Creating...' : 'Create Customer'}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
