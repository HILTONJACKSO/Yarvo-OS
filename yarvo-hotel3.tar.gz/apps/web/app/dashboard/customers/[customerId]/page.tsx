"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Clock } from 'lucide-react';

export default function WalkInCustomerPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
  });

  const handleCreate = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      // For walk-in, we might only have a first name.
      const displayName = [formData.firstName, formData.lastName].filter(Boolean).join(' ') || 'Walk-In Customer';
      
      const payload = {
        customerType: 'WALK_IN',
        firstName: formData.firstName || undefined,
        lastName: formData.lastName || undefined,
        phone: formData.phone || undefined,
        displayName,
        customerNumber: `WALK-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
      };

      const res = await fetch('http://127.0.0.1:3002/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        // Go straight back to wherever or to the profile
        router.push(`/dashboard/customers/${data.id}`);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft size={20} />
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Quick Walk-In</h2>
          <p className="text-slate-400 text-sm">Register a temporary operational customer instantly</p>
        </div>
      </div>

      <Card className="border-brand-primary/20 shadow-md">
        <CardHeader className="bg-brand-bg/50 border-b border-slate-800 rounded-t-xl">
          <CardTitle className="flex items-center gap-2 text-brand-primary">
            <Clock size={20} /> Express Registration
          </CardTitle>
          <CardDescription>
            Only basic information is required to serve a walk-in guest at a restaurant or bar.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>First Name <span className="text-slate-500 text-xs font-normal">(Optional)</span></Label>
              <Input 
                value={formData.firstName} 
                onChange={(e) => setFormData({...formData, firstName: e.target.value})} 
                placeholder="e.g. John" 
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <Label>Last Name <span className="text-slate-500 text-xs font-normal">(Optional)</span></Label>
              <Input 
                value={formData.lastName} 
                onChange={(e) => setFormData({...formData, lastName: e.target.value})} 
                placeholder="e.g. Doe" 
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Phone Number <span className="text-slate-500 text-xs font-normal">(Recommended)</span></Label>
            <Input 
              value={formData.phone} 
              onChange={(e) => setFormData({...formData, phone: e.target.value})} 
              placeholder="+1 234 567 890" 
            />
            <p className="text-xs text-slate-400">A phone number helps link future visits to this profile.</p>
          </div>
        </CardContent>
        <CardFooter className="bg-slate-900 p-6 flex justify-end gap-3 rounded-b-xl border-t">
          <Button variant="ghost" onClick={() => router.back()}>Cancel</Button>
          <Button 
            className="bg-brand-primary hover:bg-brand-secondary text-white" 
            onClick={handleCreate}
            disabled={loading}
          >
            {loading ? 'Creating...' : 'Create & Proceed'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
