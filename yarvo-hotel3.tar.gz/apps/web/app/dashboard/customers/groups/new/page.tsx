"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Users, Building, AlertCircle } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

export default function NewCustomerGroupPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    groupType: 'Family',
    mainContactName: '',
    mainContactPhone: '',
    mainContactEmail: '',
    adultCount: 2,
    childCount: 0,
    infantCount: 0,
    organization: '',
    expectedService: '',
    notes: '',
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCreate = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const payload = {
        ...formData,
        groupNumber: `GRP-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
      };

      const res = await fetch('http://127.0.0.1:3002/customer-groups', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        // Go back to the customer list or specific group page
        router.push('/dashboard/customers');
      } else {
        console.error('Failed to create group');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft size={20} />
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Register Group or Family</h2>
          <p className="text-slate-400 text-sm">Create a group profile for bulk bookings or shared accounts</p>
        </div>
      </div>

      <Card className="border-slate-800 shadow-sm">
        <CardHeader className="bg-slate-900 border-b rounded-t-xl">
          <CardTitle className="text-lg">Group Details</CardTitle>
          <CardDescription>Enter the primary information for this group</CardDescription>
        </CardHeader>
        <CardContent className="p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Group Name <span className="text-red-500">*</span></Label>
              <Input 
                value={formData.name} 
                onChange={(e) => handleInputChange('name', e.target.value)} 
                placeholder="e.g. Smith Family Vacation or Tour Group Alpha" 
              />
            </div>
            <div className="space-y-2">
              <Label>Group Type <span className="text-red-500">*</span></Label>
              <Select value={formData.groupType} onValueChange={(val) => handleInputChange('groupType', val)}>
                <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Family">Family</SelectItem>
                  <SelectItem value="Friends">Friends / Social Group</SelectItem>
                  <SelectItem value="Tour">Tour Group</SelectItem>
                  <SelectItem value="Wedding">Wedding Party</SelectItem>
                  <SelectItem value="Corporate">Corporate / Business Event</SelectItem>
                  <SelectItem value="School">School / University</SelectItem>
                  <SelectItem value="Sports">Sports Team</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Main Contact Name</Label>
              <Input 
                value={formData.mainContactName} 
                onChange={(e) => handleInputChange('mainContactName', e.target.value)} 
                placeholder="e.g. John Smith" 
              />
            </div>
            
            <div className="space-y-2">
              <Label>Main Contact Phone</Label>
              <Input 
                value={formData.mainContactPhone} 
                onChange={(e) => handleInputChange('mainContactPhone', e.target.value)} 
                placeholder="+1 234 567 890" 
              />
            </div>
          </div>

          <div className="pt-4 border-t">
            <h4 className="text-sm font-medium text-slate-200 mb-4">Expected Headcount</h4>
            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label>Adults</Label>
                <Input 
                  type="number" 
                  min={0}
                  value={formData.adultCount} 
                  onChange={(e) => handleInputChange('adultCount', parseInt(e.target.value) || 0)} 
                />
              </div>
              <div className="space-y-2">
                <Label>Children (2-12)</Label>
                <Input 
                  type="number" 
                  min={0}
                  value={formData.childCount} 
                  onChange={(e) => handleInputChange('childCount', parseInt(e.target.value) || 0)} 
                />
              </div>
              <div className="space-y-2">
                <Label>Infants (Under 2)</Label>
                <Input 
                  type="number" 
                  min={0}
                  value={formData.infantCount} 
                  onChange={(e) => handleInputChange('infantCount', parseInt(e.target.value) || 0)} 
                />
              </div>
            </div>
          </div>

        </CardContent>
        <CardFooter className="p-6 bg-slate-900 border-t flex justify-end gap-3 rounded-b-xl">
          <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
          <Button 
            className="bg-brand-primary hover:bg-brand-secondary text-white" 
            onClick={handleCreate}
            disabled={loading || !formData.name}
          >
            {loading ? 'Creating...' : 'Create Group'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
