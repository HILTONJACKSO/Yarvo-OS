"use client";

import { Landmark, ArrowRightLeft, CreditCard, Banknote, Smartphone } from 'lucide-react';
import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

export default function BankingPage() {
  const [accounts, setAccounts] = useState<any[]>([]);

  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/finance/banking`);
        if (res.ok) {
          const data = await res.json();
          setAccounts(data);
        }
      } catch (err) {
        console.error('Failed to fetch banking accounts', err);
      }
    };

    fetchAccounts();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('finance.updated', fetchAccounts);

    return () => {
      socket.off('finance.updated', fetchAccounts);
      socket.disconnect();
    };
  }, []);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Banking & Cash</h1>
          <p className="text-slate-400 mt-1">Manage bank accounts, cash registers, and mobile money wallets.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 border bg-slate-950 rounded-md text-slate-300 hover:bg-slate-900 flex items-center gap-2">
            <ArrowRightLeft size={16} /> Transfer Funds
          </button>
          <button className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
            Add Account
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {accounts.map((acc, idx) => (
          <div key={idx} className="bg-slate-950 p-6 rounded-xl border shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-slate-900 rounded-lg">
                {(acc.accountType || acc.type) === 'BANK' ? <Landmark className="text-blue-500" /> : (acc.accountType || acc.type) === 'MOBILE_MONEY' ? <Smartphone className="text-amber-500" /> : <Banknote className="text-green-500" />}
              </div>
              <span className="px-2 py-1 bg-slate-800 text-slate-400 text-xs font-medium rounded-full">{acc.accountType || acc.type}</span>
            </div>
            <div>
              <h3 className="font-bold text-slate-50 text-lg">{acc.accountName || acc.name}</h3>
              <p className="text-sm text-slate-400 mt-1 font-mono">{acc.accountNumber || acc.accNumber}</p>
            </div>
            <div className="mt-6 pt-4 border-t flex justify-between items-center">
              <span className="text-sm font-medium text-slate-400">Available Balance</span>
              <span className="text-xl font-bold text-slate-50">${(acc.balance !== undefined ? acc.balance : (typeof acc.balance === 'string' ? parseFloat(acc.balance.replace(/[^0-9.-]+/g,"")) : 0)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
