"use client";

import { useState, useEffect } from 'react';
import { FileSpreadsheet, Filter, Eye, Download } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function GeneralLedgerPage() {
  const [activeTab, setActiveTab] = useState('journals');
  const [journals, setJournals] = useState<any[]>([]);

  useEffect(() => {
    const fetchJournals = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/finance/ledger`);
        if (res.ok) {
          const data = await res.json();
          setJournals(data);
        }
      } catch (err) {
        console.error('Failed to fetch ledger entries', err);
      }
    };

    fetchJournals();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('finance.updated', fetchJournals);

    return () => {
      socket.off('finance.updated', fetchJournals);
      socket.disconnect();
    };
  }, []);
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">General Ledger</h1>
          <p className="text-slate-400 mt-1">View journal entries and the trial balance.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 border bg-slate-950 rounded-md text-slate-300 hover:bg-slate-900 flex items-center gap-2">
            <Download size={16} /> Export
          </button>
          <button className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
            New Manual Journal
          </button>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <div className="flex border-b px-4 gap-6 bg-slate-900">
          <button 
            className={`py-4 font-medium text-sm border-b-2 ${activeTab === 'journals' ? 'border-brand-primary text-brand-primary' : 'border-transparent text-slate-400 hover:text-slate-300'}`}
            onClick={() => setActiveTab('journals')}
          >
            Journal Entries
          </button>
          <button 
            className={`py-4 font-medium text-sm border-b-2 ${activeTab === 'trial' ? 'border-brand-primary text-brand-primary' : 'border-transparent text-slate-400 hover:text-slate-300'}`}
            onClick={() => setActiveTab('trial')}
          >
            Trial Balance
          </button>
        </div>

        {activeTab === 'journals' && (
          <div className="p-0">
            <div className="p-4 border-b flex justify-between items-center bg-slate-950">
              <div className="flex gap-2">
                <input type="date" className="border px-3 py-1.5 rounded-md text-sm text-slate-400" />
                <input type="text" placeholder="Search description..." className="border px-3 py-1.5 rounded-md text-sm w-64" />
              </div>
              <button className="text-sm font-medium text-slate-400 flex items-center gap-1 hover:text-slate-50">
                <Filter size={16} /> Filters
              </button>
            </div>
            <table className="w-full text-left">
              <thead className="bg-slate-900 border-b">
                <tr>
                  <th className="p-4 font-medium text-slate-400 text-sm">Entry No.</th>
                  <th className="p-4 font-medium text-slate-400 text-sm">Date</th>
                  <th className="p-4 font-medium text-slate-400 text-sm">Reference</th>
                  <th className="p-4 font-medium text-slate-400 text-sm">Description</th>
                  <th className="p-4 font-medium text-slate-400 text-sm text-right">Amount</th>
                  <th className="p-4 font-medium text-slate-400 text-sm text-center">Status</th>
                  <th className="p-4 font-medium text-slate-400 text-sm"></th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {journals.map((j) => (
                  <tr key={j.id} className="hover:bg-slate-900">
                    <td className="p-4 text-sm font-medium text-brand-primary cursor-pointer hover:underline">{j.entryNumber || j.id}</td>
                    <td className="p-4 text-sm text-slate-400">{j.entryDate ? new Date(j.entryDate).toLocaleString() : j.date}</td>
                    <td className="p-4 text-sm text-slate-400">{j.referenceType || j.ref}</td>
                    <td className="p-4 text-sm text-slate-50">{j.description}</td>
                    <td className="p-4 text-sm font-medium text-right">${(j.totalDebit !== undefined ? j.totalDebit : (typeof j.amount === 'string' ? parseFloat(j.amount.replace(/[^0-9.-]+/g,"")) : j.amount) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                    <td className="p-4 text-center">
                      <span className="px-2 py-1 bg-emerald-500/10 text-green-700 text-xs font-medium rounded-full">{j.status}</span>
                    </td>
                    <td className="p-4 text-right">
                      <button className="p-1.5 text-gray-400 hover:text-brand-primary rounded"><Eye size={16} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'trial' && (
          <div className="p-6 text-center text-slate-400 h-64 flex flex-col items-center justify-center">
            <FileSpreadsheet size={48} className="text-gray-300 mb-4" />
            <p>The Trial Balance view calculates your current account balances.</p>
            <button className="mt-4 px-4 py-2 bg-brand-primary text-white rounded-md text-sm">Generate Trial Balance</button>
          </div>
        )}
      </div>
    </div>
  );
}
