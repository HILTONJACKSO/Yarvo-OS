"use client";

import { Landmark, ArrowRight, Activity, DollarSign, Wallet, FileText, BarChart3, Receipt, FileSpreadsheet } from 'lucide-react';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

export default function FinanceDashboardPage() {
  const [stats, setStats] = useState({ operatingCash: 84250, accountsReceivable: 12400, accountsPayable: 8920 });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/finance/stats`);
        if (res.ok) {
          const data = await res.json();
          setStats(data);
        }
      } catch (err) {
        console.error('Failed to fetch finance stats', err);
      }
    };

    fetchStats();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('finance.updated', fetchStats);

    return () => {
      socket.off('finance.updated', fetchStats);
      socket.disconnect();
    };
  }, []);

  const cards = [
    { title: 'General Ledger', description: 'Journal entries & Trial Balance', href: '/dashboard/finance/ledger', icon: <FileSpreadsheet className="text-blue-500" size={24} /> },
    { title: 'Chart of Accounts', description: 'Manage accounts and categories', href: '/dashboard/finance/accounts', icon: <BarChart3 className="text-purple-500" size={24} /> },
    { title: 'Banking & Cash', description: 'Bank accounts, mobile money, registers', href: '/dashboard/finance/banking', icon: <Landmark className="text-green-500" size={24} /> },
    { title: 'Invoicing & Payments', description: 'Receivables & Payables', href: '/dashboard/finance/invoices', icon: <Receipt className="text-amber-500" size={24} /> },
    { title: 'Fixed Assets', description: 'Asset register & depreciation', href: '/dashboard/finance/assets', icon: <Wallet className="text-indigo-500" size={24} /> },
    { title: 'Department Budgets', description: 'Monitor spending against budgets', href: '/dashboard/finance/budgets', icon: <Activity className="text-rose-500" size={24} /> },
    { title: 'Financial Reports', description: 'P&L, Balance Sheet, Cash Flow, Tax', href: '/dashboard/finance/reports', icon: <FileText className="text-slate-400" size={24} /> },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Finance Hub</h1>
          <p className="text-slate-400 mt-1">Central management for all accounting and financial records.</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400">Operating Cash</p>
            <p className="text-2xl font-bold text-slate-50">${(stats.operatingCash || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          <div className="p-3 bg-green-50 text-green-500 rounded-lg"><DollarSign size={24} /></div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400">Accounts Receivable</p>
            <p className="text-2xl font-bold text-slate-50">${(stats.accountsReceivable || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          <div className="p-3 bg-blue-50 text-blue-500 rounded-lg"><ArrowRight size={24} /></div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400">Accounts Payable</p>
            <p className="text-2xl font-bold text-slate-50">${(stats.accountsPayable || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          <div className="p-3 bg-amber-50 text-amber-500 rounded-lg"><ArrowRight className="rotate-180" size={24} /></div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
        {cards.map((card, idx) => (
          <Link key={idx} href={card.href} className="bg-slate-950 p-6 rounded-xl border shadow-sm hover:border-brand-primary/50 hover:shadow-md transition group cursor-pointer">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-slate-900 rounded-lg group-hover:scale-110 transition-transform">{card.icon}</div>
              <ArrowRight size={20} className="text-gray-300 group-hover:text-brand-primary transition-colors" />
            </div>
            <h3 className="font-bold text-slate-50 text-lg">{card.title}</h3>
            <p className="text-slate-400 text-sm mt-1">{card.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
