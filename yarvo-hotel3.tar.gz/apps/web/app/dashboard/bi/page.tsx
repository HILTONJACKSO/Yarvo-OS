"use client";

import { useState, useEffect } from 'react';
import { TrendingUp, DollarSign, Users, Target, Activity, BedDouble, AlertTriangle, ChevronRight, Zap } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function ExecutiveBIDashboard() {
  const [kpis, setKpis] = useState<any[]>([]);
  const [departmentRevenue, setDepartmentRevenue] = useState<any[]>([]);
  const [totalYtdRevenue, setTotalYtdRevenue] = useState<string>('$0.00');
  const [insights, setInsights] = useState<string>('No AI insights generated yet. The system needs more operational data to provide recommendations.');
  const [actionItems, setActionItems] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBiData = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch('http://127.0.0.1:3002/businesses/current', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            
            const biRes = await fetch(`http://127.0.0.1:3002/bi/executive`, {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            
            if (biRes.ok) {
              const biData = await biRes.json();
              setKpis(biData.kpis || []);
              setDepartmentRevenue(biData.departmentRevenue || []);
              if (biData.totalYtdRevenue) setTotalYtdRevenue(biData.totalYtdRevenue);
              if (biData.insights) setInsights(biData.insights);
              if (biData.actionItems) setActionItems(biData.actionItems);
            }
          }
        }
      } catch (error) {
        console.error('Error fetching BI data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBiData();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('finance.updated', fetchBiData);
    socket.on('crm.updated', fetchBiData);
    socket.on('inventory.updated', fetchBiData);

    return () => {
      socket.off('finance.updated', fetchBiData);
      socket.off('crm.updated', fetchBiData);
      socket.off('inventory.updated', fetchBiData);
      socket.disconnect();
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-center bg-gray-900 text-white p-6 rounded-2xl shadow-lg">
        <div>
          <h1 className="text-3xl font-black tracking-tight">Executive BI Dashboard</h1>
          <p className="text-gray-400 mt-1">Real-time enterprise performance and Yarvo AI insights.</p>
        </div>
        <div className="text-right">
          <div className="text-sm font-medium text-gray-400">Total YTD Revenue</div>
          <div className="text-4xl font-bold text-emerald-400">{totalYtdRevenue}</div>
        </div>
      </div>

      {/* AI Insights Panel */}
      <div className="bg-gradient-to-r from-brand-primary/10 to-purple-500/10 border border-brand-primary/20 rounded-2xl p-6">
        <h2 className="flex items-center gap-2 font-bold text-slate-50 mb-4">
          <SparklesIcon className="text-brand-primary" /> Yarvo AI Insights
        </h2>
        <div className="bg-slate-950/60 p-4 rounded-xl border border-white">
          <p className="text-sm text-slate-200">{insights}</p>
        </div>
      </div>

      {/* KPI Cards */}
      {kpis.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((kpi, idx) => (
            <div key={idx} className="bg-slate-950 p-6 rounded-2xl border shadow-sm flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div className="p-2 bg-slate-900 rounded-lg"><Activity size={24} className="text-brand-primary" /></div>
                <span className={`text-sm font-bold flex items-center gap-1 \${kpi.trendUp ? 'text-emerald-600' : 'text-red-500'}`}>
                  {kpi.trendUp ? <TrendingUp size={14} /> : <TrendingUp size={14} className="rotate-180" />} {kpi.trend}
                </span>
              </div>
              <div className="mt-4">
                <h3 className="text-slate-400 font-medium text-sm">{kpi.title}</h3>
                <div className="text-3xl font-black text-slate-50 mt-1">{kpi.value}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-slate-950 p-8 rounded-3xl border shadow-sm text-center">
          <p className="text-slate-400 font-medium">KPI data is currently unavailable.</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Department Breakdown */}
        <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm">
          <h2 className="font-bold text-slate-50 mb-6 flex items-center justify-between">
            Revenue by Department
            <Target size={18} className="text-gray-400" />
          </h2>
          {departmentRevenue.length > 0 ? (
            <div className="space-y-5">
              {departmentRevenue.map((dept, idx) => (
                <div key={idx}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-medium text-slate-300">{dept.name}</span>
                    <span className="font-bold text-slate-50">{dept.value}</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-brand-primary h-2 rounded-full" style={{ width: dept.percentage }}></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-sm text-center py-4">No departmental revenue recorded yet.</p>
          )}
        </div>

        {/* Operational Alerts */}
        <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm">
          <h2 className="font-bold text-slate-50 mb-6 flex items-center justify-between">
            Action Items
            <AlertTriangle size={18} className="text-gray-400" />
          </h2>
          {actionItems.length > 0 ? (
            <div className="space-y-4">
              {actionItems.map((item, idx) => (
                <div key={idx} className="p-4 border bg-slate-900 rounded-xl flex items-start gap-3">
                  <AlertTriangle className="text-brand-primary mt-0.5" size={18} />
                  <p className="text-slate-300 text-sm">{item}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <p className="text-gray-400 text-sm">No action items or alerts pending.</p>
            </div>
          )}
        </div>

        {/* Ask Yarvo AI */}
        <div className="bg-gray-900 p-6 rounded-2xl border border-gray-800 shadow-sm text-white flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <Zap size={120} />
          </div>
          <div>
            <h2 className="font-bold text-xl mb-2">Ask Yarvo AI</h2>
            <p className="text-gray-400 text-sm">Query your financial and operational data using natural language.</p>
          </div>
          <div className="mt-6 space-y-2 relative z-10">
            <div className="relative mt-4">
              <input type="text" placeholder="Type a question..." className="w-full bg-black/50 border border-gray-700 rounded-lg py-3 px-4 text-sm focus:outline-none focus:border-brand-primary" />
              <button className="absolute right-2 top-2 bottom-2 bg-brand-primary px-3 rounded text-sm font-medium">Ask</button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

function SparklesIcon(props: any) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
      <path d="M5 3v4"/>
      <path d="M19 17v4"/>
      <path d="M3 5h4"/>
      <path d="M17 19h4"/>
    </svg>
  );
}
