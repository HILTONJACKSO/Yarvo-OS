"use client";

import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import Link from 'next/link';
import { 
  ShoppingBag, Layers, AlertCircle, Eye, EyeOff,
  Search, Plus, Tag, Box, ArrowRight, Grid3X3, Watch
} from 'lucide-react';

export default function CatalogDashboardPage() {
  const [stats, setStats] = useState({
    totalProducts: 0,
    activeProducts: 0,
    soldOutProducts: 0,
    serviceItems: 0,
    menus: 0,
    categories: 0,
    missingPrices: 0,
    missingCategories: 0
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/catalog/stats`);
        if (res.ok) {
          setStats(await res.json());
        }
      } catch (error) {
        console.error('Failed to fetch catalog stats', error);
      }
    };

    fetchStats();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('catalogItem.updated', fetchStats);
    socket.on('catalogCategory.updated', fetchStats);
    socket.on('menu.updated', fetchStats);

    return () => {
      socket.disconnect();
    };
  }, []);
  const [alerts] = useState([
    { id: 1, type: 'error', message: 'Four products do not have prices.', link: '/dashboard/catalog/items?filter=missing-prices', actionText: 'Fix Prices' },
    { id: 2, type: 'warning', message: 'Eight products are marked sold out.', link: '/dashboard/catalog/items?filter=sold-out', actionText: 'Review Stock' },
    { id: 3, type: 'warning', message: 'Three items are not assigned to a menu.', link: '/dashboard/catalog/items?filter=no-menu', actionText: 'Assign Items' },
    { id: 4, type: 'info', message: 'Two products are available at inactive service points.', link: '/dashboard/catalog/items?filter=inactive-points', actionText: 'Review' }
  ]);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Catalog Dashboard</h2>
          <p className="text-slate-400">Manage all your products, services, pricing, and menus.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/dashboard/catalog/availability/quick-update" className="inline-flex items-center gap-2 px-4 py-2 bg-slate-950 border text-slate-300 rounded-md hover:bg-slate-900 transition-colors shadow-sm font-medium">
            <Watch size={16} /> Quick Availability
          </Link>
          <Link href="/dashboard/catalog/items/new" className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
            <Plus size={16} /> Add Product
          </Link>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-950 rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-400">Total Products</span>
            <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
              <ShoppingBag size={16} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-50">{stats.totalProducts}</h3>
          <p className="text-xs text-slate-400 mt-1">{stats.activeProducts} Active</p>
        </div>

        <div className="bg-slate-950 rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-400">Sold Out Items</span>
            <div className="w-8 h-8 rounded-full bg-red-50 flex items-center justify-center text-red-600">
              <EyeOff size={16} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-50">{stats.soldOutProducts}</h3>
          <p className="text-xs text-red-600 mt-1 font-medium">Requires attention</p>
        </div>

        <div className="bg-slate-950 rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-400">Menus</span>
            <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
              <Grid3X3 size={16} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-50">{stats.menus}</h3>
          <p className="text-xs text-slate-400 mt-1">Across 4 departments</p>
        </div>

        <div className="bg-slate-950 rounded-xl shadow-sm border p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-400">Categories</span>
            <div className="w-8 h-8 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
              <Layers size={16} />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-50">{stats.categories}</h3>
          <p className="text-xs text-slate-400 mt-1">{stats.missingCategories} items unassigned</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Navigation / Quick Actions */}
        <div className="lg:col-span-2 bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="p-5 border-b bg-slate-900">
            <h3 className="font-semibold text-slate-50">Catalog Management</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 p-5 gap-4">
            
            <Link href="/dashboard/catalog/items" className="flex items-start gap-4 p-4 rounded-xl border hover:border-brand-primary hover:bg-brand-primary/5 transition-all group">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-700 shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <ShoppingBag size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-slate-50 mb-1 flex items-center gap-1">Products & Services <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity -ml-2 group-hover:ml-0" /></h4>
                <p className="text-xs text-slate-400">Manage all items, edit prices, and update configurations.</p>
              </div>
            </Link>

            <Link href="/dashboard/catalog/categories" className="flex items-start gap-4 p-4 rounded-xl border hover:border-brand-primary hover:bg-brand-primary/5 transition-all group">
              <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center text-purple-700 shrink-0 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                <Layers size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-slate-50 mb-1 flex items-center gap-1">Categories <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity -ml-2 group-hover:ml-0" /></h4>
                <p className="text-xs text-slate-400">Organize your items into logical groups for staff and customers.</p>
              </div>
            </Link>

            <Link href="/dashboard/catalog/menus" className="flex items-start gap-4 p-4 rounded-xl border hover:border-brand-primary hover:bg-brand-primary/5 transition-all group">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-700 shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <Grid3X3 size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-slate-50 mb-1 flex items-center gap-1">Menus & Ordering <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity -ml-2 group-hover:ml-0" /></h4>
                <p className="text-xs text-slate-400">Build specific menus for your restaurant, bar, and room service.</p>
              </div>
            </Link>

            <Link href="/dashboard/catalog/modifiers" className="flex items-start gap-4 p-4 rounded-xl border hover:border-brand-primary hover:bg-brand-primary/5 transition-all group">
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-700 shrink-0 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                <Tag size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-slate-50 mb-1 flex items-center gap-1">Modifiers & Add-ons <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity -ml-2 group-hover:ml-0" /></h4>
                <p className="text-xs text-slate-400">Create customization options like cooking preferences and sides.</p>
              </div>
            </Link>

            <Link href="/dashboard/catalog/packages" className="flex items-start gap-4 p-4 rounded-xl border hover:border-brand-primary hover:bg-brand-primary/5 transition-all group">
              <div className="w-10 h-10 rounded-lg bg-pink-100 flex items-center justify-center text-pink-700 shrink-0 group-hover:bg-pink-600 group-hover:text-white transition-colors">
                <Box size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-slate-50 mb-1 flex items-center gap-1">Packages <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity -ml-2 group-hover:ml-0" /></h4>
                <p className="text-xs text-slate-400">Group multiple items together into combos and event packages.</p>
              </div>
            </Link>
            
            <Link href="/dashboard/catalog/menu-preview" className="flex items-start gap-4 p-4 rounded-xl border hover:border-brand-primary hover:bg-brand-primary/5 transition-all group">
              <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-700 shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <Eye size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-slate-50 mb-1 flex items-center gap-1">Digital Preview <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity -ml-2 group-hover:ml-0" /></h4>
                <p className="text-xs text-slate-400">See exactly what your customers see when browsing menus.</p>
              </div>
            </Link>

          </div>
        </div>

        {/* Alerts & Notifications */}
        <div className="lg:col-span-1 bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="p-5 border-b flex justify-between items-center bg-slate-900">
            <h3 className="font-semibold text-slate-50 flex items-center gap-2">
              <AlertCircle size={18} className="text-brand-primary" /> Action Required
            </h3>
          </div>
          <div className="divide-y">
            {alerts.map(alert => (
              <div key={alert.id} className="p-4 flex flex-col gap-2 hover:bg-slate-900 transition-colors">
                <div className="flex items-start gap-3">
                  <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                    alert.type === 'error' ? 'bg-red-500' : 
                    alert.type === 'warning' ? 'bg-amber-500' : 'bg-blue-500'
                  }`}></div>
                  <p className="text-sm text-slate-300 leading-snug">{alert.message}</p>
                </div>
                <div className="pl-5">
                  <Link href={alert.link} className="text-xs font-medium text-brand-primary hover:underline">
                    {alert.actionText} â†’
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
