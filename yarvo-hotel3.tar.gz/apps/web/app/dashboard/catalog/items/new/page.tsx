"use client";

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, CheckCircle2, ChevronRight, Save, Upload, Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function NewCatalogItemWizard() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const steps = [
    { id: 1, name: 'Basic Information', description: 'Name, Category, and Type' },
    { id: 2, name: 'Pricing & Taxes', description: 'Base price and rules' },
    { id: 3, name: 'Preparation', description: 'Routing and prep time' },
    { id: 4, name: 'Variations', description: 'Sizes and modifiers' },
    { id: 5, name: 'Media & Details', description: 'Images and description' },
    { id: 6, name: 'Availability', description: 'Branches and status' },
  ];

  const handleNext = () => {
    if (currentStep < 6) setCurrentStep(c => c + 1);
  };

  const handlePrev = () => {
    if (currentStep > 1) setCurrentStep(c => c - 1);
  };

  const handleSave = () => {
    // Save logic
    router.push('/dashboard/catalog/items');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/catalog/items" className="p-2 border rounded-md hover:bg-slate-900 transition-colors">
            <ArrowLeft size={20} className="text-slate-400" />
          </Link>
          <div>
            <h2 className="text-2xl font-bold text-slate-50">Add New Product or Service</h2>
            <p className="text-slate-400">Create a new item in your catalog.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 border border-slate-800 text-slate-300 rounded-md hover:bg-slate-900 transition-colors font-medium">
            Save as Draft
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 mt-8">
        {/* Sidebar Steps */}
        <div className="w-full lg:w-64 shrink-0">
          <nav aria-label="Progress">
            <ol role="list" className="overflow-hidden lg:block hidden">
              {steps.map((step, stepIdx) => (
                <li key={step.name} className={`relative ${stepIdx !== steps.length - 1 ? 'pb-10' : ''}`}>
                  {stepIdx !== steps.length - 1 ? (
                    <div className="absolute left-4 top-4 -ml-px mt-0.5 h-full w-0.5 bg-gray-200" aria-hidden="true" />
                  ) : null}
                  <button onClick={() => setCurrentStep(step.id)} className="relative flex items-start group">
                    <span className="h-9 flex items-center">
                      <span className={`relative z-10 w-8 h-8 flex items-center justify-center rounded-full border-2 bg-slate-950 ${
                        currentStep === step.id ? 'border-brand-primary text-brand-primary' : 
                        currentStep > step.id ? 'border-brand-primary bg-brand-primary text-white' : 
                        'border-slate-700 text-slate-400'
                      }`}>
                        {currentStep > step.id ? <CheckCircle2 size={16} /> : <span className="text-sm font-medium">{step.id}</span>}
                      </span>
                    </span>
                    <span className="ml-4 min-w-0 flex flex-col text-left">
                      <span className={`text-sm font-medium tracking-wide ${currentStep === step.id ? 'text-brand-primary' : 'text-slate-400'}`}>{step.name}</span>
                      <span className="text-xs text-slate-400">{step.description}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ol>
            {/* Mobile Progress Bar */}
            <div className="lg:hidden flex items-center gap-2 mb-6">
              <span className="text-sm font-medium text-brand-primary">Step {currentStep} of 6:</span>
              <span className="text-sm text-slate-400">{steps[currentStep-1].name}</span>
            </div>
          </nav>
        </div>

        {/* Form Content */}
        <div className="flex-1">
          <div className="bg-slate-950 rounded-xl shadow-sm border p-6 min-h-[500px]">
            
            {/* STEP 1 */}
            {currentStep === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Basic Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Item Name <span className="text-red-500">*</span></label>
                    <input type="text" placeholder="e.g. Wagyu Burger" className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Internal Code</label>
                    <input type="text" placeholder="e.g. FOOD-001" className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                    <p className="text-xs text-slate-400">Leave blank to auto-generate.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Category <span className="text-red-500">*</span></label>
                    <select className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary">
                      <option value="">Select Category...</option>
                      <option value="burgers">Burgers</option>
                      <option value="sides">Sides</option>
                      <option value="drinks">Drinks</option>
                      <option value="spa">Spa Services</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Item Type <span className="text-red-500">*</span></label>
                    <select className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary">
                      <option value="FOOD">Food</option>
                      <option value="BEVERAGE">Beverage</option>
                      <option value="ALCOHOLIC_BEVERAGE">Alcoholic Beverage</option>
                      <option value="SERVICE">Service</option>
                      <option value="PACKAGE">Package</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>

                  <div className="md:col-span-2 space-y-2">
                    <label className="text-sm font-medium text-slate-300">Customer-Facing Name (Optional)</label>
                    <input type="text" placeholder="How it appears on digital menus, if different from internal name" className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2 */}
            {currentStep === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Pricing & Taxes</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Base Price <span className="text-red-500">*</span></label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                      <input type="number" placeholder="0.00" className="w-full pl-8 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Cost Price (Internal)</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                      <input type="number" placeholder="0.00" className="w-full pl-8 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Tax Category</label>
                    <select className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary">
                      <option value="standard">Standard VAT (20%)</option>
                      <option value="reduced">Reduced VAT (5%)</option>
                      <option value="zero">Zero Rated (0%)</option>
                      <option value="exempt">Tax Exempt</option>
                    </select>
                  </div>
                  
                  <div className="flex flex-col gap-4 mt-6">
                    <label className="flex items-center gap-3">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded border-slate-700" />
                      <span className="text-sm text-slate-300">Price includes tax</span>
                    </label>
                    <label className="flex items-center gap-3">
                      <input type="checkbox" defaultChecked className="w-4 h-4 text-brand-primary rounded border-slate-700" />
                      <span className="text-sm text-slate-300">Service charge applies</span>
                    </label>
                    <label className="flex items-center gap-3">
                      <input type="checkbox" defaultChecked className="w-4 h-4 text-brand-primary rounded border-slate-700" />
                      <span className="text-sm text-slate-300">Allow discounts on this item</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Steps 3-6 placeholders for brevity in the plan execution */}
            {currentStep > 2 && (
              <div className="space-y-6 flex flex-col items-center justify-center min-h-[300px] text-center animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="w-16 h-16 bg-brand-primary/10 text-brand-primary rounded-full flex items-center justify-center mb-4">
                  <CheckCircle2 size={32} />
                </div>
                <h3 className="text-xl font-medium text-slate-50">{steps[currentStep-1].name} Placeholder</h3>
                <p className="text-slate-400 max-w-sm">This step is scaffolded for Functionality 7. To proceed quickly, we can skip straight to saving.</p>
              </div>
            )}

          </div>

          {/* Form Actions */}
          <div className="mt-6 flex items-center justify-between">
            <button 
              onClick={handlePrev}
              disabled={currentStep === 1}
              className="px-6 py-2.5 border border-slate-800 text-slate-300 rounded-lg hover:bg-slate-900 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Back
            </button>
            
            {currentStep < 6 ? (
              <button 
                onClick={handleNext}
                className="flex items-center gap-2 px-6 py-2.5 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors font-medium"
              >
                Continue <ChevronRight size={18} />
              </button>
            ) : (
              <button 
                onClick={handleSave}
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium"
              >
                <Save size={18} /> Save & Publish
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
