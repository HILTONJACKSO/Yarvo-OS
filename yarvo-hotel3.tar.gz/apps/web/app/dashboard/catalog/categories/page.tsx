"use client";

import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import Link from 'next/link';
import { Layers, Plus, Search, FileEdit, Trash2, ChevronRight, Check } from 'lucide-react';

export default function CatalogCategoriesPage() {
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/catalog-categories`);
        if (res.ok) {
          setCategories(await res.json());
        }
      } catch (error) {
        console.error('Failed to fetch categories', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('catalogCategory.updated', fetchCategories);

    return () => {
      socket.disconnect();
    };
  }, []);

  if (loading) {
    return <div className="p-8 text-center text-slate-400">Loading categories...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Categories</h2>
          <p className="text-slate-400">Organize your products and services into logical groups.</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
          <Plus size={16} /> Add Category
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        
        {/* Main List */}
        <div className="flex-1 space-y-4">
          <div className="flex gap-4 bg-slate-950 p-4 rounded-xl shadow-sm border">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search categories..." 
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
              />
            </div>
          </div>

          <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 border-b text-sm text-slate-400">
                  <th className="p-4 font-medium">Category Name</th>
                  <th className="p-4 font-medium">Code</th>
                  <th className="p-4 font-medium">Parent</th>
                  <th className="p-4 font-medium">Items</th>
                  <th className="p-4 font-medium">Status</th>
                  <th className="p-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {categories.map(cat => (
                  <tr key={cat.id} className="hover:bg-slate-900/50 transition-colors group">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                          <Layers size={16} />
                        </div>
                        <span className="font-medium text-slate-50">{cat.name}</span>
                      </div>
                    </td>
                    <td className="p-4 text-sm text-slate-400 font-mono">{cat.code}</td>
                    <td className="p-4">
                      {cat.parentCategoryId ? (
                        <span className="text-sm text-slate-400 flex items-center gap-1">
                          <ChevronRight size={14} /> {categories.find(c => c.id === cat.parentCategoryId)?.name || cat.parentCategoryId}
                        </span>
                      ) : (
                        <span className="text-sm text-gray-400">-</span>
                      )}
                    </td>
                    <td className="p-4 text-sm text-slate-400">{cat._count?.items || 0}</td>
                    <td className="p-4">
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${cat.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-200'}`}>
                        {cat.status}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-brand-primary hover:bg-brand-primary/10 rounded-md transition-colors">
                          <FileEdit size={16} />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Sidebar Quick Form */}
        <div className="w-full lg:w-80 shrink-0">
          <div className="bg-slate-950 rounded-xl shadow-sm border p-5 sticky top-6">
            <h3 className="font-semibold text-slate-50 mb-4 border-b pb-4">Quick Add</h3>
            <form className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-slate-300">Name</label>
                <input type="text" className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" placeholder="Category Name" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-slate-300">Code</label>
                <input type="text" className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" placeholder="Optional" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-slate-300">Parent Category</label>
                <select className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950">
                  <option value="">None (Top Level)</option>
                  <option value="drinks">Drinks</option>
                  <option value="spa">Spa Services</option>
                </select>
              </div>
              <div className="pt-2 border-t mt-4">
                <button type="button" className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors font-medium">
                  <Check size={16} /> Save Category
                </button>
              </div>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
}
