"use client";

import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { Smartphone, Monitor, ChevronLeft, Search, Plus, Info, Coffee, Utensils, Wine } from 'lucide-react';

export default function DigitalMenuPreviewPage() {
  const [device, setDevice] = useState<'mobile' | 'desktop'>('mobile');
  const [selectedMenu, setSelectedMenu] = useState('1');

  const [menus, setMenus] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMenus = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002'}/menus`);
        if (res.ok) {
          const data = await res.json();
          setMenus(data);
          if (data.length > 0 && selectedMenu === '1') {
            setSelectedMenu(data[0].id);
          }
        }
      } catch (error) {
        console.error('Failed to fetch menus', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMenus();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:3002');
    socket.on('menu.updated', fetchMenus);

    return () => {
      socket.disconnect();
    };
  }, [selectedMenu]);

  const currentMenu = menus.find(m => m.id === selectedMenu) || menus[0] || null;
  const menuCategories = currentMenu?.categories?.map((c: any) => c.category) || [];
  const menuItems = currentMenu?.items || [];

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 h-[calc(100vh-100px)] flex flex-col">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Digital Menu Preview</h2>
          <p className="text-slate-400">Preview exactly what your guests see when they scan a QR code.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-slate-800 p-1 rounded-lg">
            <button 
              onClick={() => setDevice('mobile')}
              className={`p-2 rounded-md flex items-center justify-center transition-colors ${device === 'mobile' ? 'bg-slate-950 shadow-sm text-brand-primary' : 'text-slate-400 hover:text-slate-50'}`}
            >
              <Smartphone size={20} />
            </button>
            <button 
              onClick={() => setDevice('desktop')}
              className={`p-2 rounded-md flex items-center justify-center transition-colors ${device === 'desktop' ? 'bg-slate-950 shadow-sm text-brand-primary' : 'text-slate-400 hover:text-slate-50'}`}
            >
              <Monitor size={20} />
            </button>
          </div>
          <select 
            value={selectedMenu}
            onChange={(e) => setSelectedMenu(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950 shadow-sm"
          >
            {menus.map(menu => (
              <option key={menu.id} value={menu.id}>{menu.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Preview Container */}
      <div className="flex-1 bg-slate-800 border rounded-xl overflow-hidden flex items-center justify-center p-8">
        
        {/* Device Frame */}
        <div className={`bg-slate-950 shadow-2xl overflow-hidden relative transition-all duration-500 ease-in-out ${
          device === 'mobile' ? 'w-[375px] h-[812px] rounded-[3rem] border-[8px] border-gray-900' : 'w-full max-w-4xl h-[700px] rounded-xl border border-slate-800'
        }`}>
          
          {/* Mobile Notch Placeholder */}
          {device === 'mobile' && (
            <div className="absolute top-0 inset-x-0 h-6 bg-gray-900 rounded-b-xl w-40 mx-auto z-50"></div>
          )}

          {/* Digital Menu Content App */}
          <div className="w-full h-full flex flex-col bg-slate-900 overflow-y-auto no-scrollbar pt-6">
            
            {/* Guest App Header */}
            <header className="px-4 py-3 bg-slate-950 sticky top-0 z-40 shadow-sm flex items-center justify-between">
              <button className="p-2 -ml-2 text-slate-50"><ChevronLeft size={24} /></button>
              <h1 className="text-lg font-semibold text-slate-50">{currentMenu?.name || 'Menu Preview'}</h1>
              <button className="p-2 -mr-2 text-slate-50"><Search size={20} /></button>
            </header>

            {/* Menu Banner */}
            <div className="h-40 w-full relative shrink-0">
              <img src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=800&h=400&fit=crop" alt="Restaurant Cover" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <h2 className="text-2xl font-bold">{currentMenu?.name || 'Loading...'}</h2>
                <p className="text-sm opacity-90">Served {(currentMenu?.startTime || currentMenu?.endTime) ? `${currentMenu?.startTime || ''} - ${currentMenu?.endTime || ''}` : '24/7'}</p>
              </div>
            </div>

            {/* Category Navigation */}
            <div className="px-4 py-3 bg-slate-950 sticky top-[60px] z-30 border-b flex overflow-x-auto no-scrollbar gap-2 shrink-0">
              {menuCategories.map((cat: any, idx: number) => (
                <button key={cat.id} className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  idx === 0 ? 'bg-brand-primary text-white' : 'bg-slate-800 text-slate-300'
                }`}>
                  {cat.icon} {cat.name}
                </button>
              ))}
            </div>

            <div className="p-4 space-y-6 flex-1 pb-24">
              {menuCategories.map((cat: any) => {
                const catItems = menuItems.filter((mi: any) => mi.catalogItem?.categoryId === cat.id);
                return (
                  <div key={cat.id} className="space-y-4">
                    <h3 className="text-xl font-bold text-slate-50">{cat.name}</h3>
                    <div className={`grid gap-4 ${device === 'desktop' ? 'grid-cols-2' : 'grid-cols-1'}`}>
                      {catItems.map((menuItem: any) => {
                        const item = menuItem.catalogItem;
                        return (
                          <div key={item.id} className="bg-slate-950 p-3 rounded-xl shadow-sm border border-slate-800 flex gap-4 hover:shadow-md transition-shadow cursor-pointer">
                            <div className="flex-1 flex flex-col justify-center">
                              <h4 className="font-semibold text-slate-50">{item.name}</h4>
                              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{item.description}</p>
                              <div className="mt-2 font-medium text-brand-primary">${(item.basePrice || 0).toFixed(2)}</div>
                            </div>
                            <div className="w-24 h-24 shrink-0 rounded-lg overflow-hidden relative">
                              {item.imageUrl ? (
                                <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                              ) : (
                                <div className="w-full h-full bg-slate-800 flex items-center justify-center text-gray-400">
                                  <Utensils size={24} />
                                </div>
                              )}
                              <button className="absolute bottom-1 right-1 bg-slate-950 text-brand-primary rounded-full p-1 shadow-sm border border-slate-800">
                                <Plus size={16} />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                      {catItems.length === 0 && (
                        <div className="text-sm text-slate-400 italic">No items available in this category.</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            
          </div>
        </div>

      </div>
    </div>
  );
}
