export class CreatePurchaseRequestDto {}
