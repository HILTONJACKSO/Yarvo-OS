"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { ArrowLeft, Check, Plus, Minus, Trash2, Send } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';

export default function POSTerminalPage() {
  const router = useRouter();
  const { orderId } = useParams();
  const searchParams = useSearchParams();
  const typeParam = searchParams.get('type') || 'DINE_IN';
  
  const [loading, setLoading] = useState(true);
  const [catalog, setCatalog] = useState<any[]>([]);
  const [category, setCategory] = useState('Food'); // Food vs Drinks
  
  const [order, setOrder] = useState<any>(null);
  const [ticket, setTicket] = useState<any[]>([]);

  useEffect(() => {
    const init = async () => {
      try {
        const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
        const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';
        let bid = 'bus-kwalee-1';
        try {
          const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
          if (bRes.ok) {
            const bData = await bRes.json();
            if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
            else if (bData?.businessId) bid = bData.businessId;
            else if (bData?.id) bid = bData.id;
          }
        } catch {}

        const headers = { 'x-business-id': bid, 'Authorization': `Bearer ${token}` };

        // Fetch Order
        const oRes = await fetch(`${apiUrl}/orders/${orderId}`, { headers });
        if (oRes.ok) {
          const oData = await oRes.json();
          setOrder(oData);
          if (oData.items && oData.items.length > 0) {
            setTicket(oData.items.map((i: any) => ({
              catalogItemId: i.catalogItemId,
              name: i.itemNameSnapshot,
              price: i.unitPrice,
              quantity: i.quantity,
              status: i.status
            })));
          }
        }

        // Fetch Catalog
        const cRes = await fetch(`${apiUrl}/catalog-items`, { headers });
        if (cRes.ok) {
          const cData = await cRes.json();
          setCatalog(cData);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    init();
  }, [orderId]);

  const filteredCatalog = catalog.filter(c => {
    if (category === 'Food') {
      return !c.name.toLowerCase().includes('drink') && !c.name.toLowerCase().includes('beer') && !c.name.toLowerCase().includes('wine') && !c.name.toLowerCase().includes('water') && !c.name.toLowerCase().includes('juice') && !c.name.toLowerCase().includes('soda');
    } else {
      return c.name.toLowerCase().includes('drink') || c.name.toLowerCase().includes('beer') || c.name.toLowerCase().includes('wine') || c.name.toLowerCase().includes('water') || c.name.toLowerCase().includes('juice') || c.name.toLowerCase().includes('soda');
    }
  });

  const addToTicket = (item: any) => {
    setTicket(prev => {
      const existing = prev.find(t => t.catalogItemId === item.id);
      if (existing) {
        return prev.map(t => t.catalogItemId === item.id ? { ...t, quantity: t.quantity + 1 } : t);
      }
      return [...prev, {
        catalogItemId: item.id,
        name: item.name,
        price: item.basePrice || 0,
        quantity: 1,
        status: 'DRAFT'
      }];
    });
  };

  const updateQuantity = (id: string, delta: number) => {
    setTicket(prev => prev.map(t => {
      if (t.catalogItemId === id) {
        const newQ = Math.max(1, t.quantity + delta);
        return { ...t, quantity: newQ };
      }
      return t;
    }));
  };

  const removeItem = (id: string) => {
    setTicket(prev => prev.filter(t => t.catalogItemId !== id));
  };

  const subtotal = ticket.reduce((acc, t) => acc + (t.price * t.quantity), 0);
  const tax = subtotal * 0.1;
  const total = subtotal + tax;

  const [saving, setSaving] = useState(false);

  const handleSendOrder = async () => {
    setSaving(true);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';
      const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };

      // Determine where it goes based on what is in the ticket
      const hasFood = ticket.some(t => {
        const n = t.name.toLowerCase();
        return !n.includes('drink') && !n.includes('beer') && !n.includes('wine') && !n.includes('water') && !n.includes('juice') && !n.includes('soda');
      });
      const hasDrinks = ticket.some(t => {
        const n = t.name.toLowerCase();
        return n.includes('drink') || n.includes('beer') || n.includes('wine') || n.includes('water') || n.includes('juice') || n.includes('soda');
      });

      let statusMsg = 'Sent to Kitchen/Bar';
      if (hasFood && !hasDrinks) statusMsg = 'Sent to Kitchen';
      if (!hasFood && hasDrinks) statusMsg = 'Sent to Bar';

      // 1. Save Items
      const saveRes = await fetch(`${apiUrl}/orders/${orderId}/items`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ items: ticket })
      });

      if (!saveRes.ok) throw new Error('Failed to save items');

      // 2. Update Status to OPEN and items to PREPARING
      const statusRes = await fetch(`${apiUrl}/orders/${orderId}/status`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ status: 'OPEN', itemStatus: 'PREPARING' })
      });

      if (!statusRes.ok) throw new Error('Failed to update status');

      toast.success(statusMsg);
      router.push('/dashboard/orders');
    } catch (e: any) {
      toast.error(e.message || 'An error occurred');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-400 animate-pulse">Loading POS Terminal...</div>;
  }

  return (
    <div className="h-[calc(100vh-64px)] flex overflow-hidden bg-slate-950">
      
      {/* Left: Catalog */}
      <div className="flex-1 flex flex-col border-r border-slate-800">
        <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center gap-4">
          <Link href="/dashboard/orders" className="p-2 bg-slate-800 text-slate-400 rounded-md hover:text-slate-50 transition">
            <ArrowLeft size={18} />
          </Link>
          <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button 
              onClick={() => setCategory('Food')}
              className={`px-6 py-2 rounded-md text-sm font-bold transition ${category === 'Food' ? 'bg-brand-primary text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Food Menu
            </button>
            <button 
              onClick={() => setCategory('Drinks')}
              className={`px-6 py-2 rounded-md text-sm font-bold transition ${category === 'Drinks' ? 'bg-brand-primary text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Drinks & Bar
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 bg-slate-950">
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredCatalog.map(item => (
              <button 
                key={item.id}
                onClick={() => addToTicket(item)}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-left hover:border-brand-primary/50 hover:bg-slate-800/50 transition group flex flex-col h-32"
              >
                <span className="font-bold text-slate-50 text-sm flex-1">{item.name}</span>
                <span className="text-brand-primary font-bold mt-2">${(item.basePrice || 0).toFixed(2)}</span>
              </button>
            ))}
            {filteredCatalog.length === 0 && (
              <div className="col-span-full py-12 text-center text-slate-500">
                No items found in {category}.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right: Ticket */}
      <div className="w-[400px] flex flex-col bg-slate-900">
        <div className="p-4 border-b border-slate-800 bg-slate-950">
          <h2 className="text-lg font-bold text-slate-50 flex items-center justify-between">
            Current Order
            <span className="text-xs font-medium px-2 py-1 bg-slate-800 text-slate-400 rounded-md">
              {order?.orderNumber || 'DRAFT'}
            </span>
          </h2>
          <p className="text-sm text-slate-400 mt-1 capitalize">{typeParam.replace('_', ' ')} Destination</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {ticket.map((t, idx) => (
            <div key={idx} className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-slate-50 text-sm truncate">{t.name}</h4>
                <p className="text-xs text-brand-primary mt-0.5">${(t.price * t.quantity).toFixed(2)}</p>
              </div>
              <div className="flex items-center gap-2 bg-slate-900 rounded-md p-1 border border-slate-800">
                <button onClick={() => updateQuantity(t.catalogItemId, -1)} className="p-1 hover:bg-slate-800 rounded text-slate-400">
                  <Minus size={14} />
                </button>
                <span className="w-6 text-center font-bold text-sm text-slate-50">{t.quantity}</span>
                <button onClick={() => updateQuantity(t.catalogItemId, 1)} className="p-1 hover:bg-slate-800 rounded text-slate-400">
                  <Plus size={14} />
                </button>
              </div>
              <button onClick={() => removeItem(t.catalogItemId)} className="p-2 text-red-400 hover:bg-red-500/10 rounded-md transition">
                <Trash2 size={16} />
              </button>
            </div>
          ))}
          {ticket.length === 0 && (
            <div className="py-12 text-center text-slate-500 text-sm">
              Ticket is empty.<br/>Add items from the menu.
            </div>
          )}
        </div>

        <div className="p-4 bg-slate-950 border-t border-slate-800">
          <div className="space-y-2 mb-4">
            <div className="flex justify-between text-sm text-slate-400">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-slate-400">
              <span>Tax (10%)</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold text-xl text-slate-50 pt-2 border-t border-slate-800 mt-2">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>

          <button 
            onClick={handleSendOrder}
            disabled={ticket.length === 0 || saving}
            className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
              ticket.length > 0 && !saving ? 'bg-brand-primary text-white hover:bg-brand-secondary' : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            {saving ? 'Processing...' : (
              <>
                <Send size={18} />
                Send Order
              </>
            )}
          </button>
        </div>
      </div>

    </div>
  );
}
