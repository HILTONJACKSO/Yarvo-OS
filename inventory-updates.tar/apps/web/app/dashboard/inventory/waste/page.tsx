"use client";

import { useState, useEffect } from 'react';
import { Search, AlertTriangle, Plus, FileText } from 'lucide-react';
import Link from 'next/link';

export default function InventoryWastePage() {
  const [waste, setWaste] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/inventory/waste`);
      if (response.ok) {
        const data = await response.json();
        setWaste(data);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Waste & Damages</h1>
          <p className="text-slate-400 mt-1">Record spoilage, breakages, and expired stock to adjust inventory accurately.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
            <Plus size={18} /> Record Waste
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-500/10 text-red-600 rounded-lg"><AlertTriangle size={24} /></div>
          <div>
            <p className="text-slate-400 font-medium text-sm">Total Waste (This Month)</p>
            <h3 className="text-2xl font-black text-slate-50">$0.00</h3>
          </div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center gap-4">
          <div className="p-3 bg-orange-100 text-orange-600 rounded-lg"><FileText size={24} /></div>
          <div>
            <p className="text-slate-400 font-medium text-sm">Pending Approvals</p>
            <h3 className="text-2xl font-black text-slate-50">0</h3>
          </div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm flex items-center gap-4">
          <div className="p-3 bg-slate-800 text-slate-400 rounded-lg"><AlertTriangle size={24} /></div>
          <div>
            <p className="text-slate-400 font-medium text-sm">Top Waste Category</p>
            <h3 className="text-lg font-bold text-slate-50">-</h3>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search waste logs..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Locations</option>
            <option value="main">Main Bar</option>
            <option value="kitchen">Kitchen Store</option>
          </select>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Ref #</th>
              <th className="p-4 font-semibold">Date</th>
              <th className="p-4 font-semibold">Item</th>
              <th className="p-4 font-semibold">Location</th>
              <th className="p-4 font-semibold">Quantity</th>
              <th className="p-4 font-semibold">Reason</th>
              <th className="p-4 font-semibold text-right">Lost Value</th>
              <th className="p-4 font-semibold text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {waste.map((log) => (
              <tr key={log.id} className="hover:bg-slate-900">
                <td className="p-4 font-mono text-xs text-brand-primary font-medium">{log.number}</td>
                <td className="p-4 text-slate-400">{log.date}</td>
                <td className="p-4 font-medium text-slate-50">{log.item}</td>
                <td className="p-4 text-slate-400">{log.location}</td>
                <td className="p-4 font-medium text-red-600">- {log.qty}</td>
                <td className="p-4 text-slate-400">{log.reason}</td>
                <td className="p-4 text-right font-medium text-red-600">${log.cost.toFixed(2)}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${log.status === 'APPROVED' ? 'bg-emerald-500/10 text-green-700' : 'bg-amber-500/10 text-yellow-700'}`}>
                    {log.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
