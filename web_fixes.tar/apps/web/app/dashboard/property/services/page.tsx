"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Building, Utensils, Beer, Music, Umbrella, Waves, Calendar, Coffee, Sparkles, WashingMachine, ConciergeBell, Settings, AlertTriangle } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

const SERVICE_DEFINITIONS = [
  { type: 'HOTEL', icon: Building, name: 'Hotel Rooms', desc: 'Manage rooms, reservations, guests, check-ins, and check-outs.' },
  { type: 'RESTAURANT', icon: Utensils, name: 'Restaurant', desc: 'Manage tables, menus, customer orders, kitchen movement, and payments.' },
  { type: 'BAR', icon: Beer, name: 'Bar', desc: 'Manage bar counters, drink orders, and tabs.' },
  { type: 'NIGHTCLUB', icon: Music, name: 'Nightclub', desc: 'Manage VIP tables, entry tickets, and club operations.' },
  { type: 'BEACH', icon: Umbrella, name: 'Beach', desc: 'Sell entry tickets and manage cabanas, chairs, and umbrellas.' },
  { type: 'POOL', icon: Waves, name: 'Swimming Pool', desc: 'Manage pool access, cabanas, and towel rentals.' },
  { type: 'EVENTS', icon: Calendar, name: 'Events and Conferences', desc: 'Manage event spaces, banquet halls, and conference bookings.' },
  { type: 'LOUNGE', icon: Coffee, name: 'Lounge', desc: 'Manage executive lounges or quiet seating areas.' },
  { type: 'SPA', icon: Sparkles, name: 'Spa and Wellness', desc: 'Manage spa treatments, therapists, and bookings.' },
  { type: 'LAUNDRY', icon: WashingMachine, name: 'Laundry', desc: 'Manage guest laundry and internal housekeeping laundry.' },
  { type: 'ROOM_SERVICE', icon: ConciergeBell, name: 'Room Service', desc: 'Manage in-room dining orders.' },
  { type: 'OTHER', icon: Settings, name: 'Other Services', desc: 'Miscellaneous services and custom modules.' },
];

export default function PropertyServicesPage() {
  const router = useRouter();
  const [token, setToken] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 2500);
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    setToken(t || '');
    if (!t) return;

    const fetchCurrent = () => {
      fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, { headers: { 'Authorization': `Bearer ${t}` }})
        .then(r => r.json())
        .then(data => {
          if (!data || !Array.isArray(data) || data.length === 0) return;
          const bizId = data[0].businessId;
          setBusinessId(bizId);
          const bId = data[0].business.branches?.[0]?.id;
          setBranchId(bId);
          
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/branch-services`, { headers: { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId, 'x-business-id': bizId }})
            .then(r => r.json())
            .then(servicesData => {
              setServices(Array.isArray(servicesData) ? servicesData : []);
              setLoading(false);
            });
        })
        .catch(console.error);
    };

    fetchCurrent();

    const socket = io(`${process.env.NEXT_PUBLIC_API_URL}`, {
      auth: { token: t }
    });

    socket.on('property.service.updated', () => {
      fetchCurrent();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const toggleService = async (serviceType: string, checked: boolean) => {
    // Optimistic UI update
    setServices(prev => {
      const existing = prev.find(s => s.serviceType === serviceType);
      if (existing) {
        return prev.map(s => s.serviceType === serviceType ? { ...s, isEnabled: checked } : s);
      } else {
        return [...prev, { serviceType, isEnabled: checked }];
      }
    });

    // Real-time backend save: only send the changed service
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/branch-services`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId, 'x-business-id': businessId },
        body: JSON.stringify({ services: [{ serviceType, isEnabled: checked }] })
      });
      if (res.ok) {
        showToast(`${serviceType.charAt(0) + serviceType.slice(1).toLowerCase().replace('_', ' ')} ${checked ? 'enabled' : 'disabled'}`);
      } else {
        alert('Failed to save service toggle');
      }
    } catch (err) {
      console.error("Failed to save service toggle:", err);
      alert('Network error while saving toggle');
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/branch-services`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId, 'x-business-id': businessId },
        body: JSON.stringify({ services })
      });
      if (!res.ok) {
        alert('Failed to save services');
      } else {
        showToast('All services saved successfully');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="text-slate-400">Loading services...</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">What services does this branch offer?</h1>
          <p className="text-slate-400 text-sm">Enable the modules that match your business operations.</p>
        </div>
        <Button onClick={handleSave} disabled={saving} className="bg-brand-primary">
          {saving ? 'Saving...' : 'Save and Continue'}
        </Button>
      </div>

      <div className="bg-amber-50 border border-amber-200 text-amber-400 p-4 rounded-lg mb-8 flex items-start gap-3">
        <AlertTriangle size={20} className="text-amber-500 shrink-0 mt-0.5" />
        <div className="text-sm">
          <strong>Important:</strong> Disabling a service will hide it from staff navigation. Existing records will not be deleted, but new activity will be blocked until re-enabled.
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {SERVICE_DEFINITIONS.map(def => {
          const serviceState = services.find(s => s.serviceType === def.type);
          const isEnabled = serviceState?.isEnabled || false;
          const Icon = def.icon;
          
          return (
            <div 
              key={def.type} 
              className={`p-5 rounded-xl border transition-all ${isEnabled ? 'border-brand-primary bg-brand-primary/5 shadow-sm' : 'border-slate-800 bg-slate-950 hover:border-slate-700'}`}
            >
              <div className="flex justify-between items-start mb-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${isEnabled ? 'bg-brand-primary text-white' : 'bg-slate-800 text-slate-400'}`}>
                  <Icon size={20} />
                </div>
                
                <button
                  type="button"
                  role="switch"
                  aria-checked={isEnabled}
                  onClick={() => toggleService(def.type, !isEnabled)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-primary focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950 ${isEnabled ? 'bg-brand-primary' : 'bg-slate-700'}`}
                >
                  <span className={`pointer-events-none block h-5 w-5 rounded-full bg-white shadow-lg ring-0 transition-transform ${isEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
                </button>
                
              </div>
              <h3 className={`font-bold text-lg mb-1 ${isEnabled ? 'text-slate-50' : 'text-slate-300'}`}>{def.name}</h3>
              <p className="text-sm text-slate-400 line-clamp-2">{def.desc}</p>
            </div>
          );
        })}
      </div>

      {toastMsg && (
        <div className="fixed bottom-4 right-4 bg-emerald-600 border border-emerald-500 text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 animate-in slide-in-from-bottom-5 fade-in duration-300 z-50">
          <Sparkles size={18} className="text-emerald-200" />
          <span className="font-medium text-sm">{toastMsg}</span>
        </div>
      )}
    </div>
  );
}
