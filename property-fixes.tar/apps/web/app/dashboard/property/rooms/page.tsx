"use client";

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, DoorClosed, Grid, Sparkles } from 'lucide-react';

export default function RoomsPage() {
  const [rooms, setRooms] = useState<any[]>([]);
  const [areas, setAreas] = useState<any[]>([]);
  const [types, setTypes] = useState<any[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [isAddingBulk, setIsAddingBulk] = useState(false);
  
  const [token, setToken] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');

  const [formData, setFormData] = useState({
    prefix: '',
    startNum: '',
    endNum: '',
    propertyAreaId: '',
    roomTypeId: '',
  });

  const fetchData = async (t: string, bId: string) => {
    try {
      const headers = { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId, 'x-business-id': businessId };
      const [resRooms, resAreas, resTypes] = await Promise.all([
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/rooms`, { headers }),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/property-areas`, { headers }),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/room-types`, { headers }),
      ]);
      const dataRooms = await resRooms.json();
      const dataAreas = await resAreas.json();
      const dataTypes = await resTypes.json();
      
      setRooms(Array.isArray(dataRooms) ? dataRooms : []);
      setAreas(Array.isArray(dataAreas) ? dataAreas : []);
      setTypes(Array.isArray(dataTypes) ? dataTypes : []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, { headers: { 'Authorization': `Bearer ${t}` }})
      .then(r => r.json())
      .then(data => {
        if (!data || !Array.isArray(data) || data.length === 0) return;
        setBusinessId(data[0].businessId);
        const bId = data[0].business.branches?.[0]?.id;
        setBranchId(bId);
        fetchData(t, bId).finally(() => setLoading(false));
      });
  }, []);

  const handleBulkGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        bulk: {
          prefix: formData.prefix,
          startNum: parseInt(formData.startNum),
          endNum: parseInt(formData.endNum),
          propertyAreaId: formData.propertyAreaId,
          roomTypeId: formData.roomTypeId
        }
      };

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/rooms`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId, 'x-business-id': businessId },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsAddingBulk(false);
        setFormData({ prefix: '', startNum: '', endNum: '', propertyAreaId: '', roomTypeId: '' });
        fetchData(token, branchId);
      } else {
        alert('Failed to generate rooms');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const getAreaName = (id: string) => areas.find(a => a.id === id)?.name || 'Unknown Area';
  const getTypeName = (id: string) => types.find(t => t.id === id)?.name || 'Unknown Type';

  if (loading) return <div className="text-slate-400">Loading rooms...</div>;

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Rooms</h1>
          <p className="text-slate-400 text-sm">Manage individual hotel rooms and assign them to floors.</p>
        </div>
        <Button onClick={() => setIsAddingBulk(!isAddingBulk)} className="bg-brand-primary flex items-center gap-2">
          {isAddingBulk ? 'Cancel' : <><Sparkles size={16} /> Bulk Generate</>}
        </Button>
      </div>

      {isAddingBulk && (
        <form onSubmit={handleBulkGenerate} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div className="space-y-2">
            <Label>Room Type</Label>
            <Select required value={formData.roomTypeId} onValueChange={v => setFormData({...formData, roomTypeId: v || ''})}>
              <SelectTrigger>
                {formData.roomTypeId ? types.find(t => t.id === formData.roomTypeId)?.name : <span className="text-slate-400">Select type</span>}
              </SelectTrigger>
              <SelectContent>
                {types.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Floor / Area</Label>
            <Select required value={formData.propertyAreaId} onValueChange={v => setFormData({...formData, propertyAreaId: v || ''})}>
              <SelectTrigger>
                {formData.propertyAreaId ? areas.find(a => a.id === formData.propertyAreaId)?.name : <span className="text-slate-400">Select area</span>}
              </SelectTrigger>
              <SelectContent>
                {areas.map(a => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Prefix (Optional)</Label>
            <Input value={formData.prefix} onChange={e => setFormData({...formData, prefix: e.target.value})} placeholder="e.g. A or F1-" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-2">
              <Label>Start</Label>
              <Input type="number" required value={formData.startNum} onChange={e => setFormData({...formData, startNum: e.target.value})} placeholder="101" />
            </div>
            <div className="space-y-2">
              <Label>End</Label>
              <Input type="number" required value={formData.endNum} onChange={e => setFormData({...formData, endNum: e.target.value})} placeholder="110" />
            </div>
          </div>
          <div className="md:col-span-4 flex justify-end mt-2">
            <Button type="submit" className="bg-brand-primary">Generate Rooms</Button>
          </div>
        </form>
      )}

      {rooms.length === 0 && !isAddingBulk ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <DoorClosed className="mx-auto h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-50 mb-1">No rooms defined</h3>
          <p className="text-slate-400 mb-4">Generate your first batch of rooms using the bulk creation tool.</p>
          <Button onClick={() => setIsAddingBulk(true)} variant="outline">Generate Rooms</Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {rooms.map(room => (
            <div key={room.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 shadow-sm flex flex-col items-center justify-center text-center relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500"></div>
              <div className="text-xl font-bold text-slate-50 mb-1 mt-2">{room.roomNumber}</div>
              <div className="text-xs text-slate-400 truncate w-full px-2" title={getTypeName(room.roomTypeId)}>
                {getTypeName(room.roomTypeId)}
              </div>
              <div className="text-xs text-gray-400 mt-2 truncate w-full px-2">
                {getAreaName(room.areaId)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
