import { DevicePhoneMobileIcon as Smartphone, ComputerDesktopIcon as Laptop, DeviceTabletIcon as Tablet, ArrowDownTrayIcon as Download, BoltIcon as Zap, WifiIcon as WifiOff } from "@heroicons/react/24/outline";

export function PwaSection() {
  return (
    <section id="pwa" className="py-24 bg-blue-600 text-white overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Left: Content */}
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500 border border-blue-400 text-white text-sm font-medium mb-6">
            <Download className="w-4 h-4" />
            Installable Progressive Web App
          </div>
          
          <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight">
            No Expensive Hardware Required.
          </h2>
          <p className="text-lg text-blue-100 mb-10 leading-relaxed">
            Stop buying overpriced proprietary POS terminals. Yarvo OS runs directly in the browser and can be installed as an app on any phone, tablet, or computer you already own.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-white mb-1">Mobile Waiters</h4>
                <p className="text-sm text-blue-200">Waiters take orders on their own smartphones.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
                <Tablet className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-white mb-1">Tablet POS</h4>
                <p className="text-sm text-blue-200">Bartenders use iPads as cash registers.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
                <Laptop className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-white mb-1">Desktop Admin</h4>
                <p className="text-sm text-blue-200">Managers control everything from laptops.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
                <Zap className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h4 className="font-bold text-white mb-1">Instant Updates</h4>
                <p className="text-sm text-blue-200">No app store approvals needed for updates.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Preview Illustration */}
        <div className="relative h-[500px] w-full flex justify-center items-center perspective-[1000px]">
          {/* Decorative Elements */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.2)_0%,transparent_70%)] rounded-full"></div>
          
          {/* Laptop */}
          <div className="absolute z-10 w-[450px] h-[280px] bg-slate-900 rounded-t-2xl rounded-b-md border-8 border-slate-800 shadow-2xl transform rotate-y-[-10deg] -translate-x-12 translate-y-12 flex flex-col overflow-hidden">
            <div className="h-4 bg-slate-800 flex items-center gap-1.5 px-2">
              <div className="w-2 h-2 rounded-full bg-red-500"></div><div className="w-2 h-2 rounded-full bg-amber-500"></div><div className="w-2 h-2 rounded-full bg-emerald-500"></div>
            </div>
            <div className="flex-1 bg-slate-950 p-4 border-t border-slate-700">
              <div className="w-full h-8 bg-blue-600/20 rounded mb-4"></div>
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="h-16 bg-slate-800 rounded"></div>
                <div className="h-16 bg-slate-800 rounded"></div>
                <div className="h-16 bg-slate-800 rounded"></div>
              </div>
              <div className="h-24 bg-slate-800 rounded"></div>
            </div>
          </div>

          {/* Tablet */}
          <div className="absolute z-20 w-[220px] h-[320px] bg-slate-900 rounded-2xl border-8 border-slate-800 shadow-2xl transform rotate-y-[5deg] translate-x-24 -translate-y-8 flex flex-col overflow-hidden">
            <div className="flex-1 bg-slate-950 p-3">
              <div className="flex justify-between items-center mb-4">
                <div className="w-6 h-6 bg-blue-600 rounded"></div>
                <div className="w-16 h-4 bg-slate-800 rounded"></div>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-3">
                <div className="h-20 bg-slate-800 rounded"></div>
                <div className="h-20 bg-amber-500/20 border border-blue-500/50 rounded"></div>
                <div className="h-20 bg-slate-800 rounded"></div>
                <div className="h-20 bg-slate-800 rounded"></div>
              </div>
              <div className="h-10 w-full bg-emerald-600 rounded mt-auto"></div>
            </div>
          </div>

          {/* Phone */}
          <div className="absolute z-30 w-[140px] h-[280px] bg-slate-900 rounded-[1.5rem] border-[6px] border-slate-800 shadow-2xl transform rotate-y-[-15deg] -translate-x-32 -translate-y-16 flex flex-col overflow-hidden">
            <div className="w-12 h-3 bg-slate-800 rounded-b-lg mx-auto absolute top-0 left-1/2 -translate-x-1/2 z-40"></div>
            <div className="flex-1 bg-slate-950 p-3 pt-6">
              <div className="h-8 bg-slate-800 rounded-lg mb-3"></div>
              <div className="flex flex-col gap-2">
                <div className="h-12 bg-blue-600/20 border border-blue-500/30 rounded-lg"></div>
                <div className="h-12 bg-slate-800 rounded-lg"></div>
                <div className="h-12 bg-slate-800 rounded-lg"></div>
                <div className="h-12 bg-slate-800 rounded-lg"></div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
