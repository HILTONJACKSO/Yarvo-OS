import { ShieldCheckIcon as ShieldCheck, LockClosedIcon as Lock, CheckCircleIcon as ToggleRight, MinusCircleIcon as ToggleLeft, UserIcon as UserCog, KeyIcon as Key, CheckIcon as Check } from "@heroicons/react/24/outline";

export function StaffSection() {
  return (
    <section className="py-24 bg-slate-900 text-slate-50 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Left: Access Control UI Preview */}
        <div className="relative flex justify-center lg:justify-start perspective-[1000px]">
          {/* Decorative Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-[100%] bg-blue-600/20 rounded-full blur-[100px] pointer-events-none"></div>
          
          <div className="w-full max-w-md bg-slate-950 rounded-3xl border border-slate-800 shadow-2xl overflow-hidden transform rotate-y-[5deg] hover:rotate-y-0 transition-transform duration-500 relative">
            
            <div className="p-6 border-b border-slate-800 bg-slate-900 flex justify-between items-center">
              <h3 className="font-bold text-white flex items-center gap-2"><UserCog className="w-5 h-5 text-blue-400"/> Role Configuration</h3>
              <div className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg text-sm font-medium">Bartender</div>
            </div>

            <div className="p-6 flex flex-col gap-4">
              <div className="flex justify-between items-center bg-slate-900 p-4 rounded-xl border border-slate-800">
                <div>
                  <p className="font-bold text-slate-200">View Inventory</p>
                  <p className="text-xs text-slate-400">Allow staff to see stock levels</p>
                </div>
                <ToggleRight className="w-8 h-8 text-blue-500" />
              </div>

              <div className="flex justify-between items-center bg-slate-900 p-4 rounded-xl border border-slate-800 border-l-4 border-l-red-500">
                <div>
                  <p className="font-bold text-slate-200">Void Transaction</p>
                  <p className="text-xs text-slate-400">Cancel an order after payment</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1 text-xs font-bold text-red-400 bg-red-500/10 px-2 py-1 rounded">
                    <Key className="w-3 h-3" /> Manager PIN Required
                  </div>
                  <ToggleLeft className="w-8 h-8 text-slate-300" />
                </div>
              </div>

              <div className="flex justify-between items-center bg-slate-900 p-4 rounded-xl border border-slate-800 border-l-4 border-l-amber-500">
                <div>
                  <p className="font-bold text-slate-200">Apply Discount</p>
                  <p className="text-xs text-slate-400">Add percentage or fixed discount</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-400">Up to 10%</span>
                  <ToggleRight className="w-8 h-8 text-blue-600" />
                </div>
              </div>

              <div className="flex justify-between items-center bg-slate-900 p-4 rounded-xl border border-slate-800">
                <div>
                  <p className="font-bold text-slate-200">Open Cash Register</p>
                  <p className="text-xs text-slate-400">Access physical cash drawer</p>
                </div>
                <ToggleRight className="w-8 h-8 text-blue-500" />
              </div>

              <div className="flex justify-between items-center bg-slate-900 p-4 rounded-xl border border-slate-800">
                <div>
                  <p className="font-bold text-slate-200 text-slate-400 line-through">Edit Prices</p>
                  <p className="text-xs text-slate-300">Change menu item prices</p>
                </div>
                <ToggleLeft className="w-8 h-8 text-slate-300" />
              </div>
            </div>

            <div className="p-4 bg-slate-900 border-t border-slate-800">
              <button className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-md flex items-center justify-center gap-2">
                <Check className="w-5 h-5"/> Save Permissions
              </button>
            </div>
          </div>
        </div>

        {/* Right: Content */}
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300 text-sm font-medium mb-6">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            Enterprise-Grade Security
          </div>
          
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 tracking-tight">
            Control What Your Staff Can Do
          </h2>
          <p className="text-lg text-slate-400 mb-8 leading-relaxed">
            Stop revenue leakage and unauthorized discounts. Create specific roles for your managers, receptionists, waiters, bartenders, and cleaners.
          </p>

          <ul className="space-y-4 mb-8">
            <li className="flex items-start gap-3">
              <Lock className="w-6 h-6 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block">Require Manager Approval</strong>
                <span className="text-slate-400 text-sm">Force staff to get a manager's PIN before voiding a transaction or giving a large discount.</span>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <Lock className="w-6 h-6 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block">Restrict Visibility</strong>
                <span className="text-slate-400 text-sm">Prevent bartenders from seeing hotel room rates, or receptionists from seeing kitchen inventory.</span>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <Lock className="w-6 h-6 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block">Track Every Action</strong>
                <span className="text-slate-400 text-sm">Every click, order, and deletion is logged with the user's name and timestamp in the audit log.</span>
              </div>
            </li>
          </ul>
        </div>

      </div>
    </section>
  );
}
