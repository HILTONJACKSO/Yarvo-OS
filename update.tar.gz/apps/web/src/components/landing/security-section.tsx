import { ShieldCheckIcon as Shield, WifiIcon as WifiOff, CloudArrowUpIcon as CloudSync, ServerIcon as DatabaseBackup, FingerPrintIcon as Fingerprint } from "@heroicons/react/24/outline";

export function SecuritySection() {
  return (
    <section className="py-24 bg-slate-900 border-t border-slate-800/50">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-slate-900 text-white mb-6">
            <Shield className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            Enterprise-Grade Security & Reliability
          </h2>
          <p className="text-lg text-slate-300">
            Hospitality never sleeps. Yarvo OS is built with bank-grade security and offline capabilities to ensure your business keeps running even when the internet goes down.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all group">
            <div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <WifiOff className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-50 mb-3">Offline Mode Support</h3>
            <p className="text-slate-300 leading-relaxed text-sm">
              Keep taking orders and checking in guests even if your internet connection drops. The system queues transactions locally.
            </p>
          </div>

          <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 shadow-sm hover:shadow-xl hover:emerald-200 transition-all group">
            <div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <CloudSync className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-50 mb-3">Auto Cloud Sync</h3>
            <p className="text-slate-300 leading-relaxed text-sm">
              The moment your connection returns, all offline transactions automatically sync with the central cloud database without data loss.
            </p>
          </div>

          <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 shadow-sm hover:shadow-xl hover:amber-200 transition-all group">
            <div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <DatabaseBackup className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-50 mb-3">Hourly Backups</h3>
            <p className="text-slate-300 leading-relaxed text-sm">
              Your financial and guest data is backed up to secure servers every hour. You never have to worry about a crashed computer ruining your records.
            </p>
          </div>

          <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 shadow-sm hover:shadow-xl hover:purple-200 transition-all group">
            <div className="w-14 h-14 bg-blue-50 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Fingerprint className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-slate-50 mb-3">Audit Logs</h3>
            <p className="text-slate-300 leading-relaxed text-sm">
              Every single action in the system is cryptographically logged. Know exactly who deleted an order, changed a price, or opened a till.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
}
