import { TicketIcon as Ticket, QrCodeIcon as QrCode, CheckCircleIcon as CheckCircle2, XCircleIcon as XCircle, ExclamationCircleIcon as AlertCircle, UsersIcon as Users, TagIcon as BadgePercent, FireIcon as Utensils } from "@heroicons/react/24/outline";

export function TicketingSection() {
  const categories = [
    "Adult", "Child", "Student", "Member", "VIP", 
    "Family", "School Group", "Corporate Group", "Weekend", "Weekday"
  ];

  return (
    <section className="py-24 bg-slate-900 border-t border-slate-800/50">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 mb-6">
            <Ticket className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            Flexible Ticketing for Individuals and Groups
          </h2>
          <p className="text-lg text-slate-300 mb-8">
            Manage beach access, pool entry, nightclub admissions, and special events with a powerful ticketing engine that supports complex group structures.
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((cat, i) => (
              <span key={i} className="px-3 py-1 bg-slate-950 text-slate-400 rounded-md text-xs font-medium border border-slate-800 shadow-sm">
                {cat}
              </span>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-6xl mx-auto">
          
          {/* Left: Group Ticketing Checkout */}
          <div className="lg:col-span-7 bg-slate-950 rounded-3xl border border-slate-800 shadow-xl overflow-hidden">
            <div className="p-6 md:p-8 bg-slate-900 text-white flex justify-between items-center">
              <div>
                <h3 className="font-bold text-xl flex items-center gap-2"><Users className="w-5 h-5 text-blue-600" /> Group Admission</h3>
                <p className="text-slate-400 text-sm mt-1">Order #TKT-8842</p>
              </div>
              <div className="bg-slate-800 px-4 py-2 rounded-lg border border-slate-700">
                <p className="text-xs text-slate-400">Total Guests</p>
                <p className="font-bold text-lg text-white">20</p>
              </div>
            </div>
            
            <div className="p-6 md:p-8">
              <div className="flex flex-col gap-4 mb-8">
                <div className="flex justify-between items-center pb-4 border-b border-slate-800">
                  <div>
                    <p className="font-bold text-slate-50">Adult Day Pass</p>
                    <p className="text-xs text-slate-400">12 × $8.00</p>
                  </div>
                  <p className="font-bold text-slate-50">$96.00</p>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-slate-800">
                  <div>
                    <p className="font-bold text-slate-50">Child Day Pass</p>
                    <p className="text-xs text-slate-400">8 × $5.00</p>
                  </div>
                  <p className="font-bold text-slate-50">$40.00</p>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-slate-800">
                  <div>
                    <p className="font-bold text-slate-50">VIP Cabana Rental</p>
                    <p className="text-xs text-slate-400">2 × $20.00</p>
                  </div>
                  <p className="font-bold text-slate-50">$40.00</p>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-slate-800">
                  <div>
                    <p className="font-bold text-slate-50 flex items-center gap-1"><Utensils className="w-3 h-3 text-blue-600"/> Group Food Package</p>
                    <p className="text-xs text-slate-400">1 × $100.00</p>
                  </div>
                  <p className="font-bold text-slate-50">$100.00</p>
                </div>
              </div>

              <div className="bg-slate-900 rounded-xl p-6 border border-slate-800">
                <div className="flex justify-between text-slate-300 mb-2">
                  <span>Subtotal</span>
                  <span className="font-medium text-slate-50">$276.00</span>
                </div>
                <div className="flex justify-between text-slate-300 mb-4 pb-4 border-b border-slate-800">
                  <span className="flex items-center gap-1"><BadgePercent className="w-4 h-4"/> Taxes (10%)</span>
                  <span className="font-medium text-slate-50">$27.60</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-50 text-lg">Total</span>
                  <span className="font-bold text-blue-600 text-3xl">$303.60</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-6">
                <button className="py-4 border border-blue-200 text-blue-600 font-bold rounded-xl hover:bg-blue-50 transition-colors">
                  Split Payment
                </button>
                <button className="py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors shadow-md">
                  Pay Now
                </button>
              </div>
              <p className="text-center text-xs text-slate-400 mt-4">
                Generates 20 individual QR wristbands or 1 Master Group QR
              </p>
            </div>
          </div>

          {/* Right: QR Scanning UI */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <QrCode className="w-4 h-4" /> Entrance Scanning App
            </h3>
            
            <div className="bg-slate-900 p-2 rounded-[2.5rem] shadow-2xl border-[8px] border-slate-800 mx-auto w-full max-w-[320px]">
              <div className="bg-slate-950 rounded-[2rem] overflow-hidden flex flex-col h-[600px] relative">
                {/* Camera Viewfinder Preview */}
                <div className="h-[40%] bg-slate-800 relative flex items-center justify-center border-b border-slate-700">
                  {/* Camera effect background */}
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-400 via-slate-800 to-slate-900"></div>
                  
                  {/* Scanner box */}
                  <div className="w-40 h-40 border-2 border-blue-500 rounded-lg relative z-10 shadow-[0_0_20px_rgba(16,185,129,0.3)]">
                    <div className="absolute top-0 left-0 w-full h-0.5 bg-emerald-400 shadow-[0_0_10px_rgba(16,185,129,1)] animate-ping" style={{ animationDuration: '2s' }}></div>
                  </div>
                  <QrCode className="absolute w-24 h-24 text-white/10" />
                </div>

                {/* Scan Results Feed */}
                <div className="flex-1 bg-slate-900 p-4 overflow-y-auto flex flex-col gap-3">
                  <div className="flex items-center justify-between p-3 bg-emerald-500/10 border border-blue-500/30 rounded-xl">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-6 h-6 text-blue-600" />
                      <div>
                        <p className="text-blue-600 font-bold text-sm">Valid Entry</p>
                        <p className="text-slate-400 text-xs">Adult Day Pass • #A839</p>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">Just now</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
                    <div className="flex items-center gap-3">
                      <XCircle className="w-6 h-6 text-red-400" />
                      <div>
                        <p className="text-red-400 font-bold text-sm">Already Used</p>
                        <p className="text-slate-400 text-xs">Child Day Pass • #C112</p>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">2 mins ago</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-amber-500/10 border border-blue-500/30 rounded-xl">
                    <div className="flex items-center gap-3">
                      <AlertCircle className="w-6 h-6 text-blue-600" />
                      <div>
                        <p className="text-blue-600 font-bold text-sm">Wrong Zone</p>
                        <p className="text-slate-400 text-xs">VIP Cabana • #V002</p>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">5 mins ago</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-slate-800 border border-slate-700 rounded-xl opacity-50">
                    <div className="flex items-center gap-3">
                      <XCircle className="w-6 h-6 text-slate-400" />
                      <div>
                        <p className="text-slate-300 font-bold text-sm">Expired</p>
                        <p className="text-slate-400 text-xs">Weekend Pass • #W991</p>
                      </div>
                    </div>
                    <span className="text-xs text-slate-300">10 mins ago</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
