import { BuildingOffice2Icon as Building2, GlobeAltIcon as Network, GlobeAltIcon as Globe2, Square3Stack3DIcon as Layers, ArrowRightIcon as ArrowRight, MapPinIcon as MapPin } from "@heroicons/react/24/outline";

export function MultiBranchSection() {
  return (
    <section className="py-24 bg-slate-900 text-slate-50 overflow-hidden relative">
      {/* Background World Map Pattern or abstract network */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
      
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16 relative z-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-500/20 text-blue-400 mb-6 border border-blue-500/30">
            <Network className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 tracking-tight">
            Manage Multiple Branches From HQ
          </h2>
          <p className="text-lg text-slate-400">
            Operating a chain of hotels, or a group of restaurants? Yarvo OS Enterprise lets you control all your locations from a single dashboard.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
          <div className="bg-slate-800/50 border border-slate-700 p-8 rounded-2xl hover:bg-slate-800 transition-colors group">
            <Globe2 className="w-10 h-10 text-blue-400 mb-6 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-3">Centralized Reporting</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-4">
              Compare revenue, occupancy, and expenses across all branches in real-time. No need to merge spreadsheets.
            </p>
            <span className="text-blue-400 text-sm font-bold flex items-center gap-1 group-hover:gap-2 transition-all cursor-pointer">Learn More <ArrowRight className="w-4 h-4" /></span>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 p-8 rounded-2xl hover:bg-slate-800 transition-colors group">
            <Layers className="w-10 h-10 text-blue-600 mb-6 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-3">Unified Inventory</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-4">
              Manage central warehouse stock and track transfers between different branches and kitchens automatically.
            </p>
            <span className="text-blue-600 text-sm font-bold flex items-center gap-1 group-hover:gap-2 transition-all cursor-pointer">Learn More <ArrowRight className="w-4 h-4" /></span>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 p-8 rounded-2xl hover:bg-slate-800 transition-colors group">
            <Building2 className="w-10 h-10 text-blue-600 mb-6 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-3">Global Guest Profiles</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-4">
              Recognize VIPs across your entire group. A guest's preferences and history travel with them to any branch.
            </p>
            <span className="text-blue-600 text-sm font-bold flex items-center gap-1 group-hover:gap-2 transition-all cursor-pointer">Learn More <ArrowRight className="w-4 h-4" /></span>
          </div>

          <div className="bg-slate-800/50 border border-slate-700 p-8 rounded-2xl hover:bg-slate-800 transition-colors group">
            <MapPin className="w-10 h-10 text-blue-600 mb-6 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-white mb-3">Cross-Branch Booking</h3>
            <p className="text-slate-400 text-sm leading-relaxed mb-4">
              If the downtown hotel is full, seamlessly redirect the guest's booking to your beach resort location.
            </p>
            <span className="text-blue-600 text-sm font-bold flex items-center gap-1 group-hover:gap-2 transition-all cursor-pointer">Learn More <ArrowRight className="w-4 h-4" /></span>
          </div>
        </div>
      </div>
    </section>
  );
}
