import { CreditCardIcon as CreditCard, BanknotesIcon as Banknote, DevicePhoneMobileIcon as Smartphone, WalletIcon as Wallet, BuildingOfficeIcon as Building, ArrowRightIcon as ArrowRight, PrinterIcon as Printer, PlusIcon as Plus, CheckIcon as Check } from "@heroicons/react/24/outline";

export function PaymentSection() {
  const paymentTypes = [
    { name: "Cash", icon: <Banknote className="w-4 h-4" /> },
    { name: "Mobile Money", icon: <Smartphone className="w-4 h-4" /> },
    { name: "Credit/Debit Card", icon: <CreditCard className="w-4 h-4" /> },
    { name: "Bank Transfer", icon: <Building className="w-4 h-4" /> },
    { name: "Guest Deposit", icon: <Wallet className="w-4 h-4" /> },
    { name: "Corporate Credit", icon: <Building className="w-4 h-4" /> },
    { name: "Voucher", icon: <CreditCard className="w-4 h-4" /> }
  ];

  return (
    <section className="py-24 bg-slate-950 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Left Side: Content */}
        <div className="max-w-2xl">
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            One Bill. <br/> Multiple Payment Methods.
          </h2>
          <p className="text-lg text-slate-300 mb-10 leading-relaxed">
            Don't lose a sale because a group wants to split the bill in complicated ways. Accept a combination of cash, mobile money, cards, and guest deposits to settle a single invoice.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
            {paymentTypes.map((type, i) => (
              <div key={i} className="flex items-center gap-2 p-3 rounded-lg border border-slate-800 bg-slate-900 text-slate-300 text-sm font-medium">
                <div className="text-blue-600">{type.icon}</div>
                {type.name}
              </div>
            ))}
          </div>
          
          <div className="inline-flex items-center gap-2 text-blue-600 font-bold group cursor-pointer">
            Explore Payment Integrations <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Right Side: Split Payment UI Preview */}
        <div className="relative perspective-[1000px] flex justify-center lg:justify-end">
          {/* Decorative Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-[100%] bg-blue-100/50 rounded-full blur-3xl -z-10"></div>
          
          <div className="w-full max-w-md bg-slate-900 text-slate-50 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden transform rotate-y-[-5deg] hover:rotate-y-0 transition-transform duration-500">
            <div className="p-6 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-lg">Settle Invoice</h3>
              <span className="text-slate-400 text-sm">#INV-2026-145</span>
            </div>

            <div className="p-6">
              <div className="flex justify-between items-center mb-8 pb-6 border-b border-slate-800">
                <span className="text-slate-400 font-medium">Invoice Total</span>
                <span className="text-3xl font-bold text-white">$500.00</span>
              </div>

              <div className="space-y-3 mb-6">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Applied Payments</h4>
                
                <div className="flex justify-between items-center bg-slate-800/50 p-3 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-blue-600 flex items-center justify-center"><Banknote className="w-4 h-4"/></div>
                    <span className="font-medium">Cash</span>
                  </div>
                  <span className="font-bold text-white">$150.00</span>
                </div>

                <div className="flex justify-between items-center bg-slate-800/50 p-3 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center"><Smartphone className="w-4 h-4"/></div>
                    <span className="font-medium">Mobile Money</span>
                  </div>
                  <span className="font-bold text-white">$200.00</span>
                </div>

                <div className="flex justify-between items-center bg-slate-800/50 p-3 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-500/20 text-blue-600 flex items-center justify-center"><CreditCard className="w-4 h-4"/></div>
                    <span className="font-medium">Card (...4242)</span>
                  </div>
                  <span className="font-bold text-white">$100.00</span>
                </div>

                <div className="flex justify-between items-center bg-slate-800/50 p-3 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-amber-500/20 text-blue-600 flex items-center justify-center"><Building className="w-4 h-4"/></div>
                    <span className="font-medium">Bank Transfer</span>
                  </div>
                  <span className="font-bold text-white">$50.00</span>
                </div>
              </div>

              <button className="w-full py-3 rounded-xl border border-slate-700 text-slate-300 font-medium hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 mb-8">
                <Plus className="w-4 h-4" /> Add Payment Method
              </button>

              <div className="bg-emerald-500/10 border border-blue-500/30 rounded-xl p-4 flex justify-between items-center mb-6">
                <span className="font-bold text-blue-600">Remaining Balance</span>
                <span className="text-xl font-bold text-blue-600">$0.00</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button className="py-3 border border-slate-700 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors flex items-center justify-center gap-2">
                  <Printer className="w-4 h-4" /> Print Receipt
                </button>
                <button className="py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
                  <Check className="w-5 h-5" /> Settle Invoice
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
