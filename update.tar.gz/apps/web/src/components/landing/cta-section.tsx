import Link from "next/link";
import { ArrowRightIcon as ArrowRight, CheckCircleIcon as CheckCircle2 } from "@heroicons/react/24/outline";

export function CtaSection() {
  return (
    <section className="py-24 relative overflow-hidden bg-blue-600">
      {/* Decorative Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-400 via-blue-600 to-blue-900 opacity-80"></div>
      
      <div className="max-w-4xl mx-auto px-6 relative z-10 text-center">
        <h2 className="text-4xl md:text-6xl font-extrabold text-white mb-8 tracking-tight">
          Ready to Modernize Your Hospitality Business?
        </h2>
        <p className="text-xl text-blue-100 mb-10 leading-relaxed max-w-2xl mx-auto">
          Join hundreds of modern hotels, restaurants, and resorts using Yarvo OS to streamline operations and increase revenue.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          <Link
            href="/register"
            className="inline-flex justify-center items-center gap-2 px-8 py-4 rounded-xl text-blue-600 bg-slate-950 hover:bg-slate-900 shadow-xl font-bold transition-transform hover:-translate-y-1 text-lg"
          >
            Start Your Free Trial <ArrowRight className="w-5 h-5" />
          </Link>
          <Link
            href="#demo"
            className="inline-flex justify-center items-center px-8 py-4 rounded-xl text-white bg-blue-700 border border-blue-500 hover:bg-blue-800 font-bold transition-colors shadow-sm text-lg"
          >
            Book a Live Demo
          </Link>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-blue-200 text-sm font-medium">
          <div className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-blue-600" /> No credit card required</div>
          <div className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-blue-600" /> 14-day free trial</div>
          <div className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-blue-600" /> Free onboarding setup</div>
        </div>
      </div>
    </section>
  );
}
