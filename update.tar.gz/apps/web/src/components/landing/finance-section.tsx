import { ChartBarSquareIcon as LineChart, ChartPieIcon as PieChart, ArrowDownTrayIcon as Download, DocumentTextIcon as FileSpreadsheet, ArrowTrendingUpIcon as TrendingUp, CurrencyDollarIcon as DollarSign, ChartBarIcon as BarChart3, ChartBarIcon as Activity } from "@heroicons/react/24/outline";

export function FinanceSection() {
  return (
    <section className="py-24 bg-slate-900 border-t border-slate-800/50">
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        
        {/* Left: Content */}
        <div className="max-w-2xl lg:order-2">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 mb-6">
            <LineChart className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            Automatic Accounting and Financial Reports
          </h2>
          <p className="text-lg text-slate-300 mb-8 leading-relaxed">
            Stop relying on manual spreadsheets. Yarvo OS automatically generates real-time income statements, departmental P&L, balance sheets, and tax reports based on your daily operations.
          </p>

          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800 shadow-sm">
              <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center"><BarChart3 className="w-5 h-5 text-blue-600"/></div>
              <div>
                <strong className="text-slate-50 block">Departmental Profit & Loss</strong>
                <span className="text-slate-400 text-sm">See exactly how much profit your restaurant makes vs your rooms.</span>
              </div>
            </div>
            <div className="flex items-center gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800 shadow-sm">
              <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center"><Activity className="w-5 h-5 text-blue-600"/></div>
              <div>
                <strong className="text-slate-50 block">Live Cash Flow</strong>
                <span className="text-slate-400 text-sm">Track cash in drawer, mobile money received, and pending card payouts.</span>
              </div>
            </div>
          </div>

          <div className="flex gap-4">
            <button className="flex items-center gap-2 px-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-bold text-slate-300 hover:bg-slate-900 transition-colors shadow-sm">
              <FileSpreadsheet className="w-4 h-4 text-blue-600" /> Export to Excel
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm font-bold text-slate-300 hover:bg-slate-900 transition-colors shadow-sm">
              <Download className="w-4 h-4 text-red-500" /> Export PDF
            </button>
          </div>
        </div>

        {/* Right: Preview */}
        <div className="relative lg:order-1">
          <div className="bg-slate-950 rounded-3xl border border-slate-800 shadow-xl overflow-hidden p-6 md:p-8">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="font-bold text-slate-50 text-xl">Financial Overview</h3>
                <p className="text-sm text-slate-400">October 2026</p>
              </div>
              <select className="bg-slate-900 border border-slate-800 text-slate-300 text-sm rounded-lg px-3 py-2 font-medium focus:outline-none">
                <option>This Month</option>
                <option>Last Month</option>
                <option>This Year</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-blue-50 border border-emerald-100 p-4 rounded-2xl">
                <p className="text-sm text-emerald-700 font-medium flex items-center gap-1 mb-1"><DollarSign className="w-4 h-4"/> Total Revenue</p>
                <p className="text-2xl font-bold text-emerald-900">$124,500.00</p>
                <p className="text-xs text-blue-600 mt-2 flex items-center gap-1"><TrendingUp className="w-3 h-3"/> +12.5% from last month</p>
              </div>
              <div className="bg-red-50 border border-red-100 p-4 rounded-2xl">
                <p className="text-sm text-red-700 font-medium flex items-center gap-1 mb-1"><DollarSign className="w-4 h-4"/> Total Expenses</p>
                <p className="text-2xl font-bold text-red-900">$48,200.00</p>
                <p className="text-xs text-red-600 mt-2 flex items-center gap-1"><TrendingUp className="w-3 h-3"/> +2.1% from last month</p>
              </div>
            </div>

            <div className="mb-6">
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Revenue by Department</h4>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium text-slate-300">Rooms</span>
                    <span className="font-bold text-slate-50">55%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '55%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium text-slate-300">Restaurant & Bar</span>
                    <span className="font-bold text-slate-50">30%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-amber-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium text-slate-300">Beach & Pool</span>
                    <span className="font-bold text-slate-50">10%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-cyan-500 h-2 rounded-full" style={{ width: '10%' }}></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium text-slate-300">Events</span>
                    <span className="font-bold text-slate-50">5%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{ width: '5%' }}></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-900 rounded-xl flex justify-between items-center text-white">
              <span className="font-medium flex items-center gap-2"><PieChart className="w-5 h-5 text-blue-400"/> Net Profit Margin</span>
              <span className="text-xl font-bold text-blue-600">61.2%</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
