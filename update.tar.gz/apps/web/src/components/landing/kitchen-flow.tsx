import { ClockIcon as Clock, ExclamationTriangleIcon as AlertTriangle, FireIcon as ChefHat, BellIcon as Bell, FireIcon as Utensils, CheckCircleIcon as CheckCircle2, ArrowRightIcon as ArrowRight } from "@heroicons/react/24/outline";

export function KitchenFlow() {
  const flow = [
    "Order Placed",
    "Sent to Kitchen",
    "Accepted",
    "Preparing",
    "Ready",
    "Collected by Waiter",
    "Delivered"
  ];

  return (
    <section className="py-24 bg-slate-900 text-slate-50 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-500/20 text-blue-600 mb-6">
            <ChefHat className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 tracking-tight">
            See Every Order Move in Real Time
          </h2>
          <p className="text-lg text-slate-400">
            Eliminate miscommunication between the front-of-house and the kitchen. Track every order from the moment it is placed until it reaches the guest's table.
          </p>
        </div>

        {/* Horizontal Flow Timeline */}
        <div className="flex overflow-x-auto pb-8 mb-12 scrollbar-hide -mx-6 px-6 lg:mx-0 lg:px-0 lg:justify-center">
          <div className="flex items-center gap-2 min-w-max">
            {flow.map((step, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className={`px-4 py-2 rounded-full text-sm font-medium border ${
                  index === 3 ? 'bg-amber-500/20 border-blue-500/30 text-blue-600' :
                  index < 3 ? 'bg-slate-800 border-slate-700 text-slate-300' :
                  'bg-slate-800/50 border-slate-700/50 text-slate-400'
                }`}>
                  {step}
                </div>
                {index < flow.length - 1 && (
                  <ArrowRight className="w-4 h-4 text-slate-300" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Kitchen Dashboard Preview */}
        <div className="relative max-w-5xl mx-auto">
          {/* Decorative Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-amber-500/10 blur-[100px] rounded-full pointer-events-none"></div>
          
          <div className="relative bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="h-14 border-b border-slate-800 bg-slate-900 flex items-center px-6 justify-between">
              <div className="flex items-center gap-2">
                <ChefHat className="w-5 h-5 text-slate-400" />
                <span className="font-medium text-slate-300">Kitchen Display System</span>
              </div>
              <div className="flex gap-2">
                <div className="px-3 py-1 rounded-md bg-amber-500/20 text-blue-600 text-xs font-bold">14 Active</div>
                <div className="px-3 py-1 rounded-md bg-red-500/20 text-red-400 text-xs font-bold">2 Delayed</div>
              </div>
            </div>

            {/* Kanban Board */}
            <div className="p-6 grid grid-cols-1 md:grid-cols-4 gap-6 bg-slate-900/50 h-[500px] overflow-y-auto">
              
              {/* Column 1: New */}
              <div className="flex flex-col gap-4">
                <h4 className="text-slate-400 text-sm font-bold uppercase tracking-wider flex items-center gap-2">
                  New Orders <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md text-xs">3</span>
                </h4>
                <div className="bg-slate-800 border border-slate-700 rounded-xl p-4 opacity-50">
                  <div className="flex justify-between items-start mb-3">
                    <span className="font-bold text-white text-lg">#106</span>
                    <span className="bg-slate-700 text-slate-300 px-2 py-1 rounded text-xs font-medium">Table 2</span>
                  </div>
                  <div className="h-4 bg-slate-700 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-slate-700 rounded w-1/2"></div>
                </div>
              </div>

              {/* Column 2: Preparing */}
              <div className="flex flex-col gap-4">
                <h4 className="text-blue-600 text-sm font-bold uppercase tracking-wider flex items-center gap-2">
                  Preparing <span className="bg-amber-500/20 text-blue-600 px-2 py-0.5 rounded-md text-xs">5</span>
                </h4>
                
                {/* Active Order Card Example */}
                <div className="bg-slate-800 border border-blue-500/50 rounded-xl p-4 shadow-[0_0_15px_rgba(245,158,11,0.1)] relative">
                  <div className="absolute -top-3 -right-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1 shadow-lg animate-pulse">
                    <Clock className="w-3 h-3" /> Delayed
                  </div>

                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <span className="font-bold text-white text-xl">#104</span>
                      <span className="block text-xs text-slate-400 mt-1">Walk-In Customer</span>
                    </div>
                    <div className="text-right">
                      <span className="bg-amber-500 text-slate-50 px-3 py-1 rounded-md text-sm font-bold">Table 7</span>
                      <span className="block text-xs text-blue-600 mt-1 font-medium flex items-center justify-end gap-1">
                        <Clock className="w-3 h-3" /> 14m elapsed
                      </span>
                    </div>
                  </div>

                  <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-2 rounded-lg text-xs font-medium flex items-start gap-2 mb-4">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    Allergy: Severe Peanut Allergy
                  </div>

                  <div className="flex flex-col gap-2 mb-4">
                    <div className="flex items-center gap-2 text-slate-200">
                      <span className="font-bold text-blue-600">2x</span> Grilled Fish
                    </div>
                    <div className="flex items-center gap-2 text-slate-200">
                      <span className="font-bold text-blue-600">1x</span> Jollof Rice
                    </div>
                    <div className="flex items-center gap-2 text-slate-200">
                      <span className="font-bold text-blue-600">2x</span> Fresh Juice
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t border-slate-700">
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                      <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center text-white font-medium text-xs">M</div>
                      Waiter: Mary
                    </div>
                    <button className="bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors">
                      Mark Ready
                    </button>
                  </div>
                </div>
              </div>

              {/* Column 3: Ready */}
              <div className="flex flex-col gap-4">
                <h4 className="text-blue-600 text-sm font-bold uppercase tracking-wider flex items-center gap-2">
                  Ready <span className="bg-emerald-500/20 text-blue-600 px-2 py-0.5 rounded-md text-xs">2</span>
                </h4>
                <div className="bg-slate-800 border border-blue-500/30 rounded-xl p-4 relative">
                  {/* Notification Float */}
                  <div className="absolute -left-12 top-6 bg-slate-950 p-3 rounded-xl shadow-xl border border-slate-800 flex items-center gap-3 animate-bounce hidden xl:flex z-10" style={{ animationDuration: '4s' }}>
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <Bell className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-50">Notification for Mary</p>
                      <p className="text-[10px] text-slate-400">Order #102 is ready for pickup.</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-start mb-3">
                    <span className="font-bold text-white text-lg">#102</span>
                    <span className="bg-slate-700 text-slate-300 px-2 py-1 rounded text-xs font-medium">Room 405</span>
                  </div>
                  <div className="flex items-center gap-2 text-blue-600 text-sm font-medium mb-3">
                    <CheckCircle2 className="w-4 h-4" /> Ready for pickup
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-400 border-t border-slate-700 pt-3">
                    <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center text-white font-medium text-xs">J</div>
                    Waiter: John
                  </div>
                </div>
              </div>

              {/* Column 4: Completed */}
              <div className="flex flex-col gap-4">
                <h4 className="text-slate-400 text-sm font-bold uppercase tracking-wider flex items-center gap-2">
                  Completed
                </h4>
                <div className="bg-slate-800/30 border border-slate-700/30 rounded-xl p-4 opacity-50">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-slate-400 text-lg line-through">#098</span>
                    <span className="text-slate-400 text-xs">Delivered</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
