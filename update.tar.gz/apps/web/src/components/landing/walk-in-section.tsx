import { ArrowRightIcon as ArrowRight, UserPlusIcon as UserCheck, FireIcon as Utensils, SunIcon as Umbrella, ArrowPathIcon as Waves, MusicalNoteIcon as Music, SparklesIcon as PartyPopper, BriefcaseIcon as Briefcase, StarIcon as Crown, CursorArrowRaysIcon as MousePointerClick, CheckIcon as CheckSquare, ShoppingCartIcon as ShoppingCart, CreditCardIcon as CreditCard, ReceiptPercentIcon as Receipt } from "@heroicons/react/24/outline";

export function WalkInSection() {
  const customerTypes = [
    { icon: <UserCheck className="w-5 h-5" />, label: "Hotel Guest" },
    { icon: <Utensils className="w-5 h-5" />, label: "Restaurant Walk-In" },
    { icon: <Umbrella className="w-5 h-5" />, label: "Beach Visitor" },
    { icon: <Waves className="w-5 h-5" />, label: "Pool Visitor" },
    { icon: <Music className="w-5 h-5" />, label: "Nightclub Guest" },
    { icon: <PartyPopper className="w-5 h-5" />, label: "Event Guest" },
    { icon: <Briefcase className="w-5 h-5" />, label: "Corporate Group" },
    { icon: <Crown className="w-5 h-5" />, label: "Member" },
  ];

  const workflow = [
    { icon: <MousePointerClick className="w-6 h-6 text-blue-600" />, label: "Select Customer Type", bg: "bg-blue-50" },
    { icon: <CheckSquare className="w-6 h-6 text-blue-600" />, label: "Select Service", bg: "bg-blue-50" },
    { icon: <ShoppingCart className="w-6 h-6 text-blue-600" />, label: "Add Items or Tickets", bg: "bg-blue-50" },
    { icon: <CreditCard className="w-6 h-6 text-blue-600" />, label: "Receive Payment", bg: "bg-blue-50" },
    { icon: <Receipt className="w-6 h-6 text-slate-300" />, label: "Print Receipt", bg: "bg-slate-800" },
  ];

  return (
    <section className="py-24 bg-slate-900 border-t border-slate-800/50">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-50 mb-6 tracking-tight">
            Hotel Guests and Walk-In Customers, <br /> Managed Separately
          </h2>
          <p className="text-lg text-slate-300">
            Not every customer is staying at the hotel. Easily handle independent transactions for visitors using the restaurant, beach, pool, bar, or nightclub without complicating your hotel operations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Side: Customer Types */}
          <div className="bg-slate-950 rounded-2xl p-8 border border-slate-800 shadow-sm">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6">Customer Types</h3>
            <div className="grid grid-cols-2 gap-4">
              {customerTypes.map((type, index) => (
                <div key={index} className="flex items-center gap-3 p-3 rounded-xl border border-slate-800 bg-slate-900 hover:bg-blue-50 hover:border-blue-100 transition-colors group cursor-pointer">
                  <div className="text-slate-400 group-hover:text-blue-600 transition-colors">
                    {type.icon}
                  </div>
                  <span className="font-medium text-sm text-slate-300 group-hover:text-blue-700">{type.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right Side: Workflow */}
          <div>
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6">Simple Transaction Flow</h3>
            <div className="flex flex-col sm:flex-row flex-wrap lg:flex-col gap-4">
              {workflow.map((step, index) => (
                <div key={index} className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border border-white shadow-sm ${step.bg}`}>
                    {step.icon}
                  </div>
                  <div className="flex-1 bg-slate-950 p-4 rounded-xl border border-slate-800 shadow-sm font-medium text-slate-200">
                    {step.label}
                  </div>
                  {index < workflow.length - 1 && (
                    <ArrowRight className="hidden lg:block w-5 h-5 text-slate-300" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
