"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Bars3Icon as Menu, XMarkIcon as X, Squares2X2Icon as LayoutDashboard } from "@heroicons/react/24/outline";

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Platform", href: "#platform" },
    { name: "Solutions", href: "#solutions" },
    { name: "How It Works", href: "#how-it-works" },
    { name: "Property Map", href: "#property-map" },
    { name: "Features", href: "#features" },
    { name: "Pricing", href: "#pricing" },
    { name: "About", href: "#about" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 backdrop-blur-md bg-slate-950/80 border-b border-slate-800/50 ${
        isScrolled ? "py-3 shadow-sm" : "py-5"
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
            <LayoutDashboard className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-50">
            Yarvo OS
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-slate-300 hover:text-blue-600 transition-colors"
            >
              {link.name}
            </Link>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-4">
          <Link
            href="/login"
            className="text-sm font-medium text-slate-300 hover:text-slate-50 transition-colors"
          >
            Sign In
          </Link>
          <a
            href="mailto:demo@yarvohotel.com"
            className="text-sm font-medium px-4 py-2 rounded-lg text-blue-600 bg-blue-50 hover:bg-blue-100 transition-colors"
          >
            Book a Demo
          </a>
          <Link
            href="/register"
            className="text-sm font-medium px-5 py-2.5 rounded-lg text-white bg-blue-600 hover:bg-blue-700 shadow-sm transition-colors"
          >
            Start Free Trial
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="lg:hidden p-2 text-slate-300 hover:bg-slate-800 rounded-lg"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Panel */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-slate-950 border-b border-slate-800 shadow-lg px-6 py-6 flex flex-col gap-4 max-h-[calc(100vh-80px)] overflow-y-auto">
          <nav className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className="text-base font-medium text-slate-300 hover:text-blue-600"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </Link>
            ))}
          </nav>
          <hr className="border-slate-800 my-2" />
          <div className="flex flex-col gap-3">
            <Link
              href="/login"
              className="w-full text-center text-base font-medium px-4 py-3 rounded-xl border border-slate-800 text-slate-300 hover:bg-slate-900"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Sign In
            </Link>
            <a
              href="mailto:demo@yarvohotel.com"
              className="w-full text-center text-base font-medium px-4 py-3 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-100"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Book a Demo
            </a>
            <Link
              href="/register"
              className="w-full text-center text-base font-medium px-4 py-3 rounded-xl bg-blue-600 text-white hover:bg-blue-700 shadow-sm"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Start Free Trial
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
