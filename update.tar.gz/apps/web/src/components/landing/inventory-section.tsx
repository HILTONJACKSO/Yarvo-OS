import { CubeIcon as Package, FireIcon as Utensils, ArrowDownIcon as ArrowDown, ExclamationTriangleIcon as AlertTriangle, CheckCircleIcon as CheckCircle2, ArrowTrendingDownIcon as TrendingDown, ClockIcon as Clock, MagnifyingGlassIcon as Search, FunnelIcon as Filter } from "@heroicons/react/24/outline";

export function InventorySection() {
  return (
    <section className="py-24 bg-slate-950 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 mb-6">
            <Package className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            Every Sale Updates Inventory Automatically
          </h2>
          <p className="text-lg text-slate-300 mb-8">
            Connect your recipes to your stock room. When a waiter places an order, the system automatically deducts the raw ingredients and alerts you when supplies are low.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start max-w-6xl mx-auto">
          
          {/* Left: Deduction Flow */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <Utensils className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-50">Customer Orders</h3>
              </div>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 shadow-sm font-medium">
                1x Grilled Chicken Plate
              </div>
            </div>

            <div className="flex justify-center -my-2 text-slate-300"><ArrowDown className="w-6 h-6" /></div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <TrendingDown className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-50">System Deducts</h3>
              </div>
              <div className="flex flex-col gap-2">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 shadow-sm text-sm flex justify-between"><span>Chicken (Whole)</span><span className="font-bold text-slate-300">-0.5 pcs</span></div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 shadow-sm text-sm flex justify-between"><span>Cooking Oil</span><span className="font-bold text-slate-300">-50 ml</span></div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 shadow-sm text-sm flex justify-between"><span>Mixed Vegetables</span><span className="font-bold text-slate-300">-200 g</span></div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 shadow-sm text-sm flex justify-between"><span>House Seasoning</span><span className="font-bold text-slate-300">-15 g</span></div>
              </div>
            </div>

            <div className="flex justify-center -my-2 text-slate-300"><ArrowDown className="w-6 h-6" /></div>

            <div className="bg-red-50 border border-red-100 rounded-2xl p-6 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-16 h-16 bg-red-100 rounded-bl-full -z-10"></div>
              <div className="flex items-center gap-3 mb-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <h3 className="font-bold text-red-900">Low-Stock Alert Triggered</h3>
              </div>
              <p className="text-sm text-red-700">Chicken stock has fallen below the minimum threshold of 10 pcs.</p>
            </div>
          </div>

          {/* Right: Inventory Dashboard Preview */}
          <div className="lg:col-span-8 bg-slate-950 rounded-3xl border border-slate-800 shadow-xl overflow-hidden">
            <div className="px-6 py-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <h3 className="font-bold text-slate-200 text-lg">Live Inventory Control</h3>
              <div className="flex gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input type="text" placeholder="Search items..." className="pl-9 pr-4 py-2 border border-slate-800 rounded-lg text-sm bg-slate-900 w-full sm:w-48" />
                </div>
                <button className="p-2 border border-slate-800 rounded-lg text-slate-300 hover:bg-slate-900"><Filter className="w-4 h-4" /></button>
              </div>
            </div>

            {/* Alerts Panel */}
            <div className="bg-slate-900 border-b border-slate-800 p-4">
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-3 text-sm bg-slate-950 p-2.5 rounded-lg border border-slate-800 shadow-sm text-amber-700">
                  <AlertTriangle className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="font-medium">Premium Beer stock is low (12 bottles remaining).</span>
                </div>
                <div className="flex items-center gap-3 text-sm bg-slate-950 p-2.5 rounded-lg border border-slate-800 shadow-sm text-red-700">
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                  <span className="font-medium">Chicken will run out tomorrow based on current sales velocity.</span>
                </div>
                <div className="flex items-center gap-3 text-sm bg-slate-950 p-2.5 rounded-lg border border-slate-800 shadow-sm text-slate-300">
                  <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="font-medium">Five fresh juice bottles expired yesterday.</span>
                </div>
                <div className="flex items-center gap-3 text-sm bg-slate-950 p-2.5 rounded-lg border border-slate-800 shadow-sm text-blue-700">
                  <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0" />
                  <span className="font-medium">Purchase order PO-992 is waiting for your approval.</span>
                </div>
              </div>
            </div>

            {/* Inventory Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-900 text-slate-400 uppercase text-xs border-b border-slate-800">
                  <tr>
                    <th className="px-6 py-4 font-bold">Item Name</th>
                    <th className="px-6 py-4 font-bold">Dept</th>
                    <th className="px-6 py-4 font-bold">Avail / Min</th>
                    <th className="px-6 py-4 font-bold">Stock Level</th>
                    <th className="px-6 py-4 font-bold text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {[
                    { name: "Premium Beer", dept: "Bar", avail: 12, min: 48, max: 100, color: "bg-amber-500", status: "Low Stock", statusColor: "text-blue-600 bg-blue-50" },
                    { name: "Chicken (Whole)", dept: "Kitchen", avail: 8, min: 10, max: 50, color: "bg-red-500", status: "Critical", statusColor: "text-red-600 bg-red-50" },
                    { name: "Jasmine Rice", dept: "Kitchen", avail: 45, min: 20, max: 100, color: "bg-emerald-500", status: "Healthy", statusColor: "text-blue-600 bg-blue-50" },
                    { name: "Toilet Paper", dept: "Housekeeping", avail: 120, min: 50, max: 200, color: "bg-emerald-500", status: "Healthy", statusColor: "text-blue-600 bg-blue-50" },
                    { name: "Fresh Juice", dept: "Restaurant", avail: 5, min: 15, max: 30, color: "bg-amber-500", status: "Low + Expired", statusColor: "text-blue-600 bg-blue-50" },
                  ].map((item, i) => (
                    <tr key={i} className="hover:bg-slate-900 transition-colors">
                      <td className="px-6 py-4 font-medium text-slate-50">{item.name}</td>
                      <td className="px-6 py-4 text-slate-400">{item.dept}</td>
                      <td className="px-6 py-4 font-medium">{item.avail} <span className="text-slate-400 font-normal">/ {item.min}</span></td>
                      <td className="px-6 py-4">
                        <div className="w-full bg-slate-200 rounded-full h-2">
                          <div className={`${item.color} h-2 rounded-full`} style={{ width: `${(item.avail / item.max) * 100}%` }}></div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className={`px-2.5 py-1 rounded-md text-xs font-bold ${item.statusColor}`}>
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="bg-slate-900 p-4 border-t border-slate-800 text-center">
              <button className="text-blue-600 text-sm font-bold hover:underline">View All 1,452 Items</button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
