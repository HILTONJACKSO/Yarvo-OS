import Link from "next/link";
import { TermsModal } from "@/components/landing/terms-modal";
import { Squares2X2Icon as LayoutDashboard, EnvelopeIcon as Mail, PhoneIcon as Phone, CameraIcon as Camera, CodeBracketIcon as Github } from "@heroicons/react/24/outline";

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 py-16 border-t border-slate-800">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12 mb-16">
          
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-6 group">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
                <LayoutDashboard className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                Yarvo OS
              </span>
            </Link>
            <p className="text-slate-400 mb-8 leading-relaxed max-w-sm">
              The complete hospitality operating system. Manage your hotel, restaurant, beach, and club from one connected platform.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:border-blue-500 hover:bg-blue-600/20 transition-all">
                <Mail className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:border-blue-500 hover:bg-blue-600/20 transition-all">
                <Phone className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:border-blue-500 hover:bg-pink-600/20 transition-all">
                <Camera className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h4 className="text-white font-bold mb-6">Product</h4>
            <ul className="space-y-4">
              <li><Link href="#features" className="text-slate-400 hover:text-blue-400 transition-colors">Features</Link></li>
              <li><Link href="#pricing" className="text-slate-400 hover:text-blue-400 transition-colors">Pricing</Link></li>
              <li><Link href="/register" className="text-slate-400 hover:text-blue-400 transition-colors">Hardware Setup</Link></li>
              <li><Link href="#pwa" className="text-slate-400 hover:text-blue-400 transition-colors flex items-center gap-2">Progressive Web App <span className="bg-blue-600/20 text-blue-400 text-[10px] font-bold px-2 py-0.5 rounded">NEW</span></Link></li>
              <li><Link href="/register" className="text-slate-400 hover:text-blue-400 transition-colors">Updates</Link></li>
            </ul>
          </div>

          {/* Solutions Links */}
          <div>
            <h4 className="text-white font-bold mb-6">Solutions</h4>
            <ul className="space-y-4">
              <li><Link href="/register" className="text-slate-400 hover:text-blue-400 transition-colors">For Hotels & Resorts</Link></li>
              <li><Link href="/register" className="text-slate-400 hover:text-blue-400 transition-colors">For Restaurants & Cafes</Link></li>
              <li><Link href="/register" className="text-slate-400 hover:text-blue-400 transition-colors">For Bars & Nightclubs</Link></li>
              <li><Link href="/register" className="text-slate-400 hover:text-blue-400 transition-colors">For Beaches & Pools</Link></li>
              <li><Link href="/register" className="text-slate-400 hover:text-blue-400 transition-colors">For Event Centers</Link></li>
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h4 className="text-white font-bold mb-6">Resources</h4>
            <ul className="space-y-4">
              <li><a href="mailto:support@yarvohotel.com" className="text-slate-400 hover:text-blue-400 transition-colors">Help Center</a></li>
              <li><a href="https://youtube.com" className="text-slate-400 hover:text-blue-400 transition-colors">Video Tutorials</a></li>
              <li><a href="mailto:support@yarvohotel.com" className="text-slate-400 hover:text-blue-400 transition-colors">API Documentation</a></li>
              <li><a href="mailto:support@yarvohotel.com" className="text-slate-400 hover:text-blue-400 transition-colors">Developer Portal</a></li>
              <li><a href="mailto:support@yarvohotel.com" className="text-slate-400 hover:text-blue-400 transition-colors">Community</a></li>
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="text-white font-bold mb-6">Company</h4>
            <ul className="space-y-4">
              <li><Link href="#about" className="text-slate-400 hover:text-blue-400 transition-colors">About Us</Link></li>
              <li><a href="mailto:jobs@yarvohotel.com" className="text-slate-400 hover:text-blue-400 transition-colors">Careers</a></li>
              <li><a href="mailto:sales@yarvohotel.com" className="text-slate-400 hover:text-blue-400 transition-colors">Contact Sales</a></li>
              <li><Link href="/privacy" className="text-slate-400 hover:text-blue-400 transition-colors">Privacy Policy</Link></li>
              <li><TermsModal /></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-slate-400">
            © {new Date().getFullYear()} Yarvo Hospitality OS. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-slate-400">
            <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> All systems operational</span>
            <a href="mailto:support@yarvohotel.com" className="hover:text-white transition-colors">Status Page</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
