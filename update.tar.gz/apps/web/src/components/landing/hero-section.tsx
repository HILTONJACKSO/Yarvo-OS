import Link from "next/link";
import { ArrowRightIcon as ArrowRight, CheckCircleIcon as CheckCircle2, HomeModernIcon as Bed, FireIcon as Utensils, TicketIcon as Ticket, UsersIcon as Users, ExclamationCircleIcon as AlertCircle } from "@heroicons/react/24/outline";

export function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-slate-950">
      {/* Background decoration */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-blue-50/50 rounded-full blur-3xl opacity-70 pointer-events-none -z-10" />
      
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        {/* Left Side Content */}
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800 border border-slate-800 text-slate-200 text-sm font-medium mb-6">
            <span className="flex h-2 w-2 rounded-full bg-blue-600 animate-pulse"></span>
            Hospitality Operations, Connected
          </div>
          
          <h1 className="font-display text-[40px] md:text-[64px] font-extrabold tracking-[-0.04em] text-slate-50 mb-6 leading-[1.05]">
            Run Your Entire Hospitality Business <span className="text-blue-600">From One Platform.</span>
          </h1>
          
          <p className="text-lg lg:text-xl text-slate-300 mb-8 leading-relaxed">
            Manage rooms, bookings, restaurant orders, kitchen operations, guest accounts, tickets, inventory, staff, payments, taxes, and finances from one simple, connected system.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Link
              href="/register"
              className="inline-flex justify-center items-center gap-2 px-8 py-4 rounded-xl text-white bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-600/20 font-semibold transition-all hover:-translate-y-0.5"
            >
              Start Free Trial <ArrowRight className="w-5 h-5" />
            </Link>
            <a
              href="mailto:demo@yarvohotel.com"
              className="inline-flex justify-center items-center px-8 py-4 rounded-xl text-slate-300 bg-slate-950 border border-slate-800 hover:bg-slate-900 hover:border-slate-700 font-semibold transition-all shadow-sm"
            >
              Book a Live Demo
            </a>
          </div>

          <p className="text-sm text-slate-400 mb-8">
            No separate mobile app required. Install Yarvo Hospitality OS on phones, tablets, laptops, and desktop computers.
          </p>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
            <p className="text-sm font-medium text-slate-300">
              Designed for modern hotels, resorts, restaurants, beaches, bars, clubs, and event facilities.
            </p>
          </div>
        </div>

        {/* Right Side Preview */}
        <div className="relative w-full h-[600px] perspective-[2000px] hidden md:block">
          {/* Main Dashboard Panel */}
          <div className="absolute inset-0 bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden transform rotate-y-[-12deg] rotate-x-[5deg] scale-105 origin-right transition-transform hover:rotate-y-0 hover:rotate-x-0">
            {/* Preview Header */}
            <div className="h-14 border-b border-slate-800 bg-slate-900/50 flex items-center px-6 justify-between">
              <div className="flex items-center gap-4">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
                </div>
                <div className="h-6 w-64 bg-slate-800 rounded-md"></div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-800"></div>
                <div className="w-8 h-8 rounded-full bg-blue-600"></div>
              </div>
            </div>

            {/* Preview Content */}
            <div className="p-6 grid grid-cols-4 gap-6 h-full bg-slate-950">
              {/* Sidebar */}
              <div className="col-span-1 flex flex-col gap-3">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className={`h-10 rounded-lg ${i === 0 ? 'bg-blue-600/20 border border-blue-500/30' : 'bg-slate-900'}`}></div>
                ))}
              </div>
              
              {/* Main Content Area */}
              <div className="col-span-3 flex flex-col gap-6">
                {/* Stats Row */}
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: "Today's Revenue", val: "$4,250", color: "text-blue-600" },
                    { label: "Rooms Available", val: "12 / 45", color: "text-blue-400" },
                    { label: "Active Orders", val: "18", color: "text-blue-600" },
                  ].map((stat, i) => (
                    <div key={i} className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                      <p className="text-slate-400 text-xs font-medium mb-1">{stat.label}</p>
                      <p className={`text-2xl font-bold ${stat.color}`}>{stat.val}</p>
                    </div>
                  ))}
                </div>

                {/* Live Operations Feed */}
                <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col">
                  <h3 className="text-white font-medium mb-4">Live Operations</h3>
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                      <Bed className="w-5 h-5 text-blue-400" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-200">Guest checked into Room 205</p>
                        <p className="text-xs text-slate-400">2 mins ago</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                      <Utensils className="w-5 h-5 text-blue-600" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-200">Table 7 order sent to kitchen</p>
                        <p className="text-xs text-slate-400">5 mins ago</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                      <Ticket className="w-5 h-5 text-blue-600" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-200">Beach ticket sold (VIP)</p>
                        <p className="text-xs text-slate-400">12 mins ago</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50">
                      <Users className="w-5 h-5 text-blue-600" />
                      <div className="flex-1">
                        <p className="text-sm text-slate-200">Room 108 cleaning completed</p>
                        <p className="text-xs text-slate-400">15 mins ago</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Floating Cards */}
          <div className="absolute -left-12 top-32 bg-slate-950 p-4 rounded-xl shadow-xl border border-slate-800 flex items-center gap-4 animate-bounce" style={{ animationDuration: '4s' }}>
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-50">Payment Received</p>
              <p className="text-xs text-slate-400">Mobile Money - $120.00</p>
            </div>
          </div>

          <div className="absolute -right-8 bottom-32 bg-slate-950 p-4 rounded-xl shadow-xl border border-slate-800 flex items-center gap-4 animate-bounce" style={{ animationDuration: '5s', animationDelay: '1s' }}>
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
              <Utensils className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-50">Kitchen Order Ready</p>
              <p className="text-xs text-slate-400">Table 4 - 2x Items</p>
            </div>
          </div>
          
          <div className="absolute left-10 -bottom-6 bg-slate-900 p-4 rounded-xl shadow-xl border border-slate-800 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <p className="text-sm font-bold text-white">Low Stock Warning</p>
              <p className="text-xs text-slate-400">Premium Beer (5 left)</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
