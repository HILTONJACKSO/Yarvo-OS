"use client";

import { useState } from "react";
import { XMarkIcon as X } from "@heroicons/react/24/outline";

export function TermsModal() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)} 
        className="text-slate-400 hover:text-blue-400 transition-colors"
      >
        Terms of Service
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-4xl max-h-[85vh] rounded-3xl shadow-2xl flex flex-col animate-in zoom-in-95 duration-200 overflow-hidden">
            {/* Header */}
            <div className="flex justify-between items-center p-6 border-b border-slate-100 bg-white">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Terms of Service</h2>
                <p className="text-sm text-slate-500 mt-1">Last Updated: July 2026</p>
              </div>
              <button 
                onClick={() => setIsOpen(false)} 
                className="p-2 rounded-full hover:bg-slate-100 transition-colors bg-slate-50"
              >
                <X className="w-6 h-6 text-slate-500" />
              </button>
            </div>
            
            {/* Scrollable Content */}
            <div className="p-8 overflow-y-auto bg-slate-50">
              <div className="prose prose-slate max-w-none text-slate-700 space-y-8 bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
                <section>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">1. Acceptance of Terms</h3>
                  <p>
                    By accessing and using Yarvo OS ("Service"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Service. Yarvo OS is a product of Yarvo Solutions Inc.
                  </p>
                </section>

                <section>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">2. Description of Service</h3>
                  <p>
                    Yarvo OS provides an integrated hospitality management system, including but not limited to property management, point of sale, inventory tracking, staff management, and analytics dashboard. We reserve the right to modify or discontinue the Service at any time.
                  </p>
                </section>

                <section>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">3. User Accounts and Security</h3>
                  <p>
                    You are responsible for maintaining the confidentiality of your account credentials. You agree to notify us immediately of any unauthorized use of your account. Yarvo OS will not be liable for any losses caused by unauthorized use of your account.
                  </p>
                </section>

                <section>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">4. Data Privacy and Ownership</h3>
                  <p>
                    You retain all rights to your customer data. By using the Service, you grant Yarvo OS the right to host, backup, and process your data solely for the purpose of providing the Service. Please review our Privacy Policy for detailed information on how we handle data.
                  </p>
                </section>

                <section>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">5. Payment Terms</h3>
                  <p>
                    Subscriptions are billed in advance on a monthly or annual basis. There are no refunds for partial months of service. If you upgrade your plan, you will be billed the prorated difference immediately.
                  </p>
                </section>

                <section>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">6. Limitation of Liability</h3>
                  <p>
                    Yarvo OS shall not be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.
                  </p>
                </section>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
