import { BuildingOffice2Icon as Building2, SunIcon as Palmtree, FireIcon as UtensilsCrossed, BeakerIcon as Wine, MusicalNoteIcon as Music, SunIcon as Umbrella, ArrowPathIcon as Waves, SparklesIcon as PartyPopper } from "@heroicons/react/24/outline";

export function PropertyTypes() {
  const properties = [
    {
      icon: <Building2 className="w-8 h-8" />,
      title: "Hotels",
      description: "Manage rooms, guests, bookings, charges, housekeeping, and checkout.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    },
    {
      icon: <Palmtree className="w-8 h-8" />,
      title: "Resorts",
      description: "Connect multi-facility operations across large sprawling properties easily.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    },
    {
      icon: <UtensilsCrossed className="w-8 h-8" />,
      title: "Restaurants",
      description: "Manage tables, menus, orders, kitchen movement, payments, and receipts.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    },
    {
      icon: <Wine className="w-8 h-8" />,
      title: "Bars",
      description: "Fast-paced ordering, tab management, split payments, and inventory.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    },
    {
      icon: <Music className="w-8 h-8" />,
      title: "Nightclubs",
      description: "Manage entry tickets, VIP tables, guest lists, capacity, and bottle service.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    },
    {
      icon: <Umbrella className="w-8 h-8" />,
      title: "Beaches",
      description: "Sell entrance tickets, manage groups, cabanas, capacity, food, and activities.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    },
    {
      icon: <Waves className="w-8 h-8" />,
      title: "Swimming Pools",
      description: "Manage day passes, memberships, towel rentals, and poolside service.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    },
    {
      icon: <PartyPopper className="w-8 h-8" />,
      title: "Event Centers",
      description: "Book halls, manage packages, coordinate catering, and invoice corporate groups.",
      color: "bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white"
    }
  ];

  return (
    <section id="solutions" className="py-24 bg-slate-900 border-t border-slate-800/50">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            Built for Every Hospitality Experience
          </h2>
          <p className="text-lg text-slate-300">
            Whether you operate a single guesthouse or a massive luxury resort with multiple restaurants and a nightclub, Yarvo OS adapts to your business.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {properties.map((prop, index) => (
            <div 
              key={index}
              className="group bg-slate-950 rounded-2xl p-8 border border-slate-800 shadow-sm hover:shadow-xl hover:border-slate-700 transition-all duration-300 hover:-translate-y-1 cursor-pointer"
            >
              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-colors duration-300 ${prop.color}`}>
                {prop.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-50 mb-3 group-hover:text-blue-600 transition-colors">
                {prop.title}
              </h3>
              <p className="text-slate-300 leading-relaxed">
                {prop.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
