import { CalculatorIcon as Calculator, Cog8ToothIcon as Settings2, DocumentIcon as FileText, CheckIcon as Check, ChevronDownIcon as ChevronDown } from "@heroicons/react/24/outline";

export function TaxesSection() {
  return (
    <section className="py-24 bg-slate-900 border-t border-slate-800/50 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-100 text-blue-600 mb-6">
            <Calculator className="w-8 h-8" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            Flexible Taxes for Every Service
          </h2>
          <p className="text-lg text-slate-300 mb-8">
            Different departments require different tax rules. Configure custom taxes, service charges, and tourism levies for your rooms, restaurant, bar, and beach operations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start max-w-6xl mx-auto">
          
          {/* Left: Tax Configuration Preview */}
          <div className="bg-slate-950 rounded-3xl border border-slate-800 shadow-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
              <h3 className="font-bold text-slate-200 flex items-center gap-2"><Settings2 className="w-5 h-5 text-slate-400" /> Tax Configuration</h3>
              <button className="bg-blue-600 text-white px-4 py-1.5 rounded-lg text-sm font-medium">Save Tax Rule</button>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase block mb-1">Tax Name</label>
                  <input type="text" value="Tourism Levy" readOnly className="w-full border border-slate-700 rounded-lg p-2.5 text-sm font-medium text-slate-50 bg-slate-900" />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase block mb-1">Percentage (%)</label>
                  <input type="text" value="2.00" readOnly className="w-full border border-slate-700 rounded-lg p-2.5 text-sm font-medium text-slate-50 bg-slate-900" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase block mb-1">Calculation Type</label>
                  <div className="w-full border border-slate-700 rounded-lg p-2.5 text-sm font-medium text-slate-50 flex justify-between items-center bg-slate-950">
                    Exclusive (Added to bill) <ChevronDown className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase block mb-1">Department</label>
                  <div className="w-full border border-slate-700 rounded-lg p-2.5 text-sm font-medium text-slate-50 flex justify-between items-center bg-slate-950">
                    Rooms & Accommodation <ChevronDown className="w-4 h-4 text-slate-400" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase block mb-1">Start Date</label>
                  <input type="text" value="Jan 01, 2026" readOnly className="w-full border border-slate-700 rounded-lg p-2.5 text-sm font-medium text-slate-50 bg-slate-950" />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase block mb-1">End Date</label>
                  <input type="text" value="Never" readOnly className="w-full border border-slate-700 rounded-lg p-2.5 text-sm text-slate-400 bg-slate-950" />
                </div>
              </div>

              <div className="flex items-center gap-3 mt-6 p-4 bg-slate-900 border border-slate-800 rounded-xl">
                <div className="w-5 h-5 rounded border border-slate-700 bg-blue-600 flex items-center justify-center text-white"><Check className="w-3 h-3" /></div>
                <span className="text-sm font-medium text-slate-300">Display separately on printed receipt</span>
              </div>
            </div>
          </div>

          {/* Right: Receipt Preview */}
          <div className="flex justify-center">
            <div className="w-full max-w-sm bg-slate-950 p-8 rounded shadow-sm border border-slate-800" style={{ boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01)' }}>
              <div className="text-center mb-6 border-b border-slate-800 pb-6">
                <div className="w-10 h-10 bg-slate-900 text-white flex items-center justify-center font-bold text-lg rounded mb-2 mx-auto">Y</div>
                <h3 className="font-bold text-lg text-slate-50">Yarvo Resort & Spa</h3>
                <p className="text-xs text-slate-400 font-mono mt-1">TAX INVOICE #10245</p>
              </div>

              <div className="flex flex-col gap-3 text-sm font-mono mb-6 pb-6 border-b border-slate-800">
                <div className="flex justify-between"><span>Room Charge</span><span>$200.00</span></div>
                <div className="flex justify-between"><span>Restaurant</span><span>$80.00</span></div>
                <div className="flex justify-between"><span>Pool Entry</span><span>$20.00</span></div>
              </div>

              <div className="flex flex-col gap-2 text-sm font-mono mb-6 pb-6 border-b border-slate-800">
                <div className="flex justify-between"><span>Subtotal</span><span>$300.00</span></div>
                <div className="flex justify-between text-slate-400"><span>Government Tax (10%)</span><span>$30.00</span></div>
                <div className="flex justify-between text-slate-400"><span>Service Charge (5%)</span><span>$15.00</span></div>
                <div className="flex justify-between text-slate-400"><span>Tourism Levy (2%)</span><span>$6.00</span></div>
              </div>

              <div className="flex justify-between font-bold text-lg font-mono mb-8">
                <span>TOTAL</span>
                <span>$351.00</span>
              </div>

              <div className="flex items-center justify-center gap-2 text-slate-400">
                <FileText className="w-4 h-4" />
                <span className="text-xs uppercase tracking-widest">Customer Copy</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
