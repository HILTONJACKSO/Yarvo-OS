import Link from "next/link";
import { CheckIcon as Check, XMarkIcon as X, QuestionMarkCircleIcon as HelpCircle } from "@heroicons/react/24/outline";

export function PricingSection() {
  const plans = [
    {
      name: "Starter",
      description: "Perfect for single-property guesthouses and small restaurants.",
      price: "$49",
      billing: "per month",
      buttonText: "Start Free Trial",
      buttonStyle: "bg-slate-950 text-slate-50 border border-slate-800 hover:bg-slate-900",
      features: [
        { name: "Up to 20 Rooms", included: true },
        { name: "1 Point of Sale (POS)", included: true },
        { name: "Basic Inventory", included: true },
        { name: "Standard Support", included: true },
        { name: "Multi-Branch Management", included: false },
        { name: "Custom Tax Rules", included: false },
        { name: "Advanced Reporting", included: false },
      ]
    },
    {
      name: "Professional",
      description: "Ideal for growing hotels, beach resorts, and busy nightclubs.",
      price: "$149",
      billing: "per month",
      isPopular: true,
      buttonText: "Start Free Trial",
      buttonStyle: "bg-blue-600 text-white hover:bg-blue-700 shadow-md",
      features: [
        { name: "Up to 100 Rooms", included: true },
        { name: "5 Point of Sale (POS)", included: true },
        { name: "Advanced Inventory & Recipes", included: true },
        { name: "Priority 24/7 Support", included: true },
        { name: "Multi-Branch Management", included: false },
        { name: "Custom Tax Rules", included: true },
        { name: "Advanced Reporting", included: true },
      ]
    },
    {
      name: "Enterprise",
      description: "Built for large hotel chains, multi-venue resorts, and casino groups.",
      price: "Custom",
      billing: "contact sales",
      buttonText: "Contact Sales",
      buttonStyle: "bg-slate-900 text-white hover:bg-slate-800",
      features: [
        { name: "Unlimited Rooms", included: true },
        { name: "Unlimited POS", included: true },
        { name: "Centralized Warehouse", included: true },
        { name: "Dedicated Account Manager", included: true },
        { name: "Multi-Branch Management", included: true },
        { name: "Custom Tax Rules", included: true },
        { name: "Custom Integrations API", included: true },
      ]
    }
  ];

  return (
    <section id="pricing" className="py-24 bg-slate-900 border-t border-slate-800/50">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-display text-[30px] md:text-[44px] font-bold text-slate-50 mb-6 tracking-[-0.03em]">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-slate-300">
            No hidden setup fees. No expensive proprietary hardware to buy. Choose the plan that fits your property size and upgrade as you grow.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`relative bg-slate-950 rounded-3xl p-8 border ${plan.isPopular ? 'border-blue-500 shadow-2xl ring-4 ring-blue-500/10 scale-105 z-10' : 'border-slate-800 shadow-sm'} flex flex-col`}
            >
              {plan.isPopular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-blue-500 text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  Most Popular
                </div>
              )}
              
              <div className="mb-8">
                <h3 className="font-display text-[24px] font-bold text-slate-50 mb-2">{plan.name}</h3>
                <p className="font-sans text-slate-400 text-sm h-10">{plan.description}</p>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-extrabold text-slate-50">{plan.price}</span>
                  {plan.price !== "Custom" && <span className="text-slate-400 font-medium">/mo</span>}
                </div>
                <p className="text-slate-400 text-sm mt-1">{plan.billing}</p>
              </div>

              {plan.buttonText === 'Contact Sales' ? (
                <a href="mailto:sales@yarvohotel.com" className={`block text-center w-full py-3.5 rounded-xl font-bold transition-all mb-8 ${plan.buttonStyle}`}>
                  {plan.buttonText}
                </a>
              ) : (
                <Link href="/register" className={`block text-center w-full py-3.5 rounded-xl font-bold transition-all mb-8 ${plan.buttonStyle}`}>
                  {plan.buttonText}
                </Link>
              )}

              <div className="flex flex-col gap-4 flex-1">
                <p className="text-sm font-bold text-slate-50 uppercase tracking-wider mb-2">What's included</p>
                {plan.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-3">
                    {feature.included ? (
                      <div className="w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                        <Check className="w-3 h-3 text-blue-600" />
                      </div>
                    ) : (
                      <div className="w-5 h-5 flex items-center justify-center shrink-0">
                        <X className="w-4 h-4 text-slate-300" />
                      </div>
                    )}
                    <span className={`text-sm ${feature.included ? 'text-slate-300 font-medium' : 'text-slate-400'}`}>
                      {feature.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-slate-300 flex items-center justify-center gap-2">
            <HelpCircle className="w-5 h-5 text-slate-400" />
            Need a customized setup for a unique property? <a href="#" className="text-blue-600 font-bold hover:underline">Contact our sales team.</a>
          </p>
        </div>
      </div>
    </section>
  );
}
