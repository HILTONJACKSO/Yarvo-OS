import { HeartIcon as Heart, GlobeAltIcon as Globe2, BoltIcon as Zap } from "@heroicons/react/24/outline";

export function AboutSection() {
  return (
    <section id="about" className="py-24 bg-slate-950 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Left: Images/Collage */}
          <div className="relative h-[600px] rounded-3xl overflow-hidden bg-slate-800 flex items-center justify-center border border-slate-800">
             {/* Collage background */ }
             <div className="absolute inset-0 bg-slate-900">
               <div className="absolute inset-0 opacity-40 bg-[url('https://images.unsplash.com/photo-1542314831-c6a4d14faaf2?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center"></div>
               <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent"></div>
             </div>
             
             <div className="relative z-10 text-center p-8">
               <div className="w-20 h-20 bg-blue-600 rounded-2xl mx-auto flex items-center justify-center mb-6 shadow-2xl shadow-blue-600/30">
                 <span className="text-white font-bold text-4xl">Y</span>
               </div>
               <p className="text-white text-2xl font-bold tracking-tight italic">
                 "Hospitality is about people, not wrestling with clunky software."
               </p>
             </div>
          </div>

          {/* Right: Content */}
          <div className="max-w-xl">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
              Why We Built Yarvo OS
            </h2>
            <div className="space-y-6 text-lg text-slate-300 leading-relaxed mb-10">
              <p>
                For years, hoteliers and restaurant owners have been forced to stitch together 
                multiple disconnected systems. You buy a Property Management System for the rooms, 
                a Point of Sale for the restaurant, a ticketing system for the club, and an accounting 
                software to make sense of it all.
              </p>
              <p>
                <strong>The result?</strong> Endless manual data entry, lost revenue, frustrated staff, 
                and annoyed guests who have to pay three different bills before they leave the property.
              </p>
              <p>
                We built Yarvo OS to fix this. We designed a single, unified operating system where 
                the front desk talks to the kitchen, the kitchen talks to the inventory, and everything 
                flows automatically into your accounting dashboard. One system. One source of truth.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div>
                <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mb-4">
                  <Heart className="w-6 h-6 text-red-500" />
                </div>
                <h4 className="font-bold text-slate-50 mb-2">Guest-Centric</h4>
                <p className="text-sm text-slate-300">Everything revolves around providing the guest with a seamless, frictionless experience.</p>
              </div>
              <div>
                <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-blue-600" />
                </div>
                <h4 className="font-bold text-slate-50 mb-2">Modern Technology</h4>
                <p className="text-sm text-slate-300">Built using state-of-the-art web tech, eliminating the need for expensive local servers.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
