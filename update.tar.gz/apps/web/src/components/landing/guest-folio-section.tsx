import { CheckCircleIcon as CheckCircle2, HomeModernIcon as Bed, FireIcon as Utensils, BeakerIcon as Wine, ArrowPathIcon as Waves, ShoppingBagIcon as Shirt, DocumentIcon as FileText, ArrowDownIcon as ArrowDown } from "@heroicons/react/24/outline";

export function GuestFolioSection() {
  const timeline = [
    { icon: <CheckCircle2 className="w-5 h-5 text-blue-600" />, text: "Guest checks in" },
    { icon: <Bed className="w-5 h-5 text-slate-400" />, text: "Room charge added" },
    { icon: <Utensils className="w-5 h-5 text-slate-400" />, text: "Restaurant order added" },
    { icon: <Wine className="w-5 h-5 text-slate-400" />, text: "Bar purchase added" },
    { icon: <Waves className="w-5 h-5 text-slate-400" />, text: "Pool or beach access added" },
    { icon: <Shirt className="w-5 h-5 text-slate-400" />, text: "Laundry or additional services added" },
    { icon: <FileText className="w-5 h-5 text-slate-400" />, text: "Taxes calculated" },
    { icon: <ArrowDown className="w-5 h-5 text-red-500" />, text: "Deposit deducted" },
    { icon: <CheckCircle2 className="w-5 h-5 text-blue-500" />, text: "Split payment received" },
    { icon: <FileText className="w-5 h-5 text-slate-50" />, text: "Final invoice printed" },
  ];

  return (
    <section id="how-it-works" className="py-24 bg-slate-950 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        {/* Left Side: Content & Timeline */}
        <div className="max-w-2xl">
          <h2 className="text-4xl md:text-5xl font-extrabold text-slate-50 mb-6 tracking-tight">
            One Guest. <br />
            <span className="text-blue-600">One Account.</span> <br />
            One Final Bill.
          </h2>
          <p className="text-lg text-slate-300 mb-10 leading-relaxed">
            Stop forcing guests to pay separately at the restaurant, the bar, and the pool. With Yarvo OS, a hotel guest can enjoy all your facilities and have everything seamlessly routed to one master guest account for a single checkout experience.
          </p>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6">The Seamless Guest Journey</h3>
            <div className="relative">
              {/* Vertical line connecting timeline */}
              <div className="absolute left-4 top-4 bottom-4 w-0.5 bg-slate-200"></div>
              
              <div className="flex flex-col gap-4">
                {timeline.map((item, index) => (
                  <div key={index} className="flex items-center gap-4 relative z-10">
                    <div className="w-8 h-8 rounded-full bg-slate-950 border-2 border-slate-800 shadow-sm flex items-center justify-center shrink-0">
                      {item.icon}
                    </div>
                    <span className={`font-medium ${index === 0 || index === timeline.length - 1 ? 'text-slate-50' : 'text-slate-300'}`}>
                      {item.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Receipt Preview */}
        <div className="relative flex justify-center lg:justify-end perspective-[1000px]">
          {/* Decorative Background */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-[110%] bg-slate-900 border border-slate-800 rounded-[3rem] -rotate-6 -z-10"></div>
          
          <div className="w-full max-w-md bg-slate-950 rounded-t-xl rounded-b-md shadow-2xl border border-slate-800 flex flex-col relative transform rotate-y-[-5deg] hover:rotate-y-0 transition-transform duration-500">
            {/* Receipt Jagged Top (CSS trick) */}
            <div className="h-4 w-full bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIxMCI+PHBvbHlnb24gcG9pbnRzPSIwLDEwIDEwLDAgMjAsMTAiIGZpbGw9IiMwZDIxMDYiLz48L3N2Zz4=')] absolute -top-3 left-0 right-0 hidden"></div>
            
            <div className="p-8 pb-10 flex flex-col gap-6">
              <div className="text-center border-b border-dashed border-slate-700 pb-6">
                <div className="w-12 h-12 rounded-xl bg-slate-900 mx-auto mb-3 flex items-center justify-center">
                  <span className="font-bold text-slate-50 text-xl">Y</span>
                </div>
                <h3 className="font-bold text-xl text-slate-50">Guest Folio</h3>
                <p className="text-sm text-slate-400">Invoice #INV-2026-089</p>
              </div>

              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-400">Guest Name:</span>
                  <span className="font-bold text-slate-50">Daniel Johnson</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Room:</span>
                  <span className="font-bold text-slate-50">205</span>
                </div>
              </div>

              <div className="border-t border-b border-dashed border-slate-700 py-4">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Charges</h4>
                <div className="flex flex-col gap-2 text-sm">
                  <div className="flex justify-between"><span className="text-slate-300">Room (2 Nights)</span><span className="font-medium text-slate-50">$300.00</span></div>
                  <div className="flex justify-between"><span className="text-slate-300">Restaurant (Dinner)</span><span className="font-medium text-slate-50">$85.00</span></div>
                  <div className="flex justify-between"><span className="text-slate-300">Bar (Drinks)</span><span className="font-medium text-slate-50">$45.00</span></div>
                  <div className="flex justify-between"><span className="text-slate-300">Pool Access</span><span className="font-medium text-slate-50">$15.00</span></div>
                  <div className="flex justify-between"><span className="text-slate-300">Laundry</span><span className="font-medium text-slate-50">$20.00</span></div>
                  <div className="flex justify-between mt-2 pt-2 border-t border-slate-800"><span className="text-slate-300">Taxes & Fees</span><span className="font-medium text-slate-50">$46.50</span></div>
                </div>
              </div>

              <div className="flex justify-between items-center text-lg">
                <span className="font-bold text-slate-50">Total</span>
                <span className="font-bold text-blue-600">$511.50</span>
              </div>

              <div className="border-t border-dashed border-slate-700 pt-4">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Payments</h4>
                <div className="flex flex-col gap-2 text-sm">
                  <div className="flex justify-between"><span className="text-slate-300">Mobile Money</span><span className="font-medium text-blue-600">-$200.00</span></div>
                  <div className="flex justify-between"><span className="text-slate-300">Credit Card</span><span className="font-medium text-blue-600">-$200.00</span></div>
                  <div className="flex justify-between"><span className="text-slate-300">Cash</span><span className="font-medium text-blue-600">-$111.50</span></div>
                </div>
              </div>

              <div className="bg-slate-900 p-4 rounded-lg flex justify-between items-center border border-slate-800 mt-2">
                <span className="font-bold text-slate-300">Balance Due</span>
                <span className="font-bold text-slate-50 text-xl">$0.00</span>
              </div>
              
              <div className="text-center mt-2">
                <p className="text-xs text-slate-400">Thank you for staying with us!</p>
              </div>
            </div>
            
            {/* Receipt Jagged Bottom (CSS trick) */}
            <div className="h-3 w-full bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIxMCI+PHBvbHlnb24gcG9pbnRzPSIwLDAgMTAsMTAgMjAsMCIgZmlsbD0iIzBkMjEwNiIvPjwvc3ZnPg==')] absolute -bottom-3 left-0 right-0 drop-shadow-md"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
