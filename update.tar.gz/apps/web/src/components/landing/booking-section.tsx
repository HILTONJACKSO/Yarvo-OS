import { CalendarIcon as Calendar, UsersIcon as Users, ClockIcon as Clock, CreditCardIcon as CreditCard, ChevronDownIcon as ChevronDown, DevicePhoneMobileIcon as MonitorSmartphone, Squares2X2Icon as LayoutDashboard } from "@heroicons/react/24/outline";

export function BookingSection() {
  const bookingTypes = [
    "Hotel Rooms", "Restaurant Tables", "Beach Cabanas", "Pool Access", 
    "Nightclub VIP Tables", "Conference Halls", "Weddings", "Events", 
    "Birthday Packages", "Group Visits"
  ];

  return (
    <section className="py-24 bg-slate-950 overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-slate-50 mb-6 tracking-tight">
            Bookings From Every Part of the Business
          </h2>
          <p className="text-lg text-slate-300 mb-8">
            Manage everything from a simple table reservation to a 500-guest wedding and room block. Provide your customers with a beautiful booking page while your team manages it all from one calendar.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {bookingTypes.map((type, i) => (
              <span key={i} className="px-4 py-2 bg-slate-800 text-slate-300 rounded-full text-sm font-medium border border-slate-800">
                {type}
              </span>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          {/* Left: Customer Facing Preview */}
          <div className="relative">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6 flex items-center gap-2">
              <MonitorSmartphone className="w-4 h-4" /> Customer Booking Page
            </h3>
            
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl max-w-md mx-auto transform rotate-y-[5deg] hover:rotate-y-0 transition-transform duration-500">
              <div className="text-center mb-8">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-xl mx-auto flex items-center justify-center font-bold text-xl mb-4">Y</div>
                <h4 className="text-xl font-bold text-slate-50">Make a Reservation</h4>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase">Service Type</label>
                  <div className="mt-1 flex items-center justify-between border border-slate-700 bg-slate-950 rounded-xl p-3 text-sm text-slate-50 cursor-pointer">
                    <span className="font-medium">Restaurant Table</span>
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase">Date</label>
                    <div className="mt-1 flex items-center gap-2 border border-slate-700 bg-slate-950 rounded-xl p-3 text-sm text-slate-50">
                      <Calendar className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">Oct 24, 2026</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase">Time</label>
                    <div className="mt-1 flex items-center gap-2 border border-slate-700 bg-slate-950 rounded-xl p-3 text-sm text-slate-50">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">19:30</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-400 uppercase">Guests</label>
                  <div className="mt-1 flex items-center justify-between border border-slate-700 bg-slate-950 rounded-xl p-3 text-sm text-slate-50">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-600" />
                      <span className="font-medium">4 Adults, 2 Children</span>
                    </div>
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  </div>
                </div>

                <div className="pt-4 mt-2 border-t border-slate-800">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <p className="font-bold text-slate-50">Deposit Required</p>
                      <p className="text-xs text-slate-400">Secure your reservation</p>
                    </div>
                    <p className="font-bold text-lg text-blue-600">$50.00</p>
                  </div>
                  <button className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl transition-colors shadow-md">
                    <CreditCard className="w-5 h-5" /> Confirm & Pay Deposit
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Internal Dashboard Preview */}
          <div className="relative">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6 flex items-center gap-2">
              <LayoutDashboard className="w-4 h-4" /> Internal Dashboard
            </h3>
            
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative">
              <div className="flex justify-between items-center mb-6 border-b border-slate-800 pb-4">
                <h4 className="font-bold text-white">Upcoming Bookings</h4>
                <div className="flex gap-2">
                  <span className="px-3 py-1 bg-slate-800 text-slate-300 rounded-md text-xs font-medium">Today</span>
                  <span className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-md text-xs font-medium">Tomorrow</span>
                </div>
              </div>

              <div className="space-y-4">
                {[
                  { name: "Smith Family", service: "Restaurant Table", details: "6 Guests • 19:30", status: "Confirmed", deposit: "$50 Paid", color: "bg-emerald-500/20 text-blue-600" },
                  { name: "Global Corp.", service: "Conference Hall", details: "150 Guests • All Day", status: "Pending Contract", deposit: "$2,000 Due", color: "bg-amber-500/20 text-blue-600" },
                  { name: "Johnson Party", service: "VIP Nightclub", details: "8 Guests • 23:00", status: "Confirmed", deposit: "$200 Paid", color: "bg-emerald-500/20 text-blue-600" },
                ].map((booking, i) => (
                  <div key={i} className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-800 transition-colors cursor-pointer">
                    <div>
                      <p className="font-bold text-white text-lg">{booking.name}</p>
                      <p className="text-sm text-blue-400 font-medium">{booking.service}</p>
                      <p className="text-xs text-slate-400 mt-1">{booking.details}</p>
                    </div>
                    <div className="flex flex-col sm:items-end gap-2">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${booking.color}`}>
                        {booking.status}
                      </span>
                      <span className="text-xs font-medium text-slate-300 bg-slate-800 px-2 py-1 rounded">
                        {booking.deposit}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
