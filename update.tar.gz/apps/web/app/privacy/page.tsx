import { Navigation } from "@/components/landing/navigation";
import { Footer } from "@/components/landing/footer";

export const metadata = {
  title: 'Privacy Policy | Yarvo OS',
  description: 'Privacy Policy for Yarvo Hospitality OS',
};

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-slate-50 font-sans selection:bg-blue-200 selection:text-blue-900">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-6 py-32 md:py-40">
        <div className="bg-white p-8 md:p-12 rounded-3xl border border-slate-200 shadow-sm">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">
            Privacy Policy
          </h1>
          <p className="text-slate-500 mb-12">Last Updated: July 2026</p>

          <div className="prose prose-slate max-w-none text-slate-700 space-y-8">
            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">1. Information We Collect</h2>
              <p>
                We collect information that you provide directly to us, including your name, email address, property details, and billing information when you register for an account. We also automatically collect certain technical data when you use the Service, such as IP addresses, browser types, and usage patterns.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">2. How We Use Your Information</h2>
              <p>
                We use the information we collect to operate, maintain, and improve Yarvo OS, process transactions, communicate with you about your account, and provide technical support. We do not sell your personal data to third parties.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">3. Data Security</h2>
              <p>
                We implement industry-standard security measures designed to protect your personal information and your guests' data from unauthorized access, disclosure, or alteration. However, no internet transmission is completely secure, and we cannot guarantee absolute security.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">4. Third-Party Services</h2>
              <p>
                Yarvo OS may integrate with third-party payment processors, accounting software, and booking channels. Information shared with these providers is governed by their respective privacy policies.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">5. Your Rights</h2>
              <p>
                Depending on your jurisdiction, you may have the right to access, correct, or delete your personal data. You can manage most account information directly within the dashboard or contact us for assistance.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">6. Contact Us</h2>
              <p>
                If you have any questions about this Privacy Policy or our data practices, please contact us at privacy@yarvohotel.com.
              </p>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  );
}
