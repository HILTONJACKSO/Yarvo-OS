"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, Filter } from 'lucide-react';
import { format, addDays, startOfWeek, addWeeks, subWeeks } from 'date-fns';
import { socket } from '@/lib/socket';

export default function ReservationCalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [rooms, setRooms] = useState<any[]>([]);
  const [reservations, setReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCalendarData = async () => {
      try {
        const [roomsRes, resRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/rooms`),
          fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/reservations`)
        ]);

        if (roomsRes.ok) {
          const roomsData = await roomsRes.json();
          setRooms(roomsData.map((r: any) => ({
            id: r.id,
            number: r.number,
            type: r.roomType?.name || 'Standard'
          })));
        }

        if (resRes.ok) {
          const resData = await resRes.json();
          const mappedReservations = resData.flatMap((r: any) => 
            (r.reservationRooms || []).map((rr: any) => ({
              id: r.id,
              roomId: rr.roomId,
              guestName: r.customer?.displayName || 'Unknown',
              status: r.status,
              startDate: r.arrivalDate,
              endDate: r.departureDate
            }))
          );
          setReservations(mappedReservations);
        }
      } catch (error) {
        console.error('Failed to fetch calendar data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCalendarData();

    const onUpdate = () => {
      fetchCalendarData();
    };

    socket.on('reservations.updated', onUpdate);
    socket.on('rooms.updated', onUpdate);

    return () => {
      socket.off('reservations.updated', onUpdate);
      socket.off('rooms.updated', onUpdate);
    };
  }, [currentDate]);

  const days = Array.from({ length: 7 }).map((_, i) => addDays(startOfWeek(currentDate), i));

  const getReservationStyle = (status: string) => {
    switch (status) {
      case 'CONFIRMED': return 'bg-blue-500/10 border-blue-300 text-blue-400';
      case 'GUARANTEED': return 'bg-emerald-500/10 border-green-300 text-emerald-400';
      case 'PENDING': return 'bg-amber-500/10 border-yellow-300 text-amber-400';
      case 'MAINTENANCE': return 'bg-gray-200 border-gray-400 text-slate-200';
      default: return 'bg-slate-950 border-slate-800 text-slate-400';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Reservation Calendar</h2>
          <p className="text-slate-400">Visual overview of room assignments and availability</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setCurrentDate(subWeeks(currentDate, 1))}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button variant="outline" onClick={() => setCurrentDate(new Date())}>
            <CalendarIcon className="w-4 h-4 mr-2" /> Today
          </Button>
          <Button variant="outline" onClick={() => setCurrentDate(addWeeks(currentDate, 1))}>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="border-b bg-slate-900 flex flex-row items-center justify-between py-3">
          <CardTitle className="text-lg font-medium flex items-center">
            {format(startOfWeek(currentDate), 'MMM d')} - {format(addDays(startOfWeek(currentDate), 6), 'MMM d, yyyy')}
          </CardTitle>
          <div className="flex items-center gap-4">
            <Select defaultValue="all">
              <SelectTrigger className="w-[180px] bg-slate-950"><Filter className="w-4 h-4 mr-2" /><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Room Types</SelectItem>
                <SelectItem value="deluxe">Deluxe Rooms</SelectItem>
                <SelectItem value="suite">Executive Suites</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <div className="min-w-[800px]">
            {/* Calendar Header Row */}
            <div className="flex border-b bg-slate-900">
              <div className="w-48 flex-shrink-0 p-4 font-semibold text-slate-300 border-r flex items-center justify-center">
                Room
              </div>
              <div className="flex-1 grid grid-cols-7 divide-x">
                {days.map((day, i) => (
                  <div key={i} className="p-3 text-center">
                    <p className="text-xs font-semibold text-slate-400 uppercase">{format(day, 'EEE')}</p>
                    <p className={`text-lg font-bold ${format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd') ? 'text-brand-primary' : 'text-slate-50'}`}>
                      {format(day, 'd')}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Calendar Body Rows */}
            {loading ? (
              <div className="p-8 text-center text-slate-400">Loading calendar data...</div>
            ) : (
              <div className="divide-y">
                {rooms.map(room => {
                  // Find reservations for this room that overlap with the current week
                  const roomReservations = reservations.filter(r => r.roomId === room.id);

                  return (
                    <div key={room.id} className="flex hover:bg-slate-900 transition-colors">
                      <div className="w-48 flex-shrink-0 p-4 border-r bg-slate-950 z-10 flex flex-col justify-center">
                        <p className="font-bold text-slate-50">Room {room.number}</p>
                        <p className="text-xs text-slate-400">{room.type}</p>
                      </div>
                      
                      <div className="flex-1 grid grid-cols-7 relative divide-x">
                        {/* Grid cells */}
                        {days.map((day, i) => (
                          <div key={i} className="h-20 p-1 border-slate-800" />
                        ))}

                        {/* Overlaid Reservations */}
                        {roomReservations.map(res => {
                          const resStart = new Date(res.startDate);
                          const resEnd = new Date(res.endDate);
                          const weekStart = startOfWeek(currentDate);
                          const weekEnd = addDays(weekStart, 7);

                          // Skip if outside this week entirely
                          if (resEnd <= weekStart || resStart >= weekEnd) return null;

                          // Calculate position and width
                          const startOffsetDays = Math.max(0, differenceInDays(resStart, weekStart));
                          const visibleDays = Math.min(
                            7 - startOffsetDays, 
                            differenceInDays(resEnd, new Date(Math.max(resStart.getTime(), weekStart.getTime())))
                          );

                          if (visibleDays <= 0) return null;

                          return (
                            <div 
                              key={res.id}
                              className={`absolute top-2 bottom-2 rounded-md border p-2 overflow-hidden cursor-pointer shadow-sm z-20 ${getReservationStyle(res.status)}`}
                              style={{
                                left: `calc(${(startOffsetDays / 7) * 100}% + 4px)`,
                                width: `calc(${(visibleDays / 7) * 100}% - 8px)`
                              }}
                              title={`${res.guestName} (${res.status})`}
                            >
                              <p className="text-xs font-bold truncate">{res.guestName}</p>
                              <p className="text-[10px] uppercase font-semibold opacity-70 truncate mt-0.5">{res.status}</p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Legend */}
      <div className="flex flex-wrap gap-4 pt-4 text-sm">
        <div className="flex items-center gap-2"><div className="w-4 h-4 rounded bg-blue-500/10 border border-blue-300"></div> Confirmed</div>
        <div className="flex items-center gap-2"><div className="w-4 h-4 rounded bg-emerald-500/10 border border-green-300"></div> Guaranteed</div>
        <div className="flex items-center gap-2"><div className="w-4 h-4 rounded bg-amber-500/10 border border-yellow-300"></div> Pending</div>
        <div className="flex items-center gap-2"><div className="w-4 h-4 rounded bg-gray-200 border border-gray-400"></div> Maintenance</div>
      </div>
    </div>
  );
}

// Add differenceInDays from date-fns if not already imported
function differenceInDays(dateLeft: Date | number, dateRight: Date | number): number {
  const diff = new Date(dateLeft).getTime() - new Date(dateRight).getTime();
  return Math.round(diff / (1000 * 60 * 60 * 24));
}
