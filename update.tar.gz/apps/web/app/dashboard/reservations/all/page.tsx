"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, CalendarCheck } from 'lucide-react';
import { format } from 'date-fns';
import { socket } from '@/lib/socket';

export default function AllReservationsPage() {
  const router = useRouter();
  const [reservations, setReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchReservations = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/reservations`);
        if (response.ok) {
          const data = await response.json();
          setReservations(data);
        }
      } catch (error) {
        console.error('Failed to fetch reservations:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchReservations();

    const onUpdate = () => {
      fetchReservations();
    };

    socket.on('reservations.updated', onUpdate);

    return () => {
      socket.off('reservations.updated', onUpdate);
    };
  }, []);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'CONFIRMED': return <Badge className="bg-blue-500">Confirmed</Badge>;
      case 'GUARANTEED': return <Badge className="bg-green-500">Guaranteed</Badge>;
      case 'PENDING': return <Badge className="bg-yellow-500 text-black">Pending</Badge>;
      case 'CANCELLED': return <Badge variant="destructive">Cancelled</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  const filtered = reservations.filter(r => 
    r.reservationNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (r.customer?.displayName || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-200">All Reservations</h2>
          <p className="text-slate-400">View and search all system bookings</p>
        </div>
        <Button onClick={() => router.push('/dashboard/reservations/new')} className="bg-brand-primary text-white hover:bg-brand-secondary">
          <CalendarCheck className="w-4 h-4 mr-2" /> New Reservation
        </Button>
      </div>

      <Card>
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search by reservation number or guest name..." 
                className="pl-10"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline"><Filter className="w-4 h-4 mr-2" /> Filters</Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-900 text-slate-400 border-b">
                <tr>
                  <th className="px-4 py-3 font-medium">Reservation</th>
                  <th className="px-4 py-3 font-medium">Guest</th>
                  <th className="px-4 py-3 font-medium">Arrival</th>
                  <th className="px-4 py-3 font-medium">Departure</th>
                  <th className="px-4 py-3 font-medium">Room Type</th>
                  <th className="px-4 py-3 font-medium text-right">Total</th>
                  <th className="px-4 py-3 font-medium text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400">Loading reservations...</td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400">No reservations found matching your criteria.</td>
                  </tr>
                ) : (
                  filtered.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-900 cursor-pointer" onClick={() => router.push(`/dashboard/reservations/${r.id}`)}>
                      <td className="px-4 py-3 font-medium text-brand-primary">{r.reservationNumber}</td>
                      <td className="px-4 py-3 font-medium text-slate-50">{r.customer?.displayName || 'Unknown Guest'}</td>
                      <td className="px-4 py-3">{format(new Date(r.arrivalDate), 'MMM d, yyyy')}</td>
                      <td className="px-4 py-3">{format(new Date(r.departureDate), 'MMM d, yyyy')}</td>
                      <td className="px-4 py-3 text-slate-400">{r.reservationRooms?.[0]?.roomType?.name || 'Unassigned'}</td>
                      <td className="px-4 py-3 text-right font-medium">${(r.expectedBalance || 0).toFixed(2)}</td>
                      <td className="px-4 py-3 text-center">{getStatusBadge(r.status)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
