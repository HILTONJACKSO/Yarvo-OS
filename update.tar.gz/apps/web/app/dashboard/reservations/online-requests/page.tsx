"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Globe, CheckCircle2, XCircle } from 'lucide-react';
import { format } from 'date-fns';
import { socket } from '@/lib/socket';

export default function OnlineRequestsPage() {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/online-booking-requests`);
        if (response.ok) {
          const data = await response.json();
          setRequests(data);
        }
      } catch (error) {
        console.error('Failed to fetch online booking requests:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRequests();

    const onUpdate = () => {
      fetchRequests();
    };

    socket.on('online_booking_requests.updated', onUpdate);

    return () => {
      socket.off('online_booking_requests.updated', onUpdate);
    };
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Online Booking Requests</h2>
          <p className="text-slate-400">Review and approve reservations coming from the website</p>
        </div>
      </div>

      <Card>
        <CardHeader className="border-b bg-slate-900 pb-4">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            <Globe className="w-5 h-5 text-brand-primary" /> Pending Requests
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-950 text-slate-400 border-b">
                <tr>
                  <th className="px-4 py-3 font-medium">Guest</th>
                  <th className="px-4 py-3 font-medium">Requested Dates</th>
                  <th className="px-4 py-3 font-medium">Room Type</th>
                  <th className="px-4 py-3 font-medium">Submitted</th>
                  <th className="px-4 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {loading ? (
                  <tr><td colSpan={6} className="text-center py-8 text-slate-400">Loading requests...</td></tr>
                ) : requests.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-8 text-slate-400">No pending online requests.</td></tr>
                ) : (
                  requests.map(r => (
                    <tr key={r.id} className="hover:bg-slate-900">
                      <td className="px-4 py-4">
                        <p className="font-medium text-slate-50">{r.customerName}</p>
                        <p className="text-sm text-slate-400">{r.email}</p>
                      </td>
                      <td className="px-4 py-4">
                        <p className="font-medium text-slate-300">{format(new Date(r.arrivalDate), 'MMM d')} - {format(new Date(r.departureDate), 'MMM d, yyyy')}</p>
                        <p className="text-sm text-slate-400">{r.roomType?.name || 'Deluxe Room'}</p>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className="bg-blue-50 text-blue-700 hover:bg-blue-50 border-blue-200">{r.source || 'Website'}</Badge>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-100 border-none">{r.status}</Badge>
                      </td>
                      <td className="px-4 py-4 text-sm text-slate-400">
                        {format(new Date(r.createdAt), 'MMM d, p')}
                      </td>
                      <td className="px-4 py-4 text-right">
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="outline" className="text-green-600 border-green-200 hover:bg-green-50">
                            <CheckCircle2 className="w-4 h-4 mr-1" /> Approve
                          </Button>
                          <Button size="sm" variant="ghost" className="text-gray-400 hover:text-red-600">
                            <XCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
