"use client";

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowLeft, ArrowRight, Save, CheckCircle2, BedDouble, Users, CreditCard, Building, UserPlus, Search as SearchIcon } from 'lucide-react';
import { differenceInDays, format } from 'date-fns';
import { toast } from 'sonner';

export default function NewReservationPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [reservationNumber, setReservationNumber] = useState('');

  // Step 1: Stay Details
  const [stay, setStay] = useState({
    branchId: 'main',
    arrivalDate: searchParams.get('arrivalDate') || '',
    expectedArrivalTime: '',
    departureDate: searchParams.get('departureDate') || '',
    adults: parseInt(searchParams.get('adults') || '2'),
    children: parseInt(searchParams.get('children') || '0'),
    numberOfRooms: parseInt(searchParams.get('numberOfRooms') || '1'),
    source: 'FRONT_DESK',
    specialOccasion: ''
  });

  // Step 2: Room Selection
  const [roomSelection, setRoomSelection] = useState({
    assignmentType: 'ROOM_TYPE_ASSIGNED', // ROOM_TYPE_ASSIGNED or SPECIFIC_ROOM_ASSIGNED
    roomTypeId: searchParams.get('roomTypeId') || '',
    roomId: ''
  });

  // Step 3: Guest Selection
  const [guestSelection, setGuestSelection] = useState({
    guestType: 'EXISTING', // EXISTING, NEW, CORPORATE, GROUP, WALK_IN
    customerId: '',
    corporateAccountId: '',
    groupId: '',
    // Quick Walk-In fields
    firstName: '',
    lastName: '',
    phone: '',
    email: ''
  });

  // Step 4: Price & Charges
  const [pricing, setPricing] = useState({
    basePrice: 90,
    discountType: 'NONE', // NONE, FLAT, PERCENTAGE
    discountValue: 0,
    taxAmount: 45,
    depositRequiredPercent: 50,
  });

  // Step 5: Guarantee
  const [guarantee, setGuarantee] = useState({
    type: 'DEPOSIT_RECORDED', // NO_GUARANTEE, DEPOSIT_RECORDED, CORPORATE, MANAGEMENT, PAY_ON_ARRIVAL
    depositMethod: 'CARD', // CASH, MOBILE_MONEY, CARD, BANK_TRANSFER
    depositAmount: 0,
    referenceNumber: ''
  });

  // Derived Pricing
  const nights = stay.arrivalDate && stay.departureDate ? Math.max(1, differenceInDays(new Date(stay.departureDate), new Date(stay.arrivalDate))) : 1;
  const subtotal = pricing.basePrice * nights * stay.numberOfRooms;
  
  let discountAmount = 0;
  if (pricing.discountType === 'FLAT') discountAmount = pricing.discountValue;
  else if (pricing.discountType === 'PERCENTAGE') discountAmount = subtotal * (pricing.discountValue / 100);
  
  const estimatedTax = pricing.taxAmount || 0;
  const estimatedTotal = subtotal - discountAmount + estimatedTax;
  const recommendedDeposit = estimatedTotal * (pricing.depositRequiredPercent / 100);
  const expectedBalance = estimatedTotal - guarantee.depositAmount;

  useEffect(() => {
    // If a deposit is required, pre-fill the guarantee deposit amount
    if (guarantee.depositAmount === 0 && recommendedDeposit > 0) {
      setGuarantee(g => ({ ...g, depositAmount: recommendedDeposit }));
    }
  }, [recommendedDeposit]);

  const handleNext = () => setStep(s => Math.min(6, s + 1));
  const handleBack = () => setStep(s => Math.max(1, s - 1));

  const submitReservation = async (status: string) => {
    setLoading(true);
    try {
      const payload = {
        guest: guestSelection,
        stay,
        pricing,
        guarantee,
        status
      };

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/reservations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error('Failed to create reservation');

      const data = await res.json();
      setReservationNumber(data.reservationNumber);
      setStep(7); // Success Screen
    } catch (err) {
      console.error(err);
      toast.error('Failed to save reservation. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const steps = [
    { num: 1, title: 'Stay Details' },
    { num: 2, title: 'Room' },
    { num: 3, title: 'Guest' },
    { num: 4, title: 'Price' },
    { num: 5, title: 'Guarantee' },
    { num: 6, title: 'Confirm' }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      <div>
        <h2 className="text-2xl font-bold text-slate-200">New Reservation</h2>
        <p className="text-slate-400">Create a new booking and secure inventory.</p>
      </div>

      {/* Progress Bar */}
      {step < 7 && (
        <div className="flex items-center justify-between px-2 mb-8 relative">
          <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -translate-y-1/2 z-0 rounded-full" />
          <div 
            className="absolute top-1/2 left-0 h-1 bg-brand-primary -translate-y-1/2 z-0 rounded-full transition-all duration-300" 
            style={{ width: `${((step - 1) / 5) * 100}%` }}
          />
          {steps.map((s) => (
            <div key={s.num} className="relative z-10 flex flex-col items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-colors border-2
                ${step > s.num ? 'bg-brand-primary border-brand-primary text-white' : 
                  step === s.num ? 'bg-slate-950 border-brand-primary text-brand-primary' : 
                  'bg-slate-950 border-slate-700 text-gray-400'}`}>
                {step > s.num ? <CheckCircle2 className="w-5 h-5" /> : s.num}
              </div>
              <span className={`text-xs font-medium absolute -bottom-6 w-24 text-center ${step >= s.num ? 'text-slate-50' : 'text-gray-400'}`}>
                {s.title}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Step 1: Stay Details */}
      {step === 1 && (
        <Card className="mt-8 shadow-sm">
          <CardHeader>
            <CardTitle>Stay Details</CardTitle>
            <CardDescription>Enter the basic requirements for this reservation.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Arrival Date *</Label>
                <Input type="date" value={stay.arrivalDate} onChange={e => setStay({...stay, arrivalDate: e.target.value})} required />
              </div>
              <div className="space-y-2">
                <Label>Departure Date *</Label>
                <Input type="date" value={stay.departureDate} onChange={e => setStay({...stay, departureDate: e.target.value})} required />
              </div>
              <div className="space-y-2">
                <Label>Expected Arrival Time</Label>
                <Input type="time" value={stay.expectedArrivalTime} onChange={e => setStay({...stay, expectedArrivalTime: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Number of Rooms *</Label>
                <Input type="number" min="1" value={Number.isNaN(stay.numberOfRooms) ? '' : stay.numberOfRooms} onChange={e => setStay({...stay, numberOfRooms: parseInt(e.target.value)})} required />
              </div>
              <div className="space-y-2">
                <Label>Adults *</Label>
                <Input type="number" min="1" value={Number.isNaN(stay.adults) ? '' : stay.adults} onChange={e => setStay({...stay, adults: parseInt(e.target.value)})} required />
              </div>
              <div className="space-y-2">
                <Label>Children</Label>
                <Input type="number" min="0" value={Number.isNaN(stay.children) ? '' : stay.children} onChange={e => setStay({...stay, children: parseInt(e.target.value)})} />
              </div>
              <div className="space-y-2">
                <Label>Reservation Source *</Label>
                <Select value={stay.source} onValueChange={v => setStay({...stay, source: v || ''})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="FRONT_DESK">Front Desk</SelectItem>
                    <SelectItem value="PHONE">Phone</SelectItem>
                    <SelectItem value="WHATSAPP">WhatsApp</SelectItem>
                    <SelectItem value="WEBSITE">Website</SelectItem>
                    <SelectItem value="WALK_IN">Walk-In</SelectItem>
                    <SelectItem value="EMAIL">Email</SelectItem>
                    <SelectItem value="TRAVEL_AGENT">Travel Agent</SelectItem>
                    <SelectItem value="CORPORATE">Corporate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Special Occasion</Label>
                <Select value={stay.specialOccasion} onValueChange={v => setStay({...stay, specialOccasion: v || ''})}>
                  <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="birthday">Birthday</SelectItem>
                    <SelectItem value="anniversary">Anniversary</SelectItem>
                    <SelectItem value="honeymoon">Honeymoon</SelectItem>
                    <SelectItem value="business">Business Trip</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Room Selection */}
      {step === 2 && (
        <Card className="mt-8 shadow-sm">
          <CardHeader>
            <CardTitle>Select Room</CardTitle>
            <CardDescription>Assign a room type now, and allocate a specific room later, or assign a specific room immediately.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <RadioGroup value={roomSelection.assignmentType} onValueChange={v => setRoomSelection({...roomSelection, assignmentType: v || ''})} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <RadioGroupItem value="ROOM_TYPE_ASSIGNED" id="type_assigned" className="peer sr-only" />
                <Label
                  htmlFor="type_assigned"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-brand-primary peer-data-[state=checked]:bg-brand-primary/5 cursor-pointer"
                >
                  <BedDouble className="mb-3 h-6 w-6" />
                  Reserve Room Type
                  <span className="text-xs font-normal text-slate-400 mt-2 text-center">Assign a specific room number later at check-in.</span>
                </Label>
              </div>
              <div>
                <RadioGroupItem value="SPECIFIC_ROOM_ASSIGNED" id="specific_assigned" className="peer sr-only" />
                <Label
                  htmlFor="specific_assigned"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-brand-primary peer-data-[state=checked]:bg-brand-primary/5 cursor-pointer"
                >
                  <Building className="mb-3 h-6 w-6" />
                  Assign Specific Room
                  <span className="text-xs font-normal text-slate-400 mt-2 text-center">Lock a physical room immediately.</span>
                </Label>
              </div>
            </RadioGroup>

            <div className="space-y-4 p-4 border rounded-lg bg-slate-900">
              <div className="space-y-2">
                <Label>Select Room Type</Label>
                <Select value={roomSelection.roomTypeId} onValueChange={v => setRoomSelection({...roomSelection, roomTypeId: v || ''})}>
                  <SelectTrigger className="bg-slate-950"><SelectValue placeholder="Choose a room type..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rt-1">Deluxe Room (5 Available)</SelectItem>
                    <SelectItem value="rt-2">Executive Suite (2 Available)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {roomSelection.assignmentType === 'SPECIFIC_ROOM_ASSIGNED' && (
                <div className="space-y-2 pt-4 border-t">
                  <Label>Available Specific Rooms</Label>
                  <Select value={roomSelection.roomId} onValueChange={v => setRoomSelection({...roomSelection, roomId: v || ''})}>
                    <SelectTrigger className="bg-slate-950"><SelectValue placeholder="Choose a physical room..." /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="r-101">Room 101 - Floor 1</SelectItem>
                      <SelectItem value="r-102">Room 102 - Floor 1</SelectItem>
                      <SelectItem value="r-205">Room 205 - Floor 2</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Guest Selection */}
      {step === 3 && (
        <Card className="mt-8 shadow-sm">
          <CardHeader>
            <CardTitle>Select Guest</CardTitle>
            <CardDescription>Who is responsible for this reservation?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Select value={guestSelection.guestType} onValueChange={v => setGuestSelection({...guestSelection, guestType: v || ''})}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="EXISTING">Search Existing Customer</SelectItem>
                <SelectItem value="WALK_IN">Quick Guest Registration</SelectItem>
                <SelectItem value="CORPORATE">Corporate Account</SelectItem>
                <SelectItem value="GROUP">Group / Family</SelectItem>
              </SelectContent>
            </Select>

            {guestSelection.guestType === 'EXISTING' && (
              <div className="space-y-4 p-4 border rounded-lg bg-slate-900">
                <div className="flex gap-2">
                  <Input placeholder="Search by name, phone, or email..." className="bg-slate-950" />
                  <Button variant="outline"><SearchIcon className="w-4 h-4" /></Button>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs font-semibold text-slate-400 uppercase">Recent Results</Label>
                  <div className="p-3 bg-slate-950 border rounded flex justify-between items-center cursor-pointer hover:border-brand-primary">
                    <div>
                      <p className="font-medium text-slate-50">Sarah Johnson</p>
                      <p className="text-xs text-slate-400">+1 555-0198 â€¢ VIP Member</p>
                    </div>
                    <Button size="sm" variant="outline">Select</Button>
                  </div>
                </div>
              </div>
            )}

            {guestSelection.guestType === 'WALK_IN' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 border rounded-lg bg-slate-900">
                <div className="space-y-2">
                  <Label>First Name *</Label>
                  <Input className="bg-slate-950" value={guestSelection.firstName} onChange={e => setGuestSelection({...guestSelection, firstName: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Last Name *</Label>
                  <Input className="bg-slate-950" value={guestSelection.lastName} onChange={e => setGuestSelection({...guestSelection, lastName: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Phone Number *</Label>
                  <Input className="bg-slate-950" value={guestSelection.phone} onChange={e => setGuestSelection({...guestSelection, phone: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Email (Optional)</Label>
                  <Input className="bg-slate-950" type="email" value={guestSelection.email} onChange={e => setGuestSelection({...guestSelection, email: e.target.value})} />
                </div>
              </div>
            )}
            
            {guestSelection.guestType === 'CORPORATE' && (
              <div className="space-y-4 p-4 border rounded-lg bg-slate-900">
                <div className="flex gap-2">
                  <Input placeholder="Search corporate accounts..." className="bg-slate-950" />
                  <Button variant="outline"><SearchIcon className="w-4 h-4" /></Button>
                </div>
                <div className="p-3 bg-slate-950 border rounded flex justify-between items-center cursor-pointer hover:border-brand-primary">
                  <div>
                    <p className="font-medium text-slate-50">ABC Mining Ltd.</p>
                    <p className="text-xs text-slate-400">CORP-0042 â€¢ Approved for Invoicing</p>
                  </div>
                  <Button size="sm" variant="outline">Select</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 4: Price & Charges */}
      {step === 4 && (
        <Card className="mt-8 shadow-sm overflow-hidden">
          <CardHeader className="bg-slate-900 border-b">
            <CardTitle>Price and Charges</CardTitle>
            <CardDescription>Review the estimated accommodation charges.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-6 space-y-6 border-r">
                <div className="space-y-2">
                  <Label>Base Room Price (Per Night)</Label>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">$</span>
                    <Input type="number" value={Number.isNaN(pricing.basePrice) ? '' : pricing.basePrice} onChange={e => setPricing({...pricing, basePrice: parseFloat(e.target.value)})} />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Discount</Label>
                  <div className="flex gap-2">
                    <Select value={pricing.discountType} onValueChange={v => setPricing({...pricing, discountType: v || ''})}>
                      <SelectTrigger className="w-[140px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="NONE">No Discount</SelectItem>
                        <SelectItem value="FLAT">Flat Amount ($)</SelectItem>
                        <SelectItem value="PERCENTAGE">Percentage (%)</SelectItem>
                      </SelectContent>
                    </Select>
                    {pricing.discountType !== 'NONE' && (
                      <Input type="number" className="flex-1" value={Number.isNaN(pricing.discountValue) ? '' : pricing.discountValue} onChange={e => setPricing({...pricing, discountValue: parseFloat(e.target.value)})} />
                    )}
                  </div>
                </div>
                
                <div className="space-y-2 mt-6">
                  <Label>Estimated Taxes ($)</Label>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400">$</span>
                    <Input type="number" value={Number.isNaN(pricing.taxAmount) ? '' : pricing.taxAmount} onChange={e => setPricing({...pricing, taxAmount: parseFloat(e.target.value)})} />
                  </div>
                </div>
              </div>

              <div className="p-6 bg-slate-900 space-y-4 text-sm">
                <h4 className="font-semibold text-slate-50 uppercase tracking-wide border-b pb-2">Calculation Summary</h4>
                
                <div className="flex justify-between text-slate-400">
                  <span>Room Rate</span>
                  <span>${pricing.basePrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Quantity</span>
                  <span>{stay.numberOfRooms} Room{stay.numberOfRooms > 1 ? 's' : ''} Ã— {nights} Night{nights > 1 ? 's' : ''}</span>
                </div>
                <div className="flex justify-between text-slate-50 font-medium">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                
                {discountAmount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount</span>
                    <span>-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                
                <div className="flex justify-between text-slate-400">
                  <span>Estimated Taxes</span>
                  <span>${estimatedTax.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between text-lg font-bold text-slate-50 border-t pt-3 mt-3">
                  <span>Estimated Total</span>
                  <span>${estimatedTotal.toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between text-orange-600 font-medium pt-1">
                  <span>Deposit Required ({pricing.depositRequiredPercent}%)</span>
                  <span>${recommendedDeposit.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 5: Guarantee */}
      {step === 5 && (
        <Card className="mt-8 shadow-sm">
          <CardHeader>
            <CardTitle>Reservation Guarantee</CardTitle>
            <CardDescription>How is this reservation being secured?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Select value={guarantee.type} onValueChange={v => setGuarantee({...guarantee, type: v || ''})}>
              <SelectTrigger className="w-full text-lg h-12"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="NO_GUARANTEE">No Guarantee (Expires Automatically)</SelectItem>
                <SelectItem value="DEPOSIT_RECORDED">Deposit Recorded</SelectItem>
                <SelectItem value="CORPORATE">Corporate Account Guarantee</SelectItem>
                <SelectItem value="MANAGEMENT">Management Override</SelectItem>
                <SelectItem value="PAY_ON_ARRIVAL">Pay on Arrival (Hold until 6 PM)</SelectItem>
              </SelectContent>
            </Select>

            {guarantee.type === 'DEPOSIT_RECORDED' && (
              <div className="p-5 border rounded-lg bg-blue-50/50 space-y-4">
                <h4 className="font-semibold text-blue-900 flex items-center gap-2"><CreditCard className="w-5 h-5" /> Record Deposit Payment</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Amount Paid *</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-400">$</span>
                      <Input type="number" value={Number.isNaN(guarantee.depositAmount) ? '' : guarantee.depositAmount} onChange={e => setGuarantee({...guarantee, depositAmount: parseFloat(e.target.value)})} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Payment Method *</Label>
                    <Select value={guarantee.depositMethod} onValueChange={v => setGuarantee({...guarantee, depositMethod: v || ''})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CASH">Cash</SelectItem>
                        <SelectItem value="CARD">Credit/Debit Card</SelectItem>
                        <SelectItem value="MOBILE_MONEY">Mobile Money</SelectItem>
                        <SelectItem value="BANK_TRANSFER">Bank Transfer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>Reference Number (Tx ID)</Label>
                    <Input value={guarantee.referenceNumber} onChange={e => setGuarantee({...guarantee, referenceNumber: e.target.value})} placeholder="e.g. TX-19381928" />
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 6: Review & Confirm */}
      {step === 6 && (
        <Card className="mt-8 shadow-sm">
          <CardHeader>
            <CardTitle>Review & Confirm</CardTitle>
            <CardDescription>Verify the reservation details before submitting.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Guest</h4>
                <p className="font-medium text-slate-50">{guestSelection.guestType === 'WALK_IN' ? `${guestSelection.firstName} ${guestSelection.lastName}` : 'Selected Guest'}</p>
                <p className="text-sm text-slate-400">{guestSelection.guestType === 'WALK_IN' ? guestSelection.phone : 'Existing Profile'}</p>
              </div>
              
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Stay</h4>
                <p className="font-medium text-slate-50">{format(new Date(stay.arrivalDate || new Date()), 'MMM d, yyyy')} â€” {format(new Date(stay.departureDate || new Date()), 'MMM d, yyyy')}</p>
                <p className="text-sm text-slate-400">{nights} Nights â€¢ {stay.numberOfRooms} Room(s) â€¢ {stay.adults} Adults</p>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Room Details</h4>
                <p className="font-medium text-slate-50">Deluxe Room</p>
                <p className="text-sm text-slate-400">{roomSelection.assignmentType === 'SPECIFIC_ROOM_ASSIGNED' ? `Assigned to Room ${roomSelection.roomId}` : 'No specific room assigned yet'}</p>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase mb-2">Financial Summary</h4>
                <p className="font-medium text-slate-50">Total: ${estimatedTotal.toFixed(2)}</p>
                <p className="text-sm text-green-600">Deposit Recorded: ${guarantee.type === 'DEPOSIT_RECORDED' ? guarantee.depositAmount.toFixed(2) : '0.00'}</p>
                <p className="text-sm font-semibold text-orange-600 mt-1">Expected Balance: ${expectedBalance.toFixed(2)}</p>
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t">
              <Label>Internal Notes</Label>
              <Textarea placeholder="Any internal notes for staff..." />
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t justify-end">
              <Button variant="outline" onClick={() => submitReservation('DRAFT')} disabled={loading}><Save className="w-4 h-4 mr-2" /> Save as Draft</Button>
              <Button variant="secondary" onClick={() => submitReservation('PENDING')} disabled={loading}>Create Pending</Button>
              <Button onClick={() => submitReservation('CONFIRMED')} disabled={loading} className="bg-brand-primary text-white hover:bg-brand-secondary">
                {loading ? 'Processing...' : 'Confirm Reservation'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 7: Success Screen */}
      {step === 7 && (
        <Card className="mt-8 border-green-500/50 bg-slate-900/80 text-center py-12 shadow-lg shadow-green-900/20">
          <CardContent className="space-y-6">
            <div className="mx-auto w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center text-green-400">
              <CheckCircle2 size={32} />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-50">Reservation Confirmed!</h2>
              <p className="text-slate-400 mt-2">The inventory has been locked and the booking is saved.</p>
            </div>
            <div className="p-4 bg-slate-950 inline-block rounded-xl border shadow-sm">
              <p className="text-xs text-slate-400 uppercase font-semibold mb-1">Reservation Number</p>
              <p className="text-2xl font-mono font-bold text-brand-primary">{reservationNumber}</p>
            </div>
            <div className="flex justify-center gap-4 pt-4">
              <Button variant="outline" onClick={() => router.push('/dashboard/reservations')}>Return to Dashboard</Button>
              <Button className="bg-brand-primary text-white" onClick={() => router.push(`/dashboard/reservations/${reservationNumber}`)}>View Details</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigation Buttons */}
      {step < 6 && (
        <div className="flex justify-between items-center mt-8">
          <Button variant="ghost" onClick={handleBack} disabled={step === 1}>
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>
          <Button onClick={handleNext} className="bg-brand-primary text-white hover:bg-brand-secondary">
            Next Step <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      )}
    </div>
  );
}
