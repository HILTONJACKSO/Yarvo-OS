"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar, Search, Users, BedDouble, CheckCircle2 } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';
import { socket } from '@/lib/socket';

export default function SearchAvailabilityPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any[] | null>(null);

  const [search, setSearch] = useState({
    branchId: 'default',
    arrivalDate: '',
    departureDate: '',
    adults: 2,
    children: 0,
    numberOfRooms: 1,
    roomTypeId: 'all',
    accessible: false,
    amenities: ''
  });

  const performSearch = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        arrivalDate: search.arrivalDate,
        departureDate: search.departureDate,
        numberOfRooms: search.numberOfRooms.toString(),
        adults: search.adults.toString(),
        children: search.children.toString()
      });
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/availability/search?${params.toString()}`);
      if (response.ok) {
        const data = await response.json();
        setResults(data);
      }
    } catch (error) {
      console.error('Failed to search rooms:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch();
  };

  useEffect(() => {
    const onUpdate = () => {
      if (results) {
        performSearch();
      }
    };
    socket.on('reservations.updated', onUpdate);
    socket.on('rooms.updated', onUpdate);
    return () => {
      socket.off('reservations.updated', onUpdate);
      socket.off('rooms.updated', onUpdate);
    };
  }, [results, search]);

  const handleSelectRoom = (roomTypeId: string) => {
    const params = new URLSearchParams({
      roomTypeId,
      arrivalDate: search.arrivalDate,
      departureDate: search.departureDate,
      adults: search.adults.toString(),
      children: search.children.toString(),
      numberOfRooms: search.numberOfRooms.toString()
    });
    router.push(`/dashboard/reservations/new?${params.toString()}`);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-200">Search Availability</h2>
        <p className="text-slate-400">Find available rooms across the property</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSearch} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Arrival Date</Label>
                <div className="relative">
                  <Input 
                    type="date" 
                    required 
                    value={search.arrivalDate} 
                    onChange={e => setSearch({...search, arrivalDate: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Departure Date</Label>
                <div className="relative">
                  <Input 
                    type="date" 
                    required 
                    value={search.departureDate} 
                    onChange={e => setSearch({...search, departureDate: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Adults</Label>
                <Input 
                  type="number" 
                  min="1" 
                  required 
                  value={search.adults} 
                  onChange={e => setSearch({...search, adults: parseInt(e.target.value)})}
                />
              </div>
              <div className="space-y-2">
                <Label>Children</Label>
                <Input 
                  type="number" 
                  min="0" 
                  value={search.children} 
                  onChange={e => setSearch({...search, children: parseInt(e.target.value)})}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Number of Rooms</Label>
                <Input 
                  type="number" 
                  min="1" 
                  required 
                  value={search.numberOfRooms} 
                  onChange={e => setSearch({...search, numberOfRooms: parseInt(e.target.value)})}
                />
              </div>
              <div className="space-y-2">
                <Label>Room Type (Optional)</Label>
                <Select value={search.roomTypeId} onValueChange={v => setSearch({...search, roomTypeId: v || ''})}>
                  <SelectTrigger><SelectValue placeholder="Any Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Any Type</SelectItem>
                    <SelectItem value="rt-1">Deluxe Room</SelectItem>
                    <SelectItem value="rt-2">Executive Suite</SelectItem>
                    <SelectItem value="rt-3">Standard Room</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Preferred Amenities</Label>
                <Input 
                  placeholder="e.g. Balcony, Ocean View" 
                  value={search.amenities}
                  onChange={e => setSearch({...search, amenities: e.target.value})}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox 
                id="accessible" 
                checked={search.accessible} 
                onCheckedChange={(c) => setSearch({...search, accessible: c as boolean})} 
              />
              <label htmlFor="accessible" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                Accessible Room Required
              </label>
            </div>

            <div className="flex justify-end pt-4 border-t">
              <Button type="submit" disabled={loading} className="bg-brand-primary hover:bg-brand-secondary text-white min-w-[150px]">
                {loading ? 'Searching...' : <><Search className="w-4 h-4 mr-2" /> Search Rooms</>}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {results && (
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-slate-200">Available Rooms</h3>
          {results.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-slate-400">
                No rooms available for the selected dates and criteria.
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {results.map(room => (
                <Card key={room.id} className="overflow-hidden hover:border-brand-primary transition">
                  <div className="flex flex-col md:flex-row">
                    <div className="w-full md:w-64 h-48 bg-gray-200 flex items-center justify-center text-gray-400 border-r md:border-r-gray-100">
                      <BedDouble size={48} />
                    </div>
                    <div className="flex-1 p-6 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="text-lg font-bold text-slate-50">{room.name}</h4>
                            <p className="text-sm text-green-600 font-medium flex items-center mt-1">
                              <CheckCircle2 className="w-4 h-4 mr-1" /> {room.available} Available
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-slate-50">${room.basePrice}</p>
                            <p className="text-xs text-slate-400 uppercase font-semibold">Per Night</p>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-x-6 gap-y-2 mb-4 text-sm text-slate-400">
                          <span className="flex items-center"><Users className="w-4 h-4 mr-1.5 text-gray-400" /> Up to {room.maxAdults} adults, {room.maxChildren} children</span>
                          <span className="flex items-center"><BedDouble className="w-4 h-4 mr-1.5 text-gray-400" /> {room.bedType}</span>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-6">
                          {room.amenities.map((amenity: string, i: number) => (
                            <span key={i} className="px-2 py-1 bg-slate-800 text-slate-400 text-xs rounded-md">{amenity}</span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t">
                        <div>
                          <p className="text-sm text-slate-400 font-medium">{room.nights} Night{room.nights > 1 ? 's' : ''} â€¢ {search.numberOfRooms} Room{search.numberOfRooms > 1 ? 's' : ''}</p>
                          <p className="text-lg font-bold text-brand-primary">Total: ${room.estimatedTotal} <span className="text-xs text-slate-400 font-normal">excludes taxes</span></p>
                        </div>
                        <Button onClick={() => handleSelectRoom(room.id)} className="bg-brand-primary text-white hover:bg-brand-secondary">
                          Select Room
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
