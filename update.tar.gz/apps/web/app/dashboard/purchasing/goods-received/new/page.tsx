"use client";

import { useState } from 'react';
import { Save, Send, Trash2, Calendar, FileText, PackageCheck } from 'lucide-react';
import Link from 'next/link';

export default function NewGoodsReceivedPage() {
  const [items, setItems] = useState<any[]>([]);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Goods Received Note (GRN)</h1>
          <p className="text-slate-400 mt-1">Receive physical stock from a supplier and update inventory levels.</p>
        </div>
        <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-brand-primary hover:bg-slate-900 transition flex items-center gap-2">
          <FileText size={18} /> Load from Purchase Order
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Supplier <span className="text-red-500">*</span></label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option>ABC Distributors</option>
                <option>Fresh Farms Co.</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Receipt Date <span className="text-red-500">*</span></label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <input type="date" className="w-full pl-9 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Receiving Location <span className="text-red-500">*</span></label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option>Main Store</option>
                <option>Kitchen Store</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Supplier Delivery Note / Invoice Ref</label>
              <input type="text" placeholder="e.g., INV-88902" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
            </div>
          </div>
        </div>

        <div className="border-t">
          <div className="p-4 bg-slate-900 border-b flex justify-between items-center">
            <h3 className="font-bold text-slate-50 flex items-center gap-2"><PackageCheck size={18}/> Items Received</h3>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Item</th>
                <th className="p-4 font-semibold text-center">Ordered</th>
                <th className="p-4 font-semibold text-center">Prev. Rcvd</th>
                <th className="p-4 font-semibold text-center w-32 text-brand-primary">Receive Now</th>
                <th className="p-4 font-semibold">Unit</th>
                <th className="p-4 font-semibold text-right">Unit Cost</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {items.map((item) => (
                <tr key={item.id} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4 text-center text-slate-400">{item.ordered}</td>
                  <td className="p-4 text-center text-slate-400">{item.previouslyReceived}</td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      defaultValue={item.receivedNow} 
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 border-brand-primary text-center font-bold"
                    />
                  </td>
                  <td className="p-4 text-slate-400">{item.unit}</td>
                  <td className="p-4 text-right text-slate-400">${item.unitCost.toFixed(2)}</td>
                  <td className="p-4 text-right">
                    <button className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={18}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between items-center">
          <button className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</button>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-slate-400 mr-4">
              <input type="checkbox" defaultChecked className="w-4 h-4 text-brand-primary rounded" />
              <span>Update inventory costs based on this receipt (Moving Average)</span>
            </div>
            
            <div className="flex gap-2">
              <button className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2">
                <Save size={18} /> Save Draft
              </button>
              <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
                <Send size={18} /> Confirm Receipt & Update Stock
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
