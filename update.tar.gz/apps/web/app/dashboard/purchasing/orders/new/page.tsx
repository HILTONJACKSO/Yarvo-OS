"use client";

import { useState, useEffect } from 'react';
import { Search, Save, Send, Trash2, Calendar, FileText, Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function NewPurchaseOrderPage() {
  const router = useRouter();
  
  // Data options
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  
  // Form State
  const [selectedSupplier, setSelectedSupplier] = useState('');
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('Net 30');
  
  // Items state
  const [items, setItems] = useState<any[]>([]);
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('access_token');
      const bid = localStorage.getItem('business_id') || 'bus-kwalee-1';
      const headers = {
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        'x-business-id': bid
      };

      try {
        const [suppliersRes, locationsRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/suppliers`, { headers }),
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/stock-locations`, { headers })
        ]);

        if (suppliersRes.ok) {
          const data = await suppliersRes.json();
          setSuppliers(data);
          if (data.length > 0) setSelectedSupplier(data[0].id);
        }

        if (locationsRes.ok) {
          const data = await locationsRes.json();
          setLocations(data);
          if (data.length > 0) setSelectedLocation(data[0].id);
        }
      } catch (err) {
        console.error("Error fetching initial data", err);
      }
    };
    fetchData();
  }, []);

  // Search effect
  useEffect(() => {
    const searchItems = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        return;
      }
      setIsSearching(true);
      try {
        const token = localStorage.getItem('access_token');
        const bid = localStorage.getItem('business_id') || 'bus-kwalee-1';
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/inventory-items`, {
          headers: {
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
            'x-business-id': bid
          }
        });
        if (response.ok) {
          const data = await response.json();
          const lowerQuery = searchQuery.toLowerCase();
          const filtered = data.filter((item: any) => 
            item.name.toLowerCase().includes(lowerQuery) || 
            item.code.toLowerCase().includes(lowerQuery)
          );
          setSearchResults(filtered);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setIsSearching(false);
      }
    };
    
    const timeoutId = setTimeout(searchItems, 300);
    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  const addItem = (invItem: any) => {
    if (items.some(i => i.inventoryItemId === invItem.id)) return;
    
    const unitCost = invItem.averageUnitCost || invItem.initialUnitCost || 0;
    
    setItems([...items, {
      inventoryItemId: invItem.id,
      name: invItem.name,
      code: invItem.code,
      unit: 'Units', 
      requested: 1,
      unitCost: unitCost,
      taxPercent: 0
    }]);
    setSearchQuery('');
  };

  const updateItem = (id: string, field: string, value: number) => {
    setItems(items.map(item => item.inventoryItemId === id ? { ...item, [field]: value } : item));
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.inventoryItemId !== id));
  };

  // Calculations
  const subtotal = items.reduce((sum, item) => sum + (item.requested * item.unitCost), 0);
  const taxAmount = items.reduce((sum, item) => sum + ((item.requested * item.unitCost) * (item.taxPercent / 100)), 0);
  const totalAmount = subtotal + taxAmount;

  const handleSubmit = async (status: string) => {
    if (items.length === 0) {
      alert("Please add at least one item to the order.");
      return;
    }

    try {
      const token = localStorage.getItem('access_token');
      const bid = localStorage.getItem('business_id') || 'bus-kwalee-1';
      
      const payload = {
        supplierId: selectedSupplier,
        expectedDeliveryDate: expectedDeliveryDate || undefined,
        deliveryLocationId: selectedLocation || undefined,
        paymentTerms,
        currency: 'USD',
        subtotal,
        taxAmount,
        totalAmount,
        status,
        items: items.map(i => {
          const lineTotal = (i.requested * i.unitCost) * (1 + (i.taxPercent / 100));
          return {
            inventoryItemId: i.inventoryItemId,
            orderedQuantity: Number(i.requested),
            unitCost: Number(i.unitCost),
            taxAmount: (i.requested * i.unitCost) * (i.taxPercent / 100),
            lineTotal: lineTotal
          };
        })
      };

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/purchase-orders`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          'x-business-id': bid
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        alert(`Purchase order ${status === 'Draft' ? 'saved as draft' : 'generated successfully'}!`);
        router.push('/dashboard/purchasing/orders');
      } else {
        alert("Failed to create purchase order.");
      }
    } catch (err) {
      console.error(err);
      alert("An error occurred.");
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Create Purchase Order</h1>
          <p className="text-slate-400 mt-1">Generate a formal order to send to a supplier.</p>
        </div>
        <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-brand-primary hover:bg-slate-900 transition flex items-center gap-2">
          <FileText size={18} /> Load from Request
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Supplier <span className="text-red-500">*</span></label>
              <select 
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
                value={selectedSupplier}
                onChange={(e) => setSelectedSupplier(e.target.value)}
              >
                {suppliers.length === 0 && <option value="">No suppliers found</option>}
                {suppliers.map(s => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Expected Delivery Date <span className="text-red-500">*</span></label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <input 
                  type="date" 
                  className="w-full pl-9 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" 
                  value={expectedDeliveryDate}
                  onChange={(e) => setExpectedDeliveryDate(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Delivery Location</label>
              <select 
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
              >
                {locations.length === 0 && <option value="">No locations found</option>}
                {locations.map(l => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Payment Terms</label>
              <select 
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
                value={paymentTerms}
                onChange={(e) => setPaymentTerms(e.target.value)}
              >
                <option value="Net 30">Net 30</option>
                <option value="Net 60">Net 60</option>
                <option value="Cash on Delivery">Cash on Delivery</option>
                <option value="Prepaid">Prepaid</option>
              </select>
            </div>
          </div>
        </div>

        <div className="border-t">
          <div className="p-4 bg-slate-900 border-b flex justify-between items-center relative">
            <h3 className="font-bold text-slate-50">Order Items</h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search to add item..." 
                className="w-full pl-9 pr-4 py-1.5 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              
              {/* Autocomplete Dropdown */}
              {searchQuery && (
                <div className="absolute z-10 w-full mt-1 bg-slate-800 border border-slate-700 rounded-md shadow-lg max-h-60 overflow-y-auto">
                  {isSearching ? (
                    <div className="p-3 text-sm text-slate-400 text-center">Searching...</div>
                  ) : searchResults.length > 0 ? (
                    <ul className="py-1">
                      {searchResults.map((result) => (
                        <li 
                          key={result.id}
                          className="px-4 py-2 hover:bg-slate-700 cursor-pointer flex justify-between items-center group"
                          onClick={() => addItem(result)}
                        >
                          <div>
                            <div className="text-sm font-medium text-slate-200">{result.name}</div>
                            <div className="text-xs text-slate-400">{result.code}</div>
                          </div>
                          <Plus size={16} className="text-brand-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <div className="p-3 text-sm text-slate-400 text-center">No items found</div>
                  )}
                </div>
              )}
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Item</th>
                <th className="p-4 font-semibold text-center w-32">Order Qty</th>
                <th className="p-4 font-semibold">Unit</th>
                <th className="p-4 font-semibold text-right w-32">Unit Cost</th>
                <th className="p-4 font-semibold text-right w-24">Tax %</th>
                <th className="p-4 font-semibold text-right">Line Total</th>
                <th className="p-4 font-semibold text-right w-16"></th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {items.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No items added yet. Search and select items above to begin.
                  </td>
                </tr>
              )}
              {items.map((item) => (
                <tr key={item.inventoryItemId} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      value={item.requested} 
                      onChange={(e) => updateItem(item.inventoryItemId, 'requested', Number(e.target.value))}
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-center"
                    />
                  </td>
                  <td className="p-4 text-slate-400">{item.unit}</td>
                  <td className="p-4">
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                      <input 
                        type="number" 
                        step="0.01"
                        value={item.unitCost} 
                        onChange={(e) => updateItem(item.inventoryItemId, 'unitCost', Number(e.target.value))}
                        className="w-full pl-7 pr-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-right"
                      />
                    </div>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      value={item.taxPercent}
                      onChange={(e) => updateItem(item.inventoryItemId, 'taxPercent', Number(e.target.value))}
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-right"
                    />
                  </td>
                  <td className="p-4 text-right font-medium text-slate-50">
                    ${((item.requested * item.unitCost) * (1 + item.taxPercent / 100)).toFixed(2)}
                  </td>
                  <td className="p-4 text-right">
                    <button onClick={() => removeItem(item.inventoryItemId)} className="p-1.5 text-gray-400 hover:text-red-600 rounded">
                      <Trash2 size={18}/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-900">
              <tr>
                <td colSpan={5} className="p-4 text-right font-medium text-slate-300">Subtotal:</td>
                <td className="p-4 text-right font-medium text-slate-50">${subtotal.toFixed(2)}</td>
                <td></td>
              </tr>
              <tr>
                <td colSpan={5} className="px-4 py-2 text-right font-medium text-slate-300">Tax:</td>
                <td className="px-4 py-2 text-right font-medium text-slate-50">${taxAmount.toFixed(2)}</td>
                <td></td>
              </tr>
              <tr>
                <td colSpan={5} className="p-4 text-right font-bold text-slate-50 border-t">Total PO Value:</td>
                <td className="p-4 text-right font-bold text-brand-primary text-lg border-t">${totalAmount.toFixed(2)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between">
          <button 
            className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium"
            onClick={() => router.push('/dashboard/purchasing/orders')}
          >
            Cancel
          </button>
          <div className="flex gap-2">
            <button 
              onClick={() => handleSubmit('Draft')}
              className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2"
            >
              <Save size={18} /> Save as Draft
            </button>
            <button 
              onClick={() => handleSubmit('Sent')}
              className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2"
            >
              <Send size={18} /> Generate PO & Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
