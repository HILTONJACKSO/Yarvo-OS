"use client";

import { useState } from 'react';
import { Search, Save, Send, Trash2, Calendar, FileText } from 'lucide-react';
import Link from 'next/link';

export default function NewPurchaseOrderPage() {
  const [items, setItems] = useState<any[]>([]);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Create Purchase Order</h1>
          <p className="text-slate-400 mt-1">Generate a formal order to send to a supplier.</p>
        </div>
        <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-brand-primary hover:bg-slate-900 transition flex items-center gap-2">
          <FileText size={18} /> Load from Request
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Supplier <span className="text-red-500">*</span></label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option>ABC Distributors</option>
                <option>Fresh Farms Co.</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Expected Delivery Date <span className="text-red-500">*</span></label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <input type="date" className="w-full pl-9 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Delivery Location</label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option>Main Store</option>
                <option>Kitchen Store</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Payment Terms</label>
              <select className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950">
                <option>Net 30</option>
                <option>Cash on Delivery</option>
                <option>Prepaid</option>
              </select>
            </div>
          </div>
        </div>

        <div className="border-t">
          <div className="p-4 bg-slate-900 border-b flex justify-between items-center">
            <h3 className="font-bold text-slate-50">Order Items</h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search to add item..." 
                className="w-full pl-9 pr-4 py-1.5 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
              />
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Item</th>
                <th className="p-4 font-semibold text-center w-32">Order Qty</th>
                <th className="p-4 font-semibold">Unit</th>
                <th className="p-4 font-semibold text-right w-32">Unit Cost</th>
                <th className="p-4 font-semibold text-right w-24">Tax %</th>
                <th className="p-4 font-semibold text-right">Line Total</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {items.map((item) => (
                <tr key={item.id} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      defaultValue={item.requested} 
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-center"
                    />
                  </td>
                  <td className="p-4 text-slate-400">{item.unit}</td>
                  <td className="p-4">
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                      <input 
                        type="number" 
                        step="0.01"
                        defaultValue={item.unitCost} 
                        className="w-full pl-7 pr-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-right"
                      />
                    </div>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      defaultValue={item.taxPercent} 
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-right"
                    />
                  </td>
                  <td className="p-4 text-right font-medium text-slate-50">
                    ${((item.requested * item.unitCost) * (1 + item.taxPercent / 100)).toFixed(2)}
                  </td>
                  <td className="p-4 text-right">
                    <button className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={18}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-900">
              <tr>
                <td colSpan={5} className="p-4 text-right font-medium text-slate-300">Subtotal:</td>
                <td className="p-4 text-right font-medium text-slate-50">$60.00</td>
                <td></td>
              </tr>
              <tr>
                <td colSpan={5} className="px-4 py-2 text-right font-medium text-slate-300">Tax:</td>
                <td className="px-4 py-2 text-right font-medium text-slate-50">$0.00</td>
                <td></td>
              </tr>
              <tr>
                <td colSpan={5} className="p-4 text-right font-bold text-slate-50 border-t">Total PO Value:</td>
                <td className="p-4 text-right font-bold text-brand-primary text-lg border-t">$60.00</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between">
          <button className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</button>
          <div className="flex gap-2">
            <button className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2">
              <Save size={18} /> Save as Draft
            </button>
            <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
              <Send size={18} /> Generate PO & Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
