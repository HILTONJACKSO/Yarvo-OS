"use client";

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { ArrowLeft, Edit2 } from 'lucide-react';
import Link from 'next/link';

export default function ViewSupplierPage() {
  const params = useParams();
  const { id } = params;
  const [supplier, setSupplier] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSupplier = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/suppliers/${id}`, {
          headers: {
            ...(token ? { 'Authorization': `Bearer ${token}` } : {})
          }
        });
        if (response.ok) {
          const data = await response.json();
          setSupplier(data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    if (id) fetchSupplier();
  }, [id]);

  if (loading) {
    return <div className="text-slate-400 p-8">Loading supplier details...</div>;
  }

  if (!supplier) {
    return (
      <div className="p-8">
        <h1 className="text-2xl text-slate-50 font-bold mb-4">Supplier not found</h1>
        <Link href="/dashboard/purchasing/suppliers" className="text-brand-primary hover:underline">
          &larr; Back to Suppliers
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/purchasing/suppliers" className="p-2 bg-slate-900 border border-slate-800 rounded-md text-slate-400 hover:text-white transition">
            <ArrowLeft size={18} />
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-slate-50">{supplier.name}</h1>
            <p className="text-slate-400 mt-1">Supplier Code: {supplier.code}</p>
          </div>
        </div>
        <Link href={`/dashboard/purchasing/suppliers/${id}/edit`} className="flex items-center gap-2 px-4 py-2 bg-slate-900 border border-slate-800 rounded-md text-slate-300 hover:text-white transition">
          <Edit2 size={16} /> Edit Supplier
        </Link>
      </div>

      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-50">General Information</h2>
        </div>
        <div className="p-6 grid grid-cols-2 gap-6">
          <div>
            <p className="text-sm text-slate-400 mb-1">Supplier Number</p>
            <p className="font-medium text-slate-50">{supplier.supplierNumber || 'N/A'}</p>
          </div>
          <div>
            <p className="text-sm text-slate-400 mb-1">Status</p>
            <span className={`px-2 py-1 text-xs font-medium rounded-full ${supplier.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-slate-800 text-slate-300'}`}>
              {supplier.status}
            </span>
          </div>
          <div>
            <p className="text-sm text-slate-400 mb-1">Currency</p>
            <p className="font-medium text-slate-50">{supplier.currency}</p>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-50">Contact Information</h2>
        </div>
        <div className="p-6 grid grid-cols-2 gap-6">
          <div>
            <p className="text-sm text-slate-400 mb-1">Contact Name</p>
            <p className="font-medium text-slate-50">{supplier.contactName || 'N/A'}</p>
          </div>
          <div>
            <p className="text-sm text-slate-400 mb-1">Phone</p>
            <p className="font-medium text-slate-50">{supplier.phone || 'N/A'}</p>
          </div>
          <div>
            <p className="text-sm text-slate-400 mb-1">Email</p>
            <p className="font-medium text-slate-50">{supplier.email || 'N/A'}</p>
          </div>
          <div className="col-span-2">
            <p className="text-sm text-slate-400 mb-1">Address</p>
            <p className="font-medium text-slate-50">{supplier.address || 'N/A'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
