"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function NewSupplierPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    supplierNumber: '',
    contactName: '',
    phone: '',
    email: '',
    address: '',
    country: '',
    city: '',
    currency: 'USD',
    status: 'ACTIVE',
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/suppliers`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(formData),
      });
      if (response.ok) {
        router.push('/dashboard/purchasing/suppliers');
      } else {
        console.error('Failed to create supplier');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/dashboard/purchasing/suppliers" className="p-2 bg-slate-900 border rounded-md text-slate-400 hover:text-white transition">
          <ArrowLeft size={18} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-slate-50">New Supplier</h1>
          <p className="text-slate-400 mt-1">Add a new vendor to your purchasing catalog.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-slate-950 border rounded-xl p-6 space-y-6">
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Supplier Name *</label>
            <input required type="text" name="name" value={formData.name} onChange={handleChange} className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Supplier Code *</label>
            <input required type="text" name="code" value={formData.code} onChange={handleChange} className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Supplier Number</label>
            <input type="text" name="supplierNumber" value={formData.supplierNumber} onChange={handleChange} placeholder="Leave blank to auto-generate" className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Contact Name</label>
            <input type="text" name="contactName" value={formData.contactName} onChange={handleChange} className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Phone</label>
            <input type="text" name="phone" value={formData.phone} onChange={handleChange} className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Email</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Currency</label>
            <select name="currency" value={formData.currency} onChange={handleChange} className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50">
              <option value="USD">USD</option>
              <option value="EUR">EUR</option>
              <option value="GBP">GBP</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Status</label>
            <select name="status" value={formData.status} onChange={handleChange} className="w-full px-4 py-2 bg-slate-900 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary text-slate-50">
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>
        </div>
        
        <div className="flex justify-end pt-4 border-t border-slate-800 gap-4">
          <Link href="/dashboard/purchasing/suppliers" className="px-6 py-2 bg-slate-800 text-slate-300 rounded-md font-medium hover:bg-slate-700 transition">Cancel</Link>
          <button disabled={loading} type="submit" className="px-6 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition disabled:opacity-50">
            {loading ? 'Creating...' : 'Create Supplier'}
          </button>
        </div>
      </form>
    </div>
  );
}
