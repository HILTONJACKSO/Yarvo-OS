"use client";

import { useState, useEffect } from 'react';
import { Search, Save, Send, Trash2, Calendar, Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function NewPurchaseRequestPage() {
  const router = useRouter();
  const [items, setItems] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [requiredDate, setRequiredDate] = useState('');
  const [priority, setPriority] = useState('Normal');
  const [notes, setNotes] = useState('');
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const bid = localStorage.getItem('business_id');
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/departments`, {
          headers: {
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
            ...(bid ? { 'x-business-id': bid } : {})
          }
        });
        if (response.ok) {
          const data = await response.json();
          setDepartments(data);
          if (data.length > 0) {
            setSelectedDepartment(data[0].id);
          }
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchDepartments();
  }, []);

  useEffect(() => {
    const searchItems = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        return;
      }
      setIsSearching(true);
      try {
        const token = localStorage.getItem('access_token');
        const bid = localStorage.getItem('business_id');
        // Currently findAll returns all, we will filter client side for simplicity
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/inventory-items`, {
          headers: {
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
            ...(bid ? { 'x-business-id': bid } : {})
          }
        });
        if (response.ok) {
          const data = await response.json();
          const lowerQuery = searchQuery.toLowerCase();
          const filtered = data.filter((item: any) => 
            item.name.toLowerCase().includes(lowerQuery) || 
            item.code.toLowerCase().includes(lowerQuery)
          );
          setSearchResults(filtered);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setIsSearching(false);
      }
    };
    
    const timeoutId = setTimeout(searchItems, 300);
    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  const addItem = (invItem: any) => {
    if (items.some(i => i.inventoryItemId === invItem.id)) return;
    
    setItems([...items, {
      inventoryItemId: invItem.id,
      name: invItem.name,
      code: invItem.code,
      available: 0, // Mocked for now, need actual stock balance
      minLevel: invItem.minimumStockLevel || 0,
      unit: 'Units', // Mocked, ideally from unitId
      requested: 1,
      expectedCost: invItem.averageUnitCost || invItem.initialUnitCost || 0
    }]);
    setSearchQuery('');
  };

  const updateQuantity = (id: string, qty: number) => {
    setItems(items.map(item => item.inventoryItemId === id ? { ...item, requested: qty } : item));
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.inventoryItemId !== id));
  };

  const estimatedTotal = items.reduce((sum, item) => sum + (item.requested * item.expectedCost), 0);

  const handleSubmit = async (status: string) => {
    if (items.length === 0) {
      alert("Please add at least one item to the request.");
      return;
    }

    try {
      const token = localStorage.getItem('access_token');
      const bid = localStorage.getItem('business_id');
      
      const payload = {
        departmentId: selectedDepartment,
        requiredDate: requiredDate || undefined,
        priority,
        notes,
        status,
        items: items.map(i => ({
          inventoryItemId: i.inventoryItemId,
          requestedQuantity: Number(i.requested),
          estimatedUnitCost: Number(i.expectedCost)
        }))
      };

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/purchase-requests`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          ...(bid ? { 'x-business-id': bid } : {})
        },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        alert(`Purchase request ${status === 'Draft' ? 'saved as draft' : 'submitted successfully'}!`);
        router.push('/dashboard/purchasing/requests');
      } else {
        alert("Failed to submit request.");
      }
    } catch (err) {
      console.error(err);
      alert("An error occurred.");
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">New Purchase Request</h1>
          <p className="text-slate-400 mt-1">Request items to be purchased by the procurement department.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Requesting Department <span className="text-red-500">*</span></label>
              <select 
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
                value={selectedDepartment}
                onChange={(e) => setSelectedDepartment(e.target.value)}
              >
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.id}>{dept.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Required By Date</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <input 
                  type="date" 
                  className="w-full pl-9 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" 
                  value={requiredDate}
                  onChange={(e) => setRequiredDate(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Priority</label>
              <select 
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="Normal">Normal</option>
                <option value="High">High</option>
                <option value="Urgent">Urgent</option>
              </select>
            </div>
            <div className="md:col-span-3">
              <label className="block text-sm font-medium text-slate-300 mb-1">Justification / Notes</label>
              <textarea 
                rows={2} 
                placeholder="Reason for request..." 
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              ></textarea>
            </div>
          </div>
        </div>

        <div className="border-t overflow-visible">
          <div className="p-4 bg-slate-900 border-b flex justify-between items-center relative">
            <h3 className="font-bold text-slate-50">Requested Items</h3>
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search to add item..." 
                className="w-full pl-9 pr-4 py-1.5 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              {searchQuery && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-slate-700 rounded-md shadow-lg z-10 max-h-48 overflow-y-auto">
                  {searchResults.length > 0 ? (
                    searchResults.map(res => (
                      <div 
                        key={res.id} 
                        className="px-4 py-2 hover:bg-slate-700 cursor-pointer flex justify-between items-center text-sm"
                        onClick={() => addItem(res)}
                      >
                        <div>
                          <p className="font-medium text-slate-200">{res.name}</p>
                          <p className="text-xs text-slate-400">{res.code}</p>
                        </div>
                        <Plus size={14} className="text-brand-primary" />
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-sm text-slate-400 text-center">No items found</div>
                  )}
                </div>
              )}
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Item</th>
                <th className="p-4 font-semibold text-center">On Hand</th>
                <th className="p-4 font-semibold text-center w-32">Request Qty</th>
                <th className="p-4 font-semibold">Unit</th>
                <th className="p-4 font-semibold text-right">Est. Cost</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {items.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">
                    No items added yet. Search above to add items.
                  </td>
                </tr>
              )}
              {items.map((item) => (
                <tr key={item.inventoryItemId} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4 text-center">
                    <span className={`${item.available <= item.minLevel ? 'text-red-600 font-medium' : 'text-slate-400'}`}>
                      {item.available} {item.unit}
                    </span>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      min="1"
                      value={item.requested}
                      onChange={(e) => updateQuantity(item.inventoryItemId, parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-center"
                    />
                  </td>
                  <td className="p-4 text-slate-400">{item.unit}</td>
                  <td className="p-4 text-right text-slate-400">${(item.requested * item.expectedCost).toFixed(2)}</td>
                  <td className="p-4 text-right">
                    <button 
                      onClick={() => removeItem(item.inventoryItemId)}
                      className="p-1.5 text-gray-400 hover:text-red-600 rounded"
                    >
                      <Trash2 size={18}/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-900">
              <tr>
                <td colSpan={4} className="p-4 text-right font-medium text-slate-300">Estimated Total:</td>
                <td className="p-4 text-right font-bold text-slate-50 text-lg">${estimatedTotal.toFixed(2)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between">
          <button 
            onClick={() => router.back()}
            className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium"
          >
            Cancel
          </button>
          <div className="flex gap-2">
            <button 
              onClick={() => handleSubmit('Draft')}
              className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2"
            >
              <Save size={18} /> Save as Draft
            </button>
            <button 
              onClick={() => handleSubmit('Pending Approval')}
              className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2"
            >
              <Send size={18} /> Submit for Approval
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
