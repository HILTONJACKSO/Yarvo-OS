"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Mic, PartyPopper, Users, Calendar, Presentation } from 'lucide-react';
import { io } from 'socket.io-client';
import { toast } from 'sonner';

export default function EventSpacesPage() {
  const [spaces, setSpaces] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({ name: '', type: 'CONFERENCE', capacity: '50', basePrice: '500' });
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState('');
  const [branchId, setBranchId] = useState('');
  const [businessId, setBusinessId] = useState('');

  const fetchData = async (t: string, bId: string, bizId: string) => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/event-spaces`, {
        headers: { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId, 'x-business-id': bizId }
      });
      const data = await res.json();
      setSpaces(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, { headers: { 'Authorization': `Bearer ${t}` }})
      .then(r => r.json())
      .then(data => {
        if (!data || !Array.isArray(data) || data.length === 0) return;
        setBusinessId(data[0].businessId);
        const bId = data[0].business.branches?.[0]?.id;
        setBranchId(bId);
        fetchData(t, bId, data[0].businessId).finally(() => setLoading(false));

        const socket = io(`${process.env.NEXT_PUBLIC_API_URL}`, {
          auth: { token: t }
        });

        socket.on('property.events.updated', () => {
          fetchData(t, bId, data[0].businessId);
        });

        return () => {
          socket.disconnect();
        };
      });
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        name: formData.name,
        code: formData.name.toUpperCase().replace(/\s+/g, '_'),
        spaceType: formData.type,
        standardCapacity: parseInt(formData.capacity) || 50,
        maximumCapacity: parseInt(formData.capacity) || 50,
        baseRentalPrice: parseFloat(formData.basePrice) || 0
      };

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/event-spaces`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId, 'x-business-id': businessId },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsAdding(false);
        setFormData({ name: '', type: 'CONFERENCE', capacity: '50', basePrice: '500' });
        fetchData(token, branchId, businessId);
      } else {
        toast.error('Failed to save event space');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'BANQUET': return <PartyPopper className="text-purple-500 w-6 h-6" />;
      case 'CONFERENCE': return <Presentation className="text-blue-500 w-6 h-6" />;
      case 'MEETING': return <Users className="text-emerald-500 w-6 h-6" />;
      default: return <Mic className="text-amber-500 w-6 h-6" />;
    }
  };

  if (loading) return <div className="text-slate-400">Loading event spaces...</div>;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-brand-primary" /> Event Spaces
          </h1>
          <p className="text-slate-400 text-sm mt-1">Manage banquet halls, conference rooms, and meeting spaces.</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-brand-primary hover:bg-brand-secondary text-white">
          {isAdding ? 'Cancel' : <><Plus size={16} className="mr-2" /> Add Event Space</>}
        </Button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Space Name</Label>
            <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Grand Ballroom" />
          </div>
          <div className="space-y-2">
            <Label>Type</Label>
            <Select required value={formData.type} onValueChange={(v) => setFormData({...formData, type: v || ''})}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="BANQUET">Banquet Hall</SelectItem>
                <SelectItem value="CONFERENCE">Conference Room</SelectItem>
                <SelectItem value="MEETING">Meeting Room</SelectItem>
                <SelectItem value="OUTDOOR">Outdoor Venue</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Max Capacity (Guests)</Label>
            <Input type="number" required value={formData.capacity} onChange={e => setFormData({...formData, capacity: e.target.value})} placeholder="50" />
          </div>
          <div className="space-y-2">
            <Label>Base Hourly/Daily Rate ($)</Label>
            <Input type="number" value={formData.basePrice} onChange={e => setFormData({...formData, basePrice: e.target.value})} placeholder="500" />
          </div>
          <div className="md:col-span-2 flex justify-end mt-4">
            <Button type="submit" className="bg-brand-primary">Save Event Space</Button>
          </div>
        </form>
      )}

      {spaces.length === 0 && !isAdding ? (
        <div className="text-center py-16 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <Mic className="mx-auto h-16 w-16 text-slate-700 mb-4" />
          <h3 className="text-lg font-medium text-slate-200 mb-2">No Event Spaces Added</h3>
          <p className="text-slate-400 mb-6 max-w-md mx-auto">You haven't configured any event venues yet. Add banquet halls, meeting rooms, or conference spaces to start booking events.</p>
          <Button onClick={() => setIsAdding(true)} variant="outline" className="border-brand-primary text-brand-primary hover:bg-brand-primary/10">Add First Space</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {spaces.map(space => (
            <div key={space.id} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex flex-col relative overflow-hidden hover:border-brand-primary/50 transition-colors">
              <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-brand-primary to-purple-500"></div>
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-slate-900 rounded-lg">
                  {getTypeIcon(space.spaceType)}
                </div>
                <div>
                  <div className="text-lg font-bold text-slate-50">{space.name}</div>
                  <div className="text-sm text-slate-400 capitalize">{space.spaceType.toLowerCase()}</div>
                </div>
              </div>
              <div className="mt-auto w-full flex justify-between text-sm text-slate-400 bg-slate-900 px-4 py-3 rounded-lg border border-slate-800">
                <div className="flex flex-col">
                  <span className="text-xs text-slate-500">Capacity</span>
                  <span className="font-semibold text-slate-200">Up to {space.maximumCapacity}</span>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-xs text-slate-500">Rate</span>
                  <span className="font-semibold text-brand-primary">${space.baseRentalPrice}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
