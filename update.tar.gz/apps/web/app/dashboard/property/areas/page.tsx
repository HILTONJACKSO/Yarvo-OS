"use client";

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, GripVertical, Building2, Map } from 'lucide-react';
import { io } from 'socket.io-client';
import { toast } from 'sonner';

const AREA_TYPES = ['Building', 'Floor', 'Wing', 'Section', 'Restaurant', 'Kitchen', 'Bar', 'Beach', 'Pool', 'Nightclub', 'Event Area', 'Reception', 'Outdoor Area', 'Storage', 'Other'];

export default function PropertyAreasPage() {
  const [areas, setAreas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  const [token, setToken] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [branchId, setBranchId] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    areaType: '',
    parentAreaId: 'none',
    capacity: '',
    description: ''
  });

  const fetchData = async (t: string, bId: string, bizId: string) => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/property-areas`, {
        headers: { 'Authorization': `Bearer ${t}`, 'x-branch-id': bId, 'x-business-id': bizId }
      });
      const data = await res.json();
      setAreas(Array.isArray(data) ? data.sort((a, b) => a.displayOrder - b.displayOrder) : []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, { headers: { 'Authorization': `Bearer ${t}` }})
      .then(r => r.json())
      .then(data => {
        if (!data || !Array.isArray(data) || data.length === 0) return;
        const bizId = data[0].businessId;
        setBusinessId(bizId);
        const bId = data[0].business.branches?.[0]?.id;
        setBranchId(bId);
        fetchData(t, bId, bizId).finally(() => setLoading(false));

        const socket = io(`${process.env.NEXT_PUBLIC_API_URL}`, {
          auth: { token: t }
        });

        socket.on('property.area.updated', () => {
          fetchData(t, bId, bizId);
        });

        return () => {
          socket.disconnect();
        };
      });
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        code: formData.name.toUpperCase().replace(/\s+/g, '_'),
        parentAreaId: formData.parentAreaId === 'none' ? null : formData.parentAreaId,
        capacity: formData.capacity ? parseInt(formData.capacity) : null,
      };

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/property-areas`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'x-branch-id': branchId, 'x-business-id': businessId },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        setIsAdding(false);
        setFormData({ name: '', areaType: '', parentAreaId: 'none', capacity: '', description: '' });
        fetchData(token, branchId, businessId);
      } else {
        toast.error('Failed to save area');
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) return <div className="text-slate-400">Loading areas...</div>;

  // Build hierarchy tree
  const rootAreas = areas.filter(a => !a.parentAreaId);
  const getChildren = (parentId: string) => areas.filter(a => a.parentAreaId === parentId);

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Areas & Sections</h1>
          <p className="text-slate-400 text-sm">Organize your physical property hierarchy.</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-brand-primary flex items-center gap-2">
          {isAdding ? 'Cancel' : <><Plus size={16} /> Add Area</>}
        </Button>
      </div>

      {isAdding && (
        <form onSubmit={handleSave} className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm mb-8 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Area Name</Label>
            <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Main Hotel Building" />
          </div>
          <div className="space-y-2">
            <Label>Area Type</Label>
            <Select value={formData.areaType} onValueChange={v => setFormData({...formData, areaType: v || ''})}>
              <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
              <SelectContent>
                {AREA_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Parent Area (Optional)</Label>
            <Select value={formData.parentAreaId || ''} onValueChange={v => setFormData({...formData, parentAreaId: v || ''})}>
              <SelectTrigger><SelectValue placeholder="None (Root Level)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None (Root Level)</SelectItem>
                {areas.map(a => <SelectItem key={a.id} value={a.id}>{a.name} ({a.areaType})</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Capacity (Optional)</Label>
            <Input type="number" value={formData.capacity || ''} onChange={e => setFormData({...formData, capacity: e.target.value})} placeholder="Max people" />
          </div>
          <div className="md:col-span-2 space-y-2">
            <Label>Description</Label>
            <Input value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Optional notes about this area" />
          </div>
          <div className="md:col-span-2 flex justify-end mt-2">
            <Button type="submit" className="bg-brand-primary">Save Area</Button>
          </div>
        </form>
      )}

      {areas.length === 0 && !isAdding ? (
        <div className="text-center py-12 bg-slate-950 rounded-xl border border-slate-800 border-dashed">
          <Map className="mx-auto h-12 w-12 text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-50 mb-1">No property areas defined</h3>
          <p className="text-slate-400 mb-4">Start by adding your main building or outdoor areas.</p>
          <Button onClick={() => setIsAdding(true)} variant="outline">Add First Area</Button>
        </div>
      ) : (
        <div className="bg-slate-950 rounded-xl border border-slate-800 shadow-sm overflow-hidden">
          {rootAreas.map(root => {
            const renderNode = (node: any, level: number) => {
              const children = getChildren(node.id);
              return (
                <div key={node.id} className={`${level === 0 ? 'border-b border-slate-800 last:border-0' : 'border-t border-slate-800/50'}`}>
                  <div 
                    className={`p-4 flex items-center justify-between hover:bg-slate-900/50 ${level === 0 ? 'bg-slate-900' : ''}`}
                    style={{ paddingLeft: `${1 + level * 2}rem` }}
                  >
                    <div className="flex items-center gap-3">
                      <GripVertical size={14} className="text-gray-500 cursor-grab" />
                      {level === 0 && (
                        <div className="w-8 h-8 rounded bg-brand-primary/10 text-brand-primary flex items-center justify-center">
                          <Building2 size={16} />
                        </div>
                      )}
                      <div>
                        <h3 className={`${level === 0 ? 'font-bold text-slate-50' : 'font-medium text-slate-200'}`}>{node.name}</h3>
                        <div className="text-xs text-slate-400">{node.areaType} {node.capacity ? `• Capacity: ${node.capacity}` : ''}</div>
                      </div>
                    </div>
                  </div>
                  {children.length > 0 && (
                    <div className="w-full">
                      {children.map(child => renderNode(child, level + 1))}
                    </div>
                  )}
                </div>
              );
            };
            return renderNode(root, 0);
          })}
        </div>
      )}
    </div>
  );
}
