"use client";

import { useState } from 'react';
import { CreditCard, Banknote, Smartphone, X, Plus, CheckCircle2, ChevronRight, DollarSign } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function ReceivePaymentPage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  // Order context
  const [orderTotal, setOrderTotal] = useState(0);
  const [payments, setPayments] = useState<any[]>([
    { id: '1', method: 'CASH', amount: 0 },
  ]);

  const addPaymentMethod = () => {
    setPayments([...payments, { id: Math.random().toString(), method: 'CARD', amount: 0 }]);
  };

  const removePaymentMethod = (id: string) => {
    setPayments(payments.filter(p => p.id !== id));
  };

  const updatePayment = (id: string, field: string, value: any) => {
    setPayments(payments.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const totalTendered = payments.reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0);
  const balanceDue = Math.max(0, orderTotal - totalTendered);
  const changeDue = Math.max(0, totalTendered - orderTotal);

  const handleProcessPayment = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      // Submit each payment split
      await Promise.all(payments.map(p => 
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/payments`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            method: p.method,
            amount: parseFloat(p.amount) || 0,
            reference: 'Manual Entry',
            orderId: null
          })
        })
      ));
      setSuccess(true);
    } catch (err) {
      console.error('Payment failed', err);
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-2xl mx-auto mt-12 p-8 bg-slate-950 rounded-xl shadow-sm text-center border border-slate-800">
        <div className="w-20 h-20 bg-emerald-500/10 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={40} />
        </div>
        <h2 className="text-3xl font-bold text-slate-50 mb-2">Payment Successful</h2>
        <p className="text-slate-400 mb-8">The payment has been recorded and the balance is settled.</p>
        
        {changeDue > 0 && (
          <div className="p-6 bg-orange-50 rounded-xl mb-8 border border-orange-100">
            <p className="text-sm text-orange-600 font-medium mb-1">Change Due</p>
            <p className="text-4xl font-bold text-orange-700">${changeDue.toFixed(2)}</p>
          </div>
        )}

        <div className="flex justify-center gap-4">
          <button className="px-6 py-3 border border-slate-700 text-slate-300 font-medium rounded-xl hover:bg-slate-900 transition-colors">
            Print Receipt
          </button>
          <button onClick={() => window.location.reload()} className="px-6 py-3 bg-brand-primary text-white font-medium rounded-xl hover:bg-brand-primary/90 transition-colors">
            New Payment
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto flex gap-8">
      {/* Left side: Payment Methods */}
      <div className="flex-1 space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Receive Payment</h2>
          <p className="text-slate-400 text-sm mt-1">Split payments across multiple methods if necessary</p>
        </div>

        <div className="space-y-4">
          {payments.map((payment, index) => (
            <div key={payment.id} className="p-4 bg-slate-950 border border-slate-800 rounded-xl shadow-sm flex items-end gap-4">
              <div className="flex-1 space-y-2">
                <label className="block text-sm font-medium text-slate-300">Payment Method</label>
                <select 
                  value={payment.method}
                  onChange={e => updatePayment(payment.id, 'method', e.target.value)}
                  className="w-full p-3 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none"
                >
                  <option value="CASH">Cash</option>
                  <option value="CARD">Credit / Debit Card</option>
                  <option value="MOBILE_MONEY">Mobile Money</option>
                  <option value="GUEST_FOLIO">Charge to Guest Folio</option>
                  <option value="CORPORATE">Corporate Account</option>
                </select>
              </div>
              <div className="flex-1 space-y-2">
                <label className="block text-sm font-medium text-slate-300">Amount Tendered</label>
                <div className="relative">
                  <DollarSign size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input 
                    type="number"
                    value={payment.amount}
                    onChange={e => updatePayment(payment.id, 'amount', e.target.value)}
                    className="w-full pl-10 p-3 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary outline-none text-lg font-medium"
                    placeholder="0.00"
                  />
                </div>
              </div>
              
              <div className="pb-1">
                {payments.length > 1 && (
                  <button 
                    onClick={() => removePaymentMethod(payment.id)}
                    className="p-3 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <X size={20} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={addPaymentMethod}
          className="flex items-center gap-2 px-4 py-3 text-brand-primary font-medium hover:bg-brand-primary/10 rounded-lg transition-colors w-full justify-center border-2 border-dashed border-brand-primary/30"
        >
          <Plus size={18} />
          Add Split Payment
        </button>

      </div>

      {/* Right side: Summary */}
      <div className="w-80 space-y-6">
        <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 sticky top-6">
          <h3 className="font-bold text-slate-50 mb-6 text-lg">Payment Summary</h3>
          
          <div className="space-y-4 mb-6">
            <div className="flex justify-between items-center text-sm text-slate-400">
              <span className="flex-1">Order Total</span>
              <div className="relative w-32">
                <DollarSign size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input 
                  type="number"
                  value={orderTotal || ''}
                  onChange={e => setOrderTotal(parseFloat(e.target.value) || 0)}
                  className="w-full pl-8 p-1.5 border border-slate-700 rounded focus:ring-2 focus:ring-brand-primary outline-none text-right font-medium text-slate-50"
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div className="flex justify-between items-center text-sm text-slate-400">
              <span>Amount Tendered</span>
              <span className="font-medium text-emerald-600">${totalTendered.toFixed(2)}</span>
            </div>
          </div>

          <div className="h-px bg-gray-200 mb-6"></div>

          {balanceDue > 0 ? (
            <div className="mb-6">
              <p className="text-sm font-medium text-slate-400 mb-1">Balance Due</p>
              <p className="text-3xl font-bold text-red-600">${balanceDue.toFixed(2)}</p>
            </div>
          ) : (
            <div className="mb-6">
              <p className="text-sm font-medium text-slate-400 mb-1">Change Due</p>
              <p className="text-3xl font-bold text-orange-500">${changeDue.toFixed(2)}</p>
            </div>
          )}

          <button 
            disabled={balanceDue > 0 || loading}
            onClick={handleProcessPayment}
            className={`w-full py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${
              balanceDue > 0 
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                : 'bg-brand-primary text-white hover:bg-brand-primary/90 shadow-lg hover:shadow-xl'
            }`}
          >
            {loading ? 'Processing...' : 'Confirm Payment'}
            {!loading && <ChevronRight size={20} />}
          </button>
        </div>
      </div>
    </div>
  );
}
