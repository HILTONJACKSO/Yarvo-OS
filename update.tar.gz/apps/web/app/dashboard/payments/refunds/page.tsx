"use client";

import { useState, useEffect } from 'react';
import { ArrowRightLeft, Search, Filter, FileText, CheckCircle2 } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function RefundsPage() {
  const [refunds, setRefunds] = useState<any[]>([]);

  useEffect(() => {
    const fetchRefunds = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/refunds`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          const parsed = data.map((r: any) => ({
            ...r,
            time: new Date(r.time).toLocaleDateString()
          }));
          setRefunds(parsed);
        }
      } catch (err) {
        console.error('Error fetching refunds', err);
      }
    };

    fetchRefunds();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('refunds.updated', fetchRefunds);

    return () => {
      socket.off('refunds.updated', fetchRefunds);
      socket.disconnect();
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Refunds</h2>
          <p className="text-slate-400 text-sm mt-1">Manage processed refunds and reverse payments</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <div className="flex items-center gap-4">
            <h3 className="font-bold text-slate-50">Refund History</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search refund ID..." 
                className="pl-9 p-2 border border-slate-800 rounded-lg text-sm focus:ring-2 focus:ring-brand-primary outline-none w-64"
              />
            </div>
          </div>
          <button className="p-2 border border-slate-800 text-slate-400 rounded-lg hover:bg-slate-900 transition-colors flex items-center gap-2 text-sm font-medium">
            <Filter size={16} /> Filter
          </button>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 text-slate-400 text-sm border-b border-slate-800">
              <th className="p-4 font-medium">Refund ID</th>
              <th className="p-4 font-medium">Payment ID</th>
              <th className="p-4 font-medium">Time</th>
              <th className="p-4 font-medium">Method</th>
              <th className="p-4 font-medium">Reason</th>
              <th className="p-4 font-medium">Status</th>
              <th className="p-4 font-medium text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            {refunds.map(ref => (
              <tr key={ref.id} className="border-b border-gray-50 hover:bg-slate-900/50 transition-colors">
                <td className="p-4 font-mono text-sm font-medium text-red-600">{ref.id}</td>
                <td className="p-4 font-mono text-sm text-slate-400">{ref.paymentId}</td>
                <td className="p-4 text-slate-400 text-sm">{ref.time}</td>
                <td className="p-4 text-slate-400 text-sm">{ref.method.replace('_', ' ')}</td>
                <td className="p-4 text-slate-400 text-sm">{ref.reason}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    ref.status === 'PROCESSED' ? 'bg-emerald-500/10 text-emerald-700' : 'bg-orange-100 text-orange-700'
                  }`}>
                    {ref.status}
                  </span>
                </td>
                <td className="p-4 text-right font-bold text-slate-50">${ref.amount.toFixed(2)}</td>
              </tr>
            ))}
            {refunds.length === 0 && (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-400">
                  No refunds processed yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
