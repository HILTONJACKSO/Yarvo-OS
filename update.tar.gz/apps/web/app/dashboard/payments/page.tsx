"use client";

import { useState, useEffect } from 'react';
import { CreditCard, ArrowRightLeft, CheckCircle2, AlertCircle, FileText, Search, Filter, Plus } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function PaymentsDashboard() {
  const [payments, setPayments] = useState<any[]>([]);
  const [stats, setStats] = useState({ todayRevenue: 0, transactions: 0, refunds: 0, pending: 0 });

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const [paymentsRes, statsRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/payments`, { headers: { 'Authorization': `Bearer ${token}` } }),
          fetch(`${process.env.NEXT_PUBLIC_API_URL}/payments/stats`, { headers: { 'Authorization': `Bearer ${token}` } })
        ]);

        if (paymentsRes.ok) {
          const pData = await paymentsRes.json();
          const parsed = pData.map((p: any) => ({
            ...p,
            time: new Date(p.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }));
          setPayments(parsed);
        }
        
        if (statsRes.ok) setStats(await statsRes.json());
      } catch (err) {
        console.error('Failed to fetch payments data:', err);
      }
    };

    fetchPayments();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('payments.updated', fetchPayments);
    socket.on('refunds.updated', fetchPayments);

    return () => {
      socket.off('payments.updated', fetchPayments);
      socket.off('refunds.updated', fetchPayments);
      socket.disconnect();
    };
  }, []);
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Payments Dashboard</h2>
          <p className="text-slate-400 text-sm mt-1">Overview of all received payments, refunds, and settlements</p>
        </div>
        <Link 
          href="/dashboard/payments/receive"
          className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors flex items-center gap-2 font-medium shadow-sm hover:shadow"
        >
          <Plus size={18} /> Receive Payment
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-400">Today's Revenue</p>
            <h3 className="text-2xl font-bold text-slate-50">${stats.todayRevenue.toFixed(2)}</h3>
          </div>
        </div>

        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
            <CreditCard size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-400">Transactions</p>
            <h3 className="text-2xl font-bold text-slate-50">{stats.transactions}</h3>
          </div>
        </div>

        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-orange-50 text-orange-600 rounded-lg">
            <ArrowRightLeft size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-400">Refunds</p>
            <h3 className="text-2xl font-bold text-slate-50">${stats.refunds.toFixed(2)}</h3>
          </div>
        </div>

        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-purple-50 text-purple-600 rounded-lg">
            <AlertCircle size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-400">Pending</p>
            <h3 className="text-2xl font-bold text-slate-50">${stats.pending.toFixed(2)}</h3>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <div className="flex items-center gap-4">
            <h3 className="font-bold text-slate-50">Transaction History</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search payment ID or reference..." 
                className="pl-9 p-2 border border-slate-800 rounded-lg text-sm focus:ring-2 focus:ring-brand-primary outline-none w-64"
              />
            </div>
          </div>
          <button className="p-2 border border-slate-800 text-slate-400 rounded-lg hover:bg-slate-900 transition-colors flex items-center gap-2 text-sm font-medium">
            <Filter size={16} /> Filter
          </button>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 text-slate-400 text-sm border-b border-slate-800">
              <th className="p-4 font-medium">Payment ID</th>
              <th className="p-4 font-medium">Time</th>
              <th className="p-4 font-medium">Reference</th>
              <th className="p-4 font-medium">Method</th>
              <th className="p-4 font-medium">Status</th>
              <th className="p-4 font-medium text-right">Amount</th>
              <th className="p-4 font-medium text-center">Receipt</th>
            </tr>
          </thead>
          <tbody>
            {payments.map(tx => (
              <tr key={tx.id} className="border-b border-gray-50 hover:bg-slate-900/50 transition-colors">
                <td className="p-4 font-mono text-sm font-medium text-brand-primary">{tx.id}</td>
                <td className="p-4 text-slate-400 text-sm">{tx.time}</td>
                <td className="p-4 text-sm font-medium">{tx.ref}</td>
                <td className="p-4 text-slate-400 text-sm">{tx.method.replace('_', ' ')}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    tx.status === 'CONFIRMED' ? 'bg-emerald-500/10 text-emerald-700' : 'bg-red-500/10 text-red-700'
                  }`}>
                    {tx.status}
                  </span>
                </td>
                <td className="p-4 text-right font-bold text-slate-50">${tx.amount.toFixed(2)}</td>
                <td className="p-4 text-center">
                  <button className="p-1.5 text-gray-400 hover:text-brand-primary transition-colors inline-block" title="View Receipt">
                    <FileText size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
