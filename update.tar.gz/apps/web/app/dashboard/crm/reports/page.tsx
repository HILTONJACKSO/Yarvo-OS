"use client";

import { PieChart, LineChart, BarChart3, Users, DollarSign, Target } from 'lucide-react';

export default function CRMReportsPage() {
  const reports = [
    { title: 'Customer Lifetime Value (CLV)', desc: 'Predictive modeling of customer revenue potential.', icon: <DollarSign className="text-emerald-500" /> },
    { title: 'Customer Segmentation', desc: 'Breakdown of customers by tags, frequency, and spending tiers.', icon: <PieChart className="text-blue-500" /> },
    { title: 'Churn Analytics', desc: 'Identification of inactive premium customers.', icon: <Target className="text-red-500" /> },
    { title: 'Demographics & Geolocation', desc: 'Age, gender, and nationality distribution.', icon: <Users className="text-purple-500" /> },
    { title: 'Loyalty & Visit Frequency', desc: 'Average visits per year and stay durations.', icon: <LineChart className="text-amber-500" /> },
    { title: 'Feedback & Satisfaction Matrix', desc: 'Department-by-department satisfaction scores.', icon: <BarChart3 className="text-pink-500" /> },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">CRM Analytics & Reports</h1>
          <p className="text-slate-400 mt-1">Deep insights into customer behavior, spending, and satisfaction.</p>
        </div>
        <button className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition shadow-sm font-medium">
          Generate Custom Report
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {reports.map((r, idx) => (
          <div key={idx} className="bg-slate-950 rounded-2xl border shadow-sm p-6 hover:shadow-md hover:border-brand-primary/30 transition cursor-pointer group">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-slate-900 rounded-xl group-hover:scale-110 transition-transform">
                {r.icon}
              </div>
            </div>
            <h3 className="font-bold text-slate-50 text-lg">{r.title}</h3>
            <p className="text-slate-400 text-sm mt-2">{r.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
