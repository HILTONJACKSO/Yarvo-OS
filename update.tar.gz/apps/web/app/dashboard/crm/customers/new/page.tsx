"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { UserPlus, ArrowLeft, Building2, User, Save, Globe, MapPin, Phone, Mail, Calendar } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function RegisterCustomerPage() {
  const router = useRouter();
  const [customerType, setCustomerType] = useState('INDIVIDUAL');
  
  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-brand-primary/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10 flex items-center gap-4">
          <Link href="/dashboard/crm/customers" className="p-3 bg-slate-900 text-gray-400 hover:text-brand-primary hover:bg-blue-50 rounded-xl transition cursor-pointer">
            <ArrowLeft size={24} />
          </Link>
          <div className="p-4 bg-brand-primary/10 text-brand-primary rounded-2xl shadow-inner">
            <UserPlus size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-50 tracking-tight">Register New Customer</h1>
            <p className="text-slate-400 mt-1 font-medium text-sm md:text-base">Create a comprehensive profile for a guest or corporate account.</p>
          </div>
        </div>
        <div className="relative z-10 flex gap-3">
          <button 
            onClick={() => router.push('/dashboard/crm/customers')}
            className="px-5 py-2.5 bg-slate-950 border border-slate-800 text-slate-300 rounded-xl font-bold hover:bg-slate-900 transition shadow-sm"
          >
            Cancel
          </button>
          <button 
            onClick={() => {
              toast.success('Customer registered successfully!');
              router.push('/dashboard/crm/customers');
            }}
            className="px-6 py-2.5 bg-brand-primary text-white rounded-xl font-bold hover:bg-brand-primary/90 transition flex items-center gap-2 shadow-md hover:shadow-lg"
          >
            <Save size={18} /> Save Profile
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1 space-y-2">
          <div className="bg-slate-950 p-4 rounded-3xl border shadow-sm sticky top-6">
            <div className="px-4 py-2 text-xs font-black uppercase tracking-wider text-gray-400 mb-2">Sections</div>
            <button className="w-full text-left px-4 py-3 bg-blue-50 text-brand-primary font-bold rounded-xl flex items-center gap-3">
              <User size={18} /> Basic Info
            </button>
            <button className="w-full text-left px-4 py-3 text-slate-400 hover:bg-slate-900 hover:text-slate-50 font-bold rounded-xl flex items-center gap-3 transition">
              <Phone size={18} /> Contact Details
            </button>
            <button className="w-full text-left px-4 py-3 text-slate-400 hover:bg-slate-900 hover:text-slate-50 font-bold rounded-xl flex items-center gap-3 transition">
              <Globe size={18} /> Preferences
            </button>
          </div>
        </div>

        {/* Form Content */}
        <div className="lg:col-span-3 space-y-8">
          
          {/* Customer Type Selector */}
          <div className="bg-slate-950 p-8 rounded-3xl border shadow-sm">
            <h2 className="text-xl font-black text-slate-50 mb-6 flex items-center gap-2">
              Customer Classification
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <div 
                onClick={() => setCustomerType('INDIVIDUAL')}
                className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex items-center gap-4 \${customerType === 'INDIVIDUAL' ? 'border-brand-primary bg-blue-50/50 shadow-sm' : 'border-slate-800 hover:border-slate-800 bg-slate-950'}`}
              >
                <div className={`p-3 rounded-xl \${customerType === 'INDIVIDUAL' ? 'bg-brand-primary text-white shadow-md' : 'bg-slate-800 text-gray-400'}`}>
                  <User size={24} />
                </div>
                <div>
                  <div className={`font-black text-lg \${customerType === 'INDIVIDUAL' ? 'text-slate-50' : 'text-slate-400'}`}>Individual</div>
                  <div className="text-slate-400 text-sm font-medium">Standard guest or VIP</div>
                </div>
              </div>
              
              <div 
                onClick={() => setCustomerType('CORPORATE')}
                className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex items-center gap-4 \${customerType === 'CORPORATE' ? 'border-brand-primary bg-blue-50/50 shadow-sm' : 'border-slate-800 hover:border-slate-800 bg-slate-950'}`}
              >
                <div className={`p-3 rounded-xl \${customerType === 'CORPORATE' ? 'bg-brand-primary text-white shadow-md' : 'bg-slate-800 text-gray-400'}`}>
                  <Building2 size={24} />
                </div>
                <div>
                  <div className={`font-black text-lg \${customerType === 'CORPORATE' ? 'text-slate-50' : 'text-slate-400'}`}>Corporate</div>
                  <div className="text-slate-400 text-sm font-medium">Business entity or agency</div>
                </div>
              </div>
            </div>
          </div>

          {/* Basic Information */}
          <div className="bg-slate-950 p-8 rounded-3xl border shadow-sm space-y-8">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="p-2 bg-slate-800 text-slate-400 rounded-lg">
                <User size={20} />
              </div>
              <h2 className="text-xl font-black text-slate-50">Basic Information</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {customerType === 'INDIVIDUAL' ? (
                <>
                  <div className="space-y-2.5">
                    <Label className="text-slate-300 font-bold">First Name</Label>
                    <Input placeholder="e.g. John" className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                  </div>
                  <div className="space-y-2.5">
                    <Label className="text-slate-300 font-bold">Last Name</Label>
                    <Input placeholder="e.g. Doe" className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                  </div>
                  <div className="space-y-2.5">
                    <Label className="text-slate-300 font-bold flex justify-between">
                      Date of Birth <span className="text-slate-500 font-normal">Optional</span>
                    </Label>
                    <div className="relative">
                      <Calendar className="absolute left-4 top-3.5 text-gray-400" size={18} />
                      <Input placeholder="mm/dd/yyyy" className="h-12 pl-11 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                    </div>
                  </div>
                  <div className="space-y-2.5">
                    <Label className="text-slate-300 font-bold flex justify-between">
                      Nationality <span className="text-slate-500 font-normal">Optional</span>
                    </Label>
                    <div className="relative">
                      <Globe className="absolute left-4 top-3.5 text-gray-400" size={18} />
                      <Input placeholder="e.g. American" className="h-12 pl-11 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2.5 md:col-span-2">
                    <Label className="text-slate-300 font-bold">Company Name</Label>
                    <Input placeholder="e.g. Global Corp Inc." className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                  </div>
                  <div className="space-y-2.5">
                    <Label className="text-slate-300 font-bold">Registration Number</Label>
                    <Input placeholder="e.g. RC-123456" className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                  </div>
                  <div className="space-y-2.5">
                    <Label className="text-slate-300 font-bold">Tax ID / VAT</Label>
                    <Input placeholder="e.g. TAX-987654321" className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Contact Details */}
          <div className="bg-slate-950 p-8 rounded-3xl border shadow-sm space-y-8">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="p-2 bg-slate-800 text-slate-400 rounded-lg">
                <Phone size={20} />
              </div>
              <h2 className="text-xl font-black text-slate-50">Contact Details</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2.5">
                <Label className="text-slate-300 font-bold">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-4 top-3.5 text-gray-400" size={18} />
                  <Input placeholder="e.g. john.doe@example.com" type="email" className="h-12 pl-11 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                </div>
              </div>
              <div className="space-y-2.5">
                <Label className="text-slate-300 font-bold">Phone Number</Label>
                <div className="relative">
                  <Phone className="absolute left-4 top-3.5 text-gray-400" size={18} />
                  <Input placeholder="e.g. +1 234 567 8900" className="h-12 pl-11 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                </div>
              </div>
              <div className="space-y-2.5 md:col-span-2">
                <Label className="text-slate-300 font-bold">Physical Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-3.5 text-gray-400" size={18} />
                  <Input placeholder="e.g. 123 Main Street, City, Country" className="h-12 pl-11 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl text-base" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
