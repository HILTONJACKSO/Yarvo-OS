"use client";

import { useState, useEffect } from 'react';
import { ArrowLeft, Edit, Mail, Phone, Calendar, MapPin, Building, Briefcase, FileText, Download, CheckCircle, Clock, Star, Activity, User, MessageSquare, AlertTriangle, ShieldCheck, BedDouble, Sun } from 'lucide-react';
import Link from 'next/link';

export default function CustomerProfilePage({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [customer, setCustomer] = useState<any>(null);
  const [preferences, setPreferences] = useState<any>(null);
  const [timeline, setTimeline] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCustomerData = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/customers/${params.id}`, {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (res.ok) {
              const data = await res.json();
              setCustomer(data);
              setPreferences(data.preferences || {
                room: 'None', bed: 'None', smoking: 'None', food: 'None', drink: 'None', diet: 'None', allergies: 'None'
              });
              setTimeline(data.timeline || []);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchCustomerData();
  }, [params.id]);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  if (!customer) return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12 text-center py-20">
      <h2 className="text-xl font-bold text-slate-50">Customer not found</h2>
      <p className="text-slate-400">The customer you are looking for does not exist.</p>
    </div>
  );

  const customerName = `${customer.firstName || ''} ${customer.lastName || ''}`.trim() || 'Unknown Customer';
  const customerInitials = customerName.substring(0, 2).toUpperCase();

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 bg-gradient-to-br from-brand-primary to-blue-600 rounded-2xl text-white flex items-center justify-center text-4xl font-bold shadow-lg">
            {customerInitials}
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-black text-slate-50">{customerName}</h1>
              {customer.customerType === 'VIP' && (
                <span className="px-3 py-1 bg-amber-500/10 text-amber-700 text-xs font-bold rounded-full flex items-center gap-1">
                  <ShieldCheck size={14} /> VIP
                </span>
              )}
            </div>
            <p className="text-slate-400 mt-1 flex items-center gap-4 text-sm font-medium">
              <span>{customer.id}</span>
              {customer.phone && <span className="flex items-center gap-1"><Phone size={14} /> {customer.phone}</span>}
              {customer.email && <span className="flex items-center gap-1"><Mail size={14} /> {customer.email}</span>}
            </p>
            <div className="flex gap-2 mt-3">
              {(customer.tags || []).map((tag: string) => (
                <span key={tag} className="px-2 py-1 bg-slate-800 text-slate-400 text-xs font-medium rounded-md">{tag}</span>
              ))}
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm font-medium text-slate-400 mb-1">Lifetime Value</div>
          <div className="text-3xl font-black text-emerald-600">{customer.ltv || '$0.00'}</div>
          <button className="mt-4 px-4 py-2 border rounded-md text-sm font-medium hover:bg-slate-900 flex items-center gap-2">
            <Edit size={16} /> Edit Profile
          </button>
        </div>
      </div>

      <div className="flex border-b gap-6 text-sm font-medium text-slate-400 mt-8">
        <button className={`pb-3 border-b-2 \${activeTab === 'overview' ? 'border-brand-primary text-brand-primary' : 'border-transparent hover:text-slate-50'}`} onClick={() => setActiveTab('overview')}>Overview</button>
        <button className={`pb-3 border-b-2 \${activeTab === 'timeline' ? 'border-brand-primary text-brand-primary' : 'border-transparent hover:text-slate-50'}`} onClick={() => setActiveTab('timeline')}>Timeline & Visits</button>
        <button className={`pb-3 border-b-2 \${activeTab === 'notes' ? 'border-brand-primary text-brand-primary' : 'border-transparent hover:text-slate-50'}`} onClick={() => setActiveTab('notes')}>Notes & Docs</button>
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          
          <div className="space-y-6 lg:col-span-2">
            {/* Status Panel */}
            {customer.status === 'IN_HOUSE' && (
              <div className="bg-brand-primary/10 border border-brand-primary/20 p-6 rounded-2xl flex justify-between items-center">
                <div>
                  <h3 className="font-bold text-slate-50 flex items-center gap-2">
                    <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span> Currently Staying
                  </h3>
                  <p className="text-sm text-slate-400 mt-1">Room {customer.roomNumber || 'TBD'}</p>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-slate-400">Outstanding Balance</div>
                  <div className="text-xl font-bold text-slate-50">${customer.balance || '0.00'}</div>
                </div>
              </div>
            )}

            {/* Basic Info & Preferences */}
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm">
                <h3 className="font-bold text-slate-50 mb-4 flex items-center gap-2"><User size={18} className="text-gray-400"/> Basic Info</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between"><span className="text-slate-400">Nationality</span> <span className="font-medium text-slate-50">{customer.nationality || 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Passport</span> <span className="font-medium text-slate-50">{customer.passport || 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Occupation</span> <span className="font-medium text-slate-50">{customer.occupation || 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Company</span> <span className="font-medium text-slate-50">{customer.company || 'N/A'}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Location</span> <span className="font-medium text-slate-50 text-right">{customer.address || 'N/A'}</span></div>
                </div>
              </div>

              <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm">
                <h3 className="font-bold text-slate-50 mb-4 flex items-center gap-2"><Star size={18} className="text-amber-500"/> Preferences</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between"><span className="text-slate-400">Room Type</span> <span className="font-medium text-slate-50">{preferences.room}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Bed</span> <span className="font-medium text-slate-50">{preferences.bed}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Favorite Food</span> <span className="font-medium text-slate-50">{preferences.food}</span></div>
                  <div className="flex justify-between"><span className="text-slate-400">Diet</span> <span className="font-medium text-slate-50">{preferences.diet}</span></div>
                  <div className="flex justify-between text-red-600"><span className="font-medium">Allergies</span> <span className="font-bold">{preferences.allergies}</span></div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {/* Stats */}
            <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm">
              <h3 className="font-bold text-slate-50 mb-4 flex items-center gap-2"><Activity size={18} className="text-blue-500"/> Customer Stats</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-900 rounded-lg text-center">
                  <div className="text-2xl font-black text-slate-50">{customer.stats?.stays || 0}</div>
                  <div className="text-xs text-slate-400 mt-1 uppercase font-medium">Stays</div>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg text-center">
                  <div className="text-2xl font-black text-slate-50">{customer.stats?.restaurantVisits || 0}</div>
                  <div className="text-xs text-slate-400 mt-1 uppercase font-medium">Rest. Visits</div>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg text-center">
                  <div className="text-2xl font-black text-slate-50">{customer.stats?.beachEntries || 0}</div>
                  <div className="text-xs text-slate-400 mt-1 uppercase font-medium">Beach Entry</div>
                </div>
                <div className="p-3 bg-slate-900 rounded-lg text-center">
                  <div className="text-2xl font-black text-slate-50">{customer.stats?.nightclubVisits || 0}</div>
                  <div className="text-xs text-slate-400 mt-1 uppercase font-medium">Nightclub</div>
                </div>
              </div>
            </div>

            {/* Lifetime Spending Breakdown */}
            <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm">
              <h3 className="font-bold text-slate-50 mb-4">Spending Breakdown</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between"><span className="text-slate-400">Hotel</span> <span className="font-medium">${customer.spending?.hotel || '0.00'}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Restaurant</span> <span className="font-medium">${customer.spending?.restaurant || '0.00'}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Bar/Nightclub</span> <span className="font-medium">${customer.spending?.bar || '0.00'}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">Admissions</span> <span className="font-medium">${customer.spending?.admissions || '0.00'}</span></div>
                <div className="flex justify-between pt-3 border-t"><span className="font-bold text-slate-50">Total</span> <span className="font-bold text-emerald-600">${customer.spending?.total || '0.00'}</span></div>
              </div>
            </div>
          </div>

        </div>
      )}

      {activeTab === 'timeline' && (
        <div className="bg-slate-950 p-6 rounded-2xl border shadow-sm mt-6">
          <h2 className="font-bold text-slate-50 mb-8 flex items-center justify-between">
            Customer Timeline
            <button className="text-sm text-brand-primary hover:underline">View All</button>
          </h2>
          {timeline.length > 0 ? (
            <div className="space-y-6">
              {timeline.map((item, idx) => (
                <div key={idx} className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center shrink-0 border border-blue-100">
                    <Clock size={16} />
                  </div>
                  <div className="flex-1 pb-6 border-b last:border-0">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-bold text-slate-50">{item.event}</h4>
                      <span className="text-sm text-slate-400">{item.date}</span>
                    </div>
                    <p className="text-sm text-slate-400">{item.desc}</p>
                    <span className="inline-block mt-2 px-2 py-0.5 bg-slate-800 text-slate-400 text-xs rounded font-medium">{item.dept}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-slate-400">No timeline events found for this customer.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
