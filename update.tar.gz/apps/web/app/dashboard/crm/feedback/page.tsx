"use client";

import { MessageSquare, AlertTriangle, Star, CheckCircle2, Clock } from 'lucide-react';
import Link from 'next/link';

import { io } from 'socket.io-client';
import { useState, useEffect } from 'react';

export default function FeedbackAndComplaintsPage() {
  const [complaints, setComplaints] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchComplaints = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const bizRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            const bid = bizData[0].businessId;
            const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/crm/complaints`, {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (res.ok) {
              const data = await res.json();
              setComplaints(Array.isArray(data) ? data : []);
            }
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchComplaints();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('crm.updated', fetchComplaints);

    return () => {
      socket.off('crm.updated', fetchComplaints);
      socket.disconnect();
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Feedback & Complaints</h1>
          <p className="text-slate-400 mt-1">Manage guest issues, track resolutions, and monitor service ratings.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-slate-950 rounded-xl p-5 border shadow-sm text-center">
          <div className="text-sm font-medium text-slate-400 mb-1">Average Rating</div>
          <div className="flex justify-center items-center gap-2 text-3xl font-black text-slate-50">
            4.76 <Star className="text-amber-500 fill-amber-500" size={24} />
          </div>
        </div>
        <div className="bg-slate-950 rounded-xl p-5 border shadow-sm text-center border-red-200 bg-red-50">
          <div className="text-sm font-bold text-red-700 mb-1">Open Complaints</div>
          <div className="text-3xl font-black text-red-700">{complaints.filter(c => c.status === 'OPEN').length}</div>
        </div>
        <div className="bg-slate-950 rounded-xl p-5 border shadow-sm text-center border-amber-200 bg-amber-50">
          <div className="text-sm font-bold text-amber-700 mb-1">In Progress</div>
          <div className="text-3xl font-black text-amber-700">{complaints.filter(c => c.status === 'IN_PROGRESS').length}</div>
        </div>
        <div className="bg-slate-950 rounded-xl p-5 border shadow-sm text-center border-green-200 bg-green-50">
          <div className="text-sm font-bold text-green-700 mb-1">Resolved Today</div>
          <div className="text-3xl font-black text-green-700">{complaints.filter(c => c.status === 'RESOLVED').length}</div>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
          <h2 className="font-bold text-slate-50">Active Complaints Pipeline</h2>
          <div className="flex gap-2 text-sm">
            <button className="px-3 py-1.5 bg-slate-950 border rounded hover:bg-slate-900 font-medium">All Issues</button>
            <button className="px-3 py-1.5 bg-slate-950 border rounded hover:bg-slate-900 font-medium">My Assigned Issues</button>
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400 text-sm">Complaint ID</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Customer</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Department</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Issue Summary</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-center">Priority</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {complaints.map((c, idx) => (
              <tr key={idx} className="hover:bg-slate-900 cursor-pointer">
                <td className="p-4 text-sm font-bold text-brand-primary">{c.id.substring(0, 8)}</td>
                <td className="p-4 text-sm font-medium text-slate-50">{c.customer?.firstName} {c.customer?.lastName}</td>
                <td className="p-4 text-sm text-slate-400">{c.category}</td>
                <td className="p-4 text-sm text-slate-400 w-1/3 truncate">{c.description}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-bold rounded ${c.priority === 'HIGH' ? 'bg-red-500/10 text-red-700' : c.priority === 'MEDIUM' ? 'bg-amber-500/10 text-amber-700' : 'bg-blue-500/10 text-blue-700'}`}>
                    {c.priority}
                  </span>
                </td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-bold rounded-full flex items-center justify-center gap-1 w-fit mx-auto ${
                    c.status === 'OPEN' ? 'bg-red-500/10 text-red-700' :
                    c.status === 'IN_PROGRESS' ? 'bg-amber-500/10 text-amber-700' : 'bg-emerald-500/10 text-green-700'
                  }`}>
                    {c.status === 'OPEN' && <AlertTriangle size={12}/>}
                    {c.status === 'IN_PROGRESS' && <Clock size={12}/>}
                    {c.status === 'RESOLVED' && <CheckCircle2 size={12}/>}
                    {c.status.replace('_', ' ')}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
