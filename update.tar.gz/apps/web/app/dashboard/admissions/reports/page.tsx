"use client";

import { FileText, TrendingDown, Users, BarChart3, AlertTriangle, Download, Ticket } from 'lucide-react';

export default function AdmissionsReportsPage() {
  const reports = [
    {
      title: 'Attendance History',
      description: 'Historical entries broken down by day, time, and venue.',
      icon: <Users className="text-blue-500" size={24} />,
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Ticket Sales & Revenue',
      description: 'Financial analysis of all admissions revenue across walk-in and online sales.',
      icon: <Ticket className="text-green-500" size={24} />,
      bgColor: 'bg-green-50',
    },
    {
      title: 'Peak Capacity Analysis',
      description: 'Review of peak times when venues reached 90%+ capacity to assist in staffing.',
      icon: <BarChart3 className="text-purple-500" size={24} />,
      bgColor: 'bg-purple-50',
    },
    {
      title: 'Rejected Entries Log',
      description: 'Audit log of all failed entry attempts, including duplicates, expired tickets, and refunds.',
      icon: <AlertTriangle className="text-red-500" size={24} />,
      bgColor: 'bg-red-50',
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Admissions Reports</h1>
          <p className="text-slate-400 mt-1">Analyze attendance trends, revenue, and gate control metrics.</p>
        </div>
      </div>

      <div className="bg-slate-950 p-6 rounded-xl border shadow-sm space-y-6">
        <div className="flex gap-4 p-4 bg-slate-900 rounded-lg border items-center">
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Report Period</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>Today</option>
              <option>This Week</option>
              <option>This Month</option>
              <option>Year to Date</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Filter by Venue</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>All Venues</option>
              <option>Silver Beach</option>
              <option>Ocean View Pool</option>
              <option>Sunset Nightclub</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {reports.map((report, idx) => (
            <div key={idx} className="border rounded-xl p-5 flex gap-4 hover:border-brand-primary/50 hover:shadow-md transition cursor-pointer group">
              <div className={`p-4 ${report.bgColor} rounded-lg h-fit group-hover:scale-110 transition-transform`}>
                {report.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-slate-50">{report.title}</h3>
                <p className="text-sm text-slate-400 mt-1">{report.description}</p>
                <div className="mt-4 flex gap-2">
                  <button className="text-xs font-medium text-brand-primary hover:underline flex items-center gap-1">
                    <BarChart3 size={14} /> View Report
                  </button>
                  <button className="text-xs font-medium text-slate-400 hover:text-slate-50 flex items-center gap-1 ml-auto">
                    <Download size={14} /> Export CSV
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
