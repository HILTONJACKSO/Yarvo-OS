"use client";

import { useEffect, useState } from 'react';
import { Users, Ticket, CheckCircle2, TrendingUp, AlertTriangle, UserCheck, XCircle } from 'lucide-react';
import Link from 'next/link';
import io from 'socket.io-client';

export default function AdmissionsDashboardPage() {
  const [stats, setStats] = useState({
    ticketsSoldToday: 0,
    guestsInside: 0,
    availableCapacity: 0,
    rejectedScans: 0,
    venueCapacity: [] as any[],
    alerts: [] as any[]
  });

  const fetchStats = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/admissions/stats`);
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (err) {
      console.error('Failed to fetch admissions stats', err);
    }
  };

  useEffect(() => {
    fetchStats();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('admissions.updated', () => {
      fetchStats();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Admissions Dashboard</h1>
          <p className="text-slate-400 mt-1">Live ticketing, attendance, and capacity monitoring.</p>
        </div>
        <div className="flex gap-3">
          <Link href="/dashboard/admissions/tickets/walk-in" className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
            Sell Walk-in Ticket
          </Link>
          <Link href="/dashboard/admissions/gate/scan" className="px-4 py-2 bg-gray-900 text-white rounded-md hover:bg-gray-800 transition">
            Open Gate Scanner
          </Link>
        </div>
      </div>

      {/* Live KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-slate-400">Tickets Sold Today</h3>
            <div className="p-2 bg-blue-50 text-blue-500 rounded-lg"><Ticket size={18} /></div>
          </div>
          <div className="text-2xl font-bold">{stats.ticketsSoldToday}</div>
          <div className="text-sm text-green-500 mt-1 flex items-center gap-1"><TrendingUp size={14} /> Tracking today</div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-slate-400">Guests Inside</h3>
            <div className="p-2 bg-green-50 text-green-500 rounded-lg"><Users size={18} /></div>
          </div>
          <div className="text-2xl font-bold">{stats.guestsInside}</div>
          <div className="text-sm text-slate-400 mt-1">Across all venues</div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm border-amber-200">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-amber-600">Available Capacity</h3>
            <div className="p-2 bg-amber-50 text-amber-500 rounded-lg"><AlertTriangle size={18} /></div>
          </div>
          <div className="text-2xl font-bold text-amber-600">{stats.availableCapacity}</div>
          <div className="text-sm text-amber-600 mt-1">Combined remaining entries</div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-slate-400">Rejected Scans</h3>
            <div className="p-2 bg-red-50 text-red-500 rounded-lg"><XCircle size={18} /></div>
          </div>
          <div className="text-2xl font-bold">{stats.rejectedScans}</div>
          <div className="text-sm text-slate-400 mt-1">Expired or duplicate</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Capacity By Venue */}
        <div className="bg-slate-950 p-6 rounded-xl border shadow-sm lg:col-span-2">
          <h2 className="text-lg font-bold text-slate-50 mb-4">Live Venue Capacity</h2>
          <div className="space-y-4">
            {stats.venueCapacity.length === 0 ? (
              <div className="text-slate-400 py-4 text-center">No venue data available yet.</div>
            ) : (
              stats.venueCapacity.map((vc: any, idx) => (
                <div key={idx}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-medium text-slate-300">{vc.name}</span>
                    <span className={`text-sm ${vc.usage >= 90 ? 'text-red-600 font-medium' : 'text-slate-400'}`}>{vc.current} / {vc.max} ({vc.usage}%)</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className={`${vc.usage >= 90 ? 'bg-red-500' : vc.usage >= 75 ? 'bg-amber-500' : 'bg-blue-500'} h-2 rounded-full`} style={{ width: `${vc.usage}%` }}></div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Real-time Alerts */}
        <div className="bg-slate-950 p-6 rounded-xl border shadow-sm">
          <h2 className="text-lg font-bold text-slate-50 mb-4 flex items-center gap-2">
            <AlertTriangle size={18} className="text-brand-primary" /> Active Alerts
          </h2>
          <div className="space-y-3">
            {stats.alerts.length === 0 ? (
              <div className="text-slate-400 py-4 text-center">No active alerts. Everything is normal.</div>
            ) : (
              stats.alerts.map((alert: any, idx) => (
                <div key={idx} className={`p-3 rounded-lg border text-sm ${
                  alert.type === 'warning' ? 'bg-amber-50 border-amber-200 text-amber-400' :
                  alert.type === 'critical' ? 'bg-red-50 border-red-200 text-red-400' :
                  'bg-blue-50 border-blue-200 text-blue-400'
                }`}>
                  {alert.message}
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
