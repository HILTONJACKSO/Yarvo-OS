"use client";

import { useState } from 'react';
import { Search, CheckCircle, XCircle, ShieldAlert } from 'lucide-react';
import Link from 'next/link';

export default function ManualValidationPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setHasSearched(true);
      setResult({ status: 'invalid', message: 'EMPTY INPUT', details: { error: 'Please enter a query' } });
      return;
    }
    
    setHasSearched(true);
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/tickets/validate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ticketNumber: searchQuery })
        });
        
        if (res.ok) {
          const data = await res.json();
          setResult(data);
        } else {
          setResult({ status: 'invalid', message: 'ERROR COMMUNICATING WITH SERVER' });
        }
      } catch (err) {
        console.error(err);
        setResult({ status: 'invalid', message: 'NETWORK ERROR' });
      }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Manual Validation</h1>
          <p className="text-slate-400 mt-1">Look up and validate tickets manually if QR scanning fails.</p>
        </div>
      </div>

      <div className="bg-slate-950 p-6 rounded-xl border shadow-sm space-y-6">
        <form onSubmit={handleSearch} className="flex gap-4">
          <div className="flex-1 relative">
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Enter Ticket Number, Phone, or Customer Name..."
              className="w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-brand-primary/50 text-lg"
            />
            <Search className="absolute left-3 top-3.5 text-gray-400" size={20} />
          </div>
          <button type="submit" className="px-6 py-3 bg-brand-primary text-white rounded-lg hover:bg-brand-secondary font-medium transition">
            Search
          </button>
        </form>

        {hasSearched && result && (
          <div className="mt-8 border rounded-xl overflow-hidden">
            <div className={`p-4 ${result.status === 'valid' ? 'bg-green-50 border-b border-green-100' : 'bg-red-50 border-b border-red-100'}`}>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  {result.status === 'valid' ? <CheckCircle className="text-green-600" /> : <XCircle className="text-red-600" />}
                  <span className={`font-bold ${result.status === 'valid' ? 'text-green-700' : 'text-red-700'}`}>
                    {result.message}
                  </span>
                </div>
                <span className="text-slate-400 text-sm">{searchQuery}</span>
              </div>
            </div>

            {result.ticket && (
              <div className="p-6 grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm text-slate-400 mb-1">Customer</label>
                  <div className="font-medium text-slate-50 text-lg">{result.ticket.customerId || 'Walk-in Guest'}</div>
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1">Ticket Type</label>
                  <div className="font-medium text-slate-50 text-lg">{result.ticket.ticketTypeId || 'Unknown'}</div>
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1">Venue</label>
                  <div className="font-medium text-slate-50">{result.ticket.venueId || 'Any'}</div>
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1">Status</label>
                  <div className="font-medium text-slate-50">{result.ticket.status}</div>
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1">Valid From</label>
                  <div className="font-medium text-slate-50">{new Date(result.ticket.validFrom).toLocaleString()}</div>
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1">Valid Until</label>
                  <div className="font-medium text-slate-50">{result.ticket.validUntil ? new Date(result.ticket.validUntil).toLocaleString() : 'No expiration'}</div>
                </div>
              </div>
            )}

            <div className="p-6 bg-slate-900 border-t flex justify-end gap-3">
              <button className="px-4 py-2 border bg-slate-950 rounded-md hover:bg-slate-900 font-medium flex items-center gap-2 text-slate-300">
                <ShieldAlert size={16} /> Mark Invalid
              </button>
              {result.status === 'valid' && (
                <button className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-bold transition">
                  Validate & Record Entry
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900">
          <h2 className="font-bold text-slate-50">Recent Manual Entries</h2>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400">Time</th>
              <th className="p-4 font-medium text-slate-400">Ticket</th>
              <th className="p-4 font-medium text-slate-400">Employee</th>
              <th className="p-4 font-medium text-slate-400">Result</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            <tr>
              <td colSpan={4} className="p-4 text-center text-slate-400">No recent manual entries.</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
