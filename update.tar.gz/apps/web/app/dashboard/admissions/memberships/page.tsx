"use client";

import { useEffect, useState } from 'react';
import { Plus, Edit2, ShieldCheck, Crown } from 'lucide-react';
import Link from 'next/link';
import io from 'socket.io-client';

export default function MembershipsPage() {
  const [memberships, setMemberships] = useState<any[]>([]);

  const fetchMemberships = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/memberships`);
      if (res.ok) {
        const data = await res.json();
        setMemberships(data);
      }
    } catch (err) {
      console.error('Failed to fetch memberships', err);
    }
  };

  useEffect(() => {
    fetchMemberships();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('admissions.updated', () => {
      fetchMemberships();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Memberships</h1>
          <p className="text-slate-400 mt-1">Manage VIPs, Season Passes, and long-term recurring access.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
          <Plus size={18} /> Issue Membership
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400">Customer Name</th>
              <th className="p-4 font-medium text-slate-400">Tier</th>
              <th className="p-4 font-medium text-slate-400">Valid Until</th>
              <th className="p-4 font-medium text-slate-400">Status</th>
              <th className="p-4 font-medium text-slate-400 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {memberships.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-8 text-center text-slate-400">
                  No memberships found.
                </td>
              </tr>
            ) : (
              memberships.map((membership) => (
                <tr key={membership.id} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50 flex items-center gap-2">
                    <Crown size={16} className={membership.membershipType === 'PLATINUM' ? 'text-purple-500' : membership.membershipType === 'GOLD' ? 'text-amber-500' : 'text-gray-400'} /> 
                    {membership.customer?.name || membership.customerId || 'Unknown'}
                  </td>
                  <td className="p-4 font-medium text-slate-300">{membership.membershipType || membership.type}</td>
                  <td className="p-4 text-slate-400">{new Date(membership.validUntil).toLocaleDateString()}</td>
                  <td className="p-4">
                    <span className={`px-2.5 py-1 text-xs rounded-full font-medium ${
                      membership.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-red-500/10 text-red-700'
                    }`}>
                      {membership.status}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button className="text-sm font-medium text-brand-primary hover:underline">
                      View Profile
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
