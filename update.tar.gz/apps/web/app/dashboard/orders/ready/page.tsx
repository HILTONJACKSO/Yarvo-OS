'use client';

import { CheckCircle2, Clock, MapPin, Search } from 'lucide-react';
import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function ReadyForDeliveryPage() {
  const [tickets, setTickets] = useState<any[]>([]);

  const fetchTickets = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/orders`);
      if (res.ok) {
        const orders = await res.json();
        const newTickets: any[] = [];
        
        orders.forEach((order: any) => {
          const readyItems = order.items?.filter((i: any) => i.status === 'READY') || [];
          if (readyItems.length > 0) {
            newTickets.push({
              id: `TKT-${order.id.substr(0,4)}`,
              orderId: order.id,
              orderNumber: order.orderNumber,
              orderType: order.orderType,
              table: order.serviceTableId || 'Unknown Table',
              status: 'READY',
              readyAt: new Date(order.updatedAt),
              items: readyItems.map((i: any) => ({
                id: i.id,
                name: i.itemNameSnapshot,
                quantity: i.quantity
              }))
            });
          }
        });
        
        setTickets(newTickets);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchTickets();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('order.updated', fetchTickets);

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleDeliver = async (ticket: any) => {
    try {
      for (const item of ticket.items) {
        await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/orders/items/${item.id}/status`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'DELIVERED' })
        });
      }
      // Refresh tickets after delivery
      fetchTickets();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto h-[calc(100vh-64px)] flex flex-col">
      <div className="flex items-center justify-between mb-8 shrink-0">
        <div>
          <h1 className="text-3xl font-bold text-slate-50">Ready for Delivery</h1>
          <p className="text-slate-400 mt-1">Items that are ready to be picked up by waiters and delivered</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border border-slate-800 shadow-sm overflow-hidden flex-1 flex flex-col">
        <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between shrink-0">
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search table or room..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-md focus:ring-2 focus:ring-brand-primary outline-none"
            />
          </div>
          <div className="text-sm font-bold text-green-600 bg-emerald-500/10 px-3 py-1.5 rounded-full flex items-center gap-2">
            <CheckCircle2 size={16} />
            {tickets.length} Orders Ready
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-slate-900">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tickets.map(ticket => {
              const waitMins = Math.floor((Date.now() - ticket.readyAt.getTime()) / 60000);
              const isWaitingLong = waitMins > 5;

              return (
                <div key={ticket.id} className={`bg-slate-950 rounded-xl border-2 shadow-sm overflow-hidden flex flex-col ${
                  isWaitingLong ? 'border-amber-400' : 'border-slate-800'
                }`}>
                  <div className={`p-4 border-b flex items-center justify-between ${
                    isWaitingLong ? 'bg-amber-500/10 border-amber-500/20' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div>
                      <h3 className="text-xl font-bold text-slate-50 flex items-center gap-2">
                        <MapPin size={20} className="text-brand-primary" />
                        {ticket.table}
                      </h3>
                      <p className="text-sm text-slate-400 font-medium mt-1">{ticket.orderNumber} &bull; {ticket.orderType.replace('_', ' ')}</p>
                    </div>
                    <div className={`flex flex-col items-end ${isWaitingLong ? 'text-amber-500' : 'text-slate-400'}`}>
                      <span className="flex items-center gap-1 text-sm font-medium"><Clock size={14} /> Wait</span>
                      <span className="text-xl font-bold">{waitMins}m</span>
                    </div>
                  </div>

                  <div className="p-4 flex-1">
                    <ul className="space-y-3">
                      {ticket.items.map((item: any, i: number) => (
                        <li key={i} className="flex items-start gap-3">
                          <span className="font-bold text-slate-50">{item.quantity}x</span>
                          <span className="text-slate-300 font-medium">{item.name}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 bg-slate-900 border-t border-slate-800">
                    <button 
                      onClick={() => handleDeliver(ticket)}
                      className="w-full bg-brand-primary text-white py-3 rounded-lg font-bold hover:bg-brand-secondary transition"
                    >
                      Mark as Delivered
                    </button>
                    <Link 
                      href={`/dashboard/orders/${ticket.orderId}`}
                      className="w-full mt-2 block text-center text-slate-400 font-medium py-2 hover:bg-gray-200 rounded-lg transition"
                    >
                      View Order Details
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
