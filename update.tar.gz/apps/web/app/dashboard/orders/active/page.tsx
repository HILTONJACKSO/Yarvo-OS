"use client";

import { Check, Clock, Flame, MapPin } from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'sonner';

export default function ActiveOrdersPage() {
  const [tickets, setTickets] = useState<any[]>([]);

  const fetchTickets = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/orders`);
      if (res.ok) {
        const orders = await res.json();
        const newTickets: any[] = [];
        
        orders.forEach((order: any) => {
          // Find items that need preparing
          const prepItems = order.items?.filter((i: any) => i.status === 'PREPARING') || [];
          if (prepItems.length > 0) {
            newTickets.push({
              id: order.id,
              orderNumber: order.orderNumber,
              orderType: order.orderType,
              table: order.orderType, // Could map to table ID if available
              status: order.status,
              orderedAt: new Date(order.updatedAt || order.createdAt),
              items: prepItems.map((i: any) => ({
                id: i.id,
                name: i.itemNameSnapshot,
                quantity: i.quantity,
                status: i.status
              }))
            });
          }
        });
        
        // Sort oldest first (most urgent)
        newTickets.sort((a, b) => a.orderedAt.getTime() - b.orderedAt.getTime());
        setTickets(newTickets);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchTickets();
    let socket: any;
    try {
      const { io } = require('socket.io-client');
      socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
      socket.on('order.updated', fetchTickets);
    } catch(e) {}

    return () => {
      if (socket) socket.disconnect();
    };
  }, []);

  const handleMarkItemReady = async (itemId: string) => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/orders/items/${itemId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'READY' })
      });
      if (res.ok) {
        toast.success("Item marked as Ready!");
        // We let the socket io update it, or fetch again directly just in case
        fetchTickets();
      } else {
        toast.error("Failed to mark item ready.");
      }
    } catch (err) {
      console.error(err);
      toast.error("Network error.");
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto h-[calc(100vh-64px)] flex flex-col">
      <div className="flex items-center justify-between mb-8 shrink-0">
        <div>
          <h1 className="text-3xl font-bold text-slate-50 flex items-center gap-3">
            <Flame className="text-orange-500" size={32} />
            Kitchen & Bar Active Orders
          </h1>
          <p className="text-slate-400 mt-1">Orders currently being prepared. Mark items as ready when done.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border border-slate-800 shadow-sm overflow-hidden flex-1 flex flex-col">
        <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between shrink-0">
          <div className="text-sm font-bold text-orange-500 bg-orange-500/10 px-3 py-1.5 rounded-full flex items-center gap-2">
            <Flame size={16} />
            {tickets.length} Active Tickets
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 bg-slate-900">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {tickets.map(ticket => {
              const waitMins = Math.floor((Date.now() - ticket.orderedAt.getTime()) / 60000);
              const isUrgent = waitMins >= 15;
              const isWarning = waitMins >= 10 && waitMins < 15;

              return (
                <div key={ticket.id} className={`bg-slate-950 rounded-xl border-2 shadow-sm overflow-hidden flex flex-col ${
                  isUrgent ? 'border-red-500' : isWarning ? 'border-amber-500' : 'border-slate-800'
                }`}>
                  <div className={`p-4 border-b flex items-center justify-between ${
                    isUrgent ? 'bg-red-500/10 border-red-500/20' : isWarning ? 'bg-amber-500/10 border-amber-500/20' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div>
                      <h3 className="text-lg font-bold text-slate-50 flex items-center gap-2">
                        {ticket.orderNumber}
                      </h3>
                      <p className="text-xs text-brand-primary font-bold mt-1 capitalize">{ticket.orderType.replace('_', ' ')}</p>
                    </div>
                    <div className={`flex flex-col items-end ${
                      isUrgent ? 'text-red-500' : isWarning ? 'text-amber-500' : 'text-slate-400'
                    }`}>
                      <span className="flex items-center gap-1 text-xs font-bold uppercase tracking-wider"><Clock size={12} /> Wait</span>
                      <span className="text-xl font-black">{waitMins}m</span>
                    </div>
                  </div>

                  <div className="p-0 flex-1">
                    <ul className="divide-y divide-slate-800/50">
                      {ticket.items.map((item: any, i: number) => (
                        <li key={i} className="flex items-center justify-between p-4 hover:bg-slate-900/50 transition">
                          <div className="flex items-start gap-3 flex-1 min-w-0 pr-4">
                            <span className="font-bold text-slate-50">{item.quantity}x</span>
                            <span className="text-slate-300 font-medium break-words leading-tight">{item.name}</span>
                          </div>
                          <button 
                            onClick={() => handleMarkItemReady(item.id)}
                            className="shrink-0 w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 flex items-center justify-center hover:bg-emerald-500 hover:text-white transition group"
                            title="Mark as Ready"
                          >
                            <Check size={20} className="group-hover:scale-110 transition-transform" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              );
            })}
            
            {tickets.length === 0 && (
              <div className="col-span-full py-20 text-center flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mb-4">
                  <Check className="text-slate-500" size={32} />
                </div>
                <h3 className="text-xl font-bold text-slate-400">All Caught Up!</h3>
                <p className="text-slate-500 mt-2">No active orders are waiting to be prepared.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
