"use client";

import Link from 'next/link';
import { Percent, DollarSign, Monitor, Receipt, Shield, MapPin, Building2, Store } from 'lucide-react';

export default function SettingsDashboard() {
  const settingGroups = [
    {
      title: "Financial Settings",
      items: [
        { name: "Taxes", path: "/dashboard/settings/taxes", icon: <Percent size={20} />, description: "Configure VAT, City Tax, and other government taxes" },
        { name: "Service Charges", path: "/dashboard/settings/service-charges", icon: <DollarSign size={20} />, description: "Manage delivery fees and optional gratuities" },
        { name: "Cash Registers", path: "/dashboard/settings/cash-registers", icon: <Monitor size={20} />, description: "Set up physical and logical cash registers" },
        { name: "Receipts", path: "/dashboard/settings/receipts", icon: <Receipt size={20} />, description: "Customize receipt headers, footers, and logo" },
      ]
    },
    {
      title: "User Management",
      items: [
        { name: "Roles & Permissions", path: "/dashboard/settings/roles", icon: <Shield size={20} />, description: "Manage staff roles and access levels" }
      ]
    },
    {
      title: "Property & Configuration",
      items: [
        { name: "Business Settings", path: "/dashboard/settings/business", icon: <Building2 size={20} />, description: "General hotel details and configuration" },
        { name: "Branches", path: "/dashboard/settings/branches", icon: <Store size={20} />, description: "Manage multiple properties or locations" }
      ]
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-50">Settings</h2>
        <p className="text-slate-400 text-sm mt-1">Manage system configurations across all modules</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {settingGroups.map(group => (
          <div key={group.title} className="space-y-4">
            <h3 className="text-lg font-bold text-slate-50 border-b border-slate-800 pb-2">{group.title}</h3>
            <div className="space-y-3">
              {group.items.map(item => (
                <Link key={item.name} href={item.path} className="block group">
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl hover:border-brand-primary/30 hover:shadow-sm transition-all flex gap-4 items-start">
                    <div className="p-2 bg-slate-900 text-slate-400 rounded-lg group-hover:bg-brand-primary/10 group-hover:text-brand-primary transition-colors">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-medium text-slate-50 group-hover:text-brand-primary transition-colors">{item.name}</h4>
                      <p className="text-sm text-slate-400 mt-1">{item.description}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
