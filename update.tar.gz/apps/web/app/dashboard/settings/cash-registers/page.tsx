"use client";

import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Save, X, Search, Monitor } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { io } from 'socket.io-client';
import { ConfirmationModal } from '@/components/ui/confirmation-modal';

export default function CashRegistersSettingsPage() {
  const [registers, setRegisters] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  const [isEditing, setIsEditing] = useState(false);
  const [currentRegister, setCurrentRegister] = useState<any>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  useEffect(() => {
    fetchRegisters();

    const token = localStorage.getItem('access_token');
    if (!token) return;

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`, {
      auth: { token }
    });

    socket.on('settings.cashRegister.updated', () => {
      fetchRegisters();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const fetchRegisters = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      const branchId = localStorage.getItem('branch_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/cash-registers`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || '',
          'x-branch-id': branchId || ''
        }
      });
      
      if (!res.ok) throw new Error('Failed to load cash registers');
      const data = await res.json();
      setRegisters(data);
      setLoading(false);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleEdit = (register: any) => {
    setCurrentRegister({ ...register });
    setIsEditing(true);
  };

  const handleCreate = () => {
    setCurrentRegister({
      name: '',
      code: '',
      status: 'ACTIVE'
    });
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      const branchId = localStorage.getItem('branch_id');
      
      const isNew = !currentRegister.id;
      const url = `${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/cash-registers${isNew ? '' : `/${currentRegister.id}`}`;
      
      const res = await fetch(url, {
        method: isNew ? 'POST' : 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || '',
          'x-branch-id': branchId || ''
        },
        body: JSON.stringify(currentRegister)
      });
      
      if (!res.ok) throw new Error('Failed to save register');
      
      setIsEditing(false);
      fetchRegisters();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDelete = async () => {
    if (!itemToDelete) return;
    
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/cash-registers/${itemToDelete}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        }
      });
      
      if (!res.ok) throw new Error('Failed to delete register');
      fetchRegisters();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setItemToDelete(null);
    }
  };

  if (loading) return <div className="p-8">Loading Cash Registers...</div>;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Cash Registers</h2>
          <p className="text-slate-400 text-sm mt-1">Configure physical and logical cash registers for cashier shifts</p>
        </div>
        <button 
          onClick={handleCreate}
          className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors"
        >
          <Plus size={18} />
          New Cash Register
        </button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {isEditing ? (
        <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 p-6 max-w-2xl">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-slate-50">{currentRegister.id ? 'Edit Cash Register' : 'New Cash Register'}</h3>
            <button onClick={() => setIsEditing(false)} className="text-gray-400 hover:text-slate-400">
              <X size={24} />
            </button>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Register Name</label>
              <input 
                type="text" 
                value={currentRegister.name} 
                onChange={e => setCurrentRegister({...currentRegister, name: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                placeholder="e.g. Lobby Terminal 1"
              />
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Code / Hardware ID</label>
              <input 
                type="text" 
                value={currentRegister.code} 
                onChange={e => setCurrentRegister({...currentRegister, code: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
                placeholder="e.g. REG_LOBBY_1"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-300">Status</label>
              <select 
                value={currentRegister.status}
                onChange={e => setCurrentRegister({...currentRegister, status: e.target.value})}
                className="w-full p-2 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
              >
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
                <option value="MAINTENANCE">Maintenance</option>
              </select>
            </div>
          </div>

          <div className="mt-8 flex justify-end gap-3">
            <button 
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 border border-slate-700 text-slate-300 rounded-lg hover:bg-slate-900 transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSave}
              className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors flex items-center gap-2"
            >
              <Save size={18} />
              Save Register
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {registers.map(register => (
            <div key={register.id} className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 p-6 flex flex-col hover:border-brand-primary/30 transition-colors">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-brand-primary/10 text-brand-primary rounded-lg">
                  <Monitor size={24} />
                </div>
                <div className="flex gap-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    register.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-700' : 
                    register.status === 'MAINTENANCE' ? 'bg-orange-100 text-orange-700' : 
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {register.status}
                  </span>
                </div>
              </div>
              
              <div className="mb-6 flex-1">
                <h3 className="text-lg font-bold text-slate-50">{register.name}</h3>
                <p className="text-sm text-slate-400 font-mono mt-1">{register.code}</p>
              </div>
              
              <div className="flex justify-end gap-2 border-t border-gray-50 pt-4">
                <button 
                  onClick={() => handleEdit(register)}
                  className="px-3 py-1.5 text-sm font-medium text-slate-300 hover:text-brand-primary bg-slate-900 hover:bg-brand-primary/10 rounded-md transition-colors flex items-center gap-1"
                >
                  <Edit2 size={14} /> Edit
                </button>
                <button 
                  onClick={() => setItemToDelete(register.id)}
                  className="px-3 py-1.5 text-sm font-medium text-red-600 hover:text-white hover:bg-red-600 bg-red-50 rounded-md transition-colors flex items-center gap-1"
                >
                  <Trash2 size={14} /> Delete
                </button>
              </div>
            </div>
          ))}
          
          {registers.length === 0 && (
            <div className="col-span-full p-8 bg-slate-950 border border-dashed border-slate-700 rounded-xl text-center">
              <Monitor size={48} className="mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-slate-50 mb-1">No Cash Registers</h3>
              <p className="text-slate-400 mb-4">Create your first cash register to allow staff to open cashier shifts.</p>
              <button 
                onClick={handleCreate}
                className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors inline-flex items-center gap-2"
              >
                <Plus size={18} />
                New Cash Register
              </button>
            </div>
          )}
        </div>
      )}

      <ConfirmationModal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={handleDelete}
        title="Confirm Deletion"
        message="Are you sure you want to delete this cash register?"
        confirmText="Delete"
      />
    </div>
  );
}
