"use client";

import { useState, useEffect } from 'react';
import { 
  TrendingUp, Users, ShoppingBag, Briefcase, Plus,
  ArrowUpRight, ArrowDownRight, DollarSign, Activity, Settings, LayoutGrid
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { socket } from '@/lib/socket';

export default function DashboardPage() {
  const router = useRouter();
  const [greeting, setGreeting] = useState('Welcome back');
  const [businessName, setBusinessName] = useState('...');
  
  // Dynamic Data States
  const [revenueData, setRevenueData] = useState<any[]>([]);
  const [stats, setStats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting('Good morning');
    else if (hour < 18) setGreeting('Good afternoon');
    else setGreeting('Good evening');

    const fetchDashboardData = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        // Fetch business info
        const bizRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (bizRes.ok) {
          const bizData = await bizRes.json();
          if (bizData && bizData.length > 0) {
            setBusinessName(bizData[0].name || bizData[0].legalName);
            const bid = bizData[0].businessId;
            
            // Fetch Dashboard Overview Stats
            const dashRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/dashboard/overview`, {
              headers: { 'Authorization': `Bearer ${token}`, 'x-business-id': bid }
            });
            if (dashRes.ok) {
              const dashData = await dashRes.json();
              setRevenueData(dashData.revenueData || []);
              setStats(dashData.stats || []);
            }
          }
        }
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();

    const onUpdate = () => {
      fetchDashboardData();
    };

    socket.on('reservations.updated', onUpdate);
    socket.on('stays.updated', onUpdate);
    socket.on('customers.updated', onUpdate);
    socket.on('orders.updated', onUpdate);

    return () => {
      socket.off('reservations.updated', onUpdate);
      socket.off('stays.updated', onUpdate);
      socket.off('customers.updated', onUpdate);
      socket.off('orders.updated', onUpdate);
    };
  }, []);

  const quickActions = [
    { title: 'New Reservation', desc: 'Create a new room booking', icon: <Plus size={20} />, href: '/dashboard/reservations/new', color: 'bg-blue-50 text-blue-600', hover: 'hover:border-blue-200' },
    { title: 'Walk-in Check-In', desc: 'Check in a guest directly', icon: <Users size={20} />, href: '/dashboard/front-desk/check-in', color: 'bg-emerald-50 text-emerald-600', hover: 'hover:border-emerald-200' },
    { title: 'Restaurant POS', desc: 'Open point of sale system', icon: <ShoppingBag size={20} />, href: '/dashboard/orders/new', color: 'bg-amber-50 text-amber-600', hover: 'hover:border-amber-200' },
    { title: 'System Settings', desc: 'Configure business details', icon: <Settings size={20} />, href: '/dashboard/settings', color: 'bg-purple-50 text-purple-600', hover: 'hover:border-purple-200' },
  ];

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-brand-primary/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10">
          <h1 className="text-3xl font-black text-slate-50 tracking-tight">{greeting}, {businessName}</h1>
          <p className="text-slate-400 mt-2 font-medium">Here's what's happening at your property today.</p>
        </div>
        <div className="relative z-10 flex gap-3">
          <button onClick={() => router.push('/dashboard/bi')} className="px-5 py-2.5 bg-brand-primary text-white rounded-xl font-medium hover:bg-brand-primary/90 transition flex items-center gap-2 shadow-md hover:shadow-lg">
            <Activity size={18} /> Executive Dashboard
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      {stats.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, i) => (
            <div key={i} className="bg-slate-950 p-6 rounded-3xl border shadow-sm hover:shadow-md transition-shadow group cursor-pointer relative overflow-hidden">
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-slate-900 rounded-2xl text-gray-400 group-hover:text-brand-primary transition-colors">
                  <Activity size={24} />
                </div>
                <div className={`flex items-center gap-1 text-sm font-bold px-2.5 py-1 rounded-full \${stat.trendUp ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>
                  {stat.trendUp ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                  {stat.trend}
                </div>
              </div>
              <div>
                <div className="text-slate-400 text-sm font-medium mb-1">{stat.label}</div>
                <div className="text-3xl font-black text-slate-50">{stat.value}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-slate-950 p-8 rounded-3xl border shadow-sm text-center">
          <p className="text-slate-400 font-medium">No statistical data available yet. Start processing transactions to see metrics.</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-slate-950 p-8 rounded-3xl border shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-xl font-bold text-slate-50">Revenue Overview</h2>
              <p className="text-sm text-slate-400 font-medium mt-1">Daily revenue performance for the current week.</p>
            </div>
            <select className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-sm font-medium text-slate-50 outline-none hover:bg-slate-800 transition cursor-pointer">
              <option className="bg-slate-900 text-slate-50">This Week</option>
              <option className="bg-slate-900 text-slate-50">Last Week</option>
              <option className="bg-slate-900 text-slate-50">This Month</option>
            </select>
          </div>
          
          {revenueData.length > 0 ? (
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={revenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2C3241" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#2C3241" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} tickFormatter={(value) => `$${value}`} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    itemStyle={{ fontWeight: 'bold' }}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="#2C3241" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-[300px] w-full flex items-center justify-center border-2 border-dashed border-slate-800 rounded-2xl">
               <p className="text-gray-400 font-medium">Insufficient revenue data to generate chart.</p>
            </div>
          )}
        </div>

        {/* Quick Actions & Recent Activity */}
        <div className="space-y-8">
          <div className="bg-slate-950 p-8 rounded-3xl border shadow-sm">
            <h2 className="text-xl font-bold text-slate-50 mb-6">Quick Actions</h2>
            <div className="grid grid-cols-1 gap-3">
              {quickActions.map((action, i) => (
                <button 
                  key={i} 
                  onClick={() => router.push(action.href)}
                  className={`flex items-center gap-4 p-4 rounded-2xl border border-transparent hover:shadow-md transition-all text-left bg-slate-900 \${action.hover} group`}
                >
                  <div className={`p-3 rounded-xl \${action.color} group-hover:scale-110 transition-transform`}>
                    {action.icon}
                  </div>
                  <div>
                    <div className="font-bold text-slate-50">{action.title}</div>
                    <div className="text-xs text-slate-400 font-medium mt-0.5">{action.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
