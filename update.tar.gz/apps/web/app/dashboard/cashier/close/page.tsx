"use client";

import { useState, useEffect } from 'react';
import { Monitor, DollarSign, Calculator, Settings, CheckCircle2, AlertTriangle, Printer } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';

export default function CloseCashierShiftPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [success, setSuccess] = useState(false);
  const [shiftData, setShiftData] = useState<any>(null);

  useEffect(() => {
    const fetchShift = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/cashier-shifts/current`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const text = await res.text();
          if (text) {
            setShiftData(JSON.parse(text));
          } else {
            router.push('/dashboard/cashier/open');
          }
        } else if (res.status === 404) {
          router.push('/dashboard/cashier/open');
        }
      } catch (err) {
        console.error('Failed to fetch shift', err);
      } finally {
        setLoading(false);
      }
    };
    fetchShift();
  }, [router]);

  const [actualCash, setActualCash] = useState<string>('');
  const [notes, setNotes] = useState('');

  const cashDifference = actualCash === '' || !shiftData ? 0 : parseFloat(actualCash) - shiftData.expectedCash;
  const isShort = cashDifference < 0;
  const isOver = cashDifference > 0;
  const isBalanced = actualCash !== '' && cashDifference === 0;

  const handleCloseShift = async () => {
    if (actualCash === '' || !shiftData) return;
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/cashier-shifts/close`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          actualCash,
          notes
        })
      });

      if (res.ok) {
        setSuccess(true);
      } else {
        const err = await res.json();
        toast.error(`Failed to close shift: ${err.message}`);
      }
    } catch (error) {
      console.error('Failed to close shift', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading && !shiftData) return <div className="p-8 text-center text-slate-400">Loading active shift...</div>;
  if (!shiftData && !success) return <div className="p-8 text-center text-slate-400">No active shift found.</div>;

  if (success) {
    return (
      <div className="max-w-md mx-auto mt-20 p-8 bg-slate-950 rounded-xl shadow-sm border border-slate-800 text-center">
        <div className="w-20 h-20 bg-emerald-500/10 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={40} />
        </div>
        <h2 className="text-2xl font-bold text-slate-50 mb-2">Shift Closed</h2>
        <p className="text-slate-400 mb-8">Your cashier shift has been successfully closed and the Z-read has been generated.</p>
        
        <div className="flex justify-center gap-3">
          <button className="px-4 py-2 border border-slate-700 text-slate-300 font-medium rounded-lg hover:bg-slate-900 transition-colors flex items-center gap-2">
            <Printer size={18} /> Print Z-Read
          </button>
          <button onClick={() => { localStorage.removeItem('access_token'); router.push('/login'); }} className="px-4 py-2 bg-brand-primary text-white font-medium rounded-lg hover:bg-brand-primary/90 transition-colors flex items-center gap-2">
            Logout
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-brand-primary/10 text-brand-primary rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Settings size={32} />
        </div>
        <h2 className="text-2xl font-bold text-slate-50">Close Cashier Shift</h2>
        <p className="text-slate-400 mt-1">Count your drawer and reconcile cash before ending your shift on {shiftData.registerName}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 flex flex-col justify-center items-center text-center">
          <Calculator className="text-gray-400 mb-4" size={32} />
          <p className="text-sm font-medium text-slate-400 mb-1">Expected Cash in Drawer</p>
          <h3 className="text-4xl font-bold text-slate-50 mb-4">${shiftData.expectedCash.toFixed(2)}</h3>
          <p className="text-xs text-slate-400 max-w-xs">This includes your opening float, cash sales, and any cash movements made during your shift.</p>
        </div>

        <div className="bg-slate-950 p-8 rounded-2xl shadow-sm border border-slate-800 space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Actual Cash Counted</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="number" 
                value={actualCash}
                onChange={e => setActualCash(e.target.value)}
                className={`w-full pl-10 p-4 border ${isBalanced ? 'border-emerald-500 ring-emerald-500' : 'border-slate-700'} rounded-xl focus:ring-2 focus:ring-brand-primary outline-none text-xl font-bold`}
                placeholder="0.00"
              />
            </div>
          </div>

          {actualCash !== '' && (
            <div className={`p-4 rounded-xl border ${
              isBalanced ? 'bg-emerald-50 border-emerald-100 text-emerald-400' : 
              isShort ? 'bg-red-50 border-red-100 text-red-400' : 
              'bg-orange-50 border-orange-100 text-orange-800'
            }`}>
              <div className="flex items-start gap-3">
                {isBalanced ? <CheckCircle2 size={24} className="mt-0.5" /> : <AlertTriangle size={24} className="mt-0.5" />}
                <div>
                  <h4 className="font-bold text-lg">
                    {isBalanced ? 'Drawer is Balanced' : isShort ? 'Drawer is Short' : 'Drawer is Over'}
                  </h4>
                  {!isBalanced && (
                    <p className="mt-1 font-medium">
                      Difference: <span className="font-bold">${Math.abs(cashDifference).toFixed(2)}</span>
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Closing Notes / Discrepancy Reason</label>
            <textarea 
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full p-3 border border-slate-700 rounded-xl focus:ring-2 focus:ring-brand-primary outline-none resize-none"
              rows={3}
              placeholder="Add any notes about overages, shortages, or drops..."
              required={actualCash !== '' && !isBalanced}
            />
            {actualCash !== '' && !isBalanced && (
              <p className="text-xs text-red-500">* Notes are required for unbalanced drawers</p>
            )}
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button 
              disabled={loading || actualCash === '' || (!isBalanced && notes.trim() === '')}
              onClick={handleCloseShift}
              className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
                actualCash === '' || (!isBalanced && notes.trim() === '') || loading
                  ? 'bg-slate-800 text-gray-400 cursor-not-allowed'
                  : isBalanced 
                    ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg'
                    : 'bg-orange-500 text-white hover:bg-orange-600 shadow-lg'
              }`}
            >
              {loading ? 'Processing Z-Read...' : 'Confirm & Close Shift'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
