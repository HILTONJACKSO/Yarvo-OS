"use client";

import { useState, useEffect } from 'react';
import { Monitor, DollarSign, Clock, ArrowDownToLine, ArrowUpFromLine, RefreshCw, AlertCircle, FileText, Settings, User } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';
import { useRouter } from 'next/navigation';

export default function MyShiftDashboard() {
  const router = useRouter();
  const [shiftData, setShiftData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShift = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;
        
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/cashier-shifts/current`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (res.ok) {
          const text = await res.text();
          if (text) {
            const data = JSON.parse(text);
            data.openedAt = new Date(data.openedAt);
            setShiftData(data);
          } else {
            // No active shift, redirect to open shift
            router.push('/dashboard/cashier/open');
          }
        } else if (res.status === 404) {
          router.push('/dashboard/cashier/open');
        }
      } catch (err) {
        console.error('Failed to fetch shift', err);
      } finally {
        setLoading(false);
      }
    };

    fetchShift();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('cashier.updated', fetchShift);
    socket.on('payments.updated', fetchShift);

    return () => {
      socket.off('cashier.updated', fetchShift);
      socket.off('payments.updated', fetchShift);
      socket.disconnect();
    };
  }, [router]);

  if (loading) return <div className="p-8 text-center text-slate-400">Loading shift data...</div>;
  if (!shiftData) return <div className="p-8 text-center text-slate-400">Redirecting to open shift...</div>;


  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Cashier Shift Dashboard</h2>
          <div className="flex items-center gap-4 mt-2 text-sm text-slate-400">
            <span className="flex items-center gap-1"><Monitor size={14} /> {shiftData.registerName}</span>
            <span className="flex items-center gap-1"><User size={14} /> Admin User</span>
            <span className="flex items-center gap-1"><Clock size={14} /> Opened {shiftData.openedAt.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
          </div>
        </div>
        
        <div className="flex gap-3">
          <Link 
            href="/dashboard/payments/receive"
            className="px-4 py-2 bg-slate-950 border border-slate-700 text-slate-300 rounded-lg hover:bg-slate-900 transition-colors flex items-center gap-2 font-medium"
          >
            <DollarSign size={18} /> Receive Payment
          </Link>
          <Link 
            href="/dashboard/cashier/close"
            className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors flex items-center gap-2 font-medium"
          >
            <Settings size={18} /> Close Shift
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm col-span-1 md:col-span-2 lg:col-span-1">
          <p className="text-sm font-medium text-slate-400 mb-1">Expected Cash in Drawer</p>
          <h3 className="text-3xl font-bold text-slate-50">${shiftData.expectedCash.toFixed(2)}</h3>
          <div className="mt-4 pt-4 border-t border-slate-800 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Opening Float</span>
              <span className="font-medium text-slate-50">${shiftData.openingCash.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Cash Sales</span>
              <span className="font-medium text-emerald-600">+${shiftData.cashSales.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Cash Out</span>
              <span className="font-medium text-red-600">-${shiftData.cashOut.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm">
          <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center mb-4">
            <DollarSign size={20} />
          </div>
          <p className="text-sm font-medium text-slate-400 mb-1">Total Non-Cash Sales</p>
          <h3 className="text-2xl font-bold text-slate-50">${(shiftData.cardSales + shiftData.mobileMoneySales).toFixed(2)}</h3>
          <div className="mt-2 text-sm text-slate-400">
            Card: ${shiftData.cardSales} â€¢ MM: ${shiftData.mobileMoneySales}
          </div>
        </div>

        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex flex-col justify-center gap-3">
          <button className="w-full px-4 py-3 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg flex items-center justify-between transition-colors border border-slate-800">
            <span className="flex items-center gap-2 font-medium"><ArrowDownToLine size={18} className="text-emerald-600" /> Cash In</span>
            <span className="text-xs text-slate-400">Add Float</span>
          </button>
          <button className="w-full px-4 py-3 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg flex items-center justify-between transition-colors border border-slate-800">
            <span className="flex items-center gap-2 font-medium"><ArrowUpFromLine size={18} className="text-red-600" /> Cash Out</span>
            <span className="text-xs text-slate-400">Petty Cash / Drop</span>
          </button>
        </div>

        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex flex-col justify-center">
          <div className="flex items-start gap-3 p-4 bg-orange-50 rounded-lg border border-orange-100">
            <AlertCircle className="text-orange-500 mt-0.5" size={20} />
            <div>
              <h4 className="font-medium text-orange-900">Shift Reconciliation</h4>
              <p className="text-sm text-orange-700 mt-1">You must balance the drawer and perform a Z-read before logging out.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <h3 className="font-bold text-slate-50">Recent Transactions</h3>
          <button className="p-2 text-gray-400 hover:text-brand-primary transition-colors">
            <RefreshCw size={18} />
          </button>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 text-slate-400 text-sm border-b border-slate-800">
              <th className="p-4 font-medium">Time</th>
              <th className="p-4 font-medium">Receipt No.</th>
              <th className="p-4 font-medium">Type</th>
              <th className="p-4 font-medium">Method</th>
              <th className="p-4 font-medium text-right">Amount</th>
              <th className="p-4 font-medium text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {shiftData.recentTransactions?.map((tx: any) => (
              <tr key={tx.id} className="border-b border-gray-50 hover:bg-slate-900/50 transition-colors">
                <td className="p-4 text-slate-400">{new Date(tx.time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</td>
                <td className="p-4 font-mono text-sm">{tx.receipt}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    tx.type === 'PAYMENT' ? 'bg-emerald-500/10 text-emerald-700' : 'bg-red-500/10 text-red-700'
                  }`}>
                    {tx.type}
                  </span>
                </td>
                <td className="p-4 text-slate-400">{tx.method.replace('_', ' ')}</td>
                <td className="p-4 text-right font-medium text-slate-50">${tx.amount.toFixed(2)}</td>
                <td className="p-4 text-center">
                  {tx.receipt !== 'N/A' && (
                    <button className="p-1.5 text-gray-400 hover:text-brand-primary transition-colors inline-block" title="View Receipt">
                      <FileText size={18} />
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {(!shiftData.recentTransactions || shiftData.recentTransactions.length === 0) && (
              <tr><td colSpan={6} className="p-4 text-center text-slate-400">No transactions yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
