"use client";

import { useState, useEffect } from 'react';
import { 
  Search, Filter, FileText, CheckCircle2,
  MoreHorizontal, Wallet, AlertCircle, ArrowUpRight
} from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';

export default function ClosedFoliosPage() {
  const [folios, setFolios] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFolios = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/guest-folios?status=CLOSED`);
        if (response.ok) {
          const data = await response.json();
          const mapped = data.map((f: any) => ({
            id: `FOL-${f.id.substring(0, 6).toUpperCase()}`,
            rawId: f.id,
            stayId: f.stay?.stayNumber || 'Unknown',
            guestName: f.primaryCustomer?.displayName || f.corporateAccount?.name || 'Unknown Guest',
            room: f.stay?.roomAssignments?.[0]?.room?.roomNumber || 'N/A',
            status: f.status,
            balance: f.currentBalance || 0,
            totalCharges: f.totalCharges || 0,
            totalPayments: f.totalPayments || 0,
            lastUpdated: new Date(f.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }));
          setFolios(mapped);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchFolios();
    socket.on('folios.updated', fetchFolios);
    socket.on('guestFolios.updated', fetchFolios);
    return () => {
      socket.off('folios.updated', fetchFolios);
      socket.off('guestFolios.updated', fetchFolios);
    };
  }, []);

  return (
    <div className="space-y-6">
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Closed Folios</h2>
          <p className="text-slate-400">Manage running tabs, charges, and payments.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border flex flex-col md:flex-row p-4 gap-4 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-slate-700 rounded-md leading-5 bg-slate-950 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-brand-primary focus:border-brand-primary sm:text-sm transition duration-150 ease-in-out"
            placeholder="Search by folio ID, guest name, or room..."
          />
        </div>
        
        <div className="flex gap-2 w-full md:w-auto">
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-700 rounded-md text-sm font-medium text-slate-300 bg-slate-950 hover:bg-slate-900">
            <Filter size={16} /> Filters
          </button>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-slate-900">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Folio & Guest</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Charges</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Payments</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Balance</th>
                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody className="bg-slate-950 divide-y divide-gray-200">
              {loading ? (
                <tr><td colSpan={6} className="px-6 py-4 text-center text-slate-400">Loading folios...</td></tr>
              ) : folios.length === 0 ? (
                <tr><td colSpan={6} className="px-6 py-4 text-center text-slate-400">No folios found.</td></tr>
              ) : folios.map((folio) => (
                <tr key={folio.id} className="hover:bg-slate-900 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400">
                        <FileText size={20} />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-slate-50">{folio.id}</div>
                        <div className="text-sm text-slate-400">Room {folio.room} â€¢ {folio.guestName}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      folio.status === 'CLOSED' ? 'bg-emerald-500/10 text-emerald-400' :
                      folio.status === 'DISPUTED' ? 'bg-red-500/10 text-red-400' :
                      'bg-blue-500/10 text-blue-400'
                    }`}>
                      {folio.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">
                    ${folio.totalCharges.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                    ${folio.totalPayments.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm font-bold ${folio.balance > 0 ? 'text-red-600' : 'text-slate-50'}`}>
                      ${folio.balance.toFixed(2)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end gap-2">
                      <Link href={`/dashboard/folios/${folio.rawId}`} className="text-brand-primary hover:text-brand-primary/80 px-3 py-1 bg-brand-primary/10 rounded-md transition-colors flex items-center gap-1">
                        View <ArrowUpRight size={14} />
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
