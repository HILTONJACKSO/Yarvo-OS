"use client";

import { useState, useEffect, useRef } from 'react';
import { Search, Save, AlertTriangle, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';

type InventoryItem = { id: string; name: string; code: string; averageUnitCost?: number | null; initialUnitCost?: number | null; standardCost?: number | null; baseUnitId?: string };
type Location = { id: string; name: string };
type Unit = { id: string; name: string; code: string };

export default function NewWastePage() {
  const router = useRouter();
  const [locations, setLocations] = useState<Location[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Form state
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [locationId, setLocationId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unitId, setUnitId] = useState('');
  const [wasteType, setWasteType] = useState('SPOILAGE');
  const [reason, setReason] = useState('');

  // Search state
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<InventoryItem[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchAll = async () => {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';

      let bid = 'bus-kwalee-1';
      try {
        const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
        if (bRes.ok) {
          const bData = await bRes.json();
          if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
          else if (bData?.businessId) bid = bData.businessId;
          else if (bData?.id) bid = bData.id;
        }
      } catch {}

      const headers = { 'x-business-id': bid, 'Authorization': `Bearer ${token}` };

      try {
        const [locRes, unitRes, itemRes] = await Promise.all([
          fetch(`${apiUrl}/inventory/locations`, { headers }),
          fetch(`${apiUrl}/inventory/units`, { headers }),
          fetch(`${apiUrl}/inventory/items`, { headers }),
        ]);

        const [locData, unitData, itemData] = await Promise.all([
          locRes.ok ? locRes.json() : [],
          unitRes.ok ? unitRes.json() : [],
          itemRes.ok ? itemRes.json() : [],
        ]);

        setLocations(Array.isArray(locData) ? locData : []);
        setUnits(Array.isArray(unitData) ? unitData : []);
        setInventoryItems(Array.isArray(itemData) ? itemData : (itemData?.items || []));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  // Search logic
  useEffect(() => {
    if (!search.trim()) {
      setSearchResults([]);
      setShowDropdown(false);
      return;
    }
    const filtered = inventoryItems.filter(i =>
      i.name.toLowerCase().includes(search.toLowerCase()) ||
      i.code?.toLowerCase().includes(search.toLowerCase())
    ).slice(0, 8);
    setSearchResults(filtered);
    setShowDropdown(filtered.length > 0);
  }, [search, inventoryItems]);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSelectItem = (item: InventoryItem) => {
    setSelectedItem(item);
    setUnitId(item.baseUnitId || units[0]?.id || '');
    setSearch('');
    setShowDropdown(false);
  };

  const handleSave = async (status: 'APPROVED' | 'PENDING') => {
    if (!selectedItem) { toast.error('Please select an inventory item'); return; }
    if (!locationId) { toast.error('Please select a store location'); return; }
    if (quantity <= 0) { toast.error('Quantity must be greater than zero'); return; }

    setSaving(true);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';

      let bid = 'bus-kwalee-1';
      try {
        const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
        if (bRes.ok) {
          const bData = await bRes.json();
          if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
          else if (bData?.businessId) bid = bData.businessId;
          else if (bData?.id) bid = bData.id;
        }
      } catch {}

      const res = await fetch(`${apiUrl}/inventory/waste`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-business-id': bid,
          'x-branch-id': 'branch-kwalee-1',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          inventoryItemId: selectedItem.id,
          stockLocationId: locationId,
          quantity,
          unitId,
          wasteType,
          reason,
          status,
        }),
      });

      if (res.ok) {
        toast.success(status === 'APPROVED' ? 'Waste recorded successfully!' : 'Waste submitted for approval!');
        router.push('/dashboard/inventory/waste');
      } else {
        const err = await res.json();
        toast.error(err.message || 'Failed to record waste');
      }
    } catch (e) {
      console.error(e);
      toast.error('Something went wrong');
    } finally {
      setSaving(false);
    }
  };

  const getCost = (item: InventoryItem | null) => {
    if (!item) return 0;
    return item.averageUnitCost || item.initialUnitCost || item.standardCost || 0;
  };
  const estimatedLostValue = selectedItem ? quantity * getCost(selectedItem) : 0;

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary" />
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/waste" className="text-sm text-brand-primary hover:underline mb-2 inline-block">← Back to Waste Logs</Link>
          <h1 className="text-2xl font-bold text-slate-50">Record Waste</h1>
          <p className="text-slate-400 mt-1">Log spoiled, damaged, or expired stock to keep inventory accurate.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 overflow-hidden">
        <div className="p-6 border-b border-slate-800 space-y-6">
          
          {/* Item Selection */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-300">Inventory Item <span className="text-red-500">*</span></label>
            
            {!selectedItem ? (
              <div className="relative" ref={searchRef}>
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="text"
                  placeholder="Search and select an item to write off..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm bg-slate-900 text-slate-100 placeholder:text-slate-500"
                />
                {showDropdown && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-50 max-h-64 overflow-y-auto">
                    {searchResults.map(item => (
                      <button
                        key={item.id}
                        onClick={() => handleSelectItem(item)}
                        className="w-full text-left px-4 py-3 hover:bg-slate-700 transition flex items-center justify-between"
                      >
                        <div>
                          <p className="text-slate-100 font-medium text-sm">{item.name}</p>
                          <p className="text-slate-500 text-xs font-mono mt-0.5">{item.code}</p>
                        </div>
                        <span className="text-xs font-medium text-brand-primary">Select</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-between p-4 border border-brand-primary/30 bg-brand-primary/5 rounded-lg">
                <div>
                  <h3 className="text-lg font-bold text-brand-primary">{selectedItem.name}</h3>
                  <p className="text-sm text-slate-400 font-mono mt-1">{selectedItem.code}</p>
                </div>
                <button 
                  onClick={() => setSelectedItem(null)}
                  className="px-3 py-1.5 text-xs font-medium bg-slate-800 text-slate-300 rounded hover:bg-slate-700 transition"
                >
                  Change Item
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Store Location <span className="text-red-500">*</span></label>
              <select
                value={locationId}
                onChange={e => setLocationId(e.target.value)}
                className="w-full px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100"
              >
                <option value="">— Select a store —</option>
                {locations.map(l => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Waste Type <span className="text-red-500">*</span></label>
              <select
                value={wasteType}
                onChange={e => setWasteType(e.target.value)}
                className="w-full px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100"
              >
                <option value="SPOILAGE">Spoilage (Food/Drink gone bad)</option>
                <option value="BREAKAGE">Breakage (Dropped/Smashed)</option>
                <option value="EXPIRATION">Expiration (Past Use-by Date)</option>
                <option value="THEFT">Theft (Missing Stock)</option>
                <option value="OTHER">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Quantity <span className="text-red-500">*</span></label>
              <div className="flex gap-2">
                <input
                  type="number"
                  min={0.1}
                  step={0.1}
                  value={quantity}
                  onChange={e => setQuantity(parseFloat(e.target.value) || 0)}
                  className="w-2/3 px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100"
                />
                <select
                  value={unitId}
                  onChange={e => setUnitId(e.target.value)}
                  className="w-1/3 px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100"
                >
                  {units.map(u => (
                    <option key={u.id} value={u.id}>{u.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Estimated Lost Value</label>
              <div className="w-full px-4 py-2.5 border border-red-500/30 rounded-lg bg-red-500/5 text-red-400 font-bold flex items-center">
                ${estimatedLostValue.toFixed(2)}
              </div>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Reason / Notes</label>
            <textarea
              value={reason}
              onChange={e => setReason(e.target.value)}
              placeholder="Provide a brief explanation of what happened..."
              rows={3}
              className="w-full px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100 placeholder:text-slate-500"
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex justify-between items-center">
          <Link href="/dashboard/inventory/waste" className="px-4 py-2 border border-slate-700 rounded-lg text-slate-300 hover:bg-slate-800 font-medium transition">
            Cancel
          </Link>
          <div className="flex gap-3">
            <button
              onClick={() => handleSave('PENDING')}
              disabled={saving}
              className="px-4 py-2 border border-brand-primary/50 text-brand-primary rounded-lg font-medium hover:bg-brand-primary/10 transition flex items-center gap-2 disabled:opacity-50"
            >
              Submit for Approval
            </button>
            <button
              onClick={() => handleSave('APPROVED')}
              disabled={saving}
              className="px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <AlertTriangle size={16} />}
              Write Off Stock Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
