"use client";

import { useState, useEffect } from 'react';
import { Search, AlertTriangle, Plus, FileText, Trash2, Check, X } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';

export default function InventoryWastePage() {
  const [waste, setWaste] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterLocation, setFilterLocation] = useState('');
  const [locations, setLocations] = useState<any[]>([]);

  const fetchData = async () => {
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';

      let bid = 'bus-kwalee-1';
      try {
        const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
        if (bRes.ok) {
          const bData = await bRes.json();
          if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
          else if (bData?.businessId) bid = bData.businessId;
          else if (bData?.id) bid = bData.id;
        }
      } catch {}

      const headers = { 'x-business-id': bid, 'Authorization': `Bearer ${token}` };

      const [wasteRes, locRes] = await Promise.all([
        fetch(`${apiUrl}/inventory/waste`, { headers }),
        fetch(`${apiUrl}/inventory/locations`, { headers })
      ]);

      if (wasteRes.ok) setWaste(await wasteRes.json());
      if (locRes.ok) setLocations(await locRes.json());

    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || '');
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  // Stats calculation
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const thisMonthWaste = waste.filter(w => {
    const d = new Date(w.createdAt);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear && w.status !== 'REJECTED';
  });

  const totalWasteValue = thisMonthWaste.reduce((sum, w) => sum + (w.totalCost || 0), 0);
  const pendingApprovals = waste.filter(w => w.status === 'PENDING').length;

  // Top waste category/item
  const itemWasteCosts: Record<string, number> = {};
  thisMonthWaste.forEach(w => {
    const name = w.inventoryItem?.name || 'Unknown Item';
    itemWasteCosts[name] = (itemWasteCosts[name] || 0) + (w.totalCost || 0);
  });
  
  let topCategory = '-';
  let highestCost = 0;
  Object.entries(itemWasteCosts).forEach(([item, cost]) => {
    if (cost > highestCost) {
      highestCost = cost;
      topCategory = item;
    }
  });

  const handleUpdateStatus = async (id: string, status: string) => {
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';
      const res = await fetch(`${apiUrl}/inventory/waste/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ status })
      });

      if (res.ok) {
        toast.success(`Waste record ${status.toLowerCase()} successfully`);
        fetchData();
      } else {
        const err = await res.json();
        toast.error(err.message || 'Failed to update status');
      }
    } catch (e) {
      toast.error('An error occurred');
    }
  };

  const filteredWaste = waste.filter(w => {
    const matchesSearch = !search || 
      w.wasteNumber?.toLowerCase().includes(search.toLowerCase()) || 
      w.inventoryItem?.name?.toLowerCase().includes(search.toLowerCase()) ||
      w.reason?.toLowerCase().includes(search.toLowerCase());
    
    const matchesLocation = !filterLocation || w.stockLocationId === filterLocation;
    
    return matchesSearch && matchesLocation;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Waste & Damages</h1>
          <p className="text-slate-400 mt-1">Record spoilage, breakages, and expired stock to adjust inventory accurately.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/inventory/waste/new" className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-primary/90 transition flex items-center gap-2">
            <Plus size={18} /> Record Waste
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-500/10 text-red-500 rounded-lg"><AlertTriangle size={24} /></div>
          <div>
            <p className="text-slate-400 font-medium text-sm">Total Waste (This Month)</p>
            <h3 className="text-2xl font-black text-slate-50">${totalWasteValue.toFixed(2)}</h3>
          </div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-orange-500/10 text-orange-500 rounded-lg"><FileText size={24} /></div>
          <div>
            <p className="text-slate-400 font-medium text-sm">Pending Approvals</p>
            <h3 className="text-2xl font-black text-slate-50">{pendingApprovals}</h3>
          </div>
        </div>
        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-slate-800 text-slate-400 rounded-lg"><Trash2 size={24} /></div>
          <div>
            <p className="text-slate-400 font-medium text-sm">Top Waste Item</p>
            <h3 className="text-lg font-bold text-slate-50 truncate w-48" title={topCategory}>{topCategory}</h3>
          </div>
        </div>
      </div>

      <div className="bg-slate-950 border border-slate-800 rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-800 bg-slate-900/50 flex items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search waste logs..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-700 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm bg-slate-900 text-slate-100 placeholder:text-slate-500"
            />
          </div>
          <select 
            value={filterLocation}
            onChange={(e) => setFilterLocation(e.target.value)}
            className="px-4 py-2 border border-slate-700 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-900 text-sm"
          >
            <option value="">All Locations</option>
            {locations.map(loc => (
              <option key={loc.id} value={loc.id}>{loc.name}</option>
            ))}
          </select>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b border-slate-800 text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Ref #</th>
              <th className="p-4 font-semibold">Date</th>
              <th className="p-4 font-semibold">Item</th>
              <th className="p-4 font-semibold">Location</th>
              <th className="p-4 font-semibold">Quantity</th>
              <th className="p-4 font-semibold">Reason</th>
              <th className="p-4 font-semibold text-right">Lost Value</th>
              <th className="p-4 font-semibold text-center">Status</th>
              <th className="p-4 font-semibold text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-sm">
            {loading ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400">Loading waste logs...</td>
              </tr>
            ) : filteredWaste.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-500">No waste records found</td>
              </tr>
            ) : (
              filteredWaste.map((log) => (
                <tr key={log.id} className="hover:bg-slate-900/50">
                  <td className="p-4 font-mono text-xs text-brand-primary font-medium">{log.wasteNumber}</td>
                  <td className="p-4 text-slate-400">{new Date(log.createdAt).toLocaleDateString()}</td>
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{log.inventoryItem?.name || 'Unknown Item'}</span>
                      <span className="text-xs text-slate-500 font-mono">{log.inventoryItem?.code}</span>
                    </div>
                  </td>
                  <td className="p-4 text-slate-400">{log.stockLocation?.name || '-'}</td>
                  <td className="p-4 font-medium text-red-500">
                    - {log.quantity} {log.unit?.name || ''}
                  </td>
                  <td className="p-4 text-slate-400 truncate max-w-[200px]" title={log.reason}>{log.reason || '-'}</td>
                  <td className="p-4 text-right font-medium text-red-500">${(log.totalCost || 0).toFixed(2)}</td>
                  <td className="p-4 text-center">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      log.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 
                      log.status === 'REJECTED' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 
                      log.status === 'PENDING' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                      'bg-slate-500/10 text-slate-400 border border-slate-500/20'
                    }`}>
                      {log.status}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    {log.status === 'PENDING' && (
                      <div className="flex items-center justify-center gap-2">
                        <button 
                          onClick={() => handleUpdateStatus(log.id, 'APPROVED')}
                          title="Approve"
                          className="p-1.5 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 rounded-md transition"
                        >
                          <Check size={16} />
                        </button>
                        <button 
                          onClick={() => handleUpdateStatus(log.id, 'REJECTED')}
                          title="Reject"
                          className="p-1.5 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-md transition"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
