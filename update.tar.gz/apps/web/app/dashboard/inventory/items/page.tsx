"use client";

import { useState, useEffect } from 'react';
import { Plus, Search, Filter, Download, Upload, MoreHorizontal } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';
import { ConfirmationModal } from '@/components/ui/confirmation-modal';

export default function InventoryItemsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      const [itemsRes, catsRes] = await Promise.all([
        fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/items`),
        fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/categories`, {
          headers: { 'x-business-id': 'bus-kwalee-1' }
        })
      ]);
      if (itemsRes.ok) setItems(await itemsRes.json());
      if (catsRes.ok) setCategories(await catsRes.json());
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!itemToDelete) return;
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/${itemToDelete}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchData();
      } else {
        toast.error('Failed to delete item');
      }
    } catch (err) {
      console.error(err);
      toast.error('Error deleting item');
    } finally {
      setItemToDelete(null);
      setActiveDropdown(null);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Stock Items</h1>
          <p className="text-slate-400 mt-1">Master catalog of all physical goods, ingredients, and supplies.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-slate-300 hover:bg-slate-900 transition flex items-center gap-2">
            <Upload size={18} /> Import
          </button>
          <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-slate-300 hover:bg-slate-900 transition flex items-center gap-2">
            <Download size={18} /> Export
          </button>
          <Link href="/dashboard/inventory/items/new" className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
            <Plus size={18} /> Add Stock Item
          </Link>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-visible">
        <div className="p-4 border-b bg-slate-900 rounded-t-xl flex flex-wrap items-center gap-4">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by name, code..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
          <button className="px-4 py-2 bg-slate-950 border rounded-md font-medium text-slate-300 hover:bg-slate-900 transition flex items-center gap-2 text-sm">
            <Filter size={16} /> Filter
          </button>
          <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950 text-sm">
            <option value="">All Categories</option>
            <option value="beer">Beer</option>
            <option value="meat">Meat and Poultry</option>
          </select>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Item Name</th>
              <th className="p-4 font-semibold">Code</th>
              <th className="p-4 font-semibold">Category</th>
              <th className="p-4 font-semibold text-right">Available</th>
              <th className="p-4 font-semibold text-right">Min. Level</th>
              <th className="p-4 font-semibold text-right">Value</th>
              <th className="p-4 font-semibold text-center">Status</th>
              <th className="p-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {items.map((item) => (
              <tr key={item.id} className="hover:bg-slate-900">
                <td className="p-4 font-medium text-slate-50">
                  <div className="flex flex-col">
                    <span>{item.name}</span>
                    <span className="text-xs text-gray-400">{item.inventoryType?.replace('_', ' ')}</span>
                  </div>
                </td>
                <td className="p-4 text-slate-400 font-mono text-xs">{item.code}</td>
                <td className="p-4 text-slate-400">{categories.find(c => c.id === item.categoryId)?.name || item.categoryId}</td>
                <td className="p-4 text-right">
                  <span className={`font-medium ${(item.available || 0) <= (item.minimumStockLevel || 0) ? 'text-red-600' : 'text-slate-50'}`}>
                    {item.available || 0}
                  </span>
                </td>
                <td className="p-4 text-right text-slate-400">{item.minimumStockLevel || 0}</td>
                <td className="p-4 text-right text-slate-400">${(item.standardCost || item.initialUnitCost || 0).toFixed(2)}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${item.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-slate-800 text-slate-300'}`}>
                    {item.status}
                  </span>
                </td>
                <td className="p-4 text-right relative">
                  <button onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)} className="p-1.5 text-gray-400 hover:text-brand-primary rounded"><MoreHorizontal size={18}/></button>
                  {activeDropdown === item.id && (
                    <div className="absolute right-8 top-10 w-48 bg-slate-800 rounded-md shadow-lg border border-slate-700 z-10 overflow-hidden">
                      <div className="py-1">
                        <Link href={`/dashboard/inventory/items/${item.id}/edit`} className="block px-4 py-2 text-sm text-slate-300 hover:bg-slate-700 w-full text-left">
                          Edit Item
                        </Link>
                        <button onClick={() => setItemToDelete(item.id)} className="block px-4 py-2 text-sm text-red-400 hover:bg-slate-700 w-full text-left">
                          Delete Item
                        </button>
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <ConfirmationModal
        isOpen={!!itemToDelete}
        onClose={() => setItemToDelete(null)}
        onConfirm={handleDelete}
        title="Confirm Deletion"
        message="Are you sure you want to delete this item?"
        confirmText="Delete"
      />
    </div>
  );
}
