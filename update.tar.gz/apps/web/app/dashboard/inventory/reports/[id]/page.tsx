"use client";

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { FileText, BarChart3, Download, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

export default function ReportViewerPage() {
  const { id } = useParams();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any[]>([]);
  const [columns, setColumns] = useState<{key: string, label: string, type?: string}[]>([]);
  
  const reportTitles: Record<string, string> = {
    'stock-valuation-report': 'Stock Valuation Report',
    'consumption-usage': 'Consumption & Usage',
    'waste-spoilage-analysis': 'Waste & Spoilage Analysis',
    'low-stock-alerts': 'Low Stock Alerts',
    'stock-movement-ledger': 'Stock Movement Ledger'
  };

  const title = typeof id === 'string' && reportTitles[id] ? reportTitles[id] : 'Inventory Report';

  useEffect(() => {
    const fetchReportData = async () => {
      try {
        const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
        const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';
        let bid = 'bus-kwalee-1';
        try {
          const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
          if (bRes.ok) {
            const bData = await bRes.json();
            if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
            else if (bData?.businessId) bid = bData.businessId;
            else if (bData?.id) bid = bData.id;
          }
        } catch {}

        const headers = { 'x-business-id': bid, 'Authorization': `Bearer ${token}` };
        
        let endpoint = '';
        if (id === 'stock-valuation-report' || id === 'low-stock-alerts') endpoint = '/inventory/stock-levels';
        else if (id === 'waste-spoilage-analysis') endpoint = '/inventory/waste';
        else if (id === 'stock-movement-ledger' || id === 'consumption-usage') endpoint = '/inventory/movements';

        if (!endpoint) {
          setLoading(false);
          return;
        }

        const response = await fetch(`${apiUrl}${endpoint}`, { headers });
        if (response.ok) {
          const rawData = await response.json();
          let processed = [];
          let cols = [];

          if (id === 'stock-valuation-report') {
            cols = [
              { key: 'name', label: 'Item Name' },
              { key: 'code', label: 'Code' },
              { key: 'location', label: 'Location' },
              { key: 'quantity', label: 'Quantity Available' },
              { key: 'cost', label: 'Unit Cost', type: 'currency' },
              { key: 'total', label: 'Total Value', type: 'currency' },
            ];
            processed = rawData.map((d: any) => ({
              name: d.item?.name,
              code: d.item?.code,
              location: d.location?.name,
              quantity: d.quantityAvailable,
              cost: d.unitCost,
              total: d.stockValue
            }));
          } else if (id === 'low-stock-alerts') {
             cols = [
              { key: 'name', label: 'Item Name' },
              { key: 'code', label: 'Code' },
              { key: 'location', label: 'Location' },
              { key: 'quantity', label: 'Quantity Available' },
              { key: 'min', label: 'Min Level' },
            ];
            processed = rawData
              .filter((d: any) => d.quantityAvailable <= 10)
              .map((d: any) => ({
                name: d.item?.name,
                code: d.item?.code,
                location: d.location?.name,
                quantity: d.quantityAvailable,
                min: 10
              }));
          } else if (id === 'waste-spoilage-analysis') {
            cols = [
              { key: 'date', label: 'Date', type: 'date' },
              { key: 'item', label: 'Item' },
              { key: 'type', label: 'Waste Type' },
              { key: 'qty', label: 'Quantity Wasted' },
              { key: 'value', label: 'Lost Value', type: 'currency' },
              { key: 'reason', label: 'Reason' },
            ];
            processed = rawData.map((w: any) => ({
              date: w.createdAt,
              item: w.inventoryItem?.name,
              type: w.wasteType,
              qty: w.quantity,
              value: w.totalCost,
              reason: w.reason
            }));
          } else {
             cols = [
              { key: 'date', label: 'Date', type: 'date' },
              { key: 'type', label: 'Type' },
              { key: 'item', label: 'Item' },
              { key: 'qty', label: 'Quantity' },
            ];
            processed = rawData.map((m: any) => ({
              date: m.createdAt,
              type: m.movementType,
              item: m.inventoryItem?.name,
              qty: m.quantity
            }));
          }

          setColumns(cols);
          setData(processed);
        } else {
          toast.error('Failed to load report data');
        }
      } catch (error) {
        console.error(error);
        toast.error('Error loading report');
      } finally {
        setLoading(false);
      }
    };

    fetchReportData();
  }, [id]);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/reports" className="text-sm text-brand-primary hover:underline mb-2 flex items-center gap-1">
            <ArrowLeft size={14} /> Back to Reports
          </Link>
          <h1 className="text-2xl font-bold text-slate-50 flex items-center gap-3">
            <BarChart3 className="text-brand-primary" /> {title}
          </h1>
        </div>
        <button className="px-4 py-2 bg-slate-800 text-slate-200 rounded-md font-medium hover:bg-slate-700 transition flex items-center gap-2 border border-slate-700">
          <Download size={16} /> Export CSV
        </button>
      </div>

      <div className="bg-slate-950 border border-slate-800 rounded-xl shadow-sm overflow-hidden min-h-[400px]">
        {loading ? (
          <div className="flex items-center justify-center h-64 text-slate-400 flex-col gap-3">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
            <p>Generating report data...</p>
          </div>
        ) : data.length === 0 ? (
          <div className="flex items-center justify-center h-64 text-slate-500 flex-col gap-3">
            <FileText size={48} className="opacity-50" />
            <p>No data available for this report period.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-800 text-xs uppercase text-slate-400">
                  {columns.map(col => (
                    <th key={col.key} className={`p-4 font-semibold ${col.type === 'currency' ? 'text-right' : ''}`}>
                      {col.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-sm">
                {data.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-900/50">
                    {columns.map(col => (
                      <td key={col.key} className={`p-4 text-slate-300 ${col.type === 'currency' ? 'text-right font-medium' : ''}`}>
                        {col.type === 'currency' ? `$${(row[col.key] || 0).toFixed(2)}` : 
                         col.type === 'date' ? new Date(row[col.key]).toLocaleDateString() : 
                         row[col.key] || '-'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
