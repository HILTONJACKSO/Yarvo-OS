"use client";

import { useState, useEffect } from 'react';
import { FileText, TrendingDown, PackageMinus, BarChart3, AlertTriangle, Download } from 'lucide-react';
import Link from 'next/link';

export default function InventoryReportsPage() {
  const reports = [
    {
      title: 'Stock Valuation Report',
      description: 'Current value of all inventory items based on moving average cost.',
      icon: <BarChart3 className="text-blue-500" size={24} />,
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Consumption & Usage',
      description: 'Detailed view of items consumed via POS recipes and direct department issues.',
      icon: <TrendingDown className="text-green-500" size={24} />,
      bgColor: 'bg-green-50',
    },
    {
      title: 'Waste & Spoilage Analysis',
      description: 'Financial impact of damaged, expired, or spoiled inventory items.',
      icon: <PackageMinus className="text-red-500" size={24} />,
      bgColor: 'bg-red-50',
    },
    {
      title: 'Low Stock Alerts',
      description: 'Items currently below their defined minimum par levels across all locations.',
      icon: <AlertTriangle className="text-amber-500" size={24} />,
      bgColor: 'bg-amber-50',
    },
    {
      title: 'Stock Movement Ledger',
      description: 'Complete audit trail of all physical transfers and receipts between dates.',
      icon: <FileText className="text-purple-500" size={24} />,
      bgColor: 'bg-purple-50',
    }
  ];

  const [locations, setLocations] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedPeriod, setSelectedPeriod] = useState('This Month');

  useEffect(() => {
    const fetchDropdownData = async () => {
      try {
        const token = localStorage.getItem('access_token');
        if (!token) return;

        const headers = { 'Authorization': `Bearer ${token}` };

        // We fetch from the current business endpoints if we have the generic API structure
        const resLocations = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/stock-locations`, { headers });
        if (resLocations.ok) {
          const locData = await resLocations.json();
          setLocations(Array.isArray(locData) ? locData : []);
        }

        const resCategories = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/inventory-categories`, { headers });
        if (resCategories.ok) {
          const catData = await resCategories.json();
          setCategories(Array.isArray(catData) ? catData : []);
        }
      } catch (err) {
        console.error('Failed to fetch dropdown data', err);
      }
    };

    fetchDropdownData();
  }, []);

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Inventory Reports</h1>
          <p className="text-slate-400 mt-1">Analyze stock valuation, usage, and operational efficiency.</p>
        </div>
      </div>

      <div className="bg-slate-950 p-6 rounded-xl border shadow-sm space-y-6">
        <div className="flex gap-4 p-4 bg-slate-900 rounded-lg border items-start">
          <div className="flex-1 flex flex-col gap-2">
            <label className="block text-sm font-medium text-slate-300 mb-1">Report Period</label>
            <select 
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm"
            >
              <option value="This Month">This Month</option>
              <option value="Last Month">Last Month</option>
              <option value="This Quarter">This Quarter</option>
              <option value="Year to Date">Year to Date</option>
              <option value="Custom Range">Custom Range</option>
            </select>
            
            {selectedPeriod === 'Custom Range' && (
              <div className="flex gap-2 items-center mt-2">
                <input type="date" className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm" />
                <span className="text-slate-400 text-xs">to</span>
                <input type="date" className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm" />
              </div>
            )}
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Filter by Location</label>
            <select 
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm"
            >
              <option value="">All Locations</option>
              {locations.map((loc: any) => (
                <option key={loc.id} value={loc.id}>{loc.name || loc.locationName}</option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Filter by Category</label>
            <select 
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm"
            >
              <option value="">All Categories</option>
              {categories.map((cat: any) => (
                <option key={cat.id} value={cat.id}>{cat.name || cat.categoryName}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {reports.map((report, idx) => (
            <div key={idx} className="border rounded-xl p-5 flex gap-4 hover:border-brand-primary/50 hover:shadow-md transition cursor-pointer group">
              <div className={`p-4 ${report.bgColor} rounded-lg h-fit group-hover:scale-110 transition-transform`}>
                {report.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-slate-50">{report.title}</h3>
                <p className="text-sm text-slate-400 mt-1">{report.description}</p>
                <div className="mt-4 flex gap-2">
                  <Link href={`/dashboard/inventory/reports/${report.title.toLowerCase().replace(/ & | /g, '-')}`} className="text-xs font-medium text-brand-primary hover:underline flex items-center gap-1">
                    <BarChart3 size={14} /> View Report
                  </Link>
                  <button className="text-xs font-medium text-slate-400 hover:text-slate-50 flex items-center gap-1 ml-auto">
                    <Download size={14} /> Export CSV
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
