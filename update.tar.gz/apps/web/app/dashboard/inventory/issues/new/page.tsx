"use client";

import { useState, useEffect } from 'react';
import { Search, Save, Send, Trash2, ArrowDownCircle } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function NewDepartmentIssuePage() {
  const router = useRouter();
  const [locations, setLocations] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [inventoryItems, setInventoryItems] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    sourceLocationId: '',
    departmentId: '',
    purpose: '',
  });

  const [selectedItems, setSelectedItems] = useState<any[]>([]);

  useEffect(() => {
    // Fetch locations, departments and inventory items
    const fetchData = async () => {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';
      
      try {
        let bid = 'bus-kwalee-1';
        try {
          const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
          if (bRes.ok) {
            const bData = await bRes.json();
            if (Array.isArray(bData) && bData.length > 0) {
              bid = bData[0].businessId || bData[0].id || bid;
            } else if (bData && bData.businessId) {
              bid = bData.businessId;
            } else if (bData && bData.id) {
              bid = bData.id;
            }
          }
        } catch (e) {
          console.error('Could not fetch business:', e);
        }

        const [locRes, deptRes, itemsRes] = await Promise.all([
          fetch(`${apiUrl}/inventory/locations`, {
            headers: { 'x-business-id': bid, 'x-branch-id': 'branch-kwalee-1', 'Authorization': `Bearer ${token}` }
          }),
          fetch(`${apiUrl}/departments`, {
            headers: { 'x-business-id': bid, 'x-branch-id': 'branch-kwalee-1', 'Authorization': `Bearer ${token}` }
          }),
          fetch(`${apiUrl}/inventory/items`, {
            headers: { 'x-business-id': bid, 'x-branch-id': 'branch-kwalee-1', 'Authorization': `Bearer ${token}` }
          })
        ]);

        if (locRes.ok) {
          const locs = await locRes.json();
          setLocations(locs);
          if (locs.length > 0) setFormData(prev => ({ ...prev, sourceLocationId: locs[0].id }));
        }

        if (deptRes.ok) {
          const depts = await deptRes.json();
          setDepartments(depts);
          if (depts.length > 0) setFormData(prev => ({ ...prev, departmentId: depts[0].id }));
        }

        if (itemsRes.ok) {
          const items = await itemsRes.json();
          setInventoryItems(items);
        }
      } catch (error) {
        console.error('Failed to fetch data:', error);
      }
    };

    fetchData();
  }, []);

  const handleAddItem = (item: any) => {
    if (!selectedItems.find(i => i.inventoryItemId === item.id)) {
      setSelectedItems([
        ...selectedItems,
        {
          inventoryItemId: item.id,
          name: item.name,
          code: item.code,
          unitId: item.baseUnit?.id || '',
          unitName: item.baseUnit?.name || 'Unit',
          requestedQuantity: 1,
        }
      ]);
      setSearchQuery('');
    }
  };

  const updateItemQuantity = (id: string, qty: number) => {
    setSelectedItems(selectedItems.map(item => 
      item.inventoryItemId === id ? { ...item, requestedQuantity: qty } : item
    ));
  };

  const removeItem = (id: string) => {
    setSelectedItems(selectedItems.filter(item => item.inventoryItemId !== id));
  };

  const handleSubmit = async (status: 'DRAFT' | 'PENDING' | 'ISSUED') => {
    if (!formData.sourceLocationId || !formData.departmentId || selectedItems.length === 0) {
      alert('Please fill all required fields and add at least one item.');
      return;
    }

    setIsSubmitting(true);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';
      
      let bid = 'bus-kwalee-1';
      try {
        const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
        if (bRes.ok) {
          const bData = await bRes.json();
          if (Array.isArray(bData) && bData.length > 0) {
            bid = bData[0].businessId || bData[0].id || bid;
          } else if (bData && bData.businessId) {
            bid = bData.businessId;
          } else if (bData && bData.id) {
            bid = bData.id;
          }
        }
      } catch (e) {
        console.error('Could not fetch business:', e);
      }

      const response = await fetch(`${apiUrl}/inventory/issues`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-business-id': bid,
          'x-branch-id': 'branch-kwalee-1',
          'x-user-id': 'user-1', // Mocked user
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          sourceLocationId: formData.sourceLocationId,
          departmentId: formData.departmentId,
          purpose: formData.purpose,
          status,
          items: selectedItems.map(i => ({
            inventoryItemId: i.inventoryItemId,
            requestedQuantity: i.requestedQuantity,
            unitId: i.unitId,
          }))
        })
      });

      if (response.ok) {
        router.push('/dashboard/inventory/movements');
        router.refresh();
      } else {
        alert('Failed to submit issue');
      }
    } catch (error) {
      console.error(error);
      alert('An error occurred while submitting.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredItems = inventoryItems.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Issue Stock to Department</h1>
          <p className="text-slate-400 mt-1">Distribute consumable supplies from stores to operational departments.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Source Store <span className="text-red-500">*</span></label>
              <select 
                value={formData.sourceLocationId}
                onChange={e => setFormData({...formData, sourceLocationId: e.target.value})}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-200"
              >
                <option value="" disabled>Select Store</option>
                {locations.map(loc => (
                  <option key={loc.id} value={loc.id}>{loc.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Requesting Department <span className="text-red-500">*</span></label>
              <select 
                value={formData.departmentId}
                onChange={e => setFormData({...formData, departmentId: e.target.value})}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-200"
              >
                <option value="" disabled>Select Department</option>
                {departments.map(dept => (
                  <option key={dept.id} value={dept.id}>{dept.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Purpose / Reason <span className="text-red-500">*</span></label>
              <input 
                type="text" 
                placeholder="e.g., Weekly cleaning supplies" 
                value={formData.purpose}
                onChange={e => setFormData({...formData, purpose: e.target.value})}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-slate-200 bg-slate-950" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Requested By</label>
              <input type="text" defaultValue="Admin User" className="w-full px-4 py-2 border rounded-md bg-slate-900 text-slate-400" disabled />
            </div>
          </div>
        </div>

        <div className="border-t">
          <div className="p-4 bg-slate-900 border-b flex justify-between items-center relative">
            <h3 className="font-bold text-slate-50">Supplies to Issue</h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder="Search to add supply..." 
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm bg-slate-950 text-slate-200"
              />
              
              {searchQuery && (
                <div className="absolute z-10 w-full mt-1 bg-slate-900 border border-slate-700 rounded-md shadow-lg max-h-60 overflow-y-auto">
                  {filteredItems.length > 0 ? (
                    filteredItems.map(item => (
                      <div 
                        key={item.id}
                        onClick={() => handleAddItem(item)}
                        className="px-4 py-2 hover:bg-slate-800 cursor-pointer text-sm text-slate-200 flex justify-between items-center"
                      >
                        <span>{item.name}</span>
                        <span className="text-xs text-slate-500">{item.code}</span>
                      </div>
                    ))
                  ) : (
                    <div className="px-4 py-2 text-sm text-slate-500">No items found</div>
                  )}
                </div>
              )}
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Supply Item</th>
                <th className="p-4 font-semibold text-center w-32">Issue Qty</th>
                <th className="p-4 font-semibold">Unit</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {selectedItems.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-slate-500">
                    No items added yet. Search and select items to issue.
                  </td>
                </tr>
              ) : selectedItems.map((item) => (
                <tr key={item.inventoryItemId} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      min="1"
                      value={item.requestedQuantity}
                      onChange={e => updateItemQuantity(item.inventoryItemId, parseFloat(e.target.value) || 1)}
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-center bg-slate-950 text-slate-200"
                    />
                  </td>
                  <td className="p-4 text-slate-400">{item.unitName}</td>
                  <td className="p-4 text-right">
                    <button 
                      onClick={() => removeItem(item.inventoryItemId)}
                      className="p-1.5 text-gray-400 hover:text-red-600 rounded"
                    >
                      <Trash2 size={18}/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between">
          <Link href="/dashboard/inventory/movements" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          <div className="flex gap-2">
            <button 
              onClick={() => handleSubmit('DRAFT')}
              disabled={isSubmitting}
              className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2 disabled:opacity-50"
            >
              <Save size={18} /> Save as Draft
            </button>
            <button 
              onClick={() => handleSubmit('PENDING')}
              disabled={isSubmitting}
              className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2 disabled:opacity-50"
            >
              <Send size={18} /> Submit Request
            </button>
            <div className="w-px h-8 bg-gray-300 mx-2 self-center"></div>
            <button 
              onClick={() => handleSubmit('ISSUED')}
              disabled={isSubmitting}
              className="px-4 py-2 bg-green-600 text-white rounded-md font-medium hover:bg-green-700 transition flex items-center gap-2 disabled:opacity-50"
            >
              <ArrowDownCircle size={18} /> Issue Immediately
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
