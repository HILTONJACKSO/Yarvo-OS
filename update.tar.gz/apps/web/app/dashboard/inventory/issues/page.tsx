"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { PackageOpen, Plus, Search, Eye, CheckCircle, Clock, AlertCircle, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';

type IssueItem = {
  id: string;
  requestedQuantity: number;
  issuedQuantity?: number;
  inventoryItem: { id: string; name: string; code: string };
  unit?: { id: string; name: string; code: string };
};

type Issue = {
  id: string;
  issueNumber: string;
  status: string;
  purpose?: string;
  createdAt: string;
  department?: { id: string; name: string };
  sourceLocation?: { id: string; name: string };
  items: IssueItem[];
};

const statusConfig: Record<string, { label: string; color: string; icon: React.ComponentType<any> }> = {
  PENDING: { label: 'Pending', color: 'text-amber-400 bg-amber-400/10 border-amber-400/30', icon: Clock },
  ISSUED: { label: 'Issued', color: 'text-blue-400 bg-blue-400/10 border-blue-400/30', icon: CheckCircle },
  USED: { label: 'Fully Used', color: 'text-green-400 bg-green-400/10 border-green-400/30', icon: CheckCircle },
  PARTIAL: { label: 'Partially Used', color: 'text-orange-400 bg-orange-400/10 border-orange-400/30', icon: AlertCircle },
  CANCELLED: { label: 'Cancelled', color: 'text-red-400 bg-red-400/10 border-red-400/30', icon: AlertCircle },
};

export default function DepartmentIssuesPage() {
  const router = useRouter();
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchIssues = async () => {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
    const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';

    let bid = 'bus-kwalee-1';
    try {
      const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
      if (bRes.ok) {
        const bData = await bRes.json();
        if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
        else if (bData?.businessId) bid = bData.businessId;
        else if (bData?.id) bid = bData.id;
      }
    } catch {}

    try {
      const res = await fetch(`${apiUrl}/department-issues`, {
        headers: { 'x-business-id': bid, 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setIssues(Array.isArray(data) ? data : []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchIssues(); }, []);

  const filtered = issues.filter(i => {
    const matchesSearch =
      i.issueNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.department?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.sourceLocation?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.purpose?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || i.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  const getStatusBadge = (status: string) => {
    const cfg = statusConfig[status] || statusConfig['PENDING'];
    const Icon = cfg.icon;
    return (
      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${cfg.color}`}>
        <Icon size={12} />
        {cfg.label}
      </span>
    );
  };

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border border-slate-800 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-orange-500/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none" />
        <div className="relative z-10 flex items-center gap-4">
          <div className="p-4 bg-orange-500/10 text-orange-400 rounded-2xl">
            <PackageOpen size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-50 tracking-tight">Department Issues</h1>
            <p className="text-slate-400 mt-1 font-medium text-sm">Track stock issued to each department and monitor usage.</p>
          </div>
        </div>
        <button
          onClick={() => router.push('/dashboard/inventory/issues/new')}
          className="relative z-10 px-6 py-3 bg-brand-primary text-white rounded-xl font-bold hover:bg-brand-primary/90 transition flex items-center gap-2 shadow-md hover:shadow-lg"
        >
          <Plus size={18} /> New Issue
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 bg-slate-950 p-4 rounded-2xl shadow-sm border border-slate-800 flex items-center gap-3 relative overflow-hidden">
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-gradient-to-b from-brand-primary to-orange-400 rounded-l-2xl" />
          <Search className="text-slate-400 ml-2" size={18} />
          <input
            type="text"
            placeholder="Search by issue #, department, store or purpose..."
            className="w-full bg-transparent border-none focus:outline-none text-slate-50 font-medium placeholder:text-slate-500 text-sm"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="bg-slate-950 rounded-2xl border border-slate-800 p-1 flex gap-1">
          {['ALL', 'PENDING', 'ISSUED', 'USED', 'PARTIAL'].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${statusFilter === s ? 'bg-brand-primary text-white' : 'text-slate-400 hover:text-slate-50 hover:bg-slate-800'}`}
            >
              {s === 'ALL' ? 'All' : (statusConfig[s]?.label || s)}
            </button>
          ))}
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Issues', value: issues.length, color: 'text-slate-300' },
          { label: 'Pending', value: issues.filter(i => i.status === 'PENDING').length, color: 'text-amber-400' },
          { label: 'Issued', value: issues.filter(i => i.status === 'ISSUED').length, color: 'text-blue-400' },
          { label: 'Used / Consumed', value: issues.filter(i => i.status === 'USED' || i.status === 'PARTIAL').length, color: 'text-green-400' },
        ].map(card => (
          <div key={card.label} className="bg-slate-950 rounded-2xl border border-slate-800 p-5">
            <p className="text-slate-500 text-xs font-medium uppercase tracking-wide mb-1">{card.label}</p>
            <p className={`text-3xl font-black ${card.color}`}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Issues list */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-20 bg-slate-950 rounded-3xl border border-slate-800">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-900 mb-6">
              <PackageOpen className="text-slate-600" size={32} />
            </div>
            <h3 className="text-xl font-black text-slate-50 mb-2">No issues found</h3>
            <p className="text-slate-400 font-medium max-w-sm mx-auto">
              {searchTerm || statusFilter !== 'ALL'
                ? 'No issues match your filters. Try adjusting your search.'
                : 'No department stock issues have been created yet.'}
            </p>
          </div>
        ) : (
          filtered.map(issue => {
            const isExpanded = expandedId === issue.id;
            const totalItems = issue.items.reduce((sum, i) => sum + (i.requestedQuantity || 0), 0);
            return (
              <div key={issue.id} className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden transition-all hover:border-slate-600">
                {/* Main row */}
                <div
                  className="flex items-center gap-4 p-5 cursor-pointer"
                  onClick={() => toggleExpand(issue.id)}
                >
                  <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
                    <div>
                      <p className="text-xs text-slate-500 font-medium uppercase tracking-wide mb-0.5">Issue #</p>
                      <p className="text-slate-100 font-bold text-sm">{issue.issueNumber}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-medium uppercase tracking-wide mb-0.5">Department</p>
                      <p className="text-slate-100 font-bold text-sm flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-orange-400 inline-block" />
                        {issue.department?.name || '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-medium uppercase tracking-wide mb-0.5">Source Store</p>
                      <p className="text-slate-300 text-sm font-medium">{issue.sourceLocation?.name || '—'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 font-medium uppercase tracking-wide mb-0.5">Date</p>
                      <p className="text-slate-300 text-sm font-medium">
                        {new Date(issue.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getStatusBadge(issue.status)}
                    <span className="text-slate-500 text-xs font-medium bg-slate-900 px-2.5 py-1 rounded-lg">
                      {issue.items.length} item{issue.items.length !== 1 ? 's' : ''}
                    </span>
                    <div className="text-slate-500 hover:text-slate-300 transition">
                      {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </div>
                  </div>
                </div>

                {/* Expanded detail */}
                {isExpanded && (
                  <div className="border-t border-slate-800 p-5 bg-slate-900/50 space-y-4 animate-in slide-in-from-top-2 duration-200">
                    {issue.purpose && (
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-slate-500 font-medium">Purpose:</span>
                        <span className="text-slate-300">{issue.purpose}</span>
                      </div>
                    )}
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-slate-800">
                            <th className="text-left text-xs font-bold text-slate-500 uppercase tracking-wide pb-3 pr-4">Item</th>
                            <th className="text-left text-xs font-bold text-slate-500 uppercase tracking-wide pb-3 pr-4">SKU</th>
                            <th className="text-right text-xs font-bold text-slate-500 uppercase tracking-wide pb-3 pr-4">Qty Issued</th>
                            <th className="text-right text-xs font-bold text-slate-500 uppercase tracking-wide pb-3">Unit</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/50">
                          {issue.items.map(item => (
                            <tr key={item.id}>
                              <td className="py-3 pr-4">
                                <span className="text-slate-100 font-semibold text-sm">{item.inventoryItem?.name}</span>
                              </td>
                              <td className="py-3 pr-4">
                                <span className="text-slate-500 text-xs font-mono">{item.inventoryItem?.code}</span>
                              </td>
                              <td className="py-3 pr-4 text-right">
                                <span className="text-orange-400 font-bold">{item.requestedQuantity}</span>
                              </td>
                              <td className="py-3 text-right">
                                <span className="text-slate-400 text-sm">{item.unit?.code || item.unit?.name || '—'}</span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Status action bar */}
                    <div className="flex items-center justify-between pt-2">
                      <p className="text-slate-500 text-xs">
                        What happened to this stock? Mark it to keep records accurate.
                      </p>
                      <div className="flex gap-2">
                        {issue.status === 'PENDING' && (
                          <button
                            onClick={async () => {
                              const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
                              const token = localStorage.getItem('access_token');
                              await fetch(`${apiUrl}/department-issues/${issue.id}/status`, {
                                method: 'PATCH',
                                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                                body: JSON.stringify({ status: 'ISSUED' })
                              });
                              fetchIssues();
                            }}
                            className="px-4 py-2 text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-400/30 rounded-xl hover:bg-blue-500/20 transition"
                          >
                            ✓ Mark as Issued
                          </button>
                        )}
                        {(issue.status === 'ISSUED' || issue.status === 'PENDING') && (
                          <>
                            <button
                              onClick={async () => {
                                const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
                                const token = localStorage.getItem('access_token');
                                await fetch(`${apiUrl}/department-issues/${issue.id}/status`, {
                                  method: 'PATCH',
                                  headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                                  body: JSON.stringify({ status: 'PARTIAL' })
                                });
                                fetchIssues();
                              }}
                              className="px-4 py-2 text-xs font-bold bg-orange-500/10 text-orange-400 border border-orange-400/30 rounded-xl hover:bg-orange-500/20 transition"
                            >
                              Partially Used
                            </button>
                            <button
                              onClick={async () => {
                                const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
                                const token = localStorage.getItem('access_token');
                                await fetch(`${apiUrl}/department-issues/${issue.id}/status`, {
                                  method: 'PATCH',
                                  headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                                  body: JSON.stringify({ status: 'USED' })
                                });
                                fetchIssues();
                              }}
                              className="px-4 py-2 text-xs font-bold bg-green-500/10 text-green-400 border border-green-400/30 rounded-xl hover:bg-green-500/20 transition"
                            >
                              ✓ Fully Consumed
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
