"use client";

import { useState, useEffect, useRef } from 'react';
import { Search, Save, Trash2, BookOpen, Plus, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';

type InventoryItem = { id: string; name: string; code: string; averageUnitCost?: number; baseUnitId?: string };
type Location = { id: string; name: string };
type CatalogItem = { id: string; name: string };
type Unit = { id: string; name: string; code: string };

type Ingredient = {
  inventoryItemId: string;
  name: string;
  code: string;
  quantity: number;
  unitId: string;
  unitName: string;
  costPerUnit: number;
};

export default function NewRecipePage() {
  const router = useRouter();
  const [catalogItems, setCatalogItems] = useState<CatalogItem[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [catalogItemId, setCatalogItemId] = useState('');
  const [locationId, setLocationId] = useState('');
  const [outputQuantity, setOutputQuantity] = useState(1);
  const [status, setStatus] = useState<'ACTIVE' | 'DRAFT'>('ACTIVE');

  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [search, setSearch] = useState('');
  const [searchResults, setSearchResults] = useState<InventoryItem[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchAll = async () => {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';

      let bid = 'bus-kwalee-1';
      try {
        const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
        if (bRes.ok) {
          const bData = await bRes.json();
          if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
          else if (bData?.businessId) bid = bData.businessId;
          else if (bData?.id) bid = bData.id;
        }
      } catch {}

      const headers = { 'x-business-id': bid, 'Authorization': `Bearer ${token}` };

      try {
        const [catRes, locRes, unitRes, itemRes] = await Promise.all([
          fetch(`${apiUrl}/catalog/items`, { headers }),
          fetch(`${apiUrl}/inventory/locations`, { headers }),
          fetch(`${apiUrl}/inventory/units`, { headers }),
          fetch(`${apiUrl}/inventory/items`, { headers }),
        ]);

        const [catData, locData, unitData, itemData] = await Promise.all([
          catRes.ok ? catRes.json() : [],
          locRes.ok ? locRes.json() : [],
          unitRes.ok ? unitRes.json() : [],
          itemRes.ok ? itemRes.json() : [],
        ]);

        setCatalogItems(Array.isArray(catData) ? catData : []);
        setLocations(Array.isArray(locData) ? locData : []);
        setUnits(Array.isArray(unitData) ? unitData : []);
        setInventoryItems(Array.isArray(itemData) ? itemData : (itemData?.items || []));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  // Search inventory items
  useEffect(() => {
    if (!search.trim()) {
      setSearchResults([]);
      setShowDropdown(false);
      return;
    }
    const filtered = inventoryItems.filter(i =>
      i.name.toLowerCase().includes(search.toLowerCase()) ||
      i.code?.toLowerCase().includes(search.toLowerCase())
    ).slice(0, 8);
    setSearchResults(filtered);
    setShowDropdown(filtered.length > 0);
  }, [search, inventoryItems]);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const addIngredient = (item: InventoryItem) => {
    if (ingredients.find(i => i.inventoryItemId === item.id)) {
      toast.error(`${item.name} is already added`);
      setSearch('');
      setShowDropdown(false);
      return;
    }
    const defaultUnit = units.find(u => u.id === item.baseUnitId) || units[0];
    setIngredients(prev => [...prev, {
      inventoryItemId: item.id,
      name: item.name,
      code: item.code,
      quantity: 1,
      unitId: defaultUnit?.id || '',
      unitName: defaultUnit?.name || '',
      costPerUnit: item.averageUnitCost || 0,
    }]);
    setSearch('');
    setShowDropdown(false);
  };

  const removeIngredient = (itemId: string) => {
    setIngredients(prev => prev.filter(i => i.inventoryItemId !== itemId));
  };

  const updateIngredient = (itemId: string, field: 'quantity' | 'unitId', value: any) => {
    setIngredients(prev => prev.map(i => {
      if (i.inventoryItemId !== itemId) return i;
      if (field === 'unitId') {
        const unit = units.find(u => u.id === value);
        return { ...i, unitId: value, unitName: unit?.name || '' };
      }
      return { ...i, [field]: value };
    }));
  };

  const totalCost = ingredients.reduce((sum, i) => sum + (i.quantity * i.costPerUnit), 0);

  const handleSave = async (saveStatus: 'ACTIVE' | 'DRAFT') => {
    if (!catalogItemId) { toast.error('Please select a catalog product'); return; }
    if (!locationId) { toast.error('Please select a production store'); return; }
    if (ingredients.length === 0) { toast.error('Please add at least one ingredient'); return; }

    setSaving(true);
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';

      let bid = 'bus-kwalee-1';
      try {
        const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
        if (bRes.ok) {
          const bData = await bRes.json();
          if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
          else if (bData?.businessId) bid = bData.businessId;
          else if (bData?.id) bid = bData.id;
        }
      } catch {}

      const res = await fetch(`${apiUrl}/inventory/recipes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-business-id': bid,
          'x-branch-id': 'branch-kwalee-1',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          catalogItemId,
          preparationLocationId: locationId,
          outputQuantity,
          status: saveStatus,
          ingredients: ingredients.map(i => ({
            inventoryItemId: i.inventoryItemId,
            quantity: i.quantity,
            unitId: i.unitId,
          })),
        }),
      });

      if (res.ok) {
        toast.success('Recipe saved successfully!');
        router.push('/dashboard/inventory/recipes');
      } else {
        const err = await res.json();
        toast.error(err.message || 'Failed to save recipe');
      }
    } catch (e) {
      console.error(e);
      toast.error('Something went wrong');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary" />
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/recipes" className="text-sm text-brand-primary hover:underline mb-2 inline-block">← Back to Recipes</Link>
          <h1 className="text-2xl font-bold text-slate-50">Create Recipe</h1>
          <p className="text-slate-400 mt-1">Link a POS product to its inventory ingredients.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border border-slate-800 overflow-hidden">
        {/* Top fields */}
        <div className="p-6 border-b border-slate-800">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Link to Catalog Product <span className="text-red-500">*</span></label>
              <select
                value={catalogItemId}
                onChange={e => setCatalogItemId(e.target.value)}
                className="w-full px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100"
              >
                <option value="">— Select a product —</option>
                {catalogItems.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Expected Yield / Portions</label>
              <input
                type="number"
                min={1}
                value={outputQuantity}
                onChange={e => setOutputQuantity(Number(e.target.value))}
                className="w-full px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Production Store <span className="text-red-500">*</span></label>
              <select
                value={locationId}
                onChange={e => setLocationId(e.target.value)}
                className="w-full px-4 py-2.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 bg-slate-900 text-slate-100"
              >
                <option value="">— Select a store —</option>
                {locations.map(l => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>
              <p className="text-xs text-slate-500 mt-1">Ingredients will be deducted from this location when the product is sold.</p>
            </div>
          </div>
        </div>

        {/* Ingredients */}
        <div>
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex justify-between items-center">
            <h3 className="font-bold text-slate-50 flex items-center gap-2"><BookOpen size={18} /> Recipe Ingredients</h3>
            <div className="relative w-72" ref={searchRef}>
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input
                type="text"
                placeholder="Search inventory items..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm bg-slate-950 text-slate-100 placeholder:text-slate-500"
              />
              {showDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-slate-900 border border-slate-700 rounded-lg shadow-xl z-50 max-h-64 overflow-y-auto">
                  {searchResults.map(item => (
                    <button
                      key={item.id}
                      onClick={() => addIngredient(item)}
                      className="w-full text-left px-4 py-3 hover:bg-slate-800 transition flex items-center justify-between group"
                    >
                      <div>
                        <p className="text-slate-100 font-medium text-sm">{item.name}</p>
                        <p className="text-slate-500 text-xs">{item.code}</p>
                      </div>
                      <Plus size={16} className="text-slate-500 group-hover:text-brand-primary transition" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Ingredient</th>
                <th className="p-4 font-semibold text-center w-32">Quantity</th>
                <th className="p-4 font-semibold w-36">Unit</th>
                <th className="p-4 font-semibold text-right">Unit Cost</th>
                <th className="p-4 font-semibold text-right">Total Cost</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-sm">
              {ingredients.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-10 text-center text-slate-500">
                    <BookOpen className="mx-auto mb-3 text-slate-700" size={32} />
                    <p className="font-medium">No ingredients added yet</p>
                    <p className="text-xs mt-1">Use the search box above to find and add inventory items</p>
                  </td>
                </tr>
              ) : (
                ingredients.map(item => (
                  <tr key={item.inventoryItemId} className="hover:bg-slate-900/50">
                    <td className="p-4 font-medium text-slate-50">
                      <div className="flex flex-col">
                        <span>{item.name}</span>
                        <span className="text-xs text-slate-500 font-mono">{item.code}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <input
                        type="number"
                        min={0.001}
                        step={0.001}
                        value={item.quantity}
                        onChange={e => updateIngredient(item.inventoryItemId, 'quantity', parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-1.5 border border-slate-700 rounded-lg focus:ring-2 focus:ring-brand-primary/50 text-center bg-slate-900 text-slate-100"
                      />
                    </td>
                    <td className="p-4">
                      <select
                        value={item.unitId}
                        onChange={e => updateIngredient(item.inventoryItemId, 'unitId', e.target.value)}
                        className="w-full px-2 py-1.5 border border-slate-700 rounded-lg text-sm bg-slate-900 text-slate-300"
                      >
                        {units.map(u => (
                          <option key={u.id} value={u.id}>{u.name}</option>
                        ))}
                      </select>
                    </td>
                    <td className="p-4 text-right text-slate-400">${item.costPerUnit.toFixed(2)}</td>
                    <td className="p-4 text-right font-medium text-slate-50">${(item.quantity * item.costPerUnit).toFixed(2)}</td>
                    <td className="p-4 text-right">
                      <button
                        onClick={() => removeIngredient(item.inventoryItemId)}
                        className="p-1.5 text-slate-500 hover:text-red-400 rounded transition"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            <tfoot className="bg-slate-900/60 border-t border-slate-800">
              <tr>
                <td colSpan={4} className="p-4 text-right font-medium text-slate-300">Total Recipe Cost:</td>
                <td className="p-4 text-right font-bold text-brand-primary text-lg">${totalCost.toFixed(2)}</td>
                <td />
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex justify-between">
          <Link href="/dashboard/inventory/recipes" className="px-4 py-2 border border-slate-700 rounded-lg text-slate-300 hover:bg-slate-800 font-medium transition">Cancel</Link>
          <div className="flex gap-2">
            <button
              onClick={() => handleSave('DRAFT')}
              disabled={saving}
              className="px-4 py-2 border border-slate-700 rounded-lg text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2 transition disabled:opacity-50"
            >
              <Save size={16} /> Save as Draft
            </button>
            <button
              onClick={() => handleSave('ACTIVE')}
              disabled={saving}
              className="px-4 py-2 bg-brand-primary text-white rounded-lg font-medium hover:bg-brand-primary/90 transition flex items-center gap-2 disabled:opacity-50"
            >
              {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Save size={16} />}
              Save and Activate
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
