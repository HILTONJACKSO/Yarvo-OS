"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Save, AlertCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function CountSheetPage() {
  const params = useParams();
  const router = useRouter();
  const [countData, setCountData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isCompleting, setIsCompleting] = useState(false);
  
  // Store item inputs locally before save
  const [inputs, setInputs] = useState<Record<string, string>>({});

  useEffect(() => {
    if (params?.id) {
      fetchData();
    }
  }, [params?.id]);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/counts/${params.id}?t=${Date.now()}`, {
        cache: 'no-store'
      });
      if (response.ok) {
        const data = await response.json();
        setCountData(data);
        
        // Initialize inputs
        const initialInputs: Record<string, string> = {};
        data.items?.forEach((item: any) => {
          if (item.countedQuantity !== null) {
            initialInputs[item.id] = String(item.countedQuantity);
          }
        });
        setInputs(initialInputs);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (itemId: string, value: string) => {
    setInputs(prev => ({ ...prev, [itemId]: value }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const itemsToUpdate = Object.entries(inputs)
        .filter(([_, value]) => value !== '')
        .map(([itemId, value]) => ({
          itemId,
          countedQuantity: parseFloat(value)
        }));

      if (itemsToUpdate.length === 0) {
        toast.error("Please enter at least one quantity before saving.");
        setIsSaving(false);
        return;
      }

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/counts/${params.id}/items`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ items: itemsToUpdate })
      });

      if (res.ok) {
        // Fetch fresh data after save to show updated variances
        await fetchData();
        toast.success("Progress saved successfully!");
      } else {
        toast.error("Failed to save progress.");
      }
    } catch (err) {
      console.error(err);
      toast.error("Error saving progress");
    } finally {
      setIsSaving(false);
    }
  };

  const handleComplete = async () => {
    // Save progress first
    await handleSave();
    
    setIsCompleting(true);
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/counts/${params.id}/complete`, {
        method: 'POST',
      });
      
      if (response.ok) {
        toast.success("Count submitted successfully!");
        router.push('/dashboard/inventory/counts');
      } else {
        toast.error("Failed to complete count.");
      }
    } catch (err) {
      console.error(err);
      toast.error("Error completing count.");
    } finally {
      setIsCompleting(false);
    }
  };

  if (loading) return <div className="p-8 text-center text-slate-400">Loading Count Sheet...</div>;
  if (!countData) return <div className="p-8 text-center text-red-400">Count not found.</div>;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/counts" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Counts</Link>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-slate-50">{countData.countNumber}</h1>
            <span className={`px-2 py-1 text-xs font-medium rounded-full ${countData.status === 'COMPLETED' ? 'bg-emerald-500/10 text-green-700' : 'bg-blue-500/10 text-blue-700'}`}>
              {countData.status.replace('_', ' ')}
            </span>
          </div>
          <p className="text-slate-400 mt-1">Location: {countData.locationStr} &bull; Type: {countData.countType.replace('_', ' ')}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={handleSave} disabled={isSaving} className="px-4 py-2 bg-slate-800 text-white rounded-md font-medium hover:bg-slate-700 transition flex items-center gap-2">
            {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />} 
            Save Progress
          </button>
          <button 
            onClick={handleComplete} 
            disabled={isCompleting || isSaving || countData.status === 'COMPLETED'} 
            className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition disabled:opacity-50 flex items-center gap-2"
          >
            {isCompleting && <Loader2 size={18} className="animate-spin" />}
            Submit Count for Review
          </button>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Item Code</th>
              <th className="p-4 font-semibold">Item Name</th>
              <th className="p-4 font-semibold text-center">Unit</th>
              {!countData.blindCount && (
                <th className="p-4 font-semibold text-right">System Qty</th>
              )}
              <th className="p-4 font-semibold text-right w-48">Actual Count</th>
              <th className="p-4 font-semibold text-right">Variance</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {countData.items?.map((item: any) => (
              <tr key={item.id} className="hover:bg-slate-900">
                <td className="p-4 font-mono text-xs text-brand-primary font-medium">{item.code}</td>
                <td className="p-4 font-medium text-slate-50">{item.name}</td>
                <td className="p-4 text-center text-slate-400">{item.unit}</td>
                
                {!countData.blindCount && (
                  <td className="p-4 text-right text-slate-400">
                    {item.systemQuantity !== null ? item.systemQuantity.toFixed(2) : '0.00'}
                  </td>
                )}
                
                <td className="p-4 text-right">
                  <input 
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="Enter qty"
                    value={inputs[item.id] !== undefined ? inputs[item.id] : ''}
                    onChange={(e) => handleInputChange(item.id, e.target.value)}
                    className="w-full max-w-[120px] px-3 py-1.5 border rounded focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-right bg-slate-900 border-slate-700 text-slate-50"
                  />
                </td>
                
                <td className={`p-4 text-right font-medium ${item.varianceQuantity === null ? 'text-slate-500' : item.varianceQuantity < 0 ? 'text-red-500' : item.varianceQuantity > 0 ? 'text-green-500' : 'text-slate-50'}`}>
                  {item.varianceQuantity === null ? '-' : 
                    `${item.varianceQuantity > 0 ? '+' : ''}${item.varianceQuantity.toFixed(2)}`
                  }
                  {item.varianceCost !== null && item.varianceCost !== 0 && (
                    <div className="text-xs opacity-70">
                      (${Math.abs(item.varianceCost).toFixed(2)})
                    </div>
                  )}
                </td>
              </tr>
            ))}
            {(!countData.items || countData.items.length === 0) && (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-400">
                  <AlertCircle size={24} className="mx-auto mb-2 opacity-50" />
                  No items found for this location.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
