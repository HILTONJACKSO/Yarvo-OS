"use client";

import { useState, useEffect } from 'react';
import { Search, Save, Send, Trash2, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function NewStockTransferPage() {
  const router = useRouter();
  const [locations, setLocations] = useState<any[]>([]);
  const [availableItems, setAvailableItems] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [sourceLocationId, setSourceLocationId] = useState('');
  const [destinationLocationId, setDestinationLocationId] = useState('');
  const [expectedDate, setExpectedDate] = useState('');
  const [notes, setNotes] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/inventory/locations`);
        if (response.ok) {
          const data = await response.json();
          setLocations(data);
        }
      } catch (error) {
        console.error('Failed to fetch locations:', error);
      }
    };
    
    const fetchItems = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/inventory/items`);
        if (response.ok) {
          const data = await response.json();
          setAvailableItems(data);
        }
      } catch (error) {
        console.error('Failed to fetch items:', error);
      }
    };

    fetchLocations();
    fetchItems();
  }, []);

  const handleAddItem = (item: any) => {
    if (!items.find(i => i.id === item.id)) {
      setItems([...items, { ...item, requestedQuantity: 1 }]);
    }
    setSearchQuery('');
  };

  const handleRemoveItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const handleUpdateQuantity = (id: string, qty: number) => {
    setItems(items.map(item => item.id === id ? { ...item, requestedQuantity: qty } : item));
  };

  const filteredAvailableItems = availableItems.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSubmit = async (status: string) => {
    if (!sourceLocationId || !destinationLocationId) {
      alert('Please select both source and destination locations.');
      return;
    }
    if (sourceLocationId === destinationLocationId) {
      alert('Source and destination locations cannot be the same.');
      return;
    }
    if (items.length === 0) {
      alert('Please add at least one item to transfer.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        sourceLocationId,
        destinationLocationId,
        expectedDate,
        notes,
        status,
        items: items.map(i => ({
          inventoryItemId: i.id,
          requestedQuantity: i.requestedQuantity,
          unitId: i.unitId || i.unit || 'unit-1', // Defaulting unit if not present
        }))
      };

      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/inventory/transfers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        router.push('/dashboard/inventory/movements');
      } else {
        alert('Failed to create transfer request.');
      }
    } catch (error) {
      console.error('Error creating transfer:', error);
      alert('An error occurred while creating the transfer.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">New Stock Transfer</h1>
          <p className="text-slate-400 mt-1">Move inventory items from one location to another.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Source Location <span className="text-red-500">*</span></label>
              <select 
                value={sourceLocationId}
                onChange={e => setSourceLocationId(e.target.value)}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
              >
                <option value="">Select source...</option>
                {locations.map(loc => (
                  <option key={loc.id} value={loc.id}>{loc.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Destination Location <span className="text-red-500">*</span></label>
              <select 
                value={destinationLocationId}
                onChange={e => setDestinationLocationId(e.target.value)}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
              >
                <option value="">Select destination...</option>
                {locations.map(loc => (
                  <option key={loc.id} value={loc.id}>{loc.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Expected Transfer Date</label>
              <input 
                type="date" 
                value={expectedDate}
                onChange={e => setExpectedDate(e.target.value)}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Requested By</label>
              <input type="text" defaultValue="Current User" disabled className="w-full px-4 py-2 border rounded-md bg-slate-900 text-slate-400" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-1">Notes</label>
              <textarea 
                rows={2} 
                placeholder="Reason for transfer..." 
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950"
              ></textarea>
            </div>
          </div>
        </div>

        <div className="border-t">
          <div className="p-4 bg-slate-900 border-b flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-slate-50">Transfer Items</h3>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                <input 
                  type="text" 
                  placeholder="Search to add item..." 
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-1.5 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm bg-slate-950"
                />
                
                {searchQuery && (
                  <div className="absolute z-10 w-full mt-1 bg-slate-800 border rounded-md shadow-lg max-h-60 overflow-y-auto">
                    {filteredAvailableItems.length > 0 ? (
                      filteredAvailableItems.map(item => (
                        <div 
                          key={item.id} 
                          className="px-4 py-2 hover:bg-slate-700 cursor-pointer text-sm"
                          onClick={() => handleAddItem(item)}
                        >
                          <div className="font-medium">{item.name}</div>
                          <div className="text-xs text-gray-400">{item.code}</div>
                        </div>
                      ))
                    ) : (
                      <div className="px-4 py-2 text-sm text-gray-400">No items found</div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b text-xs uppercase text-slate-400">
                <th className="p-4 font-semibold">Item</th>
                <th className="p-4 font-semibold text-center w-32">Transfer Qty</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y text-sm">
              {items.map((item) => (
                <tr key={item.id} className="hover:bg-slate-900">
                  <td className="p-4 font-medium text-slate-50">
                    <div className="flex flex-col">
                      <span>{item.name}</span>
                      <span className="text-xs text-gray-400">{item.code}</span>
                    </div>
                  </td>
                  <td className="p-4">
                    <input 
                      type="number" 
                      min="1"
                      value={item.requestedQuantity} 
                      onChange={e => handleUpdateQuantity(item.id, parseFloat(e.target.value))}
                      className="w-full px-3 py-1.5 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-center bg-slate-950"
                    />
                  </td>
                  <td className="p-4 text-right">
                    <button onClick={() => handleRemoveItem(item.id)} className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={18}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {items.length === 0 && (
            <div className="p-8 text-center text-slate-400">
              No items added to this transfer yet.
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-slate-900 flex justify-between">
          <Link href="/dashboard/inventory/movements" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          <div className="flex gap-2">
            <button 
              onClick={() => handleSubmit('DRAFT')}
              disabled={isSubmitting}
              className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium flex items-center gap-2 disabled:opacity-50"
            >
              <Save size={18} /> Save as Draft
            </button>
            <button 
              onClick={() => handleSubmit('PENDING')}
              disabled={isSubmitting}
              className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2 disabled:opacity-50"
            >
              <Send size={18} /> Submit Request
            </button>
            <div className="w-px h-8 bg-gray-300 mx-2 self-center"></div>
            <button 
              onClick={() => handleSubmit('COMPLETED')}
              disabled={isSubmitting}
              className="px-4 py-2 bg-green-600 text-white rounded-md font-medium hover:bg-green-700 transition flex items-center gap-2 disabled:opacity-50"
            >
              <ArrowRight size={18} /> Direct Transfer (Issue & Receive)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
