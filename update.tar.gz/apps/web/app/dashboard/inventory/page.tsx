"use client";

import { Package, AlertCircle, TrendingDown, ClipboardList, Wallet, Truck, ArrowRight, ArrowDownRight, ArrowUpRight } from 'lucide-react';
import Link from 'next/link';
import { useState, useEffect } from 'react';

export default function InventoryDashboardPage() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalStockValue: 0,
    lowStockItems: 0,
    outOfStock: 0,
    openPurchaseOrders: 0
  });

  const fetchStats = async () => {
    try {
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || '';
      const token = typeof window !== 'undefined' ? localStorage.getItem('access_token') : '';
      let bid = 'bus-kwalee-1';
      try {
        const bRes = await fetch(`${apiUrl}/businesses/current`, { headers: { 'Authorization': `Bearer ${token}` } });
        if (bRes.ok) {
          const bData = await bRes.json();
          if (Array.isArray(bData) && bData.length > 0) bid = bData[0].businessId || bData[0].id || bid;
          else if (bData?.businessId) bid = bData.businessId;
          else if (bData?.id) bid = bData.id;
        }
      } catch {}

      const headers = { 'x-business-id': bid, 'Authorization': `Bearer ${token}` };
      const response = await fetch(`${apiUrl}/inventory/stats`, { headers });
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    
    socket.on('inventory.updated', () => {
      fetchStats();
    });

    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Inventory Dashboard</h1>
          <p className="text-slate-400 mt-1">Overview of stock levels, values, and purchasing alerts.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition">
            Start Stock Count
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading inventory data...</div>
      ) : (
        <>
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-slate-400 font-medium text-sm mb-1">Total Stock Value</p>
                  <h3 className="text-3xl font-black text-slate-50">${stats.totalStockValue.toLocaleString()}</h3>
                </div>
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                  <Wallet size={20} />
                </div>
              </div>
              <div className="mt-4 flex items-center gap-1 text-sm text-gray-400 font-medium">
                <span>Calculated in real-time</span>
              </div>
            </div>

            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-slate-400 font-medium text-sm mb-1">Low-Stock Items</p>
                  <h3 className="text-3xl font-black text-yellow-600">{stats.lowStockItems}</h3>
                </div>
                <div className="p-2 bg-yellow-50 text-yellow-600 rounded-lg">
                  <TrendingDown size={20} />
                </div>
              </div>
              <div className="mt-4 flex items-center gap-1 text-sm text-gray-400 font-medium">
                <span>Requires attention soon</span>
              </div>
            </div>

            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-slate-400 font-medium text-sm mb-1">Out of Stock</p>
                  <h3 className="text-3xl font-black text-red-600">{stats.outOfStock}</h3>
                </div>
                <div className="p-2 bg-red-50 text-red-600 rounded-lg">
                  <AlertCircle size={20} />
                </div>
              </div>
              <div className="mt-4 flex items-center gap-1 text-sm text-gray-400 font-medium">
                <span>Calculated in real-time</span>
              </div>
            </div>

            <div className="bg-slate-950 p-5 rounded-xl border shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-slate-400 font-medium text-sm mb-1">Open Purchase Orders</p>
                  <h3 className="text-3xl font-black text-slate-50">{stats.openPurchaseOrders}</h3>
                </div>
                <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                  <Truck size={20} />
                </div>
              </div>
              <div className="mt-4 flex items-center gap-1 text-sm text-gray-400 font-medium">
                <span>Calculated in real-time</span>
              </div>
            </div>
          </div>

          {/* Quick Actions & Alerts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <div className="lg:col-span-1 bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
              <div className="p-4 border-b bg-slate-900">
                <h3 className="font-bold text-slate-50">Quick Actions</h3>
              </div>
              <div className="divide-y">
                <Link href="/dashboard/inventory/items/new" className="flex items-center gap-3 p-4 hover:bg-slate-900 transition">
                  <div className="p-2 bg-slate-800 rounded text-slate-400"><Package size={16} /></div>
                  <div className="flex-1">
                    <p className="font-medium text-sm text-slate-50">Add Stock Item</p>
                  </div>
                  <ArrowRight size={16} className="text-gray-400" />
                </Link>
                <Link href="/dashboard/purchasing/goods-received/new" className="flex items-center gap-3 p-4 hover:bg-slate-900 transition">
                  <div className="p-2 bg-slate-800 rounded text-slate-400"><Truck size={16} /></div>
                  <div className="flex-1">
                    <p className="font-medium text-sm text-slate-50">Receive Goods</p>
                  </div>
                  <ArrowRight size={16} className="text-gray-400" />
                </Link>
                <Link href="/dashboard/inventory/transfers/new" className="flex items-center gap-3 p-4 hover:bg-slate-900 transition">
                  <div className="p-2 bg-slate-800 rounded text-slate-400"><ArrowRight size={16} /></div>
                  <div className="flex-1">
                    <p className="font-medium text-sm text-slate-50">Transfer Stock</p>
                  </div>
                  <ArrowRight size={16} className="text-gray-400" />
                </Link>
                <Link href="/dashboard/inventory/waste" className="flex items-center gap-3 p-4 hover:bg-slate-900 transition">
                  <div className="p-2 bg-slate-800 rounded text-slate-400"><AlertCircle size={16} /></div>
                  <div className="flex-1">
                    <p className="font-medium text-sm text-slate-50">Record Waste</p>
                  </div>
                  <ArrowRight size={16} className="text-gray-400" />
                </Link>
                <Link href="/dashboard/purchasing/requests/new" className="flex items-center gap-3 p-4 hover:bg-slate-900 transition">
                  <div className="p-2 bg-slate-800 rounded text-slate-400"><ClipboardList size={16} /></div>
                  <div className="flex-1">
                    <p className="font-medium text-sm text-slate-50">Purchase Request</p>
                  </div>
                  <ArrowRight size={16} className="text-gray-400" />
                </Link>
              </div>
            </div>

            {/* Critical Alerts */}
            <div className="lg:col-span-2 bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
              <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
                <h3 className="font-bold text-slate-50 flex items-center gap-2"><AlertCircle size={18} className="text-gray-400" /> Needs Attention</h3>
                <span className="text-xs font-medium px-2 py-1 bg-slate-800 text-slate-400 rounded-full">0 Alerts</span>
              </div>
              <div className="p-8 text-center text-slate-400">
                All caught up! No inventory alerts at this time.
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
