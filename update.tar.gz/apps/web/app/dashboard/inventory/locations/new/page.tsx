"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Save, Truck, ArrowRightLeft, DollarSign, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function NewLocationPage() {
  const router = useRouter();
  const [isSaving, setIsSaving] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    code: '',
    locationType: 'STOREROOM',
    allowsReceiving: true,
    allowsIssuing: true,
    allowsSalesDeduction: false
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleSave = async () => {
    if (!formData.name || !formData.code) {
      toast.error("Please provide a name and code for the location.");
      return;
    }

    setIsSaving(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/locations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-business-id': 'bus-kwalee-1'
        },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        router.push('/dashboard/inventory/locations');
      } else {
        toast.error("Failed to create location.");
      }
    } catch (err) {
      console.error(err);
      toast.error("Error saving location");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/locations" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Locations</Link>
          <h1 className="text-2xl font-bold text-slate-50">Add Stock Location</h1>
          <p className="text-slate-400 mt-1">Configure a new physical storage or sales area.</p>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-6 space-y-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Location Name <span className="text-red-500">*</span></label>
              <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="e.g. Main Storeroom" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">Short Code <span className="text-red-500">*</span></label>
              <input type="text" name="code" value={formData.code} onChange={handleChange} placeholder="e.g. STR-01" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 uppercase" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-1">Location Type <span className="text-red-500">*</span></label>
              <select name="locationType" value={formData.locationType} onChange={handleChange} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                <option value="STOREROOM">Storeroom / Warehouse</option>
                <option value="KITCHEN">Kitchen / Prep Area</option>
                <option value="BAR">Bar / Beverage Station</option>
                <option value="FLOOR">Restaurant Floor / Dining Room</option>
                <option value="RETAIL">Retail Shop / Front Desk</option>
              </select>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-bold text-slate-50 mb-4">Capabilities & Rules</h3>
            
            <div className="grid grid-cols-1 gap-4">
              <label className="flex items-start gap-3 p-4 border border-slate-700 rounded-lg cursor-pointer hover:bg-slate-900 transition-colors">
                <input type="checkbox" name="allowsReceiving" checked={formData.allowsReceiving} onChange={handleChange} className="mt-1 w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                <div>
                  <div className="font-medium text-slate-200 flex items-center gap-2"><Truck size={16} className="text-slate-400"/> Allows Receiving</div>
                  <div className="text-sm text-slate-400 mt-1">Vendors and delivery trucks can drop off new purchases directly into this location.</div>
                </div>
              </label>
              
              <label className="flex items-start gap-3 p-4 border border-slate-700 rounded-lg cursor-pointer hover:bg-slate-900 transition-colors">
                <input type="checkbox" name="allowsIssuing" checked={formData.allowsIssuing} onChange={handleChange} className="mt-1 w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                <div>
                  <div className="font-medium text-slate-200 flex items-center gap-2"><ArrowRightLeft size={16} className="text-slate-400"/> Allows Issuing</div>
                  <div className="text-sm text-slate-400 mt-1">Other departments (like the Kitchen) can request stock transfers out of this location.</div>
                </div>
              </label>
              
              <label className="flex items-start gap-3 p-4 border border-slate-700 rounded-lg cursor-pointer hover:bg-slate-900 transition-colors">
                <input type="checkbox" name="allowsSalesDeduction" checked={formData.allowsSalesDeduction} onChange={handleChange} className="mt-1 w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                <div>
                  <div className="font-medium text-slate-200 flex items-center gap-2"><DollarSign size={16} className="text-slate-400"/> Allows POS Sales Deductions</div>
                  <div className="text-sm text-slate-400 mt-1">When an item is sold via the Point of Sale, inventory is automatically deducted from this location (Ideal for Bars & Retail).</div>
                </div>
              </label>
            </div>
          </div>
          
        </div>
        
        <div className="p-4 border-t bg-slate-900 flex justify-end gap-3">
          <Link href="/dashboard/inventory/locations" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          <button 
            disabled={isSaving}
            onClick={handleSave}
            className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2 disabled:opacity-50"
          >
            {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />} 
            {isSaving ? 'Saving...' : 'Save Location'}
          </button>
        </div>
      </div>
    </div>
  );
}
