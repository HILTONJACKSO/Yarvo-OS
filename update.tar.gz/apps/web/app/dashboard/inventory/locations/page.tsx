"use client";

import { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, CheckCircle2, XCircle } from 'lucide-react';
import Link from 'next/link';

export default function StockLocationsPage() {
  const [locations, setLocations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/inventory/locations`);
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('inventory.updated', () => fetchData());
    return () => socket.disconnect();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Stock Locations</h1>
          <p className="text-slate-400 mt-1">Manage physical spaces where inventory is stored, prepared, or sold.</p>
        </div>
        <Link href="/dashboard/inventory/locations/new" className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2">
          <Plus size={18} /> Add Location
        </Link>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex items-center justify-between">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search locations..." 
              className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm"
            />
          </div>
        </div>
        
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-xs uppercase text-slate-400">
              <th className="p-4 font-semibold">Location Name</th>
              <th className="p-4 font-semibold">Code</th>
              <th className="p-4 font-semibold">Type</th>
              <th className="p-4 font-semibold text-center">Receiving</th>
              <th className="p-4 font-semibold text-center">Issuing</th>
              <th className="p-4 font-semibold text-center">Sales</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y text-sm">
            {locations.map((loc) => (
              <tr key={loc.id} className="hover:bg-slate-900">
                <td className="p-4 font-medium text-slate-50">{loc.name}</td>
                <td className="p-4 text-slate-400">{loc.code}</td>
                <td className="p-4 text-slate-400">{loc.locationType?.replace('_', ' ')}</td>
                <td className="p-4 text-center">
                  {loc.allowsReceiving ? <CheckCircle2 size={16} className="mx-auto text-green-500" /> : <XCircle size={16} className="mx-auto text-gray-300" />}
                </td>
                <td className="p-4 text-center">
                  {loc.allowsIssuing ? <CheckCircle2 size={16} className="mx-auto text-green-500" /> : <XCircle size={16} className="mx-auto text-gray-300" />}
                </td>
                <td className="p-4 text-center">
                  {loc.allowsSales ? <CheckCircle2 size={16} className="mx-auto text-green-500" /> : <XCircle size={16} className="mx-auto text-gray-300" />}
                </td>
                <td className="p-4">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${loc.status === 'ACTIVE' ? 'bg-emerald-500/10 text-green-700' : 'bg-slate-800 text-slate-300'}`}>
                    {loc.status}
                  </span>
                </td>
                <td className="p-4 flex items-center justify-end gap-2">
                  <button className="p-1.5 text-gray-400 hover:text-brand-primary rounded"><Edit2 size={16}/></button>
                  <button className="p-1.5 text-gray-400 hover:text-red-600 rounded"><Trash2 size={16}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
