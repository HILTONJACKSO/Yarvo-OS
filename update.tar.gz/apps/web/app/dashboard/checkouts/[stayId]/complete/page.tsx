"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, AlertTriangle, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';

export default function PendingCheckoutsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [pending, setPending] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPending = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/checkouts/pending`);
        if (response.ok) {
          const data = await response.json();
          const mapped = data.map((stay: any) => {
            const customer = stay.reservation?.customer;
            const resRoom = stay.reservation?.reservationRooms?.[0];
            const balance = stay.guestFolios?.reduce((acc: number, f: any) => acc + Number(f.balance), 0) || 0;
            return {
              id: stay.id,
              room: resRoom?.room?.number || 'Unknown',
              guestName: customer?.displayName || 'Unknown Guest',
              reason: balance > 0 ? 'PAYMENT_REQUIRED' : 'PENDING_CHECKOUT',
              balance,
              status: balance > 0 ? 'PENDING_PAYMENT' : 'PENDING'
            };
          });
          setPending(mapped);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchPending();

    socket.on('checkouts.updated', fetchPending);
    socket.on('stays.updated', fetchPending);
    return () => {
      socket.off('checkouts.updated', fetchPending);
      socket.off('stays.updated', fetchPending);
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <Link href="/dashboard/checkouts" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Pending Checkouts</h1>
          <p className="text-slate-400 mt-1">Checkouts that require attention or review</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border p-4 mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search pending checkouts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-slate-900 transition">
          <Filter size={18} /> Filter
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Room</th>
              <th className="p-4 font-semibold">Guest Name</th>
              <th className="p-4 font-semibold">Pending Reason</th>
              <th className="p-4 font-semibold">Balance</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={6} className="p-8 text-center text-slate-400">Loading...</td></tr>
            ) : pending.length === 0 ? (
              <tr><td colSpan={6} className="p-8 text-center text-slate-400">No pending checkouts found.</td></tr>
            ) : pending.map((item) => (
              <tr key={item.id} className="hover:bg-slate-900 transition">
                <td className="p-4 font-bold">{item.room}</td>
                <td className="p-4 font-medium">{item.guestName}</td>
                <td className="p-4 text-slate-400 flex items-center gap-2">
                  <AlertTriangle size={14} className="text-amber-500" />
                  {item.reason.replace('_', ' ')}
                </td>
                <td className="p-4 font-medium ${item.balance > 0 ? 'text-red-600' : 'text-slate-200'}">${item.balance.toFixed(2)}</td>
                <td className="p-4">
                  <span className="px-2.5 py-1 bg-amber-500/10 text-amber-400 rounded-full text-xs font-bold">
                    {item.status.replace('_', ' ')}
                  </span>
                </td>
                <td className="p-4 text-right">
                  <Link href={`/dashboard/checkouts/${item.id}`} className="inline-flex items-center gap-1 text-sm bg-brand-primary/10 text-brand-primary px-3 py-1.5 rounded-md hover:bg-brand-primary hover:text-white transition font-medium">
                    Resume <ArrowRight size={14} />
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
