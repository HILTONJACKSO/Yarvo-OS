"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, LogOut, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';

export default function DeparturesPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [departures, setDepartures] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDepartures = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/checkouts/departures`);
        if (response.ok) {
          const data = await response.json();
          const mapped = data.map((stay: any) => {
            const customer = stay.reservation?.customer;
            const resRoom = stay.reservation?.reservationRooms?.[0];
            const balance = stay.guestFolios?.reduce((acc: number, f: any) => acc + Number(f.balance), 0) || 0;
            return {
              id: stay.id,
              room: resRoom?.room?.number || 'Unknown',
              guestName: customer?.displayName || 'Unknown Guest',
              departureTime: stay.expectedDepartureTime ? new Date(stay.expectedDepartureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A',
              balance,
              status: stay.status === 'COMPLETED' ? 'CHECKED_OUT' : (balance > 0 ? 'PENDING' : 'READY')
            };
          });
          setDepartures(mapped);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchDepartures();

    socket.on('checkouts.updated', fetchDepartures);
    socket.on('stays.updated', fetchDepartures);
    return () => {
      socket.off('checkouts.updated', fetchDepartures);
      socket.off('stays.updated', fetchDepartures);
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <Link href="/dashboard/checkouts" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Departures Today</h1>
          <p className="text-slate-400 mt-1">Guests scheduled to leave today</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border p-4 mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search departures..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-slate-900 transition">
          <Filter size={18} /> Filter
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Room</th>
              <th className="p-4 font-semibold">Guest Name</th>
              <th className="p-4 font-semibold">Expected Departure</th>
              <th className="p-4 font-semibold">Balance</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={6} className="p-8 text-center text-slate-400">Loading departures...</td></tr>
            ) : departures.map((dep) => (
              <tr key={dep.id} className="hover:bg-slate-900 transition">
                <td className="p-4 font-bold">{dep.room}</td>
                <td className="p-4 font-medium">{dep.guestName}</td>
                <td className="p-4 text-slate-400">{dep.departureTime}</td>
                <td className="p-4">${dep.balance.toFixed(2)}</td>
                <td className="p-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    dep.status === 'READY' ? 'bg-emerald-500/10 text-emerald-400' :
                    dep.status === 'PENDING' ? 'bg-amber-500/10 text-amber-400' :
                    dep.status === 'LATE_CHECKOUT' ? 'bg-purple-100 text-purple-800' :
                    'bg-slate-800 text-slate-200'
                  }`}>
                    {dep.status.replace('_', ' ')}
                  </span>
                </td>
                <td className="p-4 text-right">
                  {dep.status !== 'CHECKED_OUT' && (
                    <Link href={`/dashboard/checkouts/${dep.id}`} className="inline-flex items-center gap-1 text-sm bg-brand-primary/10 text-brand-primary px-3 py-1.5 rounded-md hover:bg-brand-primary hover:text-white transition font-medium">
                      Process <ArrowRight size={14} />
                    </Link>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
