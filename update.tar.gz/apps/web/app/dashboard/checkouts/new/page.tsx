"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Search, LogOut, ArrowRight, User, Calendar, CreditCard } from 'lucide-react';
import Link from 'next/link';

export default function NewCheckoutPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [departingGuests, setDepartingGuests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real app, this fetches stays with status IN_HOUSE and plannedDepartureAt today or earlier
    setTimeout(() => {
      setDepartingGuests([
        { id: 'stay-1', room: '101', guestName: 'Alice Johnson', expectedDeparture: '11:00 AM', balance: 0, status: 'READY_FOR_SETTLEMENT' },
        { id: 'stay-2', room: '205', guestName: 'Bob Smith', expectedDeparture: '11:00 AM', balance: 145.50, status: 'PAYMENT_PENDING' },
        { id: 'stay-3', room: '310', guestName: 'Carol White', expectedDeparture: '12:00 PM', balance: 0, status: 'PREPARING' }
      ]);
      setLoading(false);
    }, 500);
  }, []);

  const filteredGuests = departingGuests.filter(g => 
    g.guestName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    g.room.includes(searchTerm)
  );

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <Link href="/dashboard/checkouts" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
        <h1 className="text-2xl font-bold text-slate-50">Select Guest for Checkout</h1>
        <p className="text-slate-400 mt-1">Search for an in-house guest to begin the checkout process</p>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border p-6 mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search by guest name or room number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
          />
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
          <h2 className="font-semibold text-slate-300">Departing Today</h2>
          <span className="bg-brand-primary/10 text-brand-primary px-2 py-1 rounded-full text-xs font-bold">{departingGuests.length} Guests</span>
        </div>
        
        {loading ? (
          <div className="p-8 text-center text-slate-400">Loading guests...</div>
        ) : filteredGuests.length === 0 ? (
          <div className="p-8 text-center text-slate-400">No guests found matching your search.</div>
        ) : (
          <div className="divide-y">
            {filteredGuests.map((guest) => (
              <div key={guest.id} className="p-4 hover:bg-slate-900 transition flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-800 rounded-lg flex items-center justify-center text-xl font-bold text-slate-300 border">
                    {guest.room}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-50 text-lg flex items-center gap-2">
                      {guest.guestName}
                    </h3>
                    <div className="flex gap-4 mt-1 text-sm text-slate-400">
                      <span className="flex items-center gap-1"><Calendar size={14}/> {guest.expectedDeparture}</span>
                      <span className="flex items-center gap-1"><CreditCard size={14}/> Balance: ${guest.balance.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                
                <Link 
                  href={`/dashboard/checkouts/${guest.id}`} 
                  className="px-6 py-2 bg-brand-primary text-white rounded-md text-sm font-medium hover:bg-brand-primary/90 transition flex items-center justify-center gap-2"
                >
                  Start Checkout <ArrowRight size={16} />
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
