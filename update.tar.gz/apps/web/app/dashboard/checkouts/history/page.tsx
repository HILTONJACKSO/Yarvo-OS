"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, FileText, CheckCircle } from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';

export default function CompletedCheckoutsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/checkouts/history`);
        if (response.ok) {
          const data = await response.json();
          const mapped = data.map((stay: any) => {
            const customer = stay.reservation?.customer;
            const resRoom = stay.reservation?.reservationRooms?.[0];
            const folios = stay.guestFolios || [];
            const total = folios.reduce((acc: number, f: any) => acc + Number(f.balance), 0);
            return {
              id: stay.id,
              room: resRoom?.room?.number || 'Unknown',
              guestName: customer?.displayName || 'Unknown Guest',
              checkoutTime: stay.actualDepartureTime ? new Date(stay.actualDepartureTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A',
              invoiceId: folios.length > 0 ? `INV-${folios[0].id.substring(0,6).toUpperCase()}` : 'N/A',
              total,
              settledBy: 'Multiple' // Placeholder
            };
          });
          setHistory(mapped);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();

    socket.on('checkouts.updated', fetchHistory);
    socket.on('stays.updated', fetchHistory);
    return () => {
      socket.off('checkouts.updated', fetchHistory);
      socket.off('stays.updated', fetchHistory);
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <Link href="/dashboard/checkouts" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Completed Checkouts</h1>
          <p className="text-slate-400 mt-1">Review past departures and generated invoices</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border p-4 mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search by guest, room, or invoice number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-slate-900 transition">
          <Filter size={18} /> Date Range
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Room</th>
              <th className="p-4 font-semibold">Guest Name</th>
              <th className="p-4 font-semibold">Checkout Time</th>
              <th className="p-4 font-semibold">Invoice</th>
              <th className="p-4 font-semibold">Total Amount</th>
              <th className="p-4 font-semibold">Settled By</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400">Loading history...</td></tr>
            ) : history.length === 0 ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400">No completed checkouts found.</td></tr>
            ) : history.map((item) => (
              <tr key={item.id} className="hover:bg-slate-900 transition">
                <td className="p-4 font-bold text-slate-50">{item.room}</td>
                <td className="p-4 font-medium">{item.guestName}</td>
                <td className="p-4 text-slate-400 flex items-center gap-1"><CheckCircle size={14} className="text-green-500"/> {item.checkoutTime}</td>
                <td className="p-4 text-brand-primary hover:underline cursor-pointer flex items-center gap-1">
                  <FileText size={14}/> {item.invoiceId}
                </td>
                <td className="p-4 font-medium">${item.total.toFixed(2)}</td>
                <td className="p-4 text-slate-400">{item.settledBy}</td>
                <td className="p-4 text-right">
                  <Link href={`/dashboard/checkouts/${item.id}/complete`} className="inline-flex items-center gap-1 text-sm border px-3 py-1.5 rounded-md hover:bg-slate-900 transition font-medium">
                    View Details
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
