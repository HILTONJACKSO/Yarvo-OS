"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, AlertTriangle, ArrowRight, FileText } from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';

export default function OutstandingBalancesPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [receivables, setReceivables] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOutstanding = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/checkouts/outstanding`);
        if (response.ok) {
          const data = await response.json();
          const mapped = data.map((stay: any) => {
            const customer = stay.reservation?.customer;
            const folios = stay.guestFolios || [];
            const openFolios = folios.filter((f: any) => f.status === 'OPEN' && Number(f.balance) > 0);
            const totalDue = openFolios.reduce((acc: number, f: any) => acc + Number(f.balance), 0);
            
            return {
              id: stay.id,
              number: `STY-${stay.id.substring(0, 6).toUpperCase()}`,
              guestOrCompany: customer?.company || customer?.displayName || 'Unknown',
              invoiceId: openFolios.length > 0 ? `FOL-${openFolios[0].id.substring(0,6).toUpperCase()}` : 'N/A',
              amount: totalDue,
              dueDate: stay.expectedDepartureTime ? new Date(stay.expectedDepartureTime).toLocaleDateString() : 'N/A',
              status: 'OPEN'
            };
          });
          setReceivables(mapped);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchOutstanding();

    socket.on('checkouts.updated', fetchOutstanding);
    socket.on('stays.updated', fetchOutstanding);
    return () => {
      socket.off('checkouts.updated', fetchOutstanding);
      socket.off('stays.updated', fetchOutstanding);
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <Link href="/dashboard/checkouts" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Outstanding Balances (Receivables)</h1>
          <p className="text-slate-400 mt-1">Manage unsettled city ledgers and corporate accounts post-checkout</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border p-4 mb-6 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search receivables..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-slate-900 transition">
          <Filter size={18} /> Filter
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Ref #</th>
              <th className="p-4 font-semibold">Guest / Company</th>
              <th className="p-4 font-semibold">Invoice</th>
              <th className="p-4 font-semibold">Amount Due</th>
              <th className="p-4 font-semibold">Due Date</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400">Loading...</td></tr>
            ) : receivables.length === 0 ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400">No outstanding balances.</td></tr>
            ) : receivables.map((item) => (
              <tr key={item.id} className="hover:bg-slate-900 transition">
                <td className="p-4 font-bold text-slate-50">{item.number}</td>
                <td className="p-4 font-medium">{item.guestOrCompany}</td>
                <td className="p-4 text-brand-primary hover:underline cursor-pointer flex items-center gap-1">
                  <FileText size={14}/> {item.invoiceId}
                </td>
                <td className="p-4 font-bold text-slate-50">${item.amount.toFixed(2)}</td>
                <td className="p-4 text-slate-400">{item.dueDate}</td>
                <td className="p-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    item.status === 'OVERDUE' ? 'bg-red-500/10 text-red-400' : 'bg-blue-500/10 text-blue-400'
                  }`}>
                    {item.status}
                  </span>
                </td>
                <td className="p-4 text-right">
                  <button className="inline-flex items-center gap-1 text-sm bg-brand-primary/10 text-brand-primary px-3 py-1.5 rounded-md hover:bg-brand-primary hover:text-white transition font-medium">
                    Receive Payment
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
