"use client";

import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Home, Users, User, Building, Settings, LogOut, Coffee, CalendarCheck, ConciergeBell, Wallet, ShoppingBag, MonitorPlay, CreditCard, Monitor, Sparkles, Package, ShoppingCart, ClipboardList, Ticket, Landmark, LineChart, Target, Menu, X } from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isStaffOpen, setIsStaffOpen] = useState(false);
  const [isPropertyOpen, setIsPropertyOpen] = useState(false);
  const [isCustomersOpen, setIsCustomersOpen] = useState(false);
  const [isReservationsOpen, setIsReservationsOpen] = useState(false);
  const [isFrontDeskOpen, setIsFrontDeskOpen] = useState(false);
  const [isFoliosOpen, setIsFoliosOpen] = useState(false);
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isServiceDisplayOpen, setIsServiceDisplayOpen] = useState(false);
  const [isPaymentsOpen, setIsPaymentsOpen] = useState(false);
  const [isCashierOpen, setIsCashierOpen] = useState(false);
  const [isHousekeepingOpen, setIsHousekeepingOpen] = useState(false);
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [isPurchasingOpen, setIsPurchasingOpen] = useState(false);
  const [isAdmissionsOpen, setIsAdmissionsOpen] = useState(false);
  const [isFinanceOpen, setIsFinanceOpen] = useState(false);
  const [isCrmOpen, setIsCrmOpen] = useState(false);
  useEffect(() => {
    const token = localStorage.getItem('access_token');
    if (!token) {
      router.push('/login');
      return;
    }

    fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(user => {
      if (user.mustChangePassword && pathname !== '/dashboard/change-password') {
        router.push('/dashboard/change-password');
      } else {
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        .then(res => res.json())
        .then(businessData => {
          setData(businessData);
          setLoading(false);
          
          if (businessData && businessData.length > 0) {
            socket.emit('join_business', { businessId: businessData[0].businessId });
          }

          // Only auto-open staff dropdown if we are on a staff-related page
          if (pathname.includes('/staff') || pathname.includes('/roles')) {
            setIsStaffOpen(true);
          }
          if (pathname.includes('/property')) {
            setIsPropertyOpen(true);
          }
          if (pathname.includes('/customers')) {
            setIsCustomersOpen(true);
          }
          if (pathname.includes('/reservations')) {
            setIsReservationsOpen(true);
          }
          if (pathname.includes('/front-desk') || pathname.includes('/stays') || pathname.includes('/checkouts')) {
            setIsFrontDeskOpen(true);
          }
          if (pathname.includes('/folios')) {
            setIsFoliosOpen(true);
          }
          if (pathname.includes('/catalog')) {
            setIsCatalogOpen(true);
          }
          if (pathname.includes('/orders')) {
            setIsOrdersOpen(true);
          }
          if (pathname.includes('/kitchen') || pathname.includes('/bar-display') || pathname.includes('/room-service')) {
            setIsServiceDisplayOpen(true);
          }
          if (pathname.includes('/payments')) {
            setIsPaymentsOpen(true);
          }
          if (pathname.includes('/cashier')) {
            setIsCashierOpen(true);
          }
          if (pathname.includes('/housekeeping')) {
            setIsHousekeepingOpen(true);
          }
          if (pathname.includes('/inventory')) {
            setIsInventoryOpen(true);
          }
          if (pathname.includes('/purchasing')) {
            setIsPurchasingOpen(true);
          }
          if (pathname.includes('/admissions')) {
            setIsAdmissionsOpen(true);
          }
          if (pathname.includes('/finance')) {
            setIsFinanceOpen(true);
          }
          if (pathname.includes('/crm')) {
            setIsCrmOpen(true);
          }
        })
      }
    })
    .catch(() => {
      localStorage.removeItem('access_token');
      router.push('/login');
    });

    // Close mobile menu when navigating
    setIsMobileMenuOpen(false);
  }, [router, pathname]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-900 text-slate-50">Loading Yarvo OS...</div>;
  }

  const currentBusiness = data && data.length > 0 ? data[0].business : null;
  const currentBranch = currentBusiness?.branches?.[0] || null;

  return (
    <div className="h-screen flex overflow-hidden bg-slate-900 text-slate-50 relative">
      {/* Mobile Sidebar Overlay Backdrop */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`w-64 flex flex-col h-screen overflow-y-auto bg-slate-950 border-r border-slate-800 [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-thumb]:bg-slate-800 [&::-webkit-scrollbar-track]:bg-transparent transition-transform duration-300 z-50 ${isMobileMenuOpen ? 'fixed inset-y-0 left-0 translate-x-0' : 'hidden md:flex'}`}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="text-xl font-bold">Yarvo OS</div>
            <button 
              className="md:hidden text-slate-400 hover:text-white"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X size={24} />
            </button>
          </div>
          <nav className="flex-1 space-y-2 text-sm">
            <Link href="/dashboard" className={`flex items-center gap-3 p-2 rounded-md transition ${pathname === '/dashboard' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}>
              <Home size={18} /> Dashboard
            </Link>
            
            {/* Staff Dropdown */}
            <div>
              <button 
                onClick={() => setIsStaffOpen(!isStaffOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/staff') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Users size={18} /> Staff</div>
              </button>
              {isStaffOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/staff" className={`block p-2 rounded-md ${pathname === '/dashboard/staff' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>All Staff</Link>
                  <Link href="/dashboard/staff/new" className={`block p-2 rounded-md ${pathname === '/dashboard/staff/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Add Staff</Link>
                  <Link href="/dashboard/settings/roles" className={`block p-2 rounded-md ${pathname.includes('/roles') ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Roles</Link>
                  <Link href="/dashboard/departments" className="block p-2 text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200 rounded-md">Departments</Link>
                  <Link href="/dashboard/activities" className="block p-2 text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200 rounded-md">Activity</Link>
                </div>
              )}
            </div>

            {/* Customers Dropdown */}
            <div>
              <button 
                onClick={() => setIsCustomersOpen(!isCustomersOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/customers') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Users size={18} /> Customers</div>
              </button>
              {isCustomersOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/customers" className={`block p-2 rounded-md ${pathname === '/dashboard/customers' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>All Customers</Link>
                  <Link href="/dashboard/customers/new" className={`block p-2 rounded-md ${pathname === '/dashboard/customers/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>New Customer</Link>
                  <Link href="/dashboard/customers/groups" className={`block p-2 rounded-md ${pathname === '/dashboard/customers/groups' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Groups & Families</Link>
                  <Link href="/dashboard/customers/corporate" className={`block p-2 rounded-md ${pathname === '/dashboard/customers/corporate' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Corporate Accounts</Link>
                </div>
              )}
            </div>

            {/* Reservations Dropdown */}
            <div>
              <button 
                onClick={() => setIsReservationsOpen(!isReservationsOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/reservations') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><CalendarCheck size={18} /> Reservations</div>
              </button>
              {isReservationsOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/reservations" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Dashboard</Link>
                  <Link href="/dashboard/reservations/new" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>New Reservation</Link>
                  <Link href="/dashboard/reservations/search" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/search' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Search Rooms</Link>
                  <Link href="/dashboard/reservations/calendar" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/calendar' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Calendar</Link>
                  <Link href="/dashboard/reservations/all" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/all' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>All Reservations</Link>
                  <Link href="/dashboard/reservations/arrivals" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/arrivals' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Arrivals</Link>
                  <Link href="/dashboard/reservations/departures" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/departures' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Departures</Link>
                  <Link href="/dashboard/reservations/waitlist" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/waitlist' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Waitlist</Link>
                  <Link href="/dashboard/reservations/online-requests" className={`block p-2 rounded-md ${pathname === '/dashboard/reservations/online-requests' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Online Requests</Link>
                </div>
              )}
            </div>

            {/* Front Desk Dropdown */}
            <div>
              <button 
                onClick={() => setIsFrontDeskOpen(!isFrontDeskOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/front-desk') || pathname.includes('/stays') || pathname.includes('/checkouts') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><ConciergeBell size={18} /> Front Desk</div>
              </button>
              {isFrontDeskOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/front-desk" className={`block p-2 rounded-md ${pathname === '/dashboard/front-desk' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Dashboard</Link>
                  <Link href="/dashboard/front-desk/in-house" className={`block p-2 rounded-md ${pathname === '/dashboard/front-desk/in-house' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>In-House Guests</Link>
                  <Link href="/dashboard/front-desk/walk-in" className={`block p-2 rounded-md ${pathname === '/dashboard/front-desk/walk-in' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Walk-In Check-In</Link>
                  <Link href="/dashboard/front-desk/requests" className={`block p-2 rounded-md ${pathname === '/dashboard/front-desk/requests' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Guest Requests</Link>
                  <Link href="/dashboard/checkouts" className={`block p-2 rounded-md ${pathname === '/dashboard/checkouts' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Checkout Dashboard</Link>
                  <Link href="/dashboard/checkouts/new" className={`block p-2 rounded-md ${pathname === '/dashboard/checkouts/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Checkout Guest</Link>
                  <Link href="/dashboard/checkouts/departures" className={`block p-2 rounded-md ${pathname === '/dashboard/checkouts/departures' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Departures Today</Link>
                  <Link href="/dashboard/checkouts/pending" className={`block p-2 rounded-md ${pathname === '/dashboard/checkouts/pending' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Pending Checkouts</Link>
                  <Link href="/dashboard/checkouts/history" className={`block p-2 rounded-md ${pathname === '/dashboard/checkouts/history' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Completed Checkouts</Link>
                  <Link href="/dashboard/checkouts/outstanding" className={`block p-2 rounded-md ${pathname === '/dashboard/checkouts/outstanding' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Outstanding Balances</Link>
                </div>
              )}
            </div>

            {/* Guest Folios Dropdown */}
            <div>
              <button 
                onClick={() => setIsFoliosOpen(!isFoliosOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/folios') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Wallet size={18} /> Guest Folios</div>
              </button>
              {isFoliosOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/folios" className={`block p-2 rounded-md ${pathname === '/dashboard/folios' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>All Folios</Link>
                  <Link href="/dashboard/checkouts" className={`block p-2 rounded-md ${pathname === '/dashboard/checkouts' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Checkout Review</Link>
                  <Link href="/dashboard/folios/closed" className={`block p-2 rounded-md ${pathname === '/dashboard/folios/closed' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Closed Folios</Link>
                  <Link href="/dashboard/folios/disputed" className={`block p-2 rounded-md ${pathname === '/dashboard/folios/disputed' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Disputed Folios</Link>
                </div>
              )}
            </div>

            <div className="h-px bg-slate-800/60 my-3"></div>
            {/* Catalog Dropdown */}
            <div>
              <button 
                onClick={() => setIsCatalogOpen(!isCatalogOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/catalog') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Coffee size={18} /> Catalog</div>
              </button>
              {isCatalogOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/catalog" className={`block p-2 rounded-md ${pathname === '/dashboard/catalog' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Dashboard</Link>
                  <Link href="/dashboard/catalog/categories" className={`block p-2 rounded-md ${pathname === '/dashboard/catalog/categories' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Categories</Link>
                  <Link href="/dashboard/catalog/items" className={`block p-2 rounded-md ${pathname === '/dashboard/catalog/items' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Products & Services</Link>
                  <Link href="/dashboard/catalog/menus" className={`block p-2 rounded-md ${pathname === '/dashboard/catalog/menus' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Menus</Link>
                  <Link href="/dashboard/catalog/menu-preview" className={`block p-2 rounded-md ${pathname === '/dashboard/catalog/menu-preview' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Digital Preview</Link>
                </div>
              )}
            </div>

            {/* Orders Dropdown */}
            <div>
              <button 
                onClick={() => setIsOrdersOpen(!isOrdersOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/orders') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><ShoppingBag size={18} /> Orders</div>
              </button>
              {isOrdersOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/orders" className={`block p-2 rounded-md ${pathname === '/dashboard/orders' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Dashboard</Link>
                  <Link href="/dashboard/orders/new" className={`block p-2 rounded-md ${pathname === '/dashboard/orders/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>New Order</Link>
                  <Link href="/dashboard/orders/active" className={`block p-2 rounded-md ${pathname === '/dashboard/orders/active' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Active Orders</Link>
                  <Link href="/dashboard/orders/ready" className={`block p-2 rounded-md ${pathname === '/dashboard/orders/ready' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Ready for Delivery</Link>
                </div>
              )}
            </div>

            {/* Inventory Dropdown */}
            <div>
              <button 
                onClick={() => setIsInventoryOpen(!isInventoryOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/inventory') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Package size={18} /> Inventory</div>
              </button>
              {isInventoryOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/inventory" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Inventory Dashboard</Link>
                  <Link href="/dashboard/inventory/items" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/items' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Stock Items</Link>
                  <Link href="/dashboard/inventory/locations" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/locations' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Locations</Link>
                  <Link href="/dashboard/inventory/stock-levels" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/stock-levels' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Stock Levels</Link>
                  <Link href="/dashboard/inventory/movements" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/movements' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Stock Movements</Link>
                  <Link href="/dashboard/inventory/transfers/new" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/transfers/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Stock Transfers</Link>
                  <Link href="/dashboard/inventory/issues" className={`block p-2 rounded-md ${pathname.startsWith('/dashboard/inventory/issues') ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Department Issues</Link>
                  <Link href="/dashboard/inventory/recipes" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/recipes' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Recipes</Link>
                  <Link href="/dashboard/inventory/counts" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/counts' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Stock Counts</Link>
                  <Link href="/dashboard/inventory/waste" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/waste' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Waste and Damage</Link>
                  <Link href="/dashboard/inventory/reports" className={`block p-2 rounded-md ${pathname === '/dashboard/inventory/reports' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Inventory Reports</Link>
                </div>
              )}
            </div>

            {/* Purchasing Dropdown */}
            <div>
              <button 
                onClick={() => setIsPurchasingOpen(!isPurchasingOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/purchasing') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><ShoppingCart size={18} /> Purchasing</div>
              </button>
              {isPurchasingOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/purchasing/suppliers" className={`block p-2 rounded-md ${pathname === '/dashboard/purchasing/suppliers' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Suppliers</Link>
                  <Link href="/dashboard/purchasing/requests/new" className={`block p-2 rounded-md ${pathname === '/dashboard/purchasing/requests/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Purchase Requests</Link>
                  <Link href="/dashboard/purchasing/orders/new" className={`block p-2 rounded-md ${pathname === '/dashboard/purchasing/orders/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Purchase Orders</Link>
                  <Link href="/dashboard/purchasing/goods-received/new" className={`block p-2 rounded-md ${pathname === '/dashboard/purchasing/goods-received/new' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Goods Received</Link>
                  <Link href="/dashboard/purchasing/supplier-invoices" className={`block p-2 rounded-md ${pathname === '/dashboard/purchasing/supplier-invoices' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Supplier Invoices</Link>
                  <Link href="/dashboard/purchasing/reports" className={`block p-2 rounded-md ${pathname === '/dashboard/purchasing/reports' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Purchasing Reports</Link>
                </div>
              )}
            </div>

            {/* Admissions Dropdown */}
            <div>
              <button 
                onClick={() => setIsAdmissionsOpen(!isAdmissionsOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/admissions') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Ticket size={18} /> Admissions</div>
              </button>
              {isAdmissionsOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/admissions" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Dashboard</Link>
                  <Link href="/dashboard/admissions/venues" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/venues' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Venues & Capacity</Link>
                  <Link href="/dashboard/admissions/tickets/types" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/tickets/types' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Ticket Types</Link>
                  <Link href="/dashboard/admissions/tickets/records" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/tickets/records' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Ticket Records</Link>
                  <Link href="/dashboard/admissions/tickets/walk-in" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/tickets/walk-in' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Walk-in Sales</Link>
                  <Link href="/dashboard/admissions/gate/scan" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/gate/scan' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Gate Scanner</Link>
                  <Link href="/dashboard/admissions/gate/manual" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/gate/manual' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Manual Validation</Link>
                  <Link href="/dashboard/admissions/memberships" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/memberships' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Memberships</Link>
                  <Link href="/dashboard/admissions/reports" className={`block p-2 rounded-md ${pathname === '/dashboard/admissions/reports' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Reports</Link>
                </div>
              )}
            </div>

            {/* Finance Dropdown */}
            <div>
              <button 
                onClick={() => setIsFinanceOpen(!isFinanceOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/finance') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Landmark size={18} /> Finance</div>
              </button>
              {isFinanceOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/finance" className={`block p-2 rounded-md ${pathname === '/dashboard/finance' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Finance Hub</Link>
                  <Link href="/dashboard/finance/ledger" className={`block p-2 rounded-md ${pathname === '/dashboard/finance/ledger' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>General Ledger</Link>
                  <Link href="/dashboard/finance/accounts" className={`block p-2 rounded-md ${pathname === '/dashboard/finance/accounts' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Chart of Accounts</Link>
                  <Link href="/dashboard/finance/banking" className={`block p-2 rounded-md ${pathname === '/dashboard/finance/banking' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Banking</Link>
                  <Link href="/dashboard/finance/invoices" className={`block p-2 rounded-md ${pathname === '/dashboard/finance/invoices' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Receivables & Payables</Link>
                  <Link href="/dashboard/finance/assets" className={`block p-2 rounded-md ${pathname === '/dashboard/finance/assets' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Fixed Assets</Link>
                  <Link href="/dashboard/finance/budgets" className={`block p-2 rounded-md ${pathname === '/dashboard/finance/budgets' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Budgets</Link>
                  <Link href="/dashboard/finance/reports" className={`block p-2 rounded-md ${pathname === '/dashboard/finance/reports' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Financial Reports</Link>
                </div>
              )}
            </div>

            <div className="h-px bg-slate-800/60 my-3"></div>
            {/* CRM Dropdown */}
            <div>
              <button 
                onClick={() => setIsCrmOpen(!isCrmOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/crm') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Users size={18} /> CRM</div>
              </button>
              {isCrmOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/crm" className={`block p-2 rounded-md ${pathname === '/dashboard/crm' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Dashboard</Link>
                  <Link href="/dashboard/crm/customers" className={`block p-2 rounded-md ${pathname === '/dashboard/crm/customers' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Customers</Link>
                  <Link href="/dashboard/crm/corporate" className={`block p-2 rounded-md ${pathname === '/dashboard/crm/corporate' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Corporate Customers</Link>
                  <Link href="/dashboard/crm/vip" className={`block p-2 rounded-md ${pathname === '/dashboard/crm/vip' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>VIP Guests</Link>
                  <Link href="/dashboard/crm/communications" className={`block p-2 rounded-md ${pathname === '/dashboard/crm/communications' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Communications</Link>
                  <Link href="/dashboard/crm/feedback" className={`block p-2 rounded-md ${pathname === '/dashboard/crm/feedback' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Feedback & Complaints</Link>
                  <Link href="/dashboard/crm/reports" className={`block p-2 rounded-md ${pathname === '/dashboard/crm/reports' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Reports</Link>
                </div>
              )}
            </div>

            {/* Executive Dashboard */}
            <Link 
              href="/dashboard/bi" 
              className={`flex items-center gap-3 p-2 rounded-md transition ${pathname.includes('/bi') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
            >
              <Target size={18} /> Executive BI Dashboard
            </Link>

            {/* Service Display Dropdown */}
            <div>
              <button 
                onClick={() => setIsServiceDisplayOpen(!isServiceDisplayOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/kitchen') || pathname.includes('/bar-display') || pathname.includes('/room-service') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><MonitorPlay size={18} /> Service Displays</div>
              </button>
              {isServiceDisplayOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/kitchen" className={`block p-2 rounded-md ${pathname === '/dashboard/kitchen' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Kitchen Display</Link>
                  <Link href="/dashboard/bar-display" className={`block p-2 rounded-md ${pathname === '/dashboard/bar-display' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Bar Display</Link>
                  <Link href="/dashboard/room-service" className={`block p-2 rounded-md ${pathname === '/dashboard/room-service' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Room Service</Link>
                </div>
              )}
            </div>

            {/* Payments Dropdown */}
            <div>
              <button 
                onClick={() => setIsPaymentsOpen(!isPaymentsOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/payments') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><CreditCard size={18} /> Payments</div>
              </button>
              {isPaymentsOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/payments" className={`block p-2 rounded-md ${pathname === '/dashboard/payments' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Dashboard</Link>
                  <Link href="/dashboard/payments/receive" className={`block p-2 rounded-md ${pathname === '/dashboard/payments/receive' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Receive Payment</Link>
                  <Link href="/dashboard/payments/refunds" className={`block p-2 rounded-md ${pathname === '/dashboard/payments/refunds' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Refunds</Link>
                </div>
              )}
            </div>

            {/* Cashier Dropdown */}
            <div>
              <button 
                onClick={() => setIsCashierOpen(!isCashierOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/cashier') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Monitor size={18} /> Cashier</div>
              </button>
              {isCashierOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/cashier/my-shift" className={`block p-2 rounded-md ${pathname === '/dashboard/cashier/my-shift' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>My Shift</Link>
                  <Link href="/dashboard/cashier/open" className={`block p-2 rounded-md ${pathname === '/dashboard/cashier/open' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Open Shift</Link>
                  <Link href="/dashboard/cashier/close" className={`block p-2 rounded-md ${pathname === '/dashboard/cashier/close' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Close Shift</Link>
                </div>
              )}
            </div>

            {/* Housekeeping Dropdown */}
            <div>
              <button 
                onClick={() => setIsHousekeepingOpen(!isHousekeepingOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/housekeeping') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Sparkles size={18} /> Housekeeping</div>
              </button>
              {isHousekeepingOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/housekeeping" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Housekeeping Dashboard</Link>
                  <Link href="/dashboard/housekeeping/room-board" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/room-board' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Room Board</Link>
                  <Link href="/dashboard/housekeeping/tasks" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/tasks' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Cleaning Tasks</Link>
                  <Link href="/dashboard/housekeeping/my-tasks" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/my-tasks' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>My Tasks</Link>
                  <Link href="/dashboard/housekeeping/assign" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/assign' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Assign Tasks</Link>
                  <Link href="/dashboard/housekeeping/inspections" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/inspections' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Room Inspections</Link>
                  <Link href="/dashboard/housekeeping/stay-over" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/stay-over' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Stay-Over Rooms</Link>
                  <Link href="/dashboard/housekeeping/linen/items" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/linen/items' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Linen Catalog</Link>
                  <Link href="/dashboard/housekeeping/linen/movements" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/linen/movements' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Linen Movements</Link>
                  <Link href="/dashboard/housekeeping/lost-and-found" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/lost-and-found' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Lost and Found</Link>
                  <Link href="/dashboard/housekeeping/reports" className={`block p-2 rounded-md ${pathname === '/dashboard/housekeeping/reports' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Reports</Link>
                </div>
              )}
            </div>

            <div className="h-px bg-slate-800/60 my-3"></div>
            {/* Property Setup Dropdown */}
            <div>
              <button 
                onClick={() => setIsPropertyOpen(!isPropertyOpen)}
                className={`flex items-center justify-between w-full p-2 rounded-md transition ${pathname.includes('/property') ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'}`}
              >
                <div className="flex items-center gap-3"><Building size={18} /> Property Setup</div>
              </button>
              {isPropertyOpen && (
                <div className="ml-9 mt-1 space-y-1 text-gray-300">
                  <Link href="/dashboard/property" className={`block p-2 rounded-md ${pathname === '/dashboard/property' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Overview</Link>
                  <Link href="/dashboard/property/services" className={`block p-2 rounded-md ${pathname === '/dashboard/property/services' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Services</Link>
                  <Link href="/dashboard/property/areas" className={`block p-2 rounded-md ${pathname === '/dashboard/property/areas' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Areas & Sections</Link>
                  
                  {/* Dynamic links based on enabled services */}
                  {currentBranch?.services?.some((s: any) => s.serviceType === 'HOTEL' && s.isEnabled) && (
                    <>
                      <Link href="/dashboard/property/room-types" className={`block p-2 rounded-md ${pathname === '/dashboard/property/room-types' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Room Types</Link>
                      <Link href="/dashboard/property/rooms" className={`block p-2 rounded-md ${pathname === '/dashboard/property/rooms' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Rooms</Link>
                      <Link href="/dashboard/rooms/blocks" className={`block p-2 rounded-md ${pathname === '/dashboard/rooms/blocks' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Maintenance Blocks</Link>
                    </>
                  )}
                  {currentBranch?.services?.some((s: any) => ['RESTAURANT', 'BAR', 'NIGHTCLUB', 'LOUNGE'].includes(s.serviceType) && s.isEnabled) && (
                    <Link href="/dashboard/property/tables" className={`block p-2 rounded-md ${pathname === '/dashboard/property/tables' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Tables & Seating</Link>
                  )}
                  {currentBranch?.services?.some((s: any) => s.serviceType === 'BEACH' && s.isEnabled) && (
                    <Link href="/dashboard/property/beach" className={`block p-2 rounded-md ${pathname === '/dashboard/property/beach' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Beach Setup</Link>
                  )}
                  {currentBranch?.services?.some((s: any) => s.serviceType === 'POOL' && s.isEnabled) && (
                    <Link href="/dashboard/property/pools" className={`block p-2 rounded-md ${pathname === '/dashboard/property/pools' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Pool Setup</Link>
                  )}
                  {currentBranch?.services?.some((s: any) => s.serviceType === 'EVENTS' && s.isEnabled) && (
                    <Link href="/dashboard/property/event-spaces" className={`block p-2 rounded-md ${pathname === '/dashboard/property/event-spaces' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Event Spaces</Link>
                  )}
                  
                  <Link href="/dashboard/property/service-points" className={`block p-2 rounded-md ${pathname === '/dashboard/property/service-points' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Service Points</Link>
                  <Link href="/dashboard/property/hours" className={`block p-2 rounded-md ${pathname === '/dashboard/property/hours' ? 'text-white font-medium' : 'text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200'}`}>Operating Hours</Link>
                </div>
              )}
            </div>

            <Link href="/dashboard/settings" className="flex items-center gap-3 p-2 text-slate-300 hover:bg-slate-800/60 text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200 rounded-md transition"><Settings size={18} /> Settings</Link>
          </nav>
        </div>
        <div className="p-6 mt-auto border-t border-white/10 space-y-2">
           <Link href="/dashboard/profile" className="flex items-center gap-3 p-2 text-slate-300 hover:bg-slate-800/60 text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200 rounded-md w-full transition">
             <User size={18} /> My Profile
           </Link>
           <button 
            onClick={() => { localStorage.removeItem('access_token'); router.push('/login'); }}
            className="flex items-center gap-3 p-2 text-slate-300 hover:bg-slate-800/60 text-slate-400 hover:text-white hover:translate-x-1 transition-all duration-200 rounded-md w-full transition text-red-400 hover:text-red-300"
          >
            <LogOut size={18} /> Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-slate-950/80 backdrop-blur-md border-b border-slate-800 p-4 px-6 flex justify-between items-center shadow-sm z-10">
          <div className="flex items-center gap-4">
            <button 
              className="md:hidden text-slate-400 hover:text-white"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu size={24} />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-50 capitalize">{pathname === '/dashboard' ? 'Overview' : pathname.split('/').pop()?.replace('-', ' ')}</h1>
              <p className="text-xs text-slate-400">
                {currentBusiness?.name || 'Your Business'} • {currentBranch?.name || 'Main Branch'}
              </p>
            </div>
          </div>
        </header>

        <main className="p-6 flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
