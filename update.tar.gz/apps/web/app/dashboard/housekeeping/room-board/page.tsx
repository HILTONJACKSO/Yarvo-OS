"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, Grid, List } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function RoomBoardPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [rooms, setRooms] = useState<any[]>([]);

  useEffect(() => {
    const fetchRooms = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/rooms`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setRooms(data.map((r: any) => ({
            id: r.id,
            number: r.number,
            type: r.type,
            occupancy: r.occupancy,
            hkStatus: r.status,
            assignedTo: r.assignedTo,
            nextArrival: null
          })));
        }
      } catch (err) {
        console.error('Failed to fetch rooms', err);
      } finally {
        setLoading(false);
      }
    };
    fetchRooms();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('housekeeping.room.updated', fetchRooms);
    return () => { socket.disconnect(); };
  }, []);

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'DIRTY': return 'bg-red-500/10 text-red-400 border-red-200';
      case 'ASSIGNED': return 'bg-blue-500/10 text-blue-400 border-blue-200';
      case 'CLEANING': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'AWAITING_INSPECTION': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'READY': return 'bg-emerald-500/10 text-emerald-400 border-green-200';
      case 'RECLEANING_REQUIRED': return 'bg-amber-500/10 text-amber-400 border-yellow-200';
      case 'DO_NOT_DISTURB': return 'bg-slate-800 text-slate-200 border-slate-800';
      case 'MAINTENANCE_REQUIRED': return 'bg-red-900 text-white border-red-950';
      default: return 'bg-slate-900 text-slate-400 border-slate-800';
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Live Room Board</h1>
        </div>
        <div className="flex bg-slate-950 rounded-md border p-1 shadow-sm">
          <button className="p-1.5 bg-slate-800 rounded text-slate-200"><Grid size={18} /></button>
          <button className="p-1.5 hover:bg-slate-900 rounded text-slate-400"><List size={18} /></button>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border p-4 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search room number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
          />
        </div>
        <select className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-slate-300 bg-slate-950">
          <option value="">All Floors</option>
          <option value="1">Floor 1</option>
          <option value="2">Floor 2</option>
        </select>
        <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-slate-900 transition">
          <Filter size={18} /> Status Filter
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading live room board...</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {rooms.map(room => (
            <div key={room.id} className={`bg-slate-950 rounded-xl border shadow-sm overflow-hidden hover:shadow-md transition cursor-pointer flex flex-col`}>
              <div className={`px-4 py-3 border-b flex justify-between items-center ${getStatusColor(room.hkStatus).split(' ')[0]} bg-opacity-20`}>
                <div className="font-black text-xl text-slate-50">{room.number}</div>
                <div className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${getStatusColor(room.hkStatus)}`}>
                  {room.hkStatus.replace(/_/g, ' ')}
                </div>
              </div>
              <div className="p-4 flex-1 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Occupancy:</span>
                  <span className={`font-semibold ${room.occupancy === 'OCCUPIED' ? 'text-blue-600' : 'text-slate-300'}`}>{room.occupancy}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Assigned:</span>
                  <span className="font-medium text-slate-200">{room.assignedTo || 'â€”'}</span>
                </div>
                {room.nextArrival && (
                  <div className="flex justify-between pt-2 border-t">
                    <span className="text-slate-400">Next Arrival:</span>
                    <span className="font-medium text-red-600">{room.nextArrival}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
