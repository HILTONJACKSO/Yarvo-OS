"use client";

import { useState, useEffect } from 'react';
import { Play, Pause, CheckCircle, AlertTriangle, ListChecks } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function MyTasksPage() {
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/tasks`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          const currentUserId = localStorage.getItem('user_id') || localStorage.getItem('employee_id');
          // Filter out only tasks that are assigned to this user and not completed.
          const activeTasks = data.filter((t: any) => 
            t.status !== 'COMPLETED' && 
            t.status !== 'UNASSIGNED' && 
            t.assignedTo === currentUserId
          );
          setTasks(activeTasks.map((t: any) => ({
            id: t.id,
            room: t.roomNumber,
            type: t.taskType,
            priority: t.priority,
            status: t.status,
            nextArrival: '2:00 PM',
            startedAt: '12:40 PM',
            notes: t.notes ? [t.notes] : []
          })));
        }
      } catch (err) {
        console.error('Failed to fetch tasks', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTasks();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('housekeeping.task.updated', fetchTasks);
    return () => { socket.disconnect(); };
  }, []);

  const startTask = async (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, status: 'IN_PROGRESS' } : t));
    const token = localStorage.getItem('access_token');
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/tasks/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ status: 'IN_PROGRESS' })
    });
  };

  const completeTask = async (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
    const token = localStorage.getItem('access_token');
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/tasks/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ status: 'AWAITING_INSPECTION' })
    });
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-400">Loading your tasks...</div>;
  }

  return (
    <div className="max-w-md mx-auto space-y-6 pb-20">
      <div className="bg-slate-950 p-4 border-b shadow-sm sticky top-0 z-10">
        <h1 className="text-2xl font-black text-slate-50">My Tasks</h1>
      </div>

      <div className="px-4 space-y-4">
        {tasks.map(task => (
          <div key={task.id} className={`bg-slate-950 rounded-2xl border shadow-sm overflow-hidden ${task.status === 'IN_PROGRESS' ? 'border-brand-primary ring-1 ring-brand-primary' : ''}`}>
            <div className={`p-5 ${task.status === 'IN_PROGRESS' ? 'bg-brand-primary/5' : ''}`}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-4xl font-black text-slate-50 mb-1">{task.room}</h2>
                  <p className="font-semibold text-brand-primary">{task.type}</p>
                </div>
                {task.priority === 'High' && (
                  <span className="px-3 py-1 bg-red-500/10 text-red-700 rounded-full text-xs font-bold uppercase tracking-wider">High Priority</span>
                )}
              </div>

              {task.nextArrival && (
                <div className="mb-4 bg-red-50 text-red-400 p-3 rounded-lg text-sm font-medium border border-red-100">
                  âš ï¸ Next Arrival: {task.nextArrival}
                </div>
              )}

              {task.notes.length > 0 && (
                <div className="mb-4 bg-blue-50 text-blue-400 p-3 rounded-lg text-sm font-medium border border-blue-100">
                  â„¹ï¸ Note: {task.notes[0]}
                </div>
              )}

              {task.status === 'ASSIGNED' && (
                <button onClick={() => startTask(task.id)} className="w-full py-4 bg-brand-primary text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-brand-primary/90 transition shadow-md">
                  <Play size={20} fill="currentColor" /> Start Cleaning
                </button>
              )}

              {task.status === 'IN_PROGRESS' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm text-slate-400 bg-slate-950 p-3 rounded-lg border mb-4">
                    <span>Started: {task.startedAt}</span>
                    <span className="font-bold text-brand-primary animate-pulse">00:32:15</span>
                  </div>
                  
                  <button className="w-full py-3 bg-slate-800 text-slate-200 rounded-xl font-bold flex items-center justify-center gap-2 border">
                    <ListChecks size={20} /> Open Checklist (0/15)
                  </button>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <button className="py-3 bg-amber-500/10 text-amber-400 rounded-xl font-bold flex items-center justify-center gap-2 border border-amber-200">
                      <Pause size={18} fill="currentColor" /> Pause
                    </button>
                    <button className="py-3 bg-red-500/10 text-red-400 rounded-xl font-bold flex items-center justify-center gap-2 border border-red-200 text-sm">
                      <AlertTriangle size={16} /> Problem
                    </button>
                  </div>

                  <button onClick={() => completeTask(task.id)} className="w-full py-4 bg-green-600 text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-green-700 transition shadow-md mt-4">
                    <CheckCircle size={20} /> Complete Cleaning
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
