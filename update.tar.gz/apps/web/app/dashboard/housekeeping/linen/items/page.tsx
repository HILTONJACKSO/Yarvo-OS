"use client";

import { useState, useEffect } from 'react';
import { Search, Plus, Filter, Package, AlertCircle } from 'lucide-react';
import Link from 'next/link';

export default function LinenItemsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/linen/items`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setItems(data.map((i: any) => ({
            id: i.id,
            name: i.name,
            code: i.sku || i.id.substring(0, 8),
            category: i.categoryId || 'General',
            stdQty: 2, // standard qty
            stockStatus: 'NORMAL' // stock status
          })));
        }
      } catch (err) {
        console.error('Failed to fetch linen items', err);
      } finally {
        setLoading(false);
      }
    };
    fetchItems();
  }, []);

  const getStockBadge = (status: string) => {
    switch(status) {
      case 'NORMAL': return <span className="text-green-700 bg-emerald-500/10 font-medium text-xs px-2 py-1 rounded-md border border-green-200">Normal Stock</span>;
      case 'LOW': return <span className="text-orange-700 bg-orange-100 font-medium text-xs px-2 py-1 rounded-md border border-orange-200">Low Stock</span>;
      case 'CRITICAL': return <span className="text-red-700 bg-red-500/10 font-medium text-xs px-2 py-1 rounded-md border border-red-200 flex items-center gap-1 w-max"><AlertCircle size={12}/> Critical Need</span>;
      default: return <span className="text-slate-400 font-medium text-xs">{status}</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Linen Catalog</h1>
          <p className="text-slate-400 mt-1">Manage standard linen configurations, quantities, and stock alerts.</p>
        </div>
        <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-primary/90 transition flex items-center gap-2">
          <Plus size={18} /> Add Linen Item
        </button>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input type="text" placeholder="Search linen items..." className="w-full pl-9 pr-4 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50" />
          </div>
          <div className="flex gap-2">
            <Link href="/dashboard/housekeeping/linen/movements" className="px-3 py-1.5 text-sm bg-slate-950 border rounded-md hover:bg-slate-900 text-slate-300 font-medium flex items-center gap-2">
              Linen Movements &rarr;
            </Link>
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-950 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Code</th>
              <th className="p-4 font-semibold">Item Name</th>
              <th className="p-4 font-semibold">Category</th>
              <th className="p-4 font-semibold">Std Room Qty</th>
              <th className="p-4 font-semibold">Stock Status</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={6} className="p-8 text-center text-slate-400">Loading catalog...</td></tr>
            ) : items.map((item) => (
              <tr key={item.id} className="hover:bg-slate-900 transition">
                <td className="p-4 text-sm font-medium text-slate-400 font-mono">{item.code}</td>
                <td className="p-4 font-bold text-slate-50 flex items-center gap-2"><Package size={16} className="text-gray-400"/> {item.name}</td>
                <td className="p-4 text-sm text-slate-400">{item.category}</td>
                <td className="p-4 font-medium text-slate-200">{item.stdQty} per room</td>
                <td className="p-4">{getStockBadge(item.stockStatus)}</td>
                <td className="p-4 text-right">
                  <button className="text-brand-primary font-medium text-sm hover:underline">Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
