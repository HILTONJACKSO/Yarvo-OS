"use client";

import { useState, useEffect } from 'react';
import { Search, Eye, CheckCircle, AlertTriangle, AlertCircle } from 'lucide-react';
import Link from 'next/link';

export default function RoomInspectionsPage() {
  const [inspections, setInspections] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInspections = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/inspections`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setInspections(data.map((i: any) => ({
            id: i.id,
            room: i.roomId,
            type: 'Checkout Cleaning',
            status: i.inspectionStatus,
            housekeeper: i.inspectedByEmployeeId || 'Unassigned',
            completedAt: i.completedAt || null,
            issues: null
          })));
        }
      } catch (err) {
        console.error('Failed to fetch inspections', err);
      } finally {
        setLoading(false);
      }
    };
    fetchInspections();
  }, []);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'PENDING': return <span className="text-purple-700 bg-purple-100 font-medium text-xs px-2 py-1 rounded-md border border-purple-200">Pending</span>;
      case 'IN_PROGRESS': return <span className="text-blue-700 bg-blue-500/10 font-medium text-xs px-2 py-1 rounded-md border border-blue-200">In Progress</span>;
      case 'PASSED': return <span className="text-green-700 bg-emerald-500/10 font-medium text-xs px-2 py-1 rounded-md border border-green-200">Passed</span>;
      case 'FAILED': return <span className="text-red-700 bg-red-500/10 font-medium text-xs px-2 py-1 rounded-md border border-red-200">Failed (Reclean)</span>;
      default: return <span className="text-slate-400 font-medium text-xs">{status}</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Room Inspections</h1>
          <p className="text-slate-400 mt-1">Review cleaned rooms before they are marked as Ready for guests.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input type="text" placeholder="Search room or housekeeper..." className="w-full pl-9 pr-4 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50" />
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 text-sm bg-slate-950 border rounded-md hover:bg-slate-900 text-slate-300 font-medium">Pending Only</button>
            <button className="px-3 py-1.5 text-sm bg-slate-950 border rounded-md hover:bg-slate-900 text-slate-300 font-medium">All Statuses</button>
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-950 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Inspection ID</th>
              <th className="p-4 font-semibold">Room</th>
              <th className="p-4 font-semibold">Cleaning Type</th>
              <th className="p-4 font-semibold">Housekeeper</th>
              <th className="p-4 font-semibold">Finished At</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400">Loading inspections...</td></tr>
            ) : inspections.map((insp) => (
              <tr key={insp.id} className="hover:bg-slate-900 transition">
                <td className="p-4 text-sm font-medium text-slate-400">{insp.id}</td>
                <td className="p-4 font-bold text-slate-50 text-lg">{insp.room}</td>
                <td className="p-4 text-sm">{insp.type}</td>
                <td className="p-4 text-sm text-slate-300">{insp.housekeeper}</td>
                <td className="p-4 text-sm text-slate-400">{insp.completedAt}</td>
                <td className="p-4">
                  <div className="flex items-center gap-2">
                    {getStatusBadge(insp.status)}
                    {insp.issues && <span className="flex items-center gap-1 text-xs text-red-600 font-bold bg-red-50 px-1.5 py-0.5 rounded border border-red-100"><AlertCircle size={12}/> {insp.issues} Issues</span>}
                  </div>
                </td>
                <td className="p-4 text-right">
                  {insp.status === 'PENDING' ? (
                    <button className="inline-flex items-center gap-2 px-3 py-1.5 bg-brand-primary text-white text-sm font-medium rounded hover:bg-brand-primary/90 transition">
                      <Eye size={16} /> Start
                    </button>
                  ) : insp.status === 'IN_PROGRESS' ? (
                    <button className="inline-flex items-center gap-2 px-3 py-1.5 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 transition">
                      <Eye size={16} /> Continue
                    </button>
                  ) : (
                    <button className="inline-flex items-center gap-2 px-3 py-1.5 bg-slate-950 border text-slate-300 text-sm font-medium rounded hover:bg-slate-900 transition">
                      View Report
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
