"use client";

import { useState, useEffect } from 'react';
import { Search, Users, ArrowRight, UserPlus, CheckCircle2 } from 'lucide-react';
import Link from 'next/link';
import { io } from 'socket.io-client';

export default function AssignTasksPage() {
  const [unassignedTasks, setUnassignedTasks] = useState<any[]>([]);
  const [staff, setStaff] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/tasks`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          const unassigned = data.filter((t: any) => t.status === 'PENDING' || t.status === 'UNASSIGNED');
          setUnassignedTasks(unassigned.map((t: any) => ({
            id: t.id,
            room: t.roomNumber || t.room?.number || 'Unknown',
            type: t.taskType,
            priority: t.priority,
            floor: t.room?.floor || '1'
          })));
        }
      } catch (err) {
        console.error('Failed to fetch tasks', err);
      } finally {
        setLoading(false);
      }
    };

    const fetchStaff = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const businessId = localStorage.getItem('business_id');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/staff`, {
          headers: { 
            'Authorization': `Bearer ${token}`,
            'x-business-id': businessId || ''
          }
        });
        if (res.ok) {
          const data = await res.json();
          setStaff(data.map((s: any) => ({
            id: s.id,
            name: s.user?.name || s.role,
            role: s.role,
            activeTasks: 0,
            floorPreference: 'All'
          })));
        } else {
          setStaff([]);
        }
      } catch (err) {
        console.error('Failed to fetch staff', err);
        setStaff([]);
      }
    };

    fetchTasks();
    fetchStaff();
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('housekeeping.task.updated', fetchTasks);

    return () => { socket.disconnect(); };
  }, []);

  const assignTask = async (taskId: string, staffId: string) => {
    const token = localStorage.getItem('access_token');
    await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/tasks/${taskId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ status: 'ASSIGNED', assignedTo: staffId }) // Backend needs assignedTo handling, but for now we'll just set status to ASSIGNED to remove from unassigned list
    });
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Assign Tasks</h1>
          <p className="text-slate-400 mt-1">Assign unassigned cleaning tasks to on-duty staff.</p>
        </div>
        <button className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-primary/90 transition">
          Auto-Assign All
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Unassigned Tasks */}
        <div className="bg-slate-950 rounded-xl shadow-sm border flex flex-col h-[600px]">
          <div className="px-6 py-4 border-b bg-slate-900 flex justify-between items-center">
            <h3 className="font-bold text-slate-50">Unassigned Tasks ({unassignedTasks.length})</h3>
            <div className="flex gap-2">
              <select className="text-sm border rounded px-2 py-1 bg-slate-950 focus:outline-none">
                <option value="">All Floors</option>
                <option value="1">Floor 1</option>
                <option value="2">Floor 2</option>
              </select>
            </div>
          </div>
          <div className="p-4 flex-1 overflow-y-auto space-y-3">
            {loading ? (
              <div className="text-center p-8 text-slate-400">Loading tasks...</div>
            ) : unassignedTasks.length === 0 ? (
              <div className="text-center p-8 text-slate-400 flex flex-col items-center">
                <CheckCircle2 size={48} className="text-green-500 mb-3" />
                <p className="font-medium text-slate-50">All tasks assigned!</p>
                <p className="text-sm">Great job keeping the board clear.</p>
              </div>
            ) : (
              unassignedTasks.map(task => (
                <div key={task.id} className="p-4 border rounded-lg hover:border-brand-primary/50 hover:bg-brand-primary/5 transition cursor-pointer flex justify-between items-center group">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-50 text-lg">{task.room}</span>
                      {task.priority === 'High' && <span className="px-2 py-0.5 bg-red-500/10 text-red-700 text-xs font-bold rounded">High Priority</span>}
                      {task.priority === 'VIP' && <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs font-bold rounded">VIP</span>}
                    </div>
                    <p className="text-sm text-slate-400">{task.type} â€¢ Floor {task.floor}</p>
                  </div>
                  <button className="text-gray-400 group-hover:text-brand-primary p-2 rounded-full hover:bg-slate-950">
                    <ArrowRight size={20} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Staff List */}
        <div className="bg-slate-950 rounded-xl shadow-sm border flex flex-col h-[600px]">
          <div className="px-6 py-4 border-b bg-slate-900 flex justify-between items-center">
            <h3 className="font-bold text-slate-50">On-Duty Staff ({staff.length})</h3>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input type="text" placeholder="Search staff..." className="text-sm border rounded pl-8 pr-2 py-1 w-48 focus:outline-none focus:ring-2 focus:ring-brand-primary/50" />
            </div>
          </div>
          <div className="p-4 flex-1 overflow-y-auto space-y-3">
            {loading ? (
              <div className="text-center p-8 text-slate-400">Loading staff...</div>
            ) : (
              staff.map(person => (
                <div key={person.id} className="p-4 border rounded-lg flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-brand-primary/10 text-brand-primary flex items-center justify-center font-bold">
                      {person.name.split(' ').map((n: string) => n[0]).join('')}
                    </div>
                    <div>
                      <p className="font-bold text-slate-50">{person.name}</p>
                      <p className="text-xs text-slate-400">{person.role} â€¢ Pref: Floor {person.floorPreference}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm font-bold text-slate-50">{person.activeTasks}</p>
                      <p className="text-xs text-slate-400">Active Tasks</p>
                    </div>
                    <button onClick={() => assignTask(unassignedTasks[0]?.id, person.id)} disabled={unassignedTasks.length === 0} className="p-2 border rounded-md text-brand-primary hover:bg-brand-primary hover:text-white transition group flex items-center gap-1 text-sm font-medium disabled:opacity-50">
                      <UserPlus size={16} /> Assign
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
