"use client";

import { useState, useEffect } from 'react';
import { Search, Filter, BedDouble, BellOff, CalendarClock } from 'lucide-react';
import Link from 'next/link';

export default function StayOverServicePage() {
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/housekeeping/stay-over`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setServices(data.map((s: any) => ({
            id: s.id,
            room: s.roomId,
            date: 'Today',
            status: s.status,
            housekeeper: s.completedByEmployeeId || null,
            dndObservedAt: s.dndObservedAt || null,
            recheckAt: s.recheckTime || null
          })));
        }
      } catch (err) {
        console.error('Failed to fetch stay-over services', err);
      } finally {
        setLoading(false);
      }
    };
    fetchServices();
  }, []);

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'PENDING': return <span className="text-slate-300 bg-slate-800 font-medium text-xs px-2 py-1 rounded-md border">Pending</span>;
      case 'SCHEDULED': return <span className="text-blue-700 bg-blue-500/10 font-medium text-xs px-2 py-1 rounded-md border border-blue-200">Scheduled</span>;
      case 'COMPLETED': return <span className="text-green-700 bg-emerald-500/10 font-medium text-xs px-2 py-1 rounded-md border border-green-200">Completed</span>;
      case 'DO_NOT_DISTURB': return <span className="text-red-700 bg-red-500/10 font-medium text-xs px-2 py-1 rounded-md border border-red-200 flex items-center gap-1 w-max"><BellOff size={12}/> DND Active</span>;
      default: return <span className="text-slate-400 font-medium text-xs">{status}</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/housekeeping" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-slate-50">Stay-Over Services</h1>
          <p className="text-slate-400 mt-1">Manage daily cleaning for in-house guests and track Do-Not-Disturb statuses.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-900 flex justify-between items-center">
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input type="text" placeholder="Search room..." className="w-full pl-9 pr-4 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/50" />
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 text-sm bg-slate-950 border rounded-md hover:bg-slate-900 text-slate-300 font-medium flex items-center gap-2"><Filter size={14}/> Filter</button>
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-950 border-b text-slate-400 text-sm">
            <tr>
              <th className="p-4 font-semibold">Service ID</th>
              <th className="p-4 font-semibold">Room</th>
              <th className="p-4 font-semibold">Date</th>
              <th className="p-4 font-semibold">Status</th>
              <th className="p-4 font-semibold">DND Observed</th>
              <th className="p-4 font-semibold">Re-check At</th>
              <th className="p-4 font-semibold text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y text-slate-200">
            {loading ? (
              <tr><td colSpan={7} className="p-8 text-center text-slate-400">Loading services...</td></tr>
            ) : services.map((service) => (
              <tr key={service.id} className="hover:bg-slate-900 transition">
                <td className="p-4 text-sm font-medium text-slate-400">{service.id}</td>
                <td className="p-4 font-bold text-slate-50 text-lg flex items-center gap-2"><BedDouble size={18} className="text-gray-400"/> {service.room}</td>
                <td className="p-4 text-sm font-medium text-slate-300">{service.date}</td>
                <td className="p-4">{getStatusBadge(service.status)}</td>
                <td className="p-4 text-sm text-slate-400">{service.dndObservedAt || 'â€”'}</td>
                <td className="p-4 text-sm text-slate-400">
                  {service.recheckAt ? (
                    <span className="flex items-center gap-1 text-orange-600 font-medium"><CalendarClock size={14}/> {service.recheckAt}</span>
                  ) : 'â€”'}
                </td>
                <td className="p-4 text-right">
                  <button className="text-brand-primary font-medium text-sm hover:underline">Manage</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
