"use client";

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Save } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function NewMenuPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [description, setDescription] = useState('');
  const [customerVisible, setCustomerVisible] = useState(true);
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    setIsSaving(true);
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      const branchId = localStorage.getItem('branch_id'); // if any

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || process.env.NEXT_PUBLIC_API_URL}/menus`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || '',
          'x-branch-id': branchId || ''
        },
        body: JSON.stringify({
          name,
          code,
          description,
          customerVisible,
          startTime,
          endTime
        })
      });

      if (res.ok) {
        router.push('/dashboard/catalog/menus');
      } else {
        console.error('Failed to create menu');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      <div className="flex items-center gap-4">
        <Link href="/dashboard/catalog/menus" className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-50 transition-colors">
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Create New Menu</h2>
          <p className="text-slate-400">Configure a new menu for a specific service point, time, or event.</p>
        </div>
      </div>

      <form onSubmit={handleSave} className="bg-slate-950 rounded-xl border border-slate-800 p-6 space-y-8">
        <div className="space-y-6">
          <h3 className="text-lg font-medium text-slate-50 border-b border-slate-800 pb-4">Menu Details</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Menu Name <span className="text-red-500">*</span></label>
              <input 
                type="text" 
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Breakfast Menu, Poolside Drinks" 
                className="w-full px-4 py-2 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-900 text-slate-50" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Internal Code</label>
              <input 
                type="text" 
                value={code}
                onChange={e => setCode(e.target.value)}
                placeholder="e.g. MENU-BFST" 
                className="w-full px-4 py-2 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-900 text-slate-50" 
              />
              <p className="text-xs text-slate-500">Leave blank to auto-generate.</p>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Description</label>
            <textarea 
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Brief description of this menu..." 
              className="w-full px-4 py-2 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-900 text-slate-50 min-h-[100px]" 
            />
          </div>

          <label className="flex items-center gap-3">
            <input 
              type="checkbox" 
              checked={customerVisible}
              onChange={e => setCustomerVisible(e.target.checked)}
              className="w-4 h-4 text-brand-primary rounded border-slate-700" 
            />
            <span className="text-sm font-medium text-slate-300">Visible to customers (e.g. on digital menus/QR codes)</span>
          </label>
        </div>

        <div className="space-y-6">
          <h3 className="text-lg font-medium text-slate-50 border-b border-slate-800 pb-4">Availability Schedule</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Start Time (Optional)</label>
              <input 
                type="time" 
                value={startTime}
                onChange={e => setStartTime(e.target.value)}
                className="w-full px-4 py-2 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-900 text-slate-50 [color-scheme:dark]" 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">End Time (Optional)</label>
              <input 
                type="time" 
                value={endTime}
                onChange={e => setEndTime(e.target.value)}
                className="w-full px-4 py-2 border border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-900 text-slate-50 [color-scheme:dark]" 
              />
            </div>
          </div>
          <p className="text-sm text-slate-400">If both times are blank, this menu is available 24/7 during business hours.</p>
        </div>

        <div className="flex justify-end gap-3 pt-6 border-t border-slate-800">
          <Link href="/dashboard/catalog/menus" className="px-4 py-2 text-slate-300 hover:text-slate-50 font-medium transition-colors">
            Cancel
          </Link>
          <button 
            type="submit" 
            disabled={isSaving || !name}
            className="inline-flex items-center gap-2 px-6 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors font-medium disabled:opacity-50"
          >
            <Save size={18} />
            {isSaving ? 'Creating...' : 'Create Menu'}
          </button>
        </div>
      </form>
    </div>
  );
}
