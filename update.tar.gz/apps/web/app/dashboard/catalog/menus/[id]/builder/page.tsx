"use client";

import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import Link from 'next/link';
import { ArrowLeft, Search, Plus, Minus, UtensilsCrossed, Tag, Info } from 'lucide-react';
import { useParams } from 'next/navigation';

export default function MenuBuilderPage() {
  const { id: menuId } = useParams();
  
  const [menu, setMenu] = useState<any>(null);
  const [availableCatalog, setAvailableCatalog] = useState<{categories: any[], items: any[]}>({ categories: [], items: [] });
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchData = async () => {
    try {
      // Fetch current menu details
      const menuRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menus`);
      if (menuRes.ok) {
        const menus = await menuRes.json();
        const found = menus.find((m: any) => m.id === menuId);
        setMenu(found);
      }

      // Fetch available catalog items not in menu
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      const availRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menu-builder/${menuId}/available`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        }
      });
      if (availRes.ok) {
        setAvailableCatalog(await availRes.json());
      }
    } catch (error) {
      console.error('Failed to fetch builder data', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('menu.updated', fetchData);
    socket.on('catalogItem.updated', fetchData);

    return () => {
      socket.disconnect();
    };
  }, [menuId]);

  const addCategory = async (categoryId: string) => {
    try {
      await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menu-builder/${menuId}/categories`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ categoryId })
      });
      fetchData();
    } catch (e) { console.error(e); }
  };

  const removeCategory = async (categoryId: string) => {
    try {
      await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menu-builder/${menuId}/categories/${categoryId}`, { method: 'DELETE' });
      fetchData();
    } catch (e) { console.error(e); }
  };

  const addItem = async (catalogItemId: string) => {
    try {
      await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menu-builder/${menuId}/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ catalogItemId })
      });
      fetchData();
    } catch (e) { console.error(e); }
  };

  const removeItem = async (catalogItemId: string) => {
    try {
      await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menu-builder/${menuId}/items/${catalogItemId}`, { method: 'DELETE' });
      fetchData();
    } catch (e) { console.error(e); }
  };

  if (loading) return <div className="p-8 text-center text-slate-400">Loading builder...</div>;
  if (!menu) return <div className="p-8 text-center text-slate-400">Menu not found.</div>;

  const menuCategories = menu.categories?.map((c: any) => c.category) || [];
  const menuItems = menu.items?.map((i: any) => i.catalogItem) || [];

  // Filter available by search
  const filteredAvailableItems = availableCatalog.items.filter(i => 
    i.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    i.code?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link href="/dashboard/catalog/menus" className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-50 transition-colors">
          <ArrowLeft size={20} />
        </Link>
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Menu Builder: {menu.name}</h2>
          <p className="text-slate-400">Add or remove categories and items for this specific menu.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[calc(100vh-200px)]">
        
        {/* Left Pane: Current Menu Structure */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-800 bg-slate-900 flex justify-between items-center shrink-0">
            <h3 className="font-semibold text-slate-50 flex items-center gap-2">
              <UtensilsCrossed size={18} className="text-brand-primary" />
              On This Menu
            </h3>
            <span className="text-xs font-medium bg-slate-800 text-slate-300 px-2 py-1 rounded-full">
              {menuCategories.length} Categories • {menuItems.length} Items
            </span>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar">
            {menuCategories.length === 0 && menuItems.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-4">
                <div className="w-16 h-16 rounded-full bg-slate-900 flex items-center justify-center">
                  <Plus size={24} className="text-slate-600" />
                </div>
                <p>This menu is empty. Add items from the right.</p>
              </div>
            )}

            {/* Render Categories and Items inside them */}
            {menuCategories.map((cat: any) => {
              const itemsInCat = menuItems.filter((i: any) => i.categoryId === cat.id);
              
              return (
                <div key={cat.id} className="space-y-3 bg-slate-900/50 p-4 rounded-xl border border-slate-800/50">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                    <h4 className="font-bold text-slate-50">{cat.name}</h4>
                    <button onClick={() => removeCategory(cat.id)} className="text-xs text-red-400 hover:text-red-300 font-medium">Remove Category</button>
                  </div>

                  <div className="space-y-2">
                    {itemsInCat.map((item: any) => (
                      <div key={item.id} className="flex justify-between items-center p-3 bg-slate-950 rounded-lg border border-slate-800 group hover:border-slate-600 transition-colors">
                        <div className="flex items-center gap-3">
                          {item.imageUrl ? (
                            <img src={item.imageUrl} className="w-10 h-10 rounded-md object-cover" />
                          ) : (
                            <div className="w-10 h-10 rounded-md bg-slate-800 flex items-center justify-center">
                              <UtensilsCrossed size={16} className="text-slate-500" />
                            </div>
                          )}
                          <div>
                            <div className="text-sm font-medium text-slate-100">{item.name}</div>
                            <div className="text-xs text-slate-500 font-mono">${(item.basePrice || 0).toFixed(2)}</div>
                          </div>
                        </div>
                        <button onClick={() => removeItem(item.id)} className="w-8 h-8 rounded-full bg-slate-900 text-slate-400 hover:text-red-400 hover:bg-red-500/10 flex items-center justify-center transition-colors">
                          <Minus size={16} />
                        </button>
                      </div>
                    ))}
                    {itemsInCat.length === 0 && (
                      <div className="text-xs text-slate-500 italic py-2">No items in this category yet. Add items assigned to this category.</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Pane: Available Catalog */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
          <div className="p-4 border-b border-slate-800 bg-slate-900 space-y-3 shrink-0">
            <h3 className="font-semibold text-slate-50 flex items-center gap-2">
              <Search size={18} className="text-slate-400" />
              Available Catalog
            </h3>
            <input 
              type="text" 
              placeholder="Search available items..." 
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2 bg-slate-950 border border-slate-700 rounded-lg focus:outline-none focus:border-brand-primary text-sm text-slate-100"
            />
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar">
            
            {/* Available Categories */}
            {availableCatalog.categories.length > 0 && !searchQuery && (
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Add Categories</h4>
                <div className="flex flex-wrap gap-2">
                  {availableCatalog.categories.map((cat: any) => (
                    <button 
                      key={cat.id}
                      onClick={() => addCategory(cat.id)}
                      className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 border border-slate-700 hover:border-brand-primary rounded-lg text-sm text-slate-200 transition-colors"
                    >
                      <Plus size={14} className="text-brand-primary" /> {cat.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Available Items */}
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Add Items</h4>
              {filteredAvailableItems.length === 0 ? (
                <div className="text-sm text-slate-500 py-4 text-center">No available items match your search.</div>
              ) : (
                <div className="space-y-2">
                  {filteredAvailableItems.map((item: any) => (
                    <div key={item.id} className="flex justify-between items-center p-3 bg-slate-900/50 rounded-lg border border-slate-800 hover:border-slate-600 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-slate-800 border overflow-hidden shrink-0">
                          {item.imageUrl ? <img src={item.imageUrl} className="w-full h-full object-cover" /> : <Box className="w-5 h-5 text-gray-400 m-auto mt-2.5" />}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-slate-100">{item.name}</div>
                          <div className="text-xs text-slate-500 flex items-center gap-2">
                            <span>${(item.basePrice || 0).toFixed(2)}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1"><Tag size={10}/> {item.category?.name || 'Uncategorized'}</span>
                          </div>
                        </div>
                      </div>
                      <button onClick={() => addItem(item.id)} className="w-8 h-8 rounded-full bg-brand-primary text-white hover:bg-brand-primary/80 flex items-center justify-center transition-colors shadow-sm">
                        <Plus size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

// Inline fallback for missing icon
const Box = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
  </svg>
);
