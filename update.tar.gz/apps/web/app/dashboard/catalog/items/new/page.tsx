"use client";

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, CheckCircle2, ChevronRight, Save, Upload, Plus } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function NewCatalogItemWizard() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [categories, setCategories] = useState<any[]>([]);
  const [categoryId, setCategoryId] = useState('');
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);
  
  // Step 1 State
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [customerFacingName, setCustomerFacingName] = useState('');

  const [itemType, setItemType] = useState('FOOD');
  const [showNewItemType, setShowNewItemType] = useState(false);
  const [customItemType, setCustomItemType] = useState('');

  // Step 2 State
  const [basePrice, setBasePrice] = useState('');
  const [costPrice, setCostPrice] = useState('');
  const [priceIncludesTax, setPriceIncludesTax] = useState(false);
  const [serviceChargeApplies, setServiceChargeApplies] = useState(true);
  const [discountAllowed, setDiscountAllowed] = useState(true);

  const [taxCategory, setTaxCategory] = useState('standard');
  const [showNewTax, setShowNewTax] = useState(false);
  const [customTax, setCustomTax] = useState('');

  // Step 3 State
  const [prepRequired, setPrepRequired] = useState(false);
  const [prepRoute, setPrepRoute] = useState('KITCHEN');
  const [showNewPrepRoute, setShowNewPrepRoute] = useState(false);
  const [customPrepRoute, setCustomPrepRoute] = useState('');
  const [prepTime, setPrepTime] = useState('');

  // Step 4 State
  const [inventoryTracked, setInventoryTracked] = useState(false);
  const [sellableWithoutStock, setSellableWithoutStock] = useState(true);
  const [lowStockBehavior, setLowStockBehavior] = useState('WARN_STAFF');

  // Step 6 State
  const [availability, setAvailability] = useState('ALWAYS');
  
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const token = localStorage.getItem('access_token');
        const businessId = localStorage.getItem('business_id');
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || process.env.NEXT_PUBLIC_API_URL}/catalog-categories`, {
          headers: {
            'Authorization': `Bearer ${token}`,
            'x-business-id': businessId || ''
          }
        });
        if (res.ok) {
          setCategories(await res.json());
        }
      } catch (error) {
        console.error('Failed to fetch categories', error);
      }
    };
    fetchCategories();
  }, []);

  const handleCreateCategory = async () => {
    if (!newCategoryName) return;
    setIsCreatingCategory(true);
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || process.env.NEXT_PUBLIC_API_URL}/catalog-categories`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        },
        body: JSON.stringify({
          name: newCategoryName,
          code: newCategoryName.toUpperCase().replace(/[^A-Z0-9]/g, '_').substring(0, 10)
        })
      });
      if (res.ok) {
        const newCat = await res.json();
        setCategories([...categories, newCat]);
        setCategoryId(newCat.id);
        setShowNewCategory(false);
        setNewCategoryName('');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsCreatingCategory(false);
    }
  };

  const steps = [
    { id: 1, name: 'Basic Information', description: 'Name, Category, and Type' },
    { id: 2, name: 'Pricing & Taxes', description: 'Base price and rules' },
    { id: 3, name: 'Preparation', description: 'Routing and prep time' },
    { id: 4, name: 'Variations', description: 'Sizes and modifiers' },
    { id: 5, name: 'Media & Details', description: 'Images and description' },
    { id: 6, name: 'Availability', description: 'Branches and status' },
  ];

  const handleNext = () => {
    if (currentStep < 6) setCurrentStep(c => c + 1);
  };

  const handlePrev = () => {
    if (currentStep > 1) setCurrentStep(c => c - 1);
  };

  const handleSave = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const businessId = localStorage.getItem('business_id');

      const payload = {
        name,
        code,
        customerFacingName,
        categoryId,
        itemType: showNewItemType ? customItemType : itemType,
        basePrice,
        costPrice,
        taxCategoryId: showNewTax ? customTax : taxCategory,
        priceIncludesTax,
        serviceChargeApplies,
        discountAllowed,
        preparationRequired: prepRequired,
        preparationRoute: showNewPrepRoute ? customPrepRoute : prepRoute,
        preparationTimeMinutes: prepTime,
        inventoryTracked,
        sellableWithoutStock,
        lowStockBehavior
      };

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || process.env.NEXT_PUBLIC_API_URL}/catalog-items`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId || ''
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        router.push('/dashboard/catalog/items');
      } else {
        console.error('Failed to save item');
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/catalog/items" className="p-2 border rounded-md hover:bg-slate-900 transition-colors">
            <ArrowLeft size={20} className="text-slate-400" />
          </Link>
          <div>
            <h2 className="text-2xl font-bold text-slate-50">Add New Product or Service</h2>
            <p className="text-slate-400">Create a new item in your catalog.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 border border-slate-800 text-slate-300 rounded-md hover:bg-slate-900 transition-colors font-medium">
            Save as Draft
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 mt-8">
        {/* Sidebar Steps */}
        <div className="w-full lg:w-64 shrink-0">
          <nav aria-label="Progress">
            <ol role="list" className="overflow-hidden lg:block hidden">
              {steps.map((step, stepIdx) => (
                <li key={step.name} className={`relative ${stepIdx !== steps.length - 1 ? 'pb-10' : ''}`}>
                  {stepIdx !== steps.length - 1 ? (
                    <div className="absolute left-4 top-4 -ml-px mt-0.5 h-full w-0.5 bg-gray-200" aria-hidden="true" />
                  ) : null}
                  <button onClick={() => setCurrentStep(step.id)} className="relative flex items-start group">
                    <span className="h-9 flex items-center">
                      <span className={`relative z-10 w-8 h-8 flex items-center justify-center rounded-full border-2 bg-slate-950 ${
                        currentStep === step.id ? 'border-brand-primary text-brand-primary' : 
                        currentStep > step.id ? 'border-brand-primary bg-brand-primary text-white' : 
                        'border-slate-700 text-slate-400'
                      }`}>
                        {currentStep > step.id ? <CheckCircle2 size={16} /> : <span className="text-sm font-medium">{step.id}</span>}
                      </span>
                    </span>
                    <span className="ml-4 min-w-0 flex flex-col text-left">
                      <span className={`text-sm font-medium tracking-wide ${currentStep === step.id ? 'text-brand-primary' : 'text-slate-400'}`}>{step.name}</span>
                      <span className="text-xs text-slate-400">{step.description}</span>
                    </span>
                  </button>
                </li>
              ))}
            </ol>
            {/* Mobile Progress Bar */}
            <div className="lg:hidden flex items-center gap-2 mb-6">
              <span className="text-sm font-medium text-brand-primary">Step {currentStep} of 6:</span>
              <span className="text-sm text-slate-400">{steps[currentStep-1].name}</span>
            </div>
          </nav>
        </div>

        {/* Form Content */}
        <div className="flex-1">
          <div className="bg-slate-950 rounded-xl shadow-sm border p-6 min-h-[500px]">
            
            {/* STEP 1 */}
            {currentStep === 1 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Basic Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Item Name <span className="text-red-500">*</span></label>
                    <input type="text" placeholder="e.g. Wagyu Burger" value={name} onChange={e => setName(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Internal Code</label>
                    <input type="text" placeholder="e.g. FOOD-001" value={code} onChange={e => setCode(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                    <p className="text-xs text-slate-400">Leave blank to auto-generate.</p>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Category <span className="text-red-500">*</span></label>
                    <select 
                      value={categoryId}
                      onChange={(e) => {
                        if (e.target.value === 'NEW') {
                          setShowNewCategory(true);
                          setCategoryId('');
                        } else {
                          setShowNewCategory(false);
                          setCategoryId(e.target.value);
                        }
                      }}
                      className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950"
                    >
                      <option value="">Select Category...</option>
                      {categories.map(cat => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                      ))}
                      <option value="NEW">+ Create New Category...</option>
                    </select>
                    
                    {showNewCategory && (
                      <div className="flex items-center gap-2 mt-2">
                        <input 
                          type="text" 
                          placeholder="New Category Name" 
                          value={newCategoryName}
                          onChange={(e) => setNewCategoryName(e.target.value)}
                          className="flex-1 px-3 py-1.5 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/20 bg-slate-900 border-slate-700"
                        />
                        <button 
                          type="button" 
                          onClick={handleCreateCategory}
                          disabled={isCreatingCategory || !newCategoryName}
                          className="px-3 py-1.5 bg-brand-primary text-white text-sm rounded-md font-medium disabled:opacity-50"
                        >
                          {isCreatingCategory ? '...' : 'Add'}
                        </button>
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Item Type <span className="text-red-500">*</span></label>
                    <select 
                      value={itemType}
                      onChange={(e) => {
                        if (e.target.value === 'NEW') {
                          setShowNewItemType(true);
                          setItemType('NEW');
                        } else {
                          setShowNewItemType(false);
                          setItemType(e.target.value);
                        }
                      }}
                      className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950"
                    >
                      <option value="FOOD">Food</option>
                      <option value="BEVERAGE">Beverage</option>
                      <option value="ALCOHOLIC_BEVERAGE">Alcoholic Beverage</option>
                      <option value="SERVICE">Service</option>
                      <option value="PACKAGE">Package</option>
                      <option value="OTHER">Other</option>
                      <option value="NEW">+ Custom Type...</option>
                    </select>
                    
                    {showNewItemType && (
                      <div className="mt-2">
                        <input 
                          type="text" 
                          placeholder="Enter custom item type (e.g. RENTAL)" 
                          value={customItemType}
                          onChange={(e) => setCustomItemType(e.target.value)}
                          className="w-full px-3 py-1.5 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/20 bg-slate-900 border-slate-700 uppercase"
                        />
                      </div>
                    )}
                  </div>

                  <div className="md:col-span-2 space-y-2">
                    <label className="text-sm font-medium text-slate-300">Customer-Facing Name (Optional)</label>
                    <input type="text" placeholder="How it appears on digital menus, if different from internal name" value={customerFacingName} onChange={e => setCustomerFacingName(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2 */}
            {currentStep === 2 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Pricing & Taxes</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Base Price <span className="text-red-500">*</span></label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                      <input type="number" placeholder="0.00" value={basePrice} onChange={e => setBasePrice(e.target.value)} className="w-full pl-8 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Cost Price (Internal)</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                      <input type="number" placeholder="0.00" value={costPrice} onChange={e => setCostPrice(e.target.value)} className="w-full pl-8 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-300">Tax Category</label>
                    <select 
                      value={taxCategory}
                      onChange={(e) => {
                        if (e.target.value === 'NEW') {
                          setShowNewTax(true);
                          setTaxCategory('NEW');
                        } else {
                          setShowNewTax(false);
                          setTaxCategory(e.target.value);
                        }
                      }}
                      className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950"
                    >
                      <option value="standard">Standard VAT (20%)</option>
                      <option value="reduced">Reduced VAT (5%)</option>
                      <option value="zero">Zero Rated (0%)</option>
                      <option value="exempt">Tax Exempt</option>
                      <option value="NEW">+ Custom Tax Category...</option>
                    </select>

                    {showNewTax && (
                      <div className="mt-2">
                        <input 
                          type="text" 
                          placeholder="Enter custom tax category" 
                          value={customTax}
                          onChange={(e) => setCustomTax(e.target.value)}
                          className="w-full px-3 py-1.5 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/20 bg-slate-900 border-slate-700"
                        />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-col gap-4 mt-6">
                    <label className="flex items-center gap-3">
                      <input type="checkbox" checked={priceIncludesTax} onChange={e => setPriceIncludesTax(e.target.checked)} className="w-4 h-4 text-brand-primary rounded border-slate-700" />
                      <span className="text-sm text-slate-300">Price includes tax</span>
                    </label>
                    <label className="flex items-center gap-3">
                      <input type="checkbox" checked={serviceChargeApplies} onChange={e => setServiceChargeApplies(e.target.checked)} className="w-4 h-4 text-brand-primary rounded border-slate-700" />
                      <span className="text-sm text-slate-300">Service charge applies</span>
                    </label>
                    <label className="flex items-center gap-3">
                      <input type="checkbox" checked={discountAllowed} onChange={e => setDiscountAllowed(e.target.checked)} className="w-4 h-4 text-brand-primary rounded border-slate-700" />
                      <span className="text-sm text-slate-300">Allow discounts on this item</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3 - Preparation */}
            {currentStep === 3 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Preparation & Routing</h3>
                
                <div className="space-y-6">
                  <label className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      checked={prepRequired}
                      onChange={(e) => setPrepRequired(e.target.checked)}
                      className="w-4 h-4 text-brand-primary rounded border-slate-700" 
                    />
                    <span className="text-sm font-medium text-slate-300">Requires preparation (e.g., cooking, mixing, setup)</span>
                  </label>

                  {prepRequired && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pl-7 border-l-2 border-slate-800">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Preparation Route / Station</label>
                        <select 
                          value={prepRoute}
                          onChange={(e) => {
                            if (e.target.value === 'NEW') {
                              setShowNewPrepRoute(true);
                              setPrepRoute('NEW');
                            } else {
                              setShowNewPrepRoute(false);
                              setPrepRoute(e.target.value);
                            }
                          }}
                          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950"
                        >
                          <option value="KITCHEN">Kitchen</option>
                          <option value="BAR">Bar</option>
                          <option value="ROOM_SERVICE">Room Service</option>
                          <option value="SPA">Spa</option>
                          <option value="LAUNDRY">Laundry</option>
                          <option value="FRONT_DESK">Front Desk</option>
                          <option value="BEACH_SERVICE">Beach Service</option>
                          <option value="POOL_SERVICE">Pool Service</option>
                          <option value="EVENTS">Events</option>
                          <option value="NEW">+ Custom Station...</option>
                        </select>

                        {showNewPrepRoute && (
                          <div className="mt-2">
                            <input 
                              type="text" 
                              placeholder="e.g. SUSHI_BAR" 
                              value={customPrepRoute}
                              onChange={(e) => setCustomPrepRoute(e.target.value)}
                              className="w-full px-3 py-1.5 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-primary/20 bg-slate-900 border-slate-700 uppercase"
                            />
                          </div>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-slate-300">Estimated Prep Time (Minutes)</label>
                        <input 
                          type="number" 
                          placeholder="e.g. 15" 
                          value={prepTime}
                          onChange={(e) => setPrepTime(e.target.value)}
                          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary" 
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 4 - Inventory */}
            {currentStep === 4 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Inventory Tracking</h3>
                
                <div className="space-y-6">
                  <label className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      checked={inventoryTracked}
                      onChange={(e) => setInventoryTracked(e.target.checked)}
                      className="w-4 h-4 text-brand-primary rounded border-slate-700" 
                    />
                    <span className="text-sm font-medium text-slate-300">Track inventory for this item</span>
                  </label>

                  {inventoryTracked && (
                    <div className="space-y-6 pl-7 border-l-2 border-slate-800">
                      <div className="flex flex-col gap-4">
                        <label className="flex items-center gap-3">
                          <input 
                            type="checkbox" 
                            checked={sellableWithoutStock}
                            onChange={(e) => setSellableWithoutStock(e.target.checked)}
                            className="w-4 h-4 text-brand-primary rounded border-slate-700" 
                          />
                          <span className="text-sm font-medium text-slate-300">Allow selling when out of stock</span>
                        </label>
                      </div>

                      <div className="space-y-2 max-w-md">
                        <label className="text-sm font-medium text-slate-300">Low Stock Behavior</label>
                        <select 
                          value={lowStockBehavior}
                          onChange={(e) => setLowStockBehavior(e.target.value)}
                          className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950"
                        >
                          <option value="ALLOW_SALE">Allow Sale (No warning)</option>
                          <option value="WARN_STAFF">Warn Staff</option>
                          <option value="BLOCK_SALE">Block Sale</option>
                          <option value="MARK_SOLD_OUT">Mark as Sold Out (Customer facing)</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 5 - Modifiers & Variations */}
            {currentStep === 5 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Modifiers & Variations</h3>
                
                <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6 text-center">
                  <div className="w-16 h-16 bg-brand-primary/10 text-brand-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Plus size={24} />
                  </div>
                  <h4 className="text-md font-medium text-slate-200 mb-2">Advanced Product Configuration</h4>
                  <p className="text-sm text-slate-400 max-w-md mx-auto mb-6">
                    Variations (e.g. Small, Medium, Large) and Modifier Groups (e.g. Add-ons, Exclusions, Options) can be configured for this item after the base product is saved to the catalog.
                  </p>
                  <button 
                    type="button"
                    disabled
                    className="px-4 py-2 bg-slate-800 text-slate-500 rounded-lg font-medium text-sm cursor-not-allowed border border-slate-700"
                  >
                    Add Variations & Modifiers (Save item first)
                  </button>
                </div>
              </div>
            )}

            {/* STEP 6 - Availability */}
            {currentStep === 6 && (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <h3 className="text-lg font-medium text-slate-50 border-b pb-4">Availability & Menus</h3>
                
                <div className="space-y-6">
                  <div className="space-y-2 max-w-md">
                    <label className="text-sm font-medium text-slate-300">When is this item available?</label>
                    <select 
                      value={availability}
                      onChange={(e) => setAvailability(e.target.value)}
                      className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950"
                    >
                      <option value="ALWAYS">Always Available (24/7)</option>
                      <option value="BUSINESS_HOURS">During Standard Business Hours</option>
                      <option value="CUSTOM_SCHEDULE">Custom Schedule (Configure below)</option>
                    </select>
                  </div>

                  {availability === 'CUSTOM_SCHEDULE' && (
                    <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
                      <p className="text-sm text-slate-400 mb-4">Select the days this item can be sold:</p>
                      <div className="flex gap-2 flex-wrap">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                          <button key={day} type="button" className="w-10 h-10 rounded-full border border-slate-700 flex items-center justify-center text-sm font-medium text-slate-400 hover:border-brand-primary hover:text-brand-primary transition-colors">
                            {day}
                          </button>
                        ))}
                      </div>
                      <div className="mt-4 flex gap-4 items-center">
                        <input type="time" defaultValue="09:00" className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-md text-sm text-slate-300" />
                        <span className="text-slate-500">to</span>
                        <input type="time" defaultValue="17:00" className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-md text-sm text-slate-300" />
                      </div>
                    </div>
                  )}

                  <div className="pt-4 border-t border-slate-800">
                    <h4 className="text-sm font-medium text-slate-300 mb-3">Menu Assignment</h4>
                    <label className="flex items-center gap-3">
                      <input type="checkbox" className="w-4 h-4 text-brand-primary rounded border-slate-700" />
                      <span className="text-sm font-medium text-slate-300">Add to Master Catalog Only (Don't assign to menus yet)</span>
                    </label>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* Form Actions */}
          <div className="mt-6 flex items-center justify-between">
            <button 
              onClick={handlePrev}
              disabled={currentStep === 1}
              className="px-6 py-2.5 border border-slate-800 text-slate-300 rounded-lg hover:bg-slate-900 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Back
            </button>
            
            {currentStep < 6 ? (
              <button 
                onClick={handleNext}
                className="flex items-center gap-2 px-6 py-2.5 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors font-medium"
              >
                Continue <ChevronRight size={18} />
              </button>
            ) : (
              <button 
                onClick={handleSave}
                className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-medium"
              >
                <Save size={18} /> Save & Publish
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
