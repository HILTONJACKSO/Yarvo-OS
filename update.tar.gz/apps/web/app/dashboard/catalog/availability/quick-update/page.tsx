"use client";

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Search, EyeOff, CheckCircle2, AlertTriangle, Box } from 'lucide-react';

export default function QuickAvailabilityPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [items, setItems] = useState([
    { id: '1', name: 'Wagyu Burger', code: 'FOOD-001', category: 'Burgers', isAvailable: true, img: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=100&h=100&fit=crop' },
    { id: '2', name: 'Fresh Oysters (Dozen)', code: 'FOOD-005', category: 'Seafood', isAvailable: false, img: 'https://images.unsplash.com/photo-1599458252573-56ae36120de1?w=100&h=100&fit=crop' },
    { id: '3', name: 'Signature Mojito', code: 'BEV-001', category: 'Cocktails', isAvailable: true, img: 'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?w=100&h=100&fit=crop' },
    { id: '4', name: 'Truffle Fries', code: 'FOOD-002', category: 'Sides', isAvailable: true, img: 'https://images.unsplash.com/photo-1576107232684-1279f390859f?w=100&h=100&fit=crop' },
  ]);

  const toggleAvailability = (id: string) => {
    setItems(items.map(i => i.id === id ? { ...i, isAvailable: !i.isAvailable } : i));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex items-center gap-4 border-b pb-6">
        <Link href="/dashboard/catalog" className="p-2 border rounded-md hover:bg-slate-900 transition-colors">
          <ArrowLeft size={20} className="text-slate-400" />
        </Link>
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Quick Availability</h2>
          <p className="text-slate-400">Instantly mark items as sold out to prevent further orders.</p>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3">
        <AlertTriangle size={20} className="text-amber-600 shrink-0 mt-0.5" />
        <div className="text-sm text-amber-400">
          <p className="font-medium mb-1">Changes take effect immediately across all menus.</p>
          <p className="opacity-90">If an item is marked "Sold Out" here, it will be instantly hidden or disabled on digital menus, room service tablets, and POS terminals.</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="Search items to mark sold out..." 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-4 rounded-xl border border-slate-800 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary text-lg"
        />
      </div>

      {/* Item List */}
      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="divide-y">
          {items.map(item => (
            <div key={item.id} className={`p-4 flex items-center justify-between transition-colors ${!item.isAvailable ? 'bg-red-50/30' : 'hover:bg-slate-900'}`}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-slate-800 border overflow-hidden shrink-0 relative">
                  {item.img ? (
                    <img src={item.img} alt={item.name} className={`w-full h-full object-cover transition-opacity ${!item.isAvailable ? 'opacity-50 grayscale' : ''}`} />
                  ) : (
                    <Box className="w-6 h-6 text-gray-400 m-auto mt-3" />
                  )}
                  {!item.isAvailable && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/10">
                      <EyeOff size={16} className="text-white drop-shadow-md" />
                    </div>
                  )}
                </div>
                <div>
                  <h4 className={`font-semibold ${!item.isAvailable ? 'text-slate-400 line-through' : 'text-slate-50'}`}>{item.name}</h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs text-slate-400 font-mono">{item.code}</span>
                    <span className="text-gray-300">•</span>
                    <span className="text-xs text-slate-400">{item.category}</span>
                  </div>
                </div>
              </div>
              
              <button 
                onClick={() => toggleAvailability(item.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${
                  item.isAvailable 
                    ? 'bg-red-50 text-red-700 hover:bg-red-500/10 border border-red-200' 
                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-500/10 border border-emerald-200'
                }`}
              >
                {item.isAvailable ? (
                  <><EyeOff size={18} /> Mark Sold Out</>
                ) : (
                  <><CheckCircle2 size={18} /> Make Available</>
                )}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
