"use client";

import { useState } from 'react';
import Link from 'next/link';
import { Tag, Plus, Search, FileEdit, Trash2, CheckSquare, List } from 'lucide-react';

export default function CatalogModifiersPage() {
  const [modifiers] = useState([
    { id: '1', name: 'Meat Temperature', code: 'MOD-MEAT', type: 'Single Choice', itemsLinked: 12, required: true },
    { id: '2', name: 'Burger Add-ons', code: 'MOD-BURG-ADD', type: 'Multiple Choice', itemsLinked: 5, required: false },
    { id: '3', name: 'Drink Size', code: 'MOD-SIZE', type: 'Single Choice', itemsLinked: 24, required: true },
    { id: '4', name: 'Massage Pressure', code: 'MOD-MASS', type: 'Single Choice', itemsLinked: 14, required: true },
  ]);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Modifiers & Add-ons</h2>
          <p className="text-slate-400">Create customization options for products (e.g., sizes, cooking temperatures).</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
          <Plus size={16} /> Create Modifier Group
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        
        {/* Main List */}
        <div className="flex-1 space-y-4">
          <div className="flex gap-4 bg-slate-950 p-4 rounded-xl shadow-sm border">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search modifiers..." 
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
              />
            </div>
          </div>

          <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 border-b text-sm text-slate-400">
                  <th className="p-4 font-medium">Modifier Group</th>
                  <th className="p-4 font-medium">Type</th>
                  <th className="p-4 font-medium">Required</th>
                  <th className="p-4 font-medium">Linked Items</th>
                  <th className="p-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {modifiers.map(mod => (
                  <tr key={mod.id} className="hover:bg-slate-900/50 transition-colors group">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                          <Tag size={16} />
                        </div>
                        <div>
                          <span className="font-medium text-slate-50 block">{mod.name}</span>
                          <span className="text-xs text-slate-400 font-mono">{mod.code}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-sm text-slate-400">
                      <div className="flex items-center gap-1.5">
                        {mod.type === 'Single Choice' ? <CheckSquare size={14} className="text-brand-primary" /> : <List size={14} className="text-purple-500" />}
                        {mod.type}
                      </div>
                    </td>
                    <td className="p-4">
                      {mod.required ? (
                        <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-red-50 text-red-700 border border-red-100">Required</span>
                      ) : (
                        <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-slate-800 text-slate-300">Optional</span>
                      )}
                    </td>
                    <td className="p-4 text-sm text-slate-400">{mod.itemsLinked} items</td>
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="p-1.5 text-slate-400 hover:text-brand-primary hover:bg-brand-primary/10 rounded-md transition-colors tooltip-trigger" title="Edit Modifier">
                          <FileEdit size={16} />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors tooltip-trigger" title="Delete Modifier">
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
