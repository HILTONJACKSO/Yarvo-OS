"use client";

import { useState } from 'react';
import Link from 'next/link';
import { Box, Plus, Search, FileEdit, Trash2, Calendar } from 'lucide-react';

export default function CatalogPackagesPage() {
  const [packages] = useState([
    { id: '1', name: 'Valentine Romantic Dinner', code: 'PKG-VAL-01', type: 'Event Package', price: 150.00, items: 4, status: 'Active' },
    { id: '2', name: 'Family Beach Day Combo', code: 'PKG-BCH-02', type: 'Beach Package', price: 85.00, items: 6, status: 'Active' },
    { id: '3', name: 'Burger & Beer Special', code: 'PKG-CMB-01', type: 'Combo', price: 28.00, items: 2, status: 'Active' },
    { id: '4', name: 'Couples Spa Retreat', code: 'PKG-SPA-01', type: 'Spa Package', price: 400.00, items: 3, status: 'Active' },
  ]);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Packages & Combos</h2>
          <p className="text-slate-400">Group multiple catalog items together and sell them at a special price.</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
          <Plus size={16} /> Create Package
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 bg-slate-950 p-4 rounded-xl shadow-sm border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search packages..." 
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
          />
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 border-b text-sm text-slate-400">
              <th className="p-4 font-medium">Package Name</th>
              <th className="p-4 font-medium">Code</th>
              <th className="p-4 font-medium">Type</th>
              <th className="p-4 font-medium">Package Price</th>
              <th className="p-4 font-medium">Items Included</th>
              <th className="p-4 font-medium">Status</th>
              <th className="p-4 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {packages.map(pkg => (
              <tr key={pkg.id} className="hover:bg-slate-900/50 transition-colors group">
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-pink-50 flex items-center justify-center text-pink-600 shrink-0 border border-pink-100">
                      <Box size={20} />
                    </div>
                    <span className="font-medium text-slate-50">{pkg.name}</span>
                  </div>
                </td>
                <td className="p-4 text-sm text-slate-400 font-mono">{pkg.code}</td>
                <td className="p-4 text-sm text-slate-400">{pkg.type}</td>
                <td className="p-4 font-medium text-slate-50">${pkg.price.toFixed(2)}</td>
                <td className="p-4 text-sm text-slate-400">{pkg.items} items</td>
                <td className="p-4">
                  <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400">
                    {pkg.status}
                  </span>
                </td>
                <td className="p-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-1.5 text-slate-400 hover:text-brand-primary hover:bg-brand-primary/10 rounded-md transition-colors tooltip-trigger" title="Edit Package">
                      <FileEdit size={16} />
                    </button>
                    <button className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors tooltip-trigger" title="Delete Package">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
