"use client";

import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { Smartphone, Monitor, ChevronLeft, Search, Plus, UtensilsCrossed, Leaf, WheatOff, Flame } from 'lucide-react';

export default function DigitalMenuPreviewPage() {
  const [device, setDevice] = useState<'mobile' | 'desktop'>('mobile');
  const [selectedMenu, setSelectedMenu] = useState('1');
  const [menus, setMenus] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>('');

  useEffect(() => {
    const fetchMenus = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menus`);
        if (res.ok) {
          const data = await res.json();
          setMenus(data);
          if (data.length > 0 && selectedMenu === '1') {
            setSelectedMenu(data[0].id);
          }
        }
      } catch (error) {
        console.error('Failed to fetch menus', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMenus();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('menu.updated', fetchMenus);

    return () => {
      socket.disconnect();
    };
  }, [selectedMenu]);

  const currentMenu = menus.find(m => m.id === selectedMenu) || menus[0] || null;
  const menuCategories = currentMenu?.categories?.map((c: any) => c.category) || [];
  const menuItems = currentMenu?.items || [];

  useEffect(() => {
    if (menuCategories.length > 0 && !activeCategory) {
      setActiveCategory(menuCategories[0].id);
    }
  }, [menuCategories, activeCategory]);

  // Helper to generate a deterministic gradient based on string
  const getGradient = (str: string) => {
    const gradients = [
      'from-rose-500/80 via-purple-500/80 to-blue-500/80',
      'from-emerald-500/80 via-teal-500/80 to-cyan-500/80',
      'from-amber-500/80 via-orange-500/80 to-rose-500/80',
      'from-blue-600/80 via-indigo-600/80 to-purple-600/80'
    ];
    let hash = 0;
    for (let i = 0; i < (str?.length || 0); i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    return gradients[Math.abs(hash) % gradients.length];
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 h-[calc(100vh-100px)] flex flex-col">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Digital Menu Preview</h2>
          <p className="text-slate-400">Experience your menu exactly as guests will see it on their devices.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-slate-800 p-1 rounded-lg">
            <button 
              onClick={() => setDevice('mobile')}
              className={`p-2 rounded-md flex items-center justify-center transition-colors ${device === 'mobile' ? 'bg-slate-950 shadow-sm text-brand-primary' : 'text-slate-400 hover:text-slate-50'}`}
            >
              <Smartphone size={20} />
            </button>
            <button 
              onClick={() => setDevice('desktop')}
              className={`p-2 rounded-md flex items-center justify-center transition-colors ${device === 'desktop' ? 'bg-slate-950 shadow-sm text-brand-primary' : 'text-slate-400 hover:text-slate-50'}`}
            >
              <Monitor size={20} />
            </button>
          </div>
          <select 
            value={selectedMenu}
            onChange={(e) => setSelectedMenu(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary bg-slate-950 shadow-sm"
          >
            {menus.length === 0 && <option value="1">Loading menus...</option>}
            {menus.map(menu => (
              <option key={menu.id} value={menu.id}>{menu.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Preview Container */}
      <div className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex items-center justify-center p-8 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
        
        {/* Device Frame */}
        <div className={`bg-[#0A0A0B] shadow-2xl overflow-hidden relative transition-all duration-500 ease-in-out ${
          device === 'mobile' ? 'w-[375px] h-[812px] rounded-[3rem] border-[10px] border-[#1A1A1C] shadow-[0_0_50px_rgba(0,0,0,0.5)] ring-1 ring-white/10' : 'w-full max-w-5xl h-[750px] rounded-2xl border border-slate-700 shadow-[0_0_50px_rgba(0,0,0,0.5)] ring-1 ring-white/5'
        }`}>
          
          {/* Mobile Notch Placeholder */}
          {device === 'mobile' && (
            <div className="absolute top-0 inset-x-0 h-7 bg-[#1A1A1C] rounded-b-2xl w-36 mx-auto z-50 flex items-center justify-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-white/10"></div>
              <div className="w-12 h-1.5 rounded-full bg-white/10"></div>
            </div>
          )}

          {/* Digital Menu Content App */}
          <div className="w-full h-full flex flex-col overflow-y-auto no-scrollbar relative scroll-smooth bg-gradient-to-br from-[#0A0A0B] to-[#121214]">
            
            {/* Guest App Header (Glassmorphism) */}
            <header className="px-4 py-4 sticky top-0 z-40 flex items-center justify-between backdrop-blur-xl bg-[#0A0A0B]/70 border-b border-white/5 transition-all">
              <button className="p-2 -ml-2 text-white/70 hover:text-white transition-colors"><ChevronLeft size={24} /></button>
              <h1 className="text-lg font-semibold text-white tracking-wide">{currentMenu?.name || 'Menu'}</h1>
              <button className="p-2 -mr-2 text-white/70 hover:text-white transition-colors"><Search size={22} /></button>
            </header>

            {/* Menu Banner */}
            <div className="h-56 w-full relative shrink-0 overflow-hidden">
              {currentMenu?.imageUrl ? (
                <img src={currentMenu.imageUrl} alt={currentMenu.name} className="w-full h-full object-cover scale-105 hover:scale-100 transition-transform duration-700" />
              ) : (
                <div className={`w-full h-full bg-gradient-to-br ${getGradient(currentMenu?.name || 'default')} opacity-80`} />
              )}
              
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] via-[#0A0A0B]/50 to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 right-6">
                <h2 className="text-3xl font-bold text-white mb-2 drop-shadow-md tracking-tight">{currentMenu?.name || 'Discover Our Menu'}</h2>
                <div className="flex items-center gap-3 text-sm text-white/80 font-medium">
                  <span className="flex items-center gap-1.5 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                    <Flame size={14} className="text-orange-400" />
                    {(currentMenu?.startTime || currentMenu?.endTime) ? `${currentMenu?.startTime || ''} - ${currentMenu?.endTime || ''}` : 'Available 24/7'}
                  </span>
                </div>
              </div>
            </div>

            {/* Category Navigation (Sticky) */}
            <div className="sticky top-[68px] z-30 px-4 py-3 backdrop-blur-xl bg-[#0A0A0B]/80 border-b border-white/5 flex overflow-x-auto no-scrollbar gap-3 shrink-0 scroll-smooth">
              {menuCategories.map((cat: any) => (
                <button 
                  key={cat.id} 
                  onClick={() => {
                    setActiveCategory(cat.id);
                    document.getElementById(`category-${cat.id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className={`shrink-0 px-5 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                    activeCategory === cat.id 
                      ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.3)] scale-105' 
                      : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white border border-white/5'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            <div className="p-4 space-y-10 flex-1 pb-32">
              {menuCategories.map((cat: any) => {
                const catItems = menuItems.filter((mi: any) => mi.catalogItem?.categoryId === cat.id);
                if (catItems.length === 0) return null;
                
                return (
                  <div key={cat.id} id={`category-${cat.id}`} className="space-y-5 scroll-mt-32">
                    <h3 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
                      {cat.name}
                      <div className="h-px bg-gradient-to-r from-white/10 to-transparent flex-1 mt-1"></div>
                    </h3>
                    
                    <div className={`grid gap-4 ${device === 'desktop' ? 'grid-cols-2 gap-6' : 'grid-cols-1'}`}>
                      {catItems.map((menuItem: any) => {
                        const item = menuItem.catalogItem;
                        return (
                          <div 
                            key={item.id} 
                            className="group bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10 flex gap-4 hover:-translate-y-1 hover:shadow-2xl hover:shadow-brand-primary/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300 cursor-pointer"
                          >
                            <div className="flex-1 flex flex-col justify-between">
                              <div>
                                <h4 className="text-lg font-semibold text-white tracking-tight leading-tight group-hover:text-brand-primary transition-colors">{item.name}</h4>
                                <p className="text-sm text-white/50 mt-1.5 line-clamp-2 leading-relaxed">{item.description || 'A delightful choice from our curated selection.'}</p>
                                
                                {/* Dietary Tags Placeholder (If applicable) */}
                                {(item.dietaryTags?.length > 0) && (
                                  <div className="flex gap-2 mt-2">
                                    {item.dietaryTags.slice(0,2).map((t:any) => (
                                      <span key={t.id} className="text-[10px] uppercase tracking-wider font-bold text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-sm">
                                        {t.dietaryTag?.name}
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>
                              
                              <div className="mt-4 flex items-center justify-between">
                                <div className="text-lg font-bold text-white">${(item.basePrice || 0).toFixed(2)}</div>
                                
                                {/* Mobile-only add button (desktop has hover button on image) */}
                                {device === 'mobile' && (
                                  <button className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white group-hover:bg-brand-primary group-hover:text-white transition-colors">
                                    <Plus size={16} />
                                  </button>
                                )}
                              </div>
                            </div>
                            
                            <div className="w-28 h-28 shrink-0 rounded-xl overflow-hidden relative shadow-inner shadow-black/50 border border-white/5 group-hover:border-white/20 transition-colors">
                              {item.imageUrl ? (
                                <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                              ) : (
                                <div className="w-full h-full bg-gradient-to-br from-white/5 to-white/10 flex items-center justify-center text-white/20 group-hover:text-white/40 transition-colors">
                                  <UtensilsCrossed size={32} strokeWidth={1.5} />
                                </div>
                              )}
                              
                              {/* Desktop-only hover overlay button */}
                              {device === 'desktop' && (
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity duration-300">
                                  <button className="w-10 h-10 rounded-full bg-brand-primary text-white flex items-center justify-center shadow-lg transform scale-50 group-hover:scale-100 transition-transform duration-300">
                                    <Plus size={20} />
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
              
              {menuCategories.length === 0 && (
                <div className="h-40 flex flex-col items-center justify-center text-white/40 space-y-3">
                  <UtensilsCrossed size={48} strokeWidth={1} />
                  <p className="text-sm">No items in this menu yet.</p>
                </div>
              )}
            </div>
            
          </div>
        </div>

      </div>
    </div>
  );
}
