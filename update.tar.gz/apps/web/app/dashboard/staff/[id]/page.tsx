"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, CheckCircle2, User, Building2, Shield, Lock, Briefcase, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';

export default function AddStaffPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [successData, setSuccessData] = useState<any>(null);
  
  const [departments, setDepartments] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [businessId, setBusinessId] = useState<string>('');
  const [token, setToken] = useState<string>('');

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    employeeCode: '',
    departmentId: '',
    roleId: '',
    branchId: '',
    canSignIn: true,
  });

  useEffect(() => {
    const t = localStorage.getItem('access_token');
    if (!t) return;
    setToken(t);

    fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, {
      headers: { 'Authorization': `Bearer ${t}` }
    })
    .then(res => res.json())
    .then(data => {
      if (!data || !Array.isArray(data) || data.length === 0) {
        setLoading(false);
        return;
      }
      const bid = data[0].businessId;
      setBusinessId(bid);
      setBranches(data[0].business.branches || []);
      if (data[0].business.branches?.length > 0) {
        setFormData(prev => ({ ...prev, branchId: data[0].business.branches[0].id }));
      }
      
      return Promise.all([
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/departments`, { headers: { 'Authorization': `Bearer ${t}`, 'x-business-id': bid } }).then(r => r.json()),
        fetch(`${process.env.NEXT_PUBLIC_API_URL}/roles`, { headers: { 'Authorization': `Bearer ${t}`, 'x-business-id': bid } }).then(r => r.json())
      ]);
    })
    .then(results => {
      if (!results) return;
      const [depts, rls] = results;
      setDepartments(Array.isArray(depts) ? depts : []);
      setRoles(Array.isArray(rls) ? rls : []);
    })
    .catch(console.error);
  }, []);

  const handleChange = (e: any) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/staff`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId
        },
        body: JSON.stringify(formData)
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Failed to create staff');
      
      setSuccessData(data);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (successData) {
    return (
      <div className="max-w-2xl mx-auto bg-slate-950 p-12 rounded-3xl shadow-sm border border-slate-800 text-center animate-in zoom-in-95 duration-500">
        <div className="flex justify-center mb-8">
          <div className="w-24 h-24 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-500 relative">
            <div className="absolute inset-0 border-4 border-emerald-100 rounded-full animate-ping opacity-20"></div>
            <CheckCircle2 size={48} />
          </div>
        </div>
        <h2 className="text-3xl font-black text-slate-50 mb-3 tracking-tight">Staff Member Created!</h2>
        <p className="text-slate-400 text-lg mb-10">
          <span className="font-bold text-slate-50">{formData.fullName}</span> has been successfully added to your staff directory.
        </p>

        {successData.temporaryPassword && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 mb-10 text-left shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -mr-16 -mt-16"></div>
            <div className="flex items-center gap-3 mb-4 relative z-10">
              <div className="p-2 bg-emerald-500/10 rounded-xl text-emerald-500">
                <Lock size={20} />
              </div>
              <h3 className="font-bold text-slate-50 text-lg">Login Credentials</h3>
            </div>
            <p className="text-sm text-slate-400 mb-6 relative z-10 font-medium leading-relaxed">
              Please share these temporary credentials securely with the employee. They will be prompted to change their password upon their first login.
            </p>
            <div className="space-y-3 font-mono text-sm relative z-10">
              <div className="flex justify-between items-center bg-slate-950 p-4 border border-slate-800 rounded-xl shadow-sm">
                <span className="text-slate-500 font-sans font-medium">Email Address</span>
                <span className="font-bold text-slate-50 text-base">{formData.email}</span>
              </div>
              <div className="flex justify-between items-center bg-slate-950 p-4 border border-slate-800 rounded-xl shadow-sm">
                <span className="text-slate-500 font-sans font-medium">Temporary Password</span>
                <span className="font-bold text-emerald-400 text-lg tracking-wider">{successData.temporaryPassword}</span>
              </div>
            </div>
          </div>
        )}

        <Button onClick={() => router.push('/dashboard/staff')} className="bg-brand-primary hover:bg-brand-primary/90 h-14 px-8 rounded-xl text-base font-bold shadow-md hover:shadow-lg transition-all">
          Return to Staff Directory
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex items-center gap-2 text-sm font-medium text-slate-400">
        <Link href="/dashboard/staff" className="hover:text-brand-primary transition">Staff</Link>
        <ChevronRight size={14} />
        <span className="text-slate-50">Add New Member</span>
      </div>
      
      <div className="bg-slate-950 rounded-3xl shadow-sm border border-slate-800 overflow-hidden relative">
        <div className="h-3 bg-gradient-to-r from-brand-primary via-blue-400 to-indigo-500 w-full"></div>
        <div className="p-8 md:p-10">
          <h2 className="text-2xl font-black text-slate-50 mb-8 tracking-tight">Onboard New Employee</h2>

          <form onSubmit={onSubmit} className="space-y-10">
            {/* Personal Details Section */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-xl"><User size={20} /></div>
                <h3 className="text-lg font-bold text-slate-50">Personal Details</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-medium">Full Name</Label>
                  <Input name="fullName" value={formData.fullName} onChange={handleChange} required className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl" placeholder="e.g. Jane Doe" />
                </div>
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-medium">Email Address</Label>
                  <Input name="email" type="email" value={formData.email} onChange={handleChange} required={formData.canSignIn} className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl" placeholder="jane.doe@company.com" />
                </div>
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-medium">Phone Number <span className="text-slate-500 font-normal">(Optional)</span></Label>
                  <Input name="phone" value={formData.phone} onChange={handleChange} className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl" placeholder="+1 (555) 000-0000" />
                </div>
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-medium">Employee Code <span className="text-slate-500 font-normal">(Optional)</span></Label>
                  <Input name="employeeCode" value={formData.employeeCode} onChange={handleChange} className="h-12 bg-slate-900 border-slate-800 focus:bg-slate-950 rounded-xl" placeholder="e.g. EMP-002" />
                </div>
              </div>
            </div>

            <div className="h-px bg-slate-800 w-full"></div>

            {/* Employment Details Section */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl"><Briefcase size={20} /></div>
                <h3 className="text-lg font-bold text-slate-50">Employment Details</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-medium">Department</Label>
                  <select 
                    name="departmentId" 
                    value={formData.departmentId} 
                    onChange={handleChange}
                    className="w-full h-12 bg-slate-900 border border-slate-800 focus:bg-slate-950 rounded-xl px-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 transition-all font-medium text-slate-50 cursor-pointer appearance-none"
                    required
                  >
                    <option value="" disabled>Select Department...</option>
                    {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </select>
                </div>
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-medium">Role Assignment</Label>
                  <select 
                    name="roleId" 
                    value={formData.roleId} 
                    onChange={handleChange}
                    className="w-full h-12 bg-slate-900 border border-slate-800 focus:bg-slate-950 rounded-xl px-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 transition-all font-medium text-slate-50 cursor-pointer appearance-none"
                    required
                  >
                    <option value="" disabled>Select Role...</option>
                    {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                  </select>
                </div>
                <div className="space-y-2.5">
                  <Label className="text-slate-300 font-medium">Primary Branch</Label>
                  <select 
                    name="branchId" 
                    value={formData.branchId} 
                    onChange={handleChange}
                    className="w-full h-12 bg-slate-900 border border-slate-800 focus:bg-slate-950 rounded-xl px-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 transition-all font-medium text-slate-50 cursor-pointer appearance-none"
                    required
                  >
                    {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="h-px bg-slate-800 w-full"></div>

            {/* Security Section */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl"><Shield size={20} /></div>
                <h3 className="text-lg font-bold text-slate-50">System Access</h3>
              </div>
              <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl flex items-start gap-4 hover:border-emerald-500/50 transition-colors group cursor-pointer" onClick={() => setFormData(prev => ({ ...prev, canSignIn: !prev.canSignIn }))}>
                <div className="relative flex items-start pt-1">
                  <input 
                    type="checkbox" 
                    name="canSignIn" 
                    checked={formData.canSignIn} 
                    onChange={handleChange} 
                    className="w-5 h-5 text-emerald-500 border-slate-700 bg-slate-950 rounded cursor-pointer focus:ring-emerald-500 focus:ring-offset-slate-900"
                    id="canSignIn"
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
                <div>
                  <label htmlFor="canSignIn" className="font-bold text-slate-50 text-base block cursor-pointer group-hover:text-emerald-400 transition-colors" onClick={(e) => e.stopPropagation()}>Enable Yarvo OS Access</label>
                  <p className="text-sm text-slate-400 font-medium mt-1 leading-relaxed">If checked, this employee will be automatically provisioned with a secure account, receive a temporary password, and be able to sign in based on their assigned role permissions.</p>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-6 mt-10">
              <Button type="button" variant="outline" onClick={() => router.push('/dashboard/staff')} className="mr-4 h-12 px-6 rounded-xl font-bold">
                Cancel
              </Button>
              <Button type="submit" disabled={loading} className="bg-brand-primary hover:bg-brand-primary/90 h-12 px-8 rounded-xl font-bold shadow-md hover:shadow-lg transition-all">
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Provisioning...
                  </div>
                ) : 'Complete Onboarding'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
