"use client";

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Plus, Search, Edit, ShieldBan, MoreVertical, Building2, Shield, Mail, Phone, Filter, Users } from 'lucide-react';
import { socket } from '@/lib/socket';

export default function StaffPage() {
  const router = useRouter();
  const [staff, setStaff] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchStaff = () => {
    const token = localStorage.getItem('access_token');
    fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/current`, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => {
      if (!data || !Array.isArray(data) || data.length === 0) {
        setLoading(false);
        return null;
      }
      const businessId = data[0].businessId;
      return fetch(`${process.env.NEXT_PUBLIC_API_URL}/staff`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'x-business-id': businessId
        }
      });
    })
    .then(res => res ? res.json() : [])
    .then(data => {
      setStaff(Array.isArray(data) ? data : []);
      setLoading(false);
    })
    .catch(console.error);
  };

  useEffect(() => {
    fetchStaff();

    const onStaffUpdated = () => {
      fetchStaff();
    };

    socket.on('staff.updated', onStaffUpdated);

    return () => {
      socket.off('staff.updated', onStaffUpdated);
    };
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-slate-950 p-8 rounded-3xl border shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-brand-primary/10 to-transparent rounded-full -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10">
          <h1 className="text-3xl font-black text-slate-50 tracking-tight">Staff Directory</h1>
          <p className="text-slate-400 mt-2 font-medium">Manage your team members, roles, and access permissions.</p>
        </div>
        <div className="relative z-10">
          <Link href="/dashboard/staff/new" className="px-5 py-2.5 bg-brand-primary text-white rounded-xl font-medium hover:bg-brand-primary/90 transition flex items-center gap-2 shadow-md hover:shadow-lg">
            <Plus size={18} /> Add Staff Member
          </Link>
        </div>
      </div>

      <div className="bg-slate-950 rounded-3xl shadow-sm border border-slate-800 overflow-hidden">
        <div className="p-6 border-b flex flex-col md:flex-row gap-4 justify-between items-center bg-slate-900/50">
          <div className="relative flex-1 w-full max-w-md">
            <Search className="absolute left-4 top-3.5 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by name, email, or role..." 
              className="w-full pl-11 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary/20 transition-all shadow-sm"
            />
          </div>
          <div className="flex gap-3 w-full md:w-auto">
            <button className="flex items-center gap-2 px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-900 transition shadow-sm">
              <Filter size={16} /> Filters
            </button>
            <select className="px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-sm font-medium text-slate-300 outline-none hover:bg-slate-900 transition cursor-pointer shadow-sm">
              <option>All Departments</option>
              <option>Management</option>
              <option>Restaurant</option>
              <option>Front Desk</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-950 text-gray-400 text-xs uppercase tracking-wider font-bold border-b border-slate-800">
              <tr>
                <th className="px-8 py-5">Employee Details</th>
                <th className="px-6 py-5">Role & Department</th>
                <th className="px-6 py-5">Contact Info</th>
                <th className="px-6 py-5">Status</th>
                <th className="px-6 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 text-sm">
              {staff.map((employee: any) => (
                <tr key={employee.id} className="hover:bg-blue-50/50 transition cursor-pointer group" onClick={() => router.push(`/dashboard/staff/${employee.id}`)}>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-brand-primary/10 text-brand-primary flex items-center justify-center font-bold text-lg group-hover:scale-105 transition-transform">
                        {employee.fullName.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-50 text-base">{employee.fullName}</div>
                        <div className="text-slate-400 text-xs font-medium mt-0.5">{employee.employeeCode || `EMP-${employee.id.substring(0, 4)}`}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-2 text-sm font-medium text-slate-50">
                        <Shield size={14} className="text-gray-400" />
                        {employee.roles?.map((r: any) => r.role.name).join(', ') || 'Unassigned'}
                      </div>
                      <div className="flex items-center gap-2 text-xs font-medium text-slate-400">
                        <Building2 size={14} className="text-gray-400" />
                        {employee.department?.name || 'Unassigned'}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex flex-col gap-1.5">
                      <div className="flex items-center gap-2 text-sm text-slate-400">
                        <Mail size={14} className="text-gray-400" />
                        {employee.email || 'No email provided'}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-slate-400">
                        <Phone size={14} className="text-gray-400" />
                        {employee.phone || 'No phone provided'}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className={`px-3 py-1.5 rounded-full text-xs font-bold tracking-wide ${employee.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-700' : 'bg-red-500/10 text-red-700'}`}>
                      {employee.status}
                    </span>
                  </td>
                  <td className="px-6 py-5 text-right" onClick={e => e.stopPropagation()}>
                    <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2.5 text-slate-400 hover:text-brand-primary transition rounded-xl hover:bg-brand-primary/10 bg-slate-950 shadow-sm border border-slate-800"><Edit size={16} /></button>
                      <button className="p-2.5 text-slate-400 hover:text-red-500 transition rounded-xl hover:bg-red-50 bg-slate-950 shadow-sm border border-slate-800"><ShieldBan size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))}
              {staff.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-8 py-16 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-900 mb-4">
                      <Users size={24} className="text-gray-400" />
                    </div>
                    <h3 className="text-lg font-bold text-slate-50 mb-1">No staff members found</h3>
                    <p className="text-slate-400">Get started by adding your first team member.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
