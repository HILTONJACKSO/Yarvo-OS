"use client";

import { useState, useEffect } from 'react';
import { User, Lock, KeyRound } from 'lucide-react';
import { toast } from 'sonner';

export default function ProfilePage() {
  const [user, setUser] = useState<any>(null);
  const [pin, setPin] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('access_token');
    if (!token) return;
    fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => setUser(data))
      .catch(console.error);
  }, []);

  const handleUpdatePin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length !== 4) {
      toast.error('PIN must be exactly 4 digits');
      return;
    }

    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/auth/set-pin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ pin })
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || 'Failed to update PIN');
      }

      toast.success('POS PIN updated successfully!');
      setPin('');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!user) return <div className="p-8 text-slate-400">Loading profile...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-2xl font-bold text-slate-50">My Profile</h2>
        <p className="text-slate-400 text-sm mt-1">Manage your personal details and security settings</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Personal Details */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-blue-500/10 text-blue-500 rounded-xl">
              <User size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-50">Personal Details</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Email Address</label>
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-slate-50 font-medium">
                {user.email}
              </div>
            </div>
            <p className="text-xs text-slate-500">To change your email or name, please contact a system administrator.</p>
          </div>
        </div>

        {/* Security Settings */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl">
              <Lock size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-50">Security & Access</h3>
          </div>

          <form onSubmit={handleUpdatePin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">POS Manager PIN</label>
              <div className="flex gap-4">
                <input
                  type="password"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                  placeholder="4-digit PIN"
                  className="w-full h-12 bg-slate-900 border border-slate-800 text-slate-50 rounded-xl px-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-center tracking-widest text-lg font-mono"
                />
                <button
                  type="submit"
                  disabled={pin.length !== 4 || loading}
                  className="bg-brand-primary hover:bg-brand-primary/90 text-white px-6 rounded-xl font-bold transition disabled:opacity-50 whitespace-nowrap flex items-center gap-2"
                >
                  <KeyRound size={18} />
                  {loading ? 'Saving...' : 'Set PIN'}
                </button>
              </div>
              <p className="text-xs text-slate-500 mt-2">
                This 4-digit PIN is used to authorize sensitive actions like order cancellations on the POS.
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
