import CustomersPage from '../page';
export default CustomersPage;
