"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Building2 } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

export default function NewCorporateAccountPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '',
    registrationNumber: '',
    taxNumber: '',
    industry: '',
    mainContactName: '',
    mainContactPosition: '',
    mainContactPhone: '',
    mainContactEmail: '',
    companyPhone: '',
    companyEmail: '',
    billingAddress: '',
    creditAllowed: false,
    creditLimit: 0,
    paymentTerms: 'Pay Immediately',
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCreate = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('access_token');
      const payload = {
        ...formData,
        corporateNumber: `CORP-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
      };

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/corporate-accounts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        // Go back to the customer list
        router.push('/dashboard/customers');
      } else {
        console.error('Failed to create corporate account');
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft size={20} />
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Register Corporate Account</h2>
          <p className="text-slate-400 text-sm">Set up B2B clients, travel agencies, and corporate billing</p>
        </div>
      </div>

      <Card className="border-slate-800 shadow-sm">
        <CardHeader className="bg-slate-900 border-b rounded-t-xl">
          <CardTitle className="text-lg">Company Details</CardTitle>
          <CardDescription>Legal and contact information for the organization</CardDescription>
        </CardHeader>
        <CardContent className="p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2 md:col-span-2">
              <Label>Company Name <span className="text-red-500">*</span></Label>
              <Input 
                value={formData.companyName} 
                onChange={(e) => handleInputChange('companyName', e.target.value)} 
                placeholder="e.g. Acme Corporation" 
              />
            </div>
            
            <div className="space-y-2">
              <Label>Tax ID / VAT Number</Label>
              <Input 
                value={formData.taxNumber} 
                onChange={(e) => handleInputChange('taxNumber', e.target.value)} 
                placeholder="e.g. US123456789" 
              />
            </div>
            
            <div className="space-y-2">
              <Label>Registration Number</Label>
              <Input 
                value={formData.registrationNumber} 
                onChange={(e) => handleInputChange('registrationNumber', e.target.value)} 
                placeholder="Company Reg No." 
              />
            </div>

            <div className="space-y-2">
              <Label>Company Email</Label>
              <Input 
                type="email"
                value={formData.companyEmail} 
                onChange={(e) => handleInputChange('companyEmail', e.target.value)} 
                placeholder="billing@company.com" 
              />
            </div>

            <div className="space-y-2">
              <Label>Company Phone</Label>
              <Input 
                value={formData.companyPhone} 
                onChange={(e) => handleInputChange('companyPhone', e.target.value)} 
                placeholder="Main switchboard" 
              />
            </div>
          </div>

          <div className="pt-4 border-t">
            <h4 className="text-sm font-medium text-slate-200 mb-4">Main Contact Person</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Contact Name <span className="text-red-500">*</span></Label>
                <Input 
                  value={formData.mainContactName} 
                  onChange={(e) => handleInputChange('mainContactName', e.target.value)} 
                  placeholder="e.g. Jane Doe" 
                />
              </div>
              <div className="space-y-2">
                <Label>Position / Title</Label>
                <Input 
                  value={formData.mainContactPosition} 
                  onChange={(e) => handleInputChange('mainContactPosition', e.target.value)} 
                  placeholder="e.g. Travel Manager" 
                />
              </div>
              <div className="space-y-2">
                <Label>Direct Phone <span className="text-red-500">*</span></Label>
                <Input 
                  value={formData.mainContactPhone} 
                  onChange={(e) => handleInputChange('mainContactPhone', e.target.value)} 
                  placeholder="+1 234 567 890" 
                />
              </div>
              <div className="space-y-2">
                <Label>Direct Email</Label>
                <Input 
                  type="email"
                  value={formData.mainContactEmail} 
                  onChange={(e) => handleInputChange('mainContactEmail', e.target.value)} 
                  placeholder="jane.doe@company.com" 
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t space-y-4">
            <h4 className="text-sm font-medium text-slate-200">Billing & Credit Terms</h4>
            
            <div className="flex items-center space-x-3 p-4 border rounded-lg bg-slate-900/50">
              <Checkbox 
                id="credit" 
                checked={formData.creditAllowed} 
                onCheckedChange={(checked) => handleInputChange('creditAllowed', checked)}
              />
              <div className="space-y-1">
                <Label htmlFor="credit" className="font-medium cursor-pointer">Allow Credit Billing (City Ledger)</Label>
                <p className="text-xs text-slate-400">Permit this company to be invoiced for services after their stay or event.</p>
              </div>
            </div>

            {formData.creditAllowed && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 border rounded-lg bg-slate-950">
                <div className="space-y-2">
                  <Label>Credit Limit ($)</Label>
                  <Input 
                    type="number"
                    min={0}
                    value={formData.creditLimit} 
                    onChange={(e) => handleInputChange('creditLimit', parseFloat(e.target.value) || 0)} 
                  />
                </div>
                <div className="space-y-2">
                  <Label>Payment Terms</Label>
                  <Select value={formData.paymentTerms} onValueChange={(val) => handleInputChange('paymentTerms', val)}>
                    <SelectTrigger><SelectValue placeholder="Select terms" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pay Immediately">Pay Immediately</SelectItem>
                      <SelectItem value="7 Days">Net 7 Days</SelectItem>
                      <SelectItem value="14 Days">Net 14 Days</SelectItem>
                      <SelectItem value="30 Days">Net 30 Days</SelectItem>
                      <SelectItem value="60 Days">Net 60 Days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

        </CardContent>
        <CardFooter className="p-6 bg-slate-900 border-t flex justify-end gap-3 rounded-b-xl">
          <Button variant="outline" onClick={() => router.back()}>Cancel</Button>
          <Button 
            className="bg-brand-primary hover:bg-brand-secondary text-white" 
            onClick={handleCreate}
            disabled={loading || !formData.companyName || !formData.mainContactName || !formData.mainContactPhone}
          >
            {loading ? 'Creating...' : 'Create Corporate Account'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
