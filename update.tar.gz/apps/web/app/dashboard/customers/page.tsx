"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Plus, Search, Filter, MoreVertical, ShieldAlert, BadgeCheck, Users, Building, AlertTriangle, Star } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { socket } from '@/lib/socket';

export default function CustomersPage() {
  const router = useRouter();
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchCustomers();

    const onCustomersUpdated = () => {
      fetchCustomers();
    };

    socket.on('customers.updated', onCustomersUpdated);
    socket.on('customer_groups.updated', onCustomersUpdated);
    socket.on('corporate_accounts.updated', onCustomersUpdated);

    return () => {
      socket.off('customers.updated', onCustomersUpdated);
      socket.off('customer_groups.updated', onCustomersUpdated);
      socket.off('corporate_accounts.updated', onCustomersUpdated);
    };
  }, []);

  const fetchCustomers = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/customers`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setCustomers(data);
      }
    } catch (error) {
      console.error('Failed to fetch customers', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCustomers = customers.filter(c => 
    c.displayName.toLowerCase().includes(search.toLowerCase()) ||
    c.customerNumber.toLowerCase().includes(search.toLowerCase()) ||
    c.phone?.includes(search) ||
    c.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-200">Customers</h2>
          <p className="text-slate-400 text-sm mt-1">Manage individuals, groups, and corporate accounts</p>
        </div>
        <div className="flex gap-3">
          <Button onClick={() => router.push('/dashboard/customers/new')} className="bg-brand-primary hover:bg-brand-secondary text-white shadow-md transition-all">
            <Plus size={16} className="mr-2" /> New Customer
          </Button>
        </div>
      </div>

      <div className="bg-slate-950 border rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b flex flex-wrap gap-4 items-center justify-between bg-slate-900">
          <div className="relative flex-1 min-w-[300px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <Input 
              placeholder="Search by name, ID, email, phone..." 
              className="pl-10 border-slate-700 focus-visible:ring-brand-primary"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" className="text-slate-400 border-slate-700">
              <Filter size={18} />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <div className="px-4 pt-2 border-b">
            <TabsList className="bg-transparent space-x-2 h-auto p-0">
              <TabsTrigger value="all" className="data-[state=active]:bg-brand-primary/10 data-[state=active]:text-brand-primary rounded-t-lg rounded-b-none px-4 py-2 border-b-2 border-transparent data-[state=active]:border-brand-primary">All</TabsTrigger>
              <TabsTrigger value="individuals" className="data-[state=active]:bg-brand-primary/10 data-[state=active]:text-brand-primary rounded-t-lg rounded-b-none px-4 py-2 border-b-2 border-transparent data-[state=active]:border-brand-primary">Individuals</TabsTrigger>
              <TabsTrigger value="groups" className="data-[state=active]:bg-brand-primary/10 data-[state=active]:text-brand-primary rounded-t-lg rounded-b-none px-4 py-2 border-b-2 border-transparent data-[state=active]:border-brand-primary">Groups</TabsTrigger>
              <TabsTrigger value="corporate" className="data-[state=active]:bg-brand-primary/10 data-[state=active]:text-brand-primary rounded-t-lg rounded-b-none px-4 py-2 border-b-2 border-transparent data-[state=active]:border-brand-primary">Corporate</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="all" className="m-0">
            {loading ? (
              <div className="p-8 text-center text-slate-400">Loading customers...</div>
            ) : filteredCustomers.length === 0 ? (
              <div className="p-12 text-center text-slate-400 flex flex-col items-center">
                <Users size={48} className="text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-slate-200">No customers found</h3>
                <p className="mt-1 text-sm">Get started by adding a new customer profile.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-400">
                  <thead className="text-xs text-slate-300 uppercase bg-slate-900 border-b">
                    <tr>
                      <th className="px-6 py-4 font-medium">Customer</th>
                      <th className="px-6 py-4 font-medium">Contact</th>
                      <th className="px-6 py-4 font-medium">Type</th>
                      <th className="px-6 py-4 font-medium">Status</th>
                      <th className="px-6 py-4 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCustomers.map((c) => (
                      <tr key={c.id} className="border-b hover:bg-slate-900/50 transition cursor-pointer" onClick={() => router.push(`/dashboard/customers/${c.id}`)}>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-brand-primary/10 flex items-center justify-center text-brand-primary font-bold">
                              {c.displayName.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-medium text-slate-50 flex items-center gap-1">
                                {c.displayName}
                                {c.isVip && <Star size={16} className="text-yellow-400 fill-current" aria-label="VIP" />}
                              </div>
                              <div className="text-xs text-slate-400">{c.customerNumber}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-slate-50">{c.phone || '-'}</div>
                          <div className="text-xs text-slate-400">{c.email || '-'}</div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-200">
                            {c.customerType}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          {c.status === 'ACTIVE' ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400">Active</span>
                          ) : c.status === 'BLOCKED' ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-500/10 text-red-400 gap-1"><AlertTriangle size={12}/> Blocked</span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-800 text-slate-200">{c.status}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-slate-400" onClick={(e) => e.stopPropagation()}>
                            <MoreVertical size={16} />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
