"use client";

import { useState } from 'react';
import { 
  Users, CalendarCheck, BedDouble, Key, Settings, 
  AlertCircle, ConciergeBell, CheckCircle2,
  TrendingUp, TrendingDown, ArrowRightLeft,
  ChevronRight, LogIn, LogOut
} from 'lucide-react';
import Link from 'next/link';
import { socket } from '@/lib/socket';
import { useEffect } from 'react';

export default function FrontDeskDashboardPage() {
  const [stats, setStats] = useState({
    expectedArrivals: 0,
    checkedInToday: 0,
    currentlyInHouse: 0,
    roomsOccupied: 0,
    roomsAvailable: 0,
    checkoutPending: 0,
    roomTransfersPending: 0,
    guestRequestsOpen: 0
  });

  const [alerts, setAlerts] = useState<any[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/stays/front-desk-stats`);
        if (response.ok) {
          const data = await response.json();
          setStats(data);
        }
      } catch (error) {
        console.error('Failed to fetch front desk stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();

    socket.on('stays.updated', fetchDashboardData);
    socket.on('reservations.updated', fetchDashboardData);
    socket.on('guestRequests.updated', fetchDashboardData);

    return () => {
      socket.off('stays.updated', fetchDashboardData);
      socket.off('reservations.updated', fetchDashboardData);
      socket.off('guestRequests.updated', fetchDashboardData);
    };
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Header & Quick Actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Front Desk Operations</h2>
          <p className="text-slate-400">Manage check-ins, active stays, and daily requests.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/dashboard/front-desk/walk-in" className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
            <ConciergeBell size={16} />
            Walk-In Check-In
          </Link>
          <Link href="/dashboard/front-desk/in-house" className="inline-flex items-center gap-2 px-4 py-2 bg-slate-950 border text-slate-300 rounded-md hover:bg-slate-900 transition-colors shadow-sm font-medium">
            <Users size={16} />
            In-House Guests
          </Link>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-slate-950 rounded-xl shadow-sm border p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
              <LogIn size={20} />
            </div>
            <span className="text-xs font-medium bg-blue-50 text-blue-700 px-2 py-1 rounded-full flex items-center gap-1">
              <CheckCircle2 size={12} /> {stats.checkedInToday} Done
            </span>
          </div>
          <h3 className="text-3xl font-bold text-slate-50">{stats.expectedArrivals}</h3>
          <p className="text-sm text-slate-400 font-medium mt-1">Expected Arrivals Today</p>
        </div>

        <div className="bg-slate-950 rounded-xl shadow-sm border p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center text-green-600">
              <Users size={20} />
            </div>
          </div>
          <h3 className="text-3xl font-bold text-slate-50">{stats.currentlyInHouse}</h3>
          <p className="text-sm text-slate-400 font-medium mt-1">Currently In-House</p>
        </div>

        <div className="bg-slate-950 rounded-xl shadow-sm border p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
              <BedDouble size={20} />
            </div>
            <span className="text-xs font-medium text-slate-400 flex items-center gap-1">
              {stats.roomsAvailable} Available
            </span>
          </div>
          <h3 className="text-3xl font-bold text-slate-50">{stats.roomsOccupied}</h3>
          <p className="text-sm text-slate-400 font-medium mt-1">Rooms Occupied</p>
        </div>

        <div className="bg-slate-950 rounded-xl shadow-sm border p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center text-orange-600">
              <LogOut size={20} />
            </div>
            <span className="text-xs font-medium bg-orange-50 text-orange-700 px-2 py-1 rounded-full flex items-center gap-1">
              <AlertCircle size={12} /> Pending
            </span>
          </div>
          <h3 className="text-3xl font-bold text-slate-50">{stats.checkoutPending}</h3>
          <p className="text-sm text-slate-400 font-medium mt-1">Checkouts Pending</p>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Alerts & Notifications */}
        <div className="lg:col-span-2 bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="p-5 border-b flex justify-between items-center bg-slate-900">
            <h3 className="font-semibold text-slate-50 flex items-center gap-2">
              <AlertCircle size={18} className="text-brand-primary" /> Action Required
            </h3>
          </div>
          <div className="divide-y">
            {alerts.map(alert => (
              <div key={alert.id} className="p-4 flex items-center justify-between hover:bg-slate-900 transition-colors">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${alert.type === 'error' ? 'bg-red-500' : alert.type === 'warning' ? 'bg-amber-500' : 'bg-blue-500'}`}></div>
                  <p className="text-sm text-slate-300">{alert.message}</p>
                </div>
                <button className="text-sm font-medium text-brand-primary hover:text-brand-primary/80">
                  {alert.action}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Operational Overview */}
        <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
          <div className="p-5 border-b bg-slate-900">
            <h3 className="font-semibold text-slate-50">Task Overview</h3>
          </div>
          <div className="p-5 space-y-4">
            
            <Link href="/dashboard/front-desk/requests" className="flex items-center justify-between p-3 rounded-lg border border-slate-800 hover:border-slate-800 hover:shadow-sm transition-all group">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-md group-hover:bg-blue-500/10 transition-colors">
                  <ConciergeBell size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-50">Guest Requests</p>
                  <p className="text-xs text-slate-400">{stats.guestRequestsOpen} Open</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-gray-400 group-hover:text-slate-400" />
            </Link>

            <Link href="/dashboard/front-desk/in-house?filter=transfers" className="flex items-center justify-between p-3 rounded-lg border border-slate-800 hover:border-slate-800 hover:shadow-sm transition-all group">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-50 text-purple-600 rounded-md group-hover:bg-purple-100 transition-colors">
                  <ArrowRightLeft size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-50">Room Transfers</p>
                  <p className="text-xs text-slate-400">{stats.roomTransfersPending} Pending</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-gray-400 group-hover:text-slate-400" />
            </Link>

            <Link href="/dashboard/folios" className="flex items-center justify-between p-3 rounded-lg border border-slate-800 hover:border-slate-800 hover:shadow-sm transition-all group">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-md group-hover:bg-emerald-500/10 transition-colors">
                  <CheckCircle2 size={18} />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-50">Open Folios</p>
                  <p className="text-xs text-slate-400">{stats.currentlyInHouse} Active</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-gray-400 group-hover:text-slate-400" />
            </Link>

          </div>
        </div>

      </div>

      {/* Recent Activity */}
      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-5 border-b flex justify-between items-center">
          <h3 className="font-semibold text-slate-50">Recent Activity</h3>
          <button className="text-sm font-medium text-brand-primary">View All</button>
        </div>
        <div className="divide-y">
          {recentActivity.map(activity => (
            <div key={activity.id} className="p-4 flex items-start gap-4">
              <div className="text-xs font-medium text-gray-400 w-16 pt-1 shrink-0">{activity.time}</div>
              <div>
                <p className="text-sm font-medium text-slate-50">{activity.action}</p>
                <p className="text-sm text-slate-400 mt-0.5">{activity.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
