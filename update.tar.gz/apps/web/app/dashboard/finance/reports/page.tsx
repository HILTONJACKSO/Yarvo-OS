"use client";

import { FileText, Download, TrendingUp, Landmark, Percent } from 'lucide-react';

export default function FinancialReportsPage() {
  const reports = [
    { title: 'Profit & Loss (Income Statement)', desc: 'Summary of revenues, costs, and expenses incurred during a specific period.', icon: <TrendingUp className="text-emerald-500" /> },
    { title: 'Balance Sheet', desc: 'Snapshot of the business assets, liabilities, and equity at a specific point in time.', icon: <Landmark className="text-blue-500" /> },
    { title: 'Cash Flow Statement', desc: 'Analysis of how changes in balance sheet accounts and income affect cash.', icon: <FileText className="text-purple-500" /> },
    { title: 'Tax & VAT Report', desc: 'Calculated tax liabilities for government filing (Sales Tax, VAT, Tourism Levy).', icon: <Percent className="text-amber-500" /> },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Financial Reports</h1>
          <p className="text-slate-400 mt-1">Generate automated financial statements ready for export.</p>
        </div>
      </div>

      <div className="bg-slate-950 p-6 rounded-xl border shadow-sm">
        <div className="flex gap-4 p-4 bg-slate-900 rounded-lg border mb-6 items-end">
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Fiscal Year</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>2026</option>
              <option>2025</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Period</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>Q3 (Jul - Sep)</option>
              <option>Q2 (Apr - Jun)</option>
              <option>Q1 (Jan - Mar)</option>
              <option>Annual</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-300 mb-1">Branch</label>
            <select className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 text-sm">
              <option>All Branches (Consolidated)</option>
              <option>Main Resort</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {reports.map((report, idx) => (
            <div key={idx} className="border rounded-xl p-5 hover:border-brand-primary/50 hover:shadow-md transition cursor-pointer group">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-slate-900 rounded-lg group-hover:scale-110 transition-transform">
                  {report.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-50">{report.title}</h3>
                  <p className="text-sm text-slate-400 mt-1">{report.desc}</p>
                </div>
              </div>
              <div className="mt-6 flex gap-3">
                <button className="flex-1 px-4 py-2 bg-brand-primary text-white rounded-md text-sm font-medium hover:bg-brand-secondary transition">
                  Generate PDF
                </button>
                <button className="flex-1 px-4 py-2 border bg-slate-950 rounded-md text-sm font-medium text-slate-300 hover:bg-slate-900 transition flex items-center justify-center gap-2">
                  <Download size={16} /> Excel CSV
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
