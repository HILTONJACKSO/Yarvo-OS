"use client";

import { Plus, BarChart3, Search } from 'lucide-react';
import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

export default function ChartOfAccountsPage() {
  const [accounts, setAccounts] = useState<any[]>([]);

  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/finance/accounts`);
        if (res.ok) {
          const data = await res.json();
          setAccounts(data);
        }
      } catch (err) {
        console.error('Failed to fetch accounts', err);
      }
    };

    fetchAccounts();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('finance.updated', fetchAccounts);

    return () => {
      socket.off('finance.updated', fetchAccounts);
      socket.disconnect();
    };
  }, []);
  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Chart of Accounts</h1>
          <p className="text-slate-400 mt-1">Manage all general ledger accounts.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
          <Plus size={18} /> New Account
        </button>
      </div>

      <div className="bg-slate-950 p-6 rounded-xl border shadow-sm">
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <input type="text" placeholder="Search by account code or name..." className="w-full pl-10 pr-4 py-2 border rounded-md" />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          </div>
          <select className="border rounded-md px-4 py-2 bg-slate-900 text-slate-300">
            <option>All Types</option>
            <option>ASSET</option>
            <option>LIABILITY</option>
            <option>EQUITY</option>
            <option>REVENUE</option>
            <option>EXPENSE</option>
          </select>
        </div>

        <div className="border rounded-xl overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-900 border-b">
              <tr>
                <th className="p-4 font-medium text-slate-400 text-sm">Code</th>
                <th className="p-4 font-medium text-slate-400 text-sm">Account Name</th>
                <th className="p-4 font-medium text-slate-400 text-sm">Type</th>
                <th className="p-4 font-medium text-slate-400 text-sm">Sub-Type</th>
                <th className="p-4 font-medium text-slate-400 text-sm text-right">Current Balance</th>
                <th className="p-4 font-medium text-slate-400 text-sm text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {accounts.map((acc, idx) => (
                <tr key={idx} className="hover:bg-slate-900 cursor-pointer">
                  <td className="p-4 text-sm font-bold text-slate-300">{acc.accountCode || acc.code}</td>
                  <td className="p-4 text-sm font-medium text-slate-50">{acc.name}</td>
                  <td className="p-4 text-sm">
                    <span className={`px-2 py-1 text-xs rounded-full font-medium ${
                      acc.type === 'ASSET' ? 'bg-green-50 text-green-700' :
                      acc.type === 'LIABILITY' ? 'bg-amber-50 text-amber-700' :
                      acc.type === 'REVENUE' ? 'bg-blue-50 text-blue-700' : 'bg-red-50 text-red-700'
                    }`}>
                      {acc.type}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-slate-400">{acc.subType}</td>
                  <td className="p-4 text-sm font-medium text-right">${(acc.balance || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                  <td className="p-4 text-center">
                    <span className="px-2 py-1 bg-emerald-500/10 text-green-700 text-xs font-medium rounded-full">{acc.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
