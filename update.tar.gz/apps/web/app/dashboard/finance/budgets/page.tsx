"use client";

import { Activity, Plus } from 'lucide-react';
import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

export default function BudgetsPage() {
  const [budgets, setBudgets] = useState<any[]>([]);

  useEffect(() => {
    const fetchBudgets = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/finance/budgets`);
        if (res.ok) {
          const data = await res.json();
          setBudgets(data);
        }
      } catch (err) {
        console.error('Failed to fetch budgets', err);
      }
    };

    fetchBudgets();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('finance.updated', fetchBudgets);

    return () => {
      socket.off('finance.updated', fetchBudgets);
      socket.disconnect();
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Department Budgets</h1>
          <p className="text-slate-400 mt-1">Monitor departmental spending against allocated budgets.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
          <Plus size={18} /> New Budget
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {budgets.map((b, idx) => {
          const totalAmt = b.totalAmount !== undefined ? b.totalAmount : b.total || 0;
          const spentAmt = b.spentAmount !== undefined ? b.spentAmount : b.spent || 0;
          const percent = totalAmt > 0 ? Math.min((spentAmt / totalAmt) * 100, 100) : 0;
          const isOver = spentAmt > totalAmt;
          return (
            <div key={idx} className="bg-slate-950 p-6 rounded-xl border shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-slate-50 text-lg">{b.department}</h3>
                  <p className="text-sm text-slate-400">{b.periodStart ? new Date(b.periodStart).toLocaleString('default', { month: 'long', year: 'numeric' }) : b.period}</p>
                </div>
                <div className={`p-2 rounded-lg ${isOver ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-500'}`}>
                  <Activity size={20} />
                </div>
              </div>
              
              <div className="flex justify-between items-end mb-2">
                <div>
                  <div className="text-sm text-slate-400 mb-1">Spent</div>
                  <div className={`text-2xl font-bold ${isOver ? 'text-red-600' : 'text-slate-50'}`}>
                    ${spentAmt.toLocaleString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-slate-400 mb-1">Budget</div>
                  <div className="text-lg font-medium text-slate-300">${totalAmt.toLocaleString()}</div>
                </div>
              </div>

              <div className="w-full bg-slate-800 rounded-full h-2.5 mt-4">
                <div 
                  className={`h-2.5 rounded-full ${isOver ? 'bg-red-500' : percent > 85 ? 'bg-amber-500' : 'bg-green-500'}`} 
                  style={{ width: `${percent}%` }}
                ></div>
              </div>
              <div className="mt-2 text-right text-xs font-medium text-slate-400">
                {isOver ? `Over budget by $${(spentAmt - totalAmt).toLocaleString()}` : `${percent.toFixed(1)}% Utilized`}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
