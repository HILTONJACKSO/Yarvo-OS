"use client";

import { Wallet, Settings2, Download, Plus } from 'lucide-react';
import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

export default function FixedAssetsPage() {
  const [assets, setAssets] = useState<any[]>([]);

  useEffect(() => {
    const fetchAssets = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/finance/assets`);
        if (res.ok) {
          const data = await res.json();
          setAssets(data);
        }
      } catch (err) {
        console.error('Failed to fetch fixed assets', err);
      }
    };

    fetchAssets();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('finance.updated', fetchAssets);

    return () => {
      socket.off('finance.updated', fetchAssets);
      socket.disconnect();
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Fixed Assets</h1>
          <p className="text-slate-400 mt-1">Manage the asset register and automated depreciation.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 border bg-slate-950 rounded-md text-slate-300 hover:bg-slate-900 flex items-center gap-2">
            <Settings2 size={16} /> Run Depreciation
          </button>
          <button className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition flex items-center gap-2">
            <Plus size={16} /> Register Asset
          </button>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400 text-sm">Asset Code</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Name</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Category</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-right">Purchase Price</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-right">Accumulated Depr.</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-right">Current Book Value</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {assets.map((a, idx) => (
              <tr key={idx} className="hover:bg-slate-900">
                <td className="p-4 text-sm font-medium text-brand-primary cursor-pointer hover:underline flex items-center gap-2">
                  <Wallet size={16} className="text-gray-400" /> {a.assetCode || a.code}
                </td>
                <td className="p-4 text-sm text-slate-50 font-medium">{a.name}</td>
                <td className="p-4 text-sm text-slate-400">{a.category}</td>
                <td className="p-4 text-sm font-medium text-right text-slate-400">${(a.purchasePrice !== undefined ? a.purchasePrice : (typeof a.purchasePrice === 'string' ? parseFloat(a.purchasePrice.replace(/[^0-9.-]+/g,"")) : a.purchasePrice) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td className="p-4 text-sm font-medium text-right text-red-500">${(a.accumulatedDepr !== undefined ? a.accumulatedDepr : (typeof a.depr === 'string' ? parseFloat(a.depr.replace(/[^0-9.-]+/g,"")) : a.depr) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td className="p-4 text-sm font-bold text-right text-slate-50">${(a.currentValue !== undefined ? a.currentValue : (typeof a.currentValue === 'string' ? parseFloat(a.currentValue.replace(/[^0-9.-]+/g,"")) : a.currentValue) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td className="p-4 text-center">
                  <span className="px-2 py-1 bg-emerald-500/10 text-green-700 text-xs font-medium rounded-full">{a.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
