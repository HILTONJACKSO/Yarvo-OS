"use client";

import { ArrowDownLeft, ArrowUpRight, Search, FileText, CheckCircle2, Clock } from 'lucide-react';
import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

export default function InvoicesPage() {
  const [activeTab, setActiveTab] = useState('receivables');
  const [invoices, setInvoices] = useState<any[]>([]);
  const [stats, setStats] = useState({ accountsReceivable: 0, accountsPayable: 0 });

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/finance/invoices`);
        if (res.ok) {
          const data = await res.json();
          setInvoices(data);
        }
      } catch (err) {
        console.error('Failed to fetch invoices', err);
      }
    };

    const fetchStats = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/finance/stats`);
        if (res.ok) {
          const data = await res.json();
          setStats(data);
        }
      } catch (err) {
        console.error('Failed to fetch finance stats', err);
      }
    };

    fetchInvoices();
    fetchStats();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('finance.updated', () => {
      fetchInvoices();
      fetchStats();
    });

    return () => {
      socket.off('finance.updated');
      socket.disconnect();
    };
  }, []);

  const receivables = invoices.filter(inv => inv.type === 'RECEIVABLE');
  const payables = invoices.filter(inv => inv.type === 'PAYABLE');

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-50">Receivables & Payables</h1>
          <p className="text-slate-400 mt-1">Manage customer invoices and supplier bills.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 border bg-slate-950 rounded-md text-slate-300 hover:bg-slate-900">
            Record Payment
          </button>
          <button className="px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-secondary transition">
            Create Invoice
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div 
          onClick={() => setActiveTab('receivables')}
          className={`p-5 rounded-xl border cursor-pointer transition ${activeTab === 'receivables' ? 'bg-blue-50 border-blue-200' : 'bg-slate-950 hover:bg-slate-900'}`}
        >
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium text-slate-300 flex items-center gap-2"><ArrowDownLeft className="text-blue-500" /> Accounts Receivable</h3>
            <span className="text-2xl font-bold text-slate-50">${(stats.accountsReceivable || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <p className="text-sm text-slate-400">Money owed to the business by customers.</p>
        </div>
        <div 
          onClick={() => setActiveTab('payables')}
          className={`p-5 rounded-xl border cursor-pointer transition ${activeTab === 'payables' ? 'bg-amber-50 border-amber-200' : 'bg-slate-950 hover:bg-slate-900'}`}
        >
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium text-slate-300 flex items-center gap-2"><ArrowUpRight className="text-amber-500" /> Accounts Payable</h3>
            <span className="text-2xl font-bold text-slate-50">${(stats.accountsPayable || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <p className="text-sm text-slate-400">Money owed by the business to suppliers.</p>
        </div>
      </div>

      <div className="bg-slate-950 rounded-xl border shadow-sm overflow-hidden">
        <div className="p-4 border-b flex justify-between items-center bg-slate-900">
          <div className="relative w-72">
            <input type="text" placeholder="Search invoices..." className="w-full pl-10 pr-4 py-2 border rounded-md text-sm" />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          </div>
        </div>

        <table className="w-full text-left">
          <thead className="bg-slate-900 border-b">
            <tr>
              <th className="p-4 font-medium text-slate-400 text-sm">Document No.</th>
              <th className="p-4 font-medium text-slate-400 text-sm">{activeTab === 'receivables' ? 'Customer' : 'Supplier'}</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Date</th>
              <th className="p-4 font-medium text-slate-400 text-sm">Due Date</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-right">Amount</th>
              <th className="p-4 font-medium text-slate-400 text-sm text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {(activeTab === 'receivables' ? receivables : payables).map((item, idx) => (
              <tr key={idx} className="hover:bg-slate-900">
                <td className="p-4 text-sm font-medium text-brand-primary cursor-pointer hover:underline flex items-center gap-2">
                  <FileText size={16} /> {item.invoiceNumber || item.id}
                </td>
                <td className="p-4 text-sm text-slate-50 font-medium">
                  {item.partyId || (activeTab === 'receivables' ? (item as any).customer : (item as any).supplier) || 'Unknown'}
                </td>
                <td className="p-4 text-sm text-slate-400">{item.invoiceDate ? new Date(item.invoiceDate).toLocaleDateString() : item.date}</td>
                <td className="p-4 text-sm text-slate-400">{item.dueDate ? new Date(item.dueDate).toLocaleDateString() : item.due}</td>
                <td className="p-4 text-sm font-medium text-right">${(item.totalAmount !== undefined ? item.totalAmount : (typeof item.amount === 'string' ? parseFloat(item.amount.replace(/[^0-9.-]+/g,"")) : item.amount) || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full flex items-center justify-center gap-1 w-fit mx-auto ${
                    item.status === 'UNPAID' ? 'bg-amber-500/10 text-amber-700' :
                    item.status === 'PARTIAL' ? 'bg-blue-500/10 text-blue-700' :
                    item.status === 'OVERDUE' ? 'bg-red-500/10 text-red-700' : 'bg-emerald-500/10 text-green-700'
                  }`}>
                    {item.status === 'OVERDUE' ? <Clock size={12} /> : null}
                    {item.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
