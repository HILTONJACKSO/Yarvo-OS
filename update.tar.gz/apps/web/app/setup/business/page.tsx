"use client";

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useRouter } from 'next/navigation';

const businessSchema = z.object({
  businessName: z.string().min(1, 'Business name is required'),
  businessType: z.string().min(1, 'Business type is required'),
  country: z.string().min(1, 'Country is required'),
  currency: z.string().min(1, 'Currency is required'),
  businessPhone: z.string().min(1, 'Phone is required'),
  businessEmail: z.string().email('Invalid email'),
  businessAddress: z.string().min(1, 'Address is required'),
});

export default function BusinessSetupPage() {
  const router = useRouter();
  
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(businessSchema),
    defaultValues: { businessName: '', businessType: 'Hotel', country: '', currency: 'USD', businessPhone: '', businessEmail: '', businessAddress: '' }
  });

  const onSubmit = (data: any) => {
    localStorage.setItem('setup_business', JSON.stringify(data));
    router.push('/setup/branch');
  };

  const inputClasses = "w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium";
  const labelClasses = "block text-sm font-bold text-slate-300 mb-2";

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-950">
      <div className="bg-slate-900 border border-slate-800 p-8 sm:p-10 rounded-2xl shadow-xl max-w-xl w-full">
        <h2 className="text-3xl font-extrabold mb-8 text-center text-slate-50 tracking-tight">Tell us about your business</h2>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <div>
            <label className={labelClasses}>Business Name</label>
            <input {...register('businessName')} placeholder="e.g. Grand Resort & Spa" className={inputClasses} />
            {errors.businessName && <p className="text-xs font-bold text-red-500 mt-1">{errors.businessName.message?.toString()}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className={labelClasses}>Business Type</label>
              <select {...register('businessType')} className={inputClasses}>
                <option value="Hotel">Hotel</option>
                <option value="Resort">Resort</option>
                <option value="Restaurant">Restaurant</option>
                <option value="Bar">Bar</option>
                <option value="Nightclub">Nightclub</option>
                <option value="Multiple Services">Multiple Services</option>
              </select>
            </div>
            <div>
              <label className={labelClasses}>Country</label>
              <input {...register('country')} placeholder="e.g. United States" className={inputClasses} />
              {errors.country && <p className="text-xs font-bold text-red-500 mt-1">{errors.country.message?.toString()}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className={labelClasses}>Currency</label>
              <input {...register('currency')} placeholder="e.g. USD" className={inputClasses} />
              {errors.currency && <p className="text-xs font-bold text-red-500 mt-1">{errors.currency.message?.toString()}</p>}
            </div>
            <div>
              <label className={labelClasses}>Phone Number</label>
              <input {...register('businessPhone')} placeholder="+1 (555) 000-0000" className={inputClasses} />
              {errors.businessPhone && <p className="text-xs font-bold text-red-500 mt-1">{errors.businessPhone.message?.toString()}</p>}
            </div>
          </div>

          <div>
            <label className={labelClasses}>Email Address</label>
            <input type="email" {...register('businessEmail')} placeholder="hello@resort.com" className={inputClasses} />
            {errors.businessEmail && <p className="text-xs font-bold text-red-500 mt-1">{errors.businessEmail.message?.toString()}</p>}
          </div>

          <div>
            <label className={labelClasses}>Business Address</label>
            <input {...register('businessAddress')} placeholder="123 Resort Blvd, City, Country" className={inputClasses} />
            {errors.businessAddress && <p className="text-xs font-bold text-red-500 mt-1">{errors.businessAddress.message?.toString()}</p>}
          </div>

          <button 
            type="submit" 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg transition-all shadow-lg shadow-blue-600/20 mt-8"
          >
            Continue to Branch Setup
          </button>
        </form>
      </div>
    </div>
  );
}
