"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useRouter } from 'next/navigation';

const branchSchema = z.object({
  branchName: z.string().min(1, 'Branch name is required'),
  branchCode: z.string().min(1, 'Branch code is required'),
  branchAddress: z.string().min(1, 'Address is required'),
  city: z.string().min(1, 'City is required'),
  branchPhone: z.string().min(1, 'Phone is required'),
  branchEmail: z.string().email('Invalid email'),
  timezone: z.string().min(1, 'Timezone is required'),
});

export default function BranchSetupPage() {
  const router = useRouter();
  const [error, setError] = useState('');
  
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(branchSchema),
    defaultValues: { branchName: '', branchCode: '', branchAddress: '', city: '', branchPhone: '', branchEmail: '', timezone: 'UTC' }
  });

  const onSubmit = async (data: any) => {
    setError('');
    const token = localStorage.getItem('access_token');
    const businessDataRaw = localStorage.getItem('setup_business');
    
    if (!token || !businessDataRaw) {
      setError('Missing authentication or business data. Please start over.');
      return;
    }

    const businessData = JSON.parse(businessDataRaw);
    const payload = { ...businessData, ...data };

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/businesses/setup`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.message || 'Setup failed');
      }
      
      // Clear temporary business data
      localStorage.removeItem('setup_business');
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const inputClasses = "w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium";
  const labelClasses = "block text-sm font-bold text-slate-300 mb-2";

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-950">
      <div className="bg-slate-900 border border-slate-800 p-8 sm:p-10 rounded-2xl shadow-xl max-w-xl w-full">
        <h2 className="text-3xl font-extrabold mb-8 text-center text-slate-50 tracking-tight">Create your first location</h2>
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-500 p-4 rounded-xl text-sm font-medium flex items-center gap-2 mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className={labelClasses}>Branch Name</label>
              <input {...register('branchName')} placeholder="e.g. Ocean View Resort" className={inputClasses} />
              {errors.branchName && <p className="text-xs font-bold text-red-500 mt-1">{errors.branchName.message?.toString()}</p>}
            </div>
            <div>
              <label className={labelClasses}>Branch Code</label>
              <input {...register('branchCode')} placeholder="e.g. OVR001" className={inputClasses} />
              {errors.branchCode && <p className="text-xs font-bold text-red-500 mt-1">{errors.branchCode.message?.toString()}</p>}
            </div>
          </div>

          <div>
            <label className={labelClasses}>Address</label>
            <input {...register('branchAddress')} placeholder="123 Ocean Drive" className={inputClasses} />
            {errors.branchAddress && <p className="text-xs font-bold text-red-500 mt-1">{errors.branchAddress.message?.toString()}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className={labelClasses}>City</label>
              <input {...register('city')} placeholder="Miami" className={inputClasses} />
              {errors.city && <p className="text-xs font-bold text-red-500 mt-1">{errors.city.message?.toString()}</p>}
            </div>
            <div>
              <label className={labelClasses}>Time Zone</label>
              <input {...register('timezone')} placeholder="UTC" className={inputClasses} />
              {errors.timezone && <p className="text-xs font-bold text-red-500 mt-1">{errors.timezone.message?.toString()}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className={labelClasses}>Phone Number</label>
              <input {...register('branchPhone')} placeholder="+1 (555) 123-4567" className={inputClasses} />
              {errors.branchPhone && <p className="text-xs font-bold text-red-500 mt-1">{errors.branchPhone.message?.toString()}</p>}
            </div>
            <div>
              <label className={labelClasses}>Email Address</label>
              <input type="email" {...register('branchEmail')} placeholder="branch@resort.com" className={inputClasses} />
              {errors.branchEmail && <p className="text-xs font-bold text-red-500 mt-1">{errors.branchEmail.message?.toString()}</p>}
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg transition-all shadow-lg shadow-blue-600/20 disabled:opacity-70 disabled:cursor-not-allowed mt-8"
          >
            {isSubmitting ? 'Saving...' : 'Complete Setup'}
          </button>
        </form>
      </div>
    </div>
  );
}
