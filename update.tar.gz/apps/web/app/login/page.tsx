"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

export default function LoginPage() {
  const router = useRouter();
  const [error, setError] = useState('');
  
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' }
  });

  const onSubmit = async (data: any) => {
    setError('');
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!res.ok) throw new Error('Invalid credentials');
      const responseData = await res.json();
      localStorage.setItem('access_token', responseData.access_token);
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-950">
      {/* Left Side - Image */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-slate-900 border-r border-slate-800">
        <Image 
          src="/images/auth-bg.png" 
          alt="Luxury Resort" 
          fill
          priority
          className="object-cover opacity-60 mix-blend-overlay"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
        
        <div className="absolute bottom-12 left-12 right-12 z-10">
          <Link href="/" className="inline-flex items-center gap-3 mb-8 hover:opacity-80 transition-opacity">
            <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-600/20">
              <span className="font-bold text-white text-2xl">Y</span>
            </div>
            <span className="text-3xl font-extrabold tracking-tight text-slate-50">Yarvo OS</span>
          </Link>
          
          <h2 className="text-3xl lg:text-4xl font-extrabold text-slate-50 mb-4 leading-tight tracking-tight">
            The world's most advanced hospitality operating system.
          </h2>
          <p className="text-lg text-slate-300 font-medium max-w-lg">
            Manage your hotel, restaurant, resort, beach, bar, and nightclub from one simple, powerful platform.
          </p>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 sm:p-12 md:p-16 lg:p-24 overflow-y-auto">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center lg:text-left">
            <div className="lg:hidden flex items-center justify-center gap-3 mb-10">
              <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-600/20">
                <span className="font-bold text-white text-2xl">Y</span>
              </div>
              <span className="text-3xl font-extrabold tracking-tight text-slate-50">Yarvo OS</span>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-extrabold text-slate-50 tracking-tight">Welcome back</h1>
            <p className="text-slate-400 mt-3 text-lg">Sign in to your Yarvo OS dashboard to manage your properties.</p>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-500 p-4 rounded-xl text-sm font-medium flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 mt-8">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-300">Email Address</label>
              <input 
                type="email" 
                placeholder="hello@luxuryresort.com"
                {...register('email')} 
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3.5 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium" 
              />
              {errors.email && <p className="text-xs text-red-500 font-bold mt-1">{errors.email.message?.toString()}</p>}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-bold text-slate-300">Password</label>
                <a href="#" className="text-sm font-bold text-blue-600 hover:text-blue-500 transition-colors">Forgot Password?</a>
              </div>
              <input 
                type="password" 
                placeholder="••••••••"
                {...register('password')} 
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3.5 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium" 
              />
              {errors.password && <p className="text-xs text-red-500 font-bold mt-1">{errors.password.message?.toString()}</p>}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <div className="relative flex items-center">
                <input type="checkbox" id="remember" className="peer h-5 w-5 cursor-pointer appearance-none rounded border border-slate-700 bg-slate-900 checked:border-blue-600 checked:bg-blue-600 transition-all" />
                <svg className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none opacity-0 peer-checked:opacity-100 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </div>
              <label htmlFor="remember" className="text-sm font-bold text-slate-300 cursor-pointer">Remember me for 30 days</label>
            </div>

            <button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg transition-all shadow-lg shadow-blue-600/20 disabled:opacity-70 disabled:cursor-not-allowed mt-4"
            >
              {isSubmitting ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="text-center pt-8 border-t border-slate-800">
            <p className="text-slate-400 font-medium">
              Don't have an account?{' '}
              <Link href="/register" className="font-bold text-slate-50 hover:text-blue-600 transition-colors">
                Create Business Account
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
