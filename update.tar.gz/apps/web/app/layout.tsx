import type { Metadata } from 'next';
import { Inter, Manrope } from 'next/font/google';
import './globals.css';
import { Toaster } from 'sonner';
const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const manrope = Manrope({
  subsets: ['latin'],
  variable: '--font-manrope',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Yarvo Hospitality OS | Hotel, Restaurant, Resort and Entertainment Management Software',
  description: 'Manage hotel rooms, restaurant orders, kitchen operations, guest accounts, tickets, inventory, staff, payments, taxes, and reporting from one installable hospitality platform.',
  manifest: '/manifest.webmanifest',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{
          __html: `
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js');
              });
            }
          `
        }} />
      </head>
      <body className={`${inter.variable} ${manrope.variable} font-sans antialiased`}>
        {children}
        <Toaster 
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#020617', // slate-950
              border: '1px solid #1e293b', // slate-800
              color: '#f8fafc', // slate-50
            },
            classNames: {
              toast: 'rounded-xl shadow-2xl font-medium',
              description: 'text-slate-400',
              success: 'border-l-4 border-l-brand-primary text-brand-primary bg-slate-950/90',
              error: 'border-l-4 border-l-red-500 text-red-500 bg-slate-950/90',
            },
          }}
        />
      </body>
    </html>
  );
}
