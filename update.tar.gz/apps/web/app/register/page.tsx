"use client";

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';

const registerSchema = z.object({
  fullName: z.string().min(1, 'Full name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(1, 'Phone number is required'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  confirmPassword: z.string().min(1, 'Please confirm your password'),
  agree: z.boolean().refine((val) => val === true, 'You must agree to the Terms'),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

export default function RegisterPage() {
  const router = useRouter();
  const [error, setError] = useState('');
  
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      fullName: '', email: '', phone: '', password: '', confirmPassword: '', agree: false
    }
  });

  const onSubmit = async (data: any) => {
    setError('');
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: data.fullName,
          email: data.email,
          phone: data.phone,
          password: data.password,
        })
      });
      if (!res.ok) {
        const body = await res.json();
        throw new Error(body.message || 'Registration failed');
      }
      const responseData = await res.json();
      localStorage.setItem('access_token', responseData.access_token);
      router.push('/setup/business');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-950">
      {/* Left Side - Image */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-slate-900 border-r border-slate-800">
        <Image 
          src="/images/auth-bg.png" 
          alt="Luxury Resort" 
          fill
          priority
          className="object-cover opacity-60 mix-blend-overlay"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>
        
        <div className="absolute bottom-12 left-12 right-12 z-10">
          <Link href="/" className="inline-flex items-center gap-3 mb-8 hover:opacity-80 transition-opacity">
            <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-600/20">
              <span className="font-bold text-white text-2xl">Y</span>
            </div>
            <span className="text-3xl font-extrabold tracking-tight text-slate-50">Yarvo OS</span>
          </Link>
          
          <h2 className="text-3xl lg:text-4xl font-extrabold text-slate-50 mb-4 leading-tight tracking-tight">
            Create your master account.
          </h2>
          <p className="text-lg text-slate-300 font-medium max-w-lg">
            Join hundreds of premium properties managing their operations seamlessly with Yarvo OS.
          </p>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 sm:p-12 md:p-16 lg:p-24 overflow-y-auto">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center lg:text-left">
            <div className="lg:hidden flex items-center justify-center gap-3 mb-10">
              <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-600/20">
                <span className="font-bold text-white text-2xl">Y</span>
              </div>
              <span className="text-3xl font-extrabold tracking-tight text-slate-50">Yarvo OS</span>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-extrabold text-slate-50 tracking-tight">Create Account</h1>
            <p className="text-slate-400 mt-3 text-lg">Set up your owner account to start configuring your property.</p>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-500 p-4 rounded-xl text-sm font-medium flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 mt-8">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-300">Full Name</label>
              <input 
                type="text" 
                placeholder="John Doe"
                {...register('fullName')} 
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3.5 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium" 
              />
              {errors.fullName && <p className="text-xs text-red-500 font-bold mt-1">{errors.fullName.message?.toString()}</p>}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-300">Email Address</label>
                <input 
                  type="email" 
                  placeholder="hello@resort.com"
                  {...register('email')} 
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3.5 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium" 
                />
                {errors.email && <p className="text-xs text-red-500 font-bold mt-1">{errors.email.message?.toString()}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-300">Phone Number</label>
                <input 
                  type="tel" 
                  placeholder="+1 (555) 000-0000"
                  {...register('phone')} 
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3.5 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium" 
                />
                {errors.phone && <p className="text-xs text-red-500 font-bold mt-1">{errors.phone.message?.toString()}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-300">Password</label>
                <input 
                  type="password" 
                  placeholder="••••••••"
                  {...register('password')} 
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3.5 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium" 
                />
                {errors.password && <p className="text-xs text-red-500 font-bold mt-1">{errors.password.message?.toString()}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-300">Confirm Password</label>
                <input 
                  type="password" 
                  placeholder="••••••••"
                  {...register('confirmPassword')} 
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3.5 text-slate-50 placeholder-slate-500 focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all font-medium" 
                />
                {errors.confirmPassword && <p className="text-xs text-red-500 font-bold mt-1">{errors.confirmPassword.message?.toString()}</p>}
              </div>
            </div>

            <div className="flex items-start gap-3 pt-4">
              <div className="relative flex items-center mt-1">
                <input type="checkbox" id="agree" {...register('agree')} className="peer h-5 w-5 cursor-pointer appearance-none rounded border border-slate-700 bg-slate-900 checked:border-blue-600 checked:bg-blue-600 transition-all" />
                <svg className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none opacity-0 peer-checked:opacity-100 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
              </div>
              <div>
                <label htmlFor="agree" className="text-sm font-medium text-slate-300 cursor-pointer">
                  I agree to the <a href="#" className="text-blue-600 hover:text-blue-500 transition-colors">Terms of Service</a> and <a href="#" className="text-blue-600 hover:text-blue-500 transition-colors">Privacy Policy</a>
                </label>
                {errors.agree && <p className="text-xs text-red-500 font-bold mt-1">{errors.agree.message?.toString()}</p>}
              </div>
            </div>

            <button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg transition-all shadow-lg shadow-blue-600/20 disabled:opacity-70 disabled:cursor-not-allowed mt-4"
            >
              {isSubmitting ? 'Creating Account...' : 'Create Business Account'}
            </button>
          </form>

          <div className="text-center pt-8 border-t border-slate-800">
            <p className="text-slate-400 font-medium">
              Already have an account?{' '}
              <Link href="/login" className="font-bold text-slate-50 hover:text-blue-600 transition-colors">
                Sign In Instead
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
