import { Navigation } from "@/components/landing/navigation";
import { Footer } from "@/components/landing/footer";

export const metadata = {
  title: 'Terms of Service | Yarvo OS',
  description: 'Terms of Service for Yarvo Hospitality OS',
};

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-slate-50 font-sans selection:bg-blue-200 selection:text-blue-900">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-6 py-32 md:py-40">
        <div className="bg-white p-8 md:p-12 rounded-3xl border border-slate-200 shadow-sm">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">
            Terms of Service
          </h1>
          <p className="text-slate-500 mb-12">Last Updated: July 2026</p>

          <div className="prose prose-slate max-w-none text-slate-700 space-y-8">
            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">1. Acceptance of Terms</h2>
              <p>
                By accessing and using Yarvo OS ("Service"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Service. Yarvo OS is a product of Yarvo Solutions Inc.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">2. Description of Service</h2>
              <p>
                Yarvo OS provides an integrated hospitality management system, including but not limited to property management, point of sale, inventory tracking, staff management, and analytics dashboard. We reserve the right to modify or discontinue the Service at any time.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">3. User Accounts and Security</h2>
              <p>
                You are responsible for maintaining the confidentiality of your account credentials. You agree to notify us immediately of any unauthorized use of your account. Yarvo OS will not be liable for any losses caused by unauthorized use of your account.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">4. Data Privacy and Ownership</h2>
              <p>
                You retain all rights to your customer data. By using the Service, you grant Yarvo OS the right to host, backup, and process your data solely for the purpose of providing the Service. Please review our Privacy Policy for detailed information on how we handle data.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">5. Payment Terms</h2>
              <p>
                Subscriptions are billed in advance on a monthly or annual basis. There are no refunds for partial months of service. If you upgrade your plan, you will be billed the prorated difference immediately.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-slate-900 mb-4">6. Limitation of Liability</h2>
              <p>
                Yarvo OS shall not be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.
              </p>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  );
}
