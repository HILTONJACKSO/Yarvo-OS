export class CreatePurchaseOrderDto {}
