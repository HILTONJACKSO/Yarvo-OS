export class CreateTaxDto {}
