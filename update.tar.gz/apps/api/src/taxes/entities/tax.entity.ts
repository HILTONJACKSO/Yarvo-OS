export class Tax {}
