export class RoomInspection {}
