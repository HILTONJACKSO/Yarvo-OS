export class CreateRoomInspectionDto {}
