export class CreatePaymentDto {}
