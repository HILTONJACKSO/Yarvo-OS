export class CreatePurchasingReportDto {}
