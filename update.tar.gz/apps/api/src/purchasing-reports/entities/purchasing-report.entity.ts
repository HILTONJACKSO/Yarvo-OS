export class PurchasingReport {}
