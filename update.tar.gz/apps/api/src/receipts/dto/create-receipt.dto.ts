export class CreateReceiptDto {}
