export class Receipt {}
