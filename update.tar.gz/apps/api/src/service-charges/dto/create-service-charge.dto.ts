export class CreateServiceChargeDto {}
