export class ServiceCharge {}
