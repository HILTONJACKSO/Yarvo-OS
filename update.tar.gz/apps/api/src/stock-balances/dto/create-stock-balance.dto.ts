export class CreateStockBalanceDto {}
