export class StockBalance {}
