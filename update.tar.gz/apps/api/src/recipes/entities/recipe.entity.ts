export class Recipe {}
