export class CreateRecipeDto {}
