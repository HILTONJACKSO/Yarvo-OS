export class CreateSupplierDto {}
