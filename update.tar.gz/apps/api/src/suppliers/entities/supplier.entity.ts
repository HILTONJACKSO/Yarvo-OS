export class Supplier {}
