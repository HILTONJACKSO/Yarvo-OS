export class PaymentAllocation {}
