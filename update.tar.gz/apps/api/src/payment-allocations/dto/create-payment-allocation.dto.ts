export class CreatePaymentAllocationDto {}
