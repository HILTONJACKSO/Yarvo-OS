export class PurchaseRequest {}
