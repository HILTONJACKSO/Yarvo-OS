export class CreateReceivableDto {}
