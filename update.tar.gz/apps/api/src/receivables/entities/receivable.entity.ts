export class Receivable {}
