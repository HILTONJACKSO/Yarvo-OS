export class StockMovement {}
