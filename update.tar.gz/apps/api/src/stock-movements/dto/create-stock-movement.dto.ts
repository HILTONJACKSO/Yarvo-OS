export class CreateStockMovementDto {}
