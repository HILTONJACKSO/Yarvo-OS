export class Settlement {}
