export class StockCount {}
