export class CreateStockCountDto {}
