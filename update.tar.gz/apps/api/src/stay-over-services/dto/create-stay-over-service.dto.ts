export class CreateStayOverServiceDto {}
