export class SupplierInvoice {}
