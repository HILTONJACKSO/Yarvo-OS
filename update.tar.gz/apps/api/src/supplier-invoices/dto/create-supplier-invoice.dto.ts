export class CreateSupplierInvoiceDto {}
