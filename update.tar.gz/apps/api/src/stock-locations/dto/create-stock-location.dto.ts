export class CreateStockLocationDto {}
