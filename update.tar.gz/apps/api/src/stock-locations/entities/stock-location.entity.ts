export class StockLocation {}
