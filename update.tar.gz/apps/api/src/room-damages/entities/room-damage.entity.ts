export class RoomDamage {}
