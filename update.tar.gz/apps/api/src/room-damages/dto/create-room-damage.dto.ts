export class CreateRoomDamageDto {}
