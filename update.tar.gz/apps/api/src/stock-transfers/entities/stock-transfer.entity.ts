export class StockTransfer {}
