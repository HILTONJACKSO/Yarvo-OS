export class CreateStockTransferDto {}
