import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Injectable()
export class DepartmentIssuesService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(businessId?: string) {
    return this.prisma.departmentStockIssue.findMany({
      where: businessId ? { businessId } : undefined,
      orderBy: { createdAt: 'desc' },
      include: {
        department: { select: { id: true, name: true } },
        sourceLocation: { select: { id: true, name: true } },
        items: {
          include: {
            inventoryItem: { select: { id: true, name: true, sku: true } },
            unit: { select: { id: true, name: true, abbreviation: true } },
          }
        }
      }
    });
  }

  async findOne(id: string) {
    return this.prisma.departmentStockIssue.findUnique({
      where: { id },
      include: {
        department: { select: { id: true, name: true } },
        sourceLocation: { select: { id: true, name: true } },
        items: {
          include: {
            inventoryItem: { select: { id: true, name: true, sku: true } },
            unit: { select: { id: true, name: true, abbreviation: true } },
          }
        }
      }
    });
  }

  async updateStatus(id: string, status: string) {
    return this.prisma.departmentStockIssue.update({
      where: { id },
      data: { status, updatedAt: new Date() }
    });
  }
}
