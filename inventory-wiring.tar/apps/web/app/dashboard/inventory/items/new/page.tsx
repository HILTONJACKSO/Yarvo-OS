"use client";

import { useState, useEffect } from 'react';
import { ChevronRight, Save, X, Info, Box, Layers, Tag, DollarSign, Link as LinkIcon, Loader2 } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function NewInventoryItemPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const totalSteps = 5;

  const [customTypeMode, setCustomTypeMode] = useState(false);
  const [customCategoryMode, setCustomCategoryMode] = useState(false);

  const [isSaving, setIsSaving] = useState(false);
  const [categories, setCategories] = useState<any[]>([]);
  const [units, setUnits] = useState<any[]>([]);

  const [formData, setFormData] = useState({
    name: '',
    code: '',
    barcode: '',
    inventoryType: 'INGREDIENT',
    categoryId: '',
    brand: '',
    description: '',
    baseUnitId: '',
    purchaseUnitId: '',
    issueUnitId: '',
    purchaseConversionFactor: '',
    minimumStockLevel: '',
    reorderLevel: '',
    maximumStockLevel: '',
    reorderQuantity: '',
    allowNegativeStock: false,
    trackBatch: false,
    trackExpiry: false,
    stockMethod: 'FIFO',
    initialUnitCost: '',
    standardCost: '',
    preferredSupplierId: '',
    isRecipeIngredient: false,
    isDirectSale: false,
    isMinibar: false,
    isHousekeeping: false,
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [catsRes, unitsRes] = await Promise.all([
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/categories`, {
            headers: { 'x-business-id': 'bus-kwalee-1' }
          }),
          fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory/units`, {
            headers: { 'x-business-id': 'bus-kwalee-1' }
          })
        ]);
        if (catsRes.ok) setCategories(await catsRes.json());
        if (unitsRes.ok) setUnits(await unitsRes.json());
      } catch (err) {
        console.error('Failed to load dependencies', err);
      }
    };
    fetchData();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleCustomCategory = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, categoryId: `ADD_NEW:${e.target.value}` }));
  };

  const handleCustomType = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, inventoryType: e.target.value }));
  };

  const handleSave = async (isDraft: boolean) => {
    setIsSaving(true);
    try {
      const payload = {
        ...formData,
        purchaseConversionFactor: formData.purchaseConversionFactor ? Number(formData.purchaseConversionFactor) : undefined,
        minimumStockLevel: formData.minimumStockLevel ? Number(formData.minimumStockLevel) : undefined,
        reorderLevel: formData.reorderLevel ? Number(formData.reorderLevel) : undefined,
        maximumStockLevel: formData.maximumStockLevel ? Number(formData.maximumStockLevel) : undefined,
        reorderQuantity: formData.reorderQuantity ? Number(formData.reorderQuantity) : undefined,
        initialUnitCost: formData.initialUnitCost ? Number(formData.initialUnitCost) : undefined,
        standardCost: formData.standardCost ? Number(formData.standardCost) : undefined,
        status: isDraft ? 'DRAFT' : 'ACTIVE'
      };

      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/inventory`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-business-id': 'bus-kwalee-1'
        },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        router.push('/dashboard/inventory/items');
      } else {
        alert('Failed to save inventory item');
      }
    } catch (err) {
      console.error(err);
      alert('Error saving inventory item');
    } finally {
      setIsSaving(false);
    }
  };

  const renderStepIndicators = () => {
    return (
      <div className="flex items-center mb-8 bg-slate-950 p-4 rounded-xl border shadow-sm overflow-x-auto">
        {[
          { num: 1, label: 'Basic Info', icon: <Info size={16} /> },
          { num: 2, label: 'Units', icon: <Box size={16} /> },
          { num: 3, label: 'Stock Control', icon: <Layers size={16} /> },
          { num: 4, label: 'Costing', icon: <DollarSign size={16} /> },
          { num: 5, label: 'Connections', icon: <LinkIcon size={16} /> },
        ].map((s, idx) => (
          <div key={s.num} className="flex items-center">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg font-medium text-sm transition-colors ${step === s.num ? 'bg-brand-primary text-white' : step > s.num ? 'text-brand-primary bg-blue-50' : 'text-slate-400'}`}>
              {s.icon}
              <span className="whitespace-nowrap">{s.label}</span>
            </div>
            {idx < 4 && <ChevronRight size={16} className="mx-2 text-gray-300" />}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <Link href="/dashboard/inventory/items" className="text-sm text-brand-primary hover:underline mb-2 inline-block">&larr; Back to Items</Link>
          <h1 className="text-2xl font-bold text-slate-50">Add Stock Item</h1>
          <p className="text-slate-400 mt-1">Create a new physical inventory or supply record.</p>
        </div>
      </div>

      {renderStepIndicators()}

      <div className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden">
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Basic Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Item Name <span className="text-red-500">*</span></label>
                  <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="e.g., Club Beer (Large)" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Stock Code <span className="text-red-500">*</span></label>
                  <input type="text" name="code" value={formData.code} onChange={handleChange} placeholder="e.g., B-CLUB-L" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Inventory Type <span className="text-red-500">*</span></label>
                  {customTypeMode ? (
                    <div className="flex items-center gap-2">
                      <input type="text" onChange={handleCustomType} placeholder="e.g., CUSTOM_TYPE" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100" autoFocus />
                      <button onClick={() => setCustomTypeMode(false)} className="text-slate-400 hover:text-red-500"><X size={20}/></button>
                    </div>
                  ) : (
                    <select 
                      className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100"
                      name="inventoryType"
                      value={formData.inventoryType}
                      onChange={(e) => { e.target.value === 'ADD_NEW' ? setCustomTypeMode(true) : handleChange(e); }}
                    >
                      <option value="INGREDIENT">INGREDIENT</option>
                      <option value="FINISHED_GOOD">FINISHED_GOOD</option>
                      <option value="BEVERAGE">BEVERAGE</option>
                      <option value="ALCOHOL">ALCOHOL</option>
                      <option value="LINEN">LINEN</option>
                      <option value="HOUSEKEEPING_SUPPLY">HOUSEKEEPING_SUPPLY</option>
                      <option value="ADD_NEW" className="text-brand-primary font-bold">+ Create Custom Type...</option>
                    </select>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Category <span className="text-red-500">*</span></label>
                  {customCategoryMode ? (
                    <div className="flex items-center gap-2">
                      <input type="text" onChange={handleCustomCategory} placeholder="e.g., Electronics" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100" autoFocus />
                      <button onClick={() => setCustomCategoryMode(false)} className="text-slate-400 hover:text-red-500"><X size={20}/></button>
                    </div>
                  ) : (
                    <select 
                      className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50 bg-slate-950 text-slate-100"
                      name="categoryId"
                      value={formData.categoryId}
                      onChange={(e) => { e.target.value === 'ADD_NEW' ? setCustomCategoryMode(true) : handleChange(e); }}
                    >
                      <option value="">Select Category...</option>
                      {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      <option value="ADD_NEW" className="text-brand-primary font-bold">+ Create New Category...</option>
                    </select>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Barcode (Optional)</label>
                  <input type="text" name="barcode" value={formData.barcode} onChange={handleChange} placeholder="Scan or type barcode" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Brand (Optional)</label>
                  <input type="text" name="brand" value={formData.brand} onChange={handleChange} placeholder="e.g., Club" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Description</label>
                  <textarea name="description" value={formData.description} onChange={handleChange} rows={3} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50"></textarea>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Units & Conversions</h2>
              <div className="bg-blue-50 p-4 rounded-lg flex gap-3 text-blue-400 text-sm mb-6">
                <Info size={20} className="shrink-0" />
                <p>The <strong>Base Unit</strong> is how this item is counted in your inventory reports (e.g., Bottle). The <strong>Purchase Unit</strong> is how you buy it from suppliers (e.g., Carton).</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Base Unit <span className="text-red-500">*</span></label>
                  <select name="baseUnitId" value={formData.baseUnitId} onChange={handleChange} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option value="">Select Base Unit...</option>
                    {units.map(u => <option key={u.id} value={u.id}>{u.name} ({u.code})</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Issue Unit</label>
                  <select name="issueUnitId" value={formData.issueUnitId} onChange={handleChange} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option value="">Same as Base Unit</option>
                    {units.map(u => <option key={u.id} value={u.id}>{u.name} ({u.code})</option>)}
                  </select>
                </div>
                
                <div className="md:col-span-2 border-t pt-4 mt-2">
                  <h3 className="font-medium text-slate-50 mb-4">Purchasing Conversion</h3>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Purchase Unit</label>
                  <select name="purchaseUnitId" value={formData.purchaseUnitId} onChange={handleChange} className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option value="">Same as Base Unit</option>
                    {units.map(u => <option key={u.id} value={u.id}>{u.name} ({u.code})</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Conversion Factor</label>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-slate-400">1 Purchase Unit =</span>
                    <input type="number" name="purchaseConversionFactor" value={formData.purchaseConversionFactor} onChange={handleChange} placeholder="24" className="w-24 px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                    <span className="text-sm text-slate-400">Base Units</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Stock Control</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Minimum Stock Level</label>
                  <input type="number" name="minimumStockLevel" value={formData.minimumStockLevel} onChange={handleChange} placeholder="e.g., 48" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Maximum Stock Level</label>
                  <input type="number" name="maximumStockLevel" value={formData.maximumStockLevel} onChange={handleChange} placeholder="e.g., 200" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Reorder Level</label>
                  <input type="number" name="reorderLevel" value={formData.reorderLevel} onChange={handleChange} placeholder="e.g., 50" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Reorder Quantity</label>
                  <input type="number" name="reorderQuantity" value={formData.reorderQuantity} onChange={handleChange} placeholder="e.g., 100" className="w-full px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                </div>
                
                <div className="md:col-span-2 border-t pt-4 mt-2">
                  <h3 className="font-medium text-slate-50 mb-4">Tracking & Method</h3>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" name="trackBatch" checked={formData.trackBatch} onChange={handleChange} className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Track Batch Numbers</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" name="trackExpiry" checked={formData.trackExpiry} onChange={handleChange} className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Track Expiry Dates (Requires FEFO dispatch)</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" name="allowNegativeStock" checked={formData.allowNegativeStock} onChange={handleChange} className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Allow Negative Stock</span>
                    </label>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Preferred Stock Method</label>
                  <select name="stockMethod" value={formData.stockMethod} onChange={handleChange} className="w-full md:w-1/2 px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option value="FIFO">FIFO (First In, First Out)</option>
                    <option value="FEFO">FEFO (First Expired, First Out)</option>
                    <option value="AVERAGE_COST">AVERAGE_COST</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Costing</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Initial Cost per Base Unit</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                    <input type="number" name="initialUnitCost" value={formData.initialUnitCost} onChange={handleChange} placeholder="1.20" className="w-full pl-8 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Standard Cost (Optional)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                    <input type="number" name="standardCost" value={formData.standardCost} onChange={handleChange} placeholder="1.25" className="w-full pl-8 pr-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50" />
                  </div>
                </div>
                <div className="md:col-span-2">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                    <span className="text-sm text-slate-300">Cost Includes Tax</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold text-slate-50 border-b pb-2">Connections & Usage</h2>
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Preferred Supplier</label>
                  <select name="preferredSupplierId" value={formData.preferredSupplierId} onChange={handleChange} className="w-full md:w-1/2 px-4 py-2 border rounded-md focus:ring-2 focus:ring-brand-primary/50">
                    <option value="">Select a supplier...</option>
                    {/* Placeholder suppliers until API has supplier list */}
                    <option value="ABC Distributors">ABC Distributors</option>
                    <option value="Fresh Farms Co.">Fresh Farms Co.</option>
                  </select>
                </div>
                
                <div className="border-t pt-4 mt-2">
                  <h3 className="font-medium text-slate-50 mb-4">Operational Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" name="isRecipeIngredient" checked={formData.isRecipeIngredient} onChange={handleChange} className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Eligible as a Recipe Ingredient</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" name="isDirectSale" checked={formData.isDirectSale} onChange={handleChange} className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Direct Sale Item (Links to POS Catalog without recipe)</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" name="isMinibar" checked={formData.isMinibar} onChange={handleChange} className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Minibar Item</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" name="isHousekeeping" checked={formData.isHousekeeping} onChange={handleChange} className="w-4 h-4 text-brand-primary rounded focus:ring-brand-primary/50" />
                      <span className="text-sm text-slate-300">Housekeeping Item (Linen / Supply)</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="p-4 border-t bg-slate-900 flex justify-between">
          {step > 1 ? (
            <button 
              onClick={() => setStep(step - 1)}
              className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium"
            >
              Back
            </button>
          ) : (
            <Link href="/dashboard/inventory/items" className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium">Cancel</Link>
          )}

          <div className="flex gap-2">
            {step < totalSteps ? (
              <button 
                onClick={() => setStep(step + 1)}
                className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition"
              >
                Next Step
              </button>
            ) : (
              <>
                <button 
                  disabled={isSaving}
                  onClick={() => handleSave(true)}
                  className="px-4 py-2 border rounded-md text-slate-300 hover:bg-slate-800 font-medium disabled:opacity-50"
                >
                  Save as Draft
                </button>
                <button 
                  disabled={isSaving}
                  onClick={() => handleSave(false)}
                  className="px-4 py-2 bg-brand-primary text-white rounded-md font-medium hover:bg-brand-secondary transition flex items-center gap-2 disabled:opacity-50"
                >
                  {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />} 
                  {isSaving ? 'Saving...' : 'Save and Activate'}
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
