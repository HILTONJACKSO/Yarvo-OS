import { IsString, IsOptional, IsNumber, IsBoolean, IsNotEmpty } from 'class-validator';

export class CreateInventoryDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  code: string;

  @IsString()
  @IsOptional()
  barcode?: string;

  @IsString()
  @IsNotEmpty()
  inventoryType: string;

  @IsString()
  @IsNotEmpty()
  categoryId: string; // Could be 'ADD_NEW:custom category name'

  @IsString()
  @IsOptional()
  brand?: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsString()
  @IsNotEmpty()
  baseUnitId: string;

  @IsString()
  @IsOptional()
  purchaseUnitId?: string;

  @IsString()
  @IsOptional()
  issueUnitId?: string;

  @IsNumber()
  @IsOptional()
  purchaseConversionFactor?: number;

  @IsNumber()
  @IsOptional()
  minimumStockLevel?: number;

  @IsNumber()
  @IsOptional()
  reorderLevel?: number;

  @IsNumber()
  @IsOptional()
  maximumStockLevel?: number;

  @IsNumber()
  @IsOptional()
  reorderQuantity?: number;

  @IsBoolean()
  @IsOptional()
  allowNegativeStock?: boolean;

  @IsBoolean()
  @IsOptional()
  trackBatch?: boolean;

  @IsBoolean()
  @IsOptional()
  trackExpiry?: boolean;

  @IsString()
  @IsNotEmpty()
  stockMethod: string;

  @IsNumber()
  @IsOptional()
  initialUnitCost?: number;

  @IsNumber()
  @IsOptional()
  standardCost?: number;

  @IsString()
  @IsOptional()
  preferredSupplierId?: string;

  @IsBoolean()
  @IsOptional()
  isRecipeIngredient?: boolean;

  @IsBoolean()
  @IsOptional()
  isDirectSale?: boolean;

  @IsBoolean()
  @IsOptional()
  isMinibar?: boolean;

  @IsBoolean()
  @IsOptional()
  isHousekeeping?: boolean;
}
