import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { AppWebsocketGateway } from '../websocket/app-websocket.gateway';
import { CreateInventoryDto } from './dto/create-inventory.dto';
import { UpdateInventoryDto } from './dto/update-inventory.dto';

@Injectable()
export class InventoryService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly wsGateway: AppWebsocketGateway,
  ) {}

  async getDashboardStats() {
    const totalValueResult = await this.prisma.stockBalance.aggregate({
      _sum: {
        stockValue: true,
      },
    });

    const lowStockCount = await this.prisma.stockBalance.count({
      where: {
        quantityAvailable: { lte: 10, gt: 0 }
      }
    });

    const outOfStockCount = await this.prisma.stockBalance.count({
      where: { quantityAvailable: { lte: 0 } }
    });

    const openOrdersCount = await this.prisma.purchaseOrder.count({
      where: { status: 'OPEN' }
    });

    return {
      totalStockValue: totalValueResult._sum.stockValue || 0,
      lowStockItems: lowStockCount,
      outOfStock: outOfStockCount,
      openPurchaseOrders: openOrdersCount,
    };
  }

  async getItems() {
    return this.prisma.inventoryItem.findMany({
      orderBy: { name: 'asc' }
    });
  }

  async getStockLevels() {
    return this.prisma.stockBalance.findMany();
  }

  async getMovements() {
    return this.prisma.stockMovement.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getTransfers() {
    return this.prisma.stockTransfer.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getRecipes() {
    return this.prisma.recipe.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getCounts() {
    return this.prisma.stockCount.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getWaste() {
    return this.prisma.inventoryWaste.findMany({
      orderBy: { createdAt: 'desc' }
    });
  }

  async getCategories() {
    return this.prisma.inventoryCategory.findMany();
  }

  async getUnits() {
    return this.prisma.unitOfMeasure.findMany();
  }

  async getLocations() {
    return this.prisma.stockLocation.findMany();
  }

  async create(businessId: string, data: CreateInventoryDto) {
    let categoryId = data.categoryId;

    if (categoryId.startsWith('ADD_NEW:')) {
      const categoryName = categoryId.split(':')[1];
      const newCategory = await this.prisma.inventoryCategory.create({
        data: {
          businessId,
          name: categoryName,
          code: categoryName.toUpperCase().replace(/\s+/g, '_').substring(0, 10),
          status: 'ACTIVE'
        }
      });
      categoryId = newCategory.id;
    }

    const item = await this.prisma.inventoryItem.create({
      data: {
        businessId,
        name: data.name,
        code: data.code,
        barcode: data.barcode,
        inventoryType: data.inventoryType,
        categoryId: categoryId,
        brand: data.brand,
        description: data.description,
        baseUnitId: data.baseUnitId,
        purchaseUnitId: data.purchaseUnitId,
        issueUnitId: data.issueUnitId,
        minimumStockLevel: data.minimumStockLevel,
        reorderLevel: data.reorderLevel,
        maximumStockLevel: data.maximumStockLevel,
        reorderQuantity: data.reorderQuantity,
        allowNegativeStock: data.allowNegativeStock || false,
        trackBatch: data.trackBatch || false,
        trackExpiry: data.trackExpiry || false,
        stockMethod: data.stockMethod || 'FIFO',
        initialUnitCost: data.initialUnitCost,
        standardCost: data.standardCost,
        preferredSupplierId: data.preferredSupplierId,
        status: 'ACTIVE'
      }
    });

    if (data.purchaseUnitId && data.purchaseConversionFactor && data.purchaseUnitId !== data.baseUnitId) {
      await this.prisma.inventoryUnitConversion.create({
        data: {
          inventoryItemId: item.id,
          fromUnitId: data.purchaseUnitId,
          toUnitId: data.baseUnitId,
          conversionFactor: data.purchaseConversionFactor
        }
      });
    }

    return item;
  }

  findAll() {
    return `This action returns all inventory`;
  }

  findOne(id: number) {
    return `This action returns a #${id} inventory`;
  }

  update(id: number, updateInventoryDto: UpdateInventoryDto) {
    return `This action updates a #${id} inventory`;
  }

  remove(id: number) {
    return `This action removes a #${id} inventory`;
  }
}
