"use client";

import { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import Link from 'next/link';
import { Grid3X3, Plus, Search, FileEdit, Trash2, Clock, MapPin, Eye, PlayCircle } from 'lucide-react';

export default function CatalogMenusPage() {
  const [menus, setMenus] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMenus = async () => {
      try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/menus`);
        if (res.ok) {
          setMenus(await res.json());
        }
      } catch (error) {
        console.error('Failed to fetch menus', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMenus();

    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('menu.updated', fetchMenus);

    return () => {
      socket.disconnect();
    };
  }, []);

  if (loading) {
    return <div className="p-8 text-center text-slate-400">Loading menus...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Menus</h2>
          <p className="text-slate-400">Create curated lists of products for specific areas and times.</p>
        </div>
        <Link href="/dashboard/catalog/menus/new" className="inline-flex items-center gap-2 px-4 py-2 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors shadow-sm font-medium">
          <Plus size={16} /> Create Menu
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 bg-slate-950 p-4 rounded-xl shadow-sm border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input 
            type="text" 
            placeholder="Search menus..." 
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary"
          />
        </div>
        <div className="flex gap-2">
          <select className="px-4 py-2 rounded-lg border border-slate-800 bg-slate-950 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary">
            <option value="all">All Departments</option>
            <option value="restaurant">Restaurant</option>
            <option value="room-service">Room Service</option>
            <option value="bar">Bar</option>
            <option value="spa">Spa</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menus.map(menu => (
          <div key={menu.id} className="bg-slate-950 rounded-xl shadow-sm border overflow-hidden flex flex-col group hover:shadow-md transition-shadow">
            <div className="p-5 border-b">
              <div className="flex items-start justify-between mb-2">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Grid3X3 size={20} />
                </div>
                <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400">
                  {menu.status}
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-50 group-hover:text-brand-primary transition-colors">{menu.name}</h3>
              <p className="text-sm text-slate-400 font-mono mt-1">{menu.code}</p>
            </div>
            
            <div className="p-5 flex-1 space-y-3 bg-slate-900/50">
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <MapPin size={16} className="text-gray-400" />
                <span>{menu.department?.name || 'No Department'}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Clock size={16} className="text-gray-400" />
                <span>{(menu.startTime || menu.endTime) ? `${menu.startTime || ''} - ${menu.endTime || ''}` : '24/7'}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Grid3X3 size={16} className="text-gray-400" />
                <span>
                  {menu.items?.length || 0} Items Included
                </span>
              </div>
            </div>

            <div className="p-4 border-t flex items-center justify-between bg-slate-950">
              <div className="flex gap-2">
                <button className="p-2 text-slate-400 hover:text-brand-primary hover:bg-brand-primary/10 rounded-md transition-colors tooltip-trigger" title="Edit Menu Settings">
                  <FileEdit size={18} />
                </button>
                <Link href="/dashboard/catalog/menu-preview" className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors tooltip-trigger" title="Preview Digital Menu">
                  <Eye size={18} />
                </Link>
              </div>
              <button className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 text-slate-300 rounded-md hover:bg-gray-200 transition-colors text-sm font-medium">
                <PlayCircle size={16} /> Menu Builder
              </button>
            </div>
          </div>
        ))}

        {/* Create New Menu Card */}
        <Link href="/dashboard/catalog/menus/new" className="bg-slate-900 border-2 border-dashed border-slate-800 rounded-xl flex flex-col items-center justify-center p-8 hover:bg-slate-800 hover:border-brand-primary/50 transition-colors group min-h-[250px]">
          <div className="w-12 h-12 rounded-full bg-slate-950 shadow-sm flex items-center justify-center text-gray-400 group-hover:text-brand-primary mb-4 transition-colors">
            <Plus size={24} />
          </div>
          <h3 className="text-lg font-bold text-slate-50">Create New Menu</h3>
          <p className="text-sm text-slate-400 text-center mt-2 max-w-[200px]">Design a new menu for a specific service point or event.</p>
        </Link>
      </div>
    </div>
  );
}
