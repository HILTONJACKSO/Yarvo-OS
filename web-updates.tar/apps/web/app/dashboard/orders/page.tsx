'use client';

import { useState, useEffect } from 'react';
import { Plus, Search, Filter, ShoppingBag, Clock, CheckCircle2, XCircle } from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { useRouter } from 'next/navigation';

export default function OrdersDashboardPage() {
  const router = useRouter();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/orders`);
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (error) {
      console.error('Failed to fetch orders:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();

    const { io } = require('socket.io-client');
    const socket = io(process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`);
    socket.on('order.updated', fetchOrders);

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-50">Orders</h1>
          <p className="text-slate-400 mt-1">Manage restaurant, bar, and room-service orders</p>
        </div>
        <Link 
          href="/dashboard/orders/new" 
          className="bg-brand-primary text-white px-4 py-2 rounded-md font-medium flex items-center gap-2 hover:bg-brand-secondary transition"
        >
          <Plus size={18} />
          Start New Order
        </Link>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-500/10 text-blue-600 flex items-center justify-center">
            <ShoppingBag size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-400 font-medium">Active Orders</p>
            <p className="text-2xl font-bold text-slate-50">
              {orders.filter(o => o.status !== 'CANCELLED' && o.status !== 'COMPLETED').length}
            </p>
          </div>
        </div>
        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-400 font-medium">In Preparation</p>
            <p className="text-2xl font-bold text-slate-50">
              {orders.filter(o => o.status === 'IN_PROGRESS').length}
            </p>
          </div>
        </div>
        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-emerald-500/10 text-green-600 flex items-center justify-center">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-400 font-medium">Ready for Delivery</p>
            <p className="text-2xl font-bold text-slate-50">
              {orders.filter(o => o.items?.some((i: any) => i.status === 'READY')).length}
            </p>
          </div>
        </div>
        <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-red-500/10 text-red-600 flex items-center justify-center">
            <XCircle size={24} />
          </div>
          <div>
            <p className="text-sm text-slate-400 font-medium">Cancelled</p>
            <p className="text-2xl font-bold text-slate-50">
              {orders.filter(o => o.status === 'CANCELLED').length}
            </p>
          </div>
        </div>
      </div>

      {/* Orders List Placeholder */}
      <div className="bg-slate-950 rounded-xl border border-slate-800 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center gap-4 bg-slate-900">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by order number, table, or room..." 
              className="w-full pl-10 pr-4 py-2 border border-slate-700 rounded-md focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none"
            />
          </div>
          <button className="px-4 py-2 border border-slate-700 rounded-md flex items-center gap-2 text-slate-300 bg-slate-950 hover:bg-slate-900 transition">
            <Filter size={18} />
            Filter
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-slate-400">Loading orders...</div>
        ) : orders.length === 0 ? (
          <div className="p-16 text-center border-b border-slate-800">
            <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="text-gray-400" size={32} />
            </div>
            <h3 className="text-lg font-medium text-slate-50 mb-1">No Active Orders</h3>
            <p className="text-slate-400 max-w-md mx-auto mb-6">
              There are currently no active orders in the system. Start a new order to begin.
            </p>
            <Link 
              href="/dashboard/orders/new" 
              className="bg-brand-primary text-white px-6 py-2.5 rounded-md font-medium inline-flex items-center gap-2 hover:bg-brand-secondary transition"
            >
              <Plus size={18} />
              Start New Order
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {orders.map(order => (
              <div key={order.id} className="p-4 hover:bg-slate-900 transition flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-slate-50">{order.orderNumber}</span>
                    <span className="px-2 py-0.5 rounded text-xs font-bold bg-slate-800 text-slate-400">
                      {order.orderType}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                      order.status === 'DRAFT' ? 'bg-slate-800 text-slate-400' :
                      order.status === 'IN_PROGRESS' ? 'bg-orange-100 text-orange-600' :
                      order.status === 'READY' ? 'bg-emerald-500/10 text-green-600' :
                      'bg-blue-500/10 text-blue-600'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                  <div className="text-sm text-slate-400">
                    {order.items?.length || 0} items â€¢ ${order.estimatedTotal?.toFixed(2) || '0.00'}
                  </div>
                </div>
                <Link 
                  href={`/dashboard/orders/${order.id}${order.status === 'DRAFT' ? '/edit' : ''}`}
                  className="px-4 py-2 border border-slate-700 rounded-lg text-sm font-medium hover:bg-slate-800 transition text-slate-300"
                >
                  {order.status === 'DRAFT' ? 'Continue Order' : 'View Details'}
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
