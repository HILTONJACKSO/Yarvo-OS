'use client';

import { useState } from 'react';
import { Utensils, GlassWater, BedDouble, Users, MapPin, ArrowRight, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function NewOrderPage() {
  const router = useRouter();
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const orderTypes = [
    {
      id: 'DINE_IN',
      name: 'Restaurant Table',
      description: 'Order for a seated table in the restaurant',
      icon: Utensils,
      color: 'bg-blue-500/10 text-blue-600',
    },
    {
      id: 'BAR',
      name: 'Bar Customer',
      description: 'Order for a customer at the bar',
      icon: GlassWater,
      color: 'bg-purple-100 text-purple-600',
    },
    {
      id: 'ROOM_SERVICE',
      name: 'Room Service',
      description: 'Order delivery to a guest room',
      icon: BedDouble,
      color: 'bg-amber-500/10 text-amber-600',
    },
    {
      id: 'TAKEAWAY',
      name: 'Walk-in / Takeaway',
      description: 'Quick order for walk-in customer',
      icon: Users,
      color: 'bg-emerald-500/10 text-green-600',
    },
    {
      id: 'POOL',
      name: 'Pool / Beach Service',
      description: 'Order delivery to a sunbed or pool cabana',
      icon: MapPin,
      color: 'bg-cyan-100 text-cyan-600',
    }
  ];

  const [loading, setLoading] = useState(false);

  const handleContinue = async () => {
    if (!selectedType) return;
    
    setLoading(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || `${process.env.NEXT_PUBLIC_API_URL}`}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderType: selectedType })
      });
      
      if (res.ok) {
        const order = await res.json();
        router.push(`/dashboard/orders/${order.id}/edit?type=${selectedType}`);
      } else {
        console.error('Failed to create order');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto h-full flex flex-col">
      <Link href="/dashboard/orders" className="text-sm font-medium text-slate-400 hover:text-slate-50 flex items-center gap-1 mb-8">
        <ArrowLeft size={16} />
        Back to Orders
      </Link>

      <div className="bg-slate-950 p-8 rounded-2xl border border-slate-800 shadow-sm flex-1">
        <h1 className="text-2xl font-bold text-slate-50 mb-2">Select Order Destination</h1>
        <p className="text-slate-400 mb-8">Where is this order being served? This determines pricing, taxes, and service charges.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {orderTypes.map((type) => {
            const Icon = type.icon;
            const isSelected = selectedType === type.id;
            return (
              <div 
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`p-6 border-2 rounded-xl cursor-pointer transition flex items-start gap-4 ${
                  isSelected 
                    ? 'border-brand-primary bg-brand-primary/5' 
                    : 'border-slate-800 hover:border-slate-700 bg-slate-950 hover:bg-slate-900'
                }`}
              >
                <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${type.color}`}>
                  <Icon size={24} />
                </div>
                <div>
                  <h3 className={`font-semibold text-lg mb-1 ${isSelected ? 'text-brand-primary' : 'text-slate-50'}`}>
                    {type.name}
                  </h3>
                  <p className="text-sm text-slate-400">{type.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-end pt-6 border-t border-slate-800">
          <button 
            onClick={handleContinue}
            disabled={!selectedType}
            className={`px-8 py-3 rounded-lg font-medium flex items-center gap-2 transition ${
              selectedType 
                ? 'bg-brand-primary text-white hover:bg-brand-secondary' 
                : 'bg-slate-800 text-gray-400 cursor-not-allowed'
            }`}
          >
            Continue to POS
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
